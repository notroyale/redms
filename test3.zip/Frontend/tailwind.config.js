/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode:'class',
  content: [
    "./src/**/*.{html,ts}",
    "./node_modules/tw-elements/dist/js/**/*.js",
    "./node_modules/flowbite/**/*.js"

  ],
  safelist: [
    'bg-blue-600',
    'bg-rose-700',
    'bg-lime-600',
    'bg-yellow-400',
    'bg-neutral-600',
  ],
  theme: {
    extend: {
      colors: {
        'danske-dark-blue': '#003754',
        'danske-mid-blue': '#40687f',
        'danske-deep-blue': '#7f9ba9',
        'danske-light-blue': '#e0eff6',
        'danske-red': '#bf3c3c',
        'danske-bg-dark-color': '#003654'},
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require("tw-elements/dist/plugin.cjs"),
     require('flowbite/plugin')

  ],


}

