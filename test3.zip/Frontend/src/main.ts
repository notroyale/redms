import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { enableProdMode } from '@angular/core';
import { environment } from './environments/environment';
import { AppSettings } from './utils/appsettings.service';
import { APP_CONFIG } from './utils/rams.constants';

fetch('assets/app-config.json').then((response) => {
  return response.json()
}).then((config: AppSettings) => {
  if (environment.production) {
    enableProdMode();
  }
  platformBrowserDynamic([
    { provide: APP_CONFIG, useValue: config }
  ])
    .bootstrapModule(AppModule)
    .catch((err) => console.error(err));
})