import { Inject, Injectable, Injector } from '@angular/core';
import { HttpBackend, HttpClient } from '@angular/common/http';
import { Observable, ReplaySubject, map, of } from 'rxjs';
import { APP_CONFIG } from './rams.constants';
import { AuthWellKnownEndpoints, LogLevel, StsConfigHttpLoader } from 'angular-auth-oidc-client';

export interface AppSettings {
  apibaseUrl: string;
  appversion: string;
  defaultLocale: string;
  issuer: string;
  authorizationEndpoint: string;
  tokenEndpoint: string;
  jwksUri: string;
  userInfoEndpoint: string;
  authority: string;
  redirectUrl: string;
  clientId: string;
  resource: string;
  secureRoutes: string[];
}

export let settings: AppSettings;

export const initializeAppFactory = (
  service: AppSettingsService) => {
    return () => { return service.initSettings(); }
};
export const httpLoaderFactory = (httpClient: HttpClient) => {

  const config$ = httpClient.get<any>(`assets/app-config.json`).pipe(
    map((customConfig: any) => {
      const authWellKnownEndpoints: AuthWellKnownEndpoints = {
        issuer: customConfig.issuer,
        authorizationEndpoint: customConfig.authorizationEndpoint,
        tokenEndpoint: customConfig.tokenEndpoint,
        // jwksUri: "https://art-adfsproxy-syst.danskenet.net/adfs/discovery/keys",
        //jwksUri: "https://localhost:5001/api/openid-keys",local
        jwksUri: customConfig.jwksUri,
        userInfoEndpoint: customConfig.userInfoEndpoint

      };
      return {
          // authority: 'https://art-adfsproxy-syst.danskenet.net/adfs',
          authority: customConfig.authority,
          authWellknownEndpoints: authWellKnownEndpoints,
          redirectUrl: `${window.location.origin}${customConfig.redirectUrl}`,
          postLogoutRedirectUri: window.location.origin,
          clientId: customConfig.clientId,
          scope: 'openid profile',
          responseType: 'id_token token',
          logLevel: LogLevel.None,
          silentRenew: true,
          maxIdTokenIatOffsetAllowedInSeconds: 700,
          useRefreshToken: true,
          renewTimeBeforeTokenExpiresInSeconds: 1000,
          autoUserInfo: false,
          disablePkce: false,
          startCheckSession: true,
          customParamsAuthRequest: {
              resource: customConfig.resource,
          },
          customParamsRefreshTokenRequest: {
            scope: 'openid profile',
          },
          secureRoutes: customConfig.secureRoutes
      };
    })
  );

  return new StsConfigHttpLoader(config$);
};

@Injectable({
  providedIn: 'root'
})
export class AppSettingsService {
  private settings!: AppSettings;
  private subject$: ReplaySubject<AppSettings> = new ReplaySubject();
  public settings$: Observable<AppSettings> = this.subject$.asObservable();
  private withoutInterceptor: HttpClient;

  constructor(private httpBackend: HttpBackend,
    private injector: Injector,
    //private store: Store,
    @Inject(APP_CONFIG) private readonly appConfig: AppSettings,
    ) {

    this.withoutInterceptor = new HttpClient(httpBackend);

    this.initSettings();
  }

  initSettings(): Observable<void>{
    settings = this.appConfig as AppSettings;
    this.settings = this.appConfig as AppSettings;
    this.subject$.next(settings);
    this.subject$.complete();

    return of();
  }
}
