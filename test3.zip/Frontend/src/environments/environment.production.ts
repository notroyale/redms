export const environment = {
  production: false,
  apibaseUrl: 'https://rams-rams-a3rm.apps.az3-osn00.danskenet.net'
};