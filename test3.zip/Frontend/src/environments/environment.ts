export const environment = {
    production: false,
    apibaseUrl: 'https://localhost:5001'
};
