import { Component, Input } from '@angular/core';
import { NewsEntry } from 'src/app/domain/news-entry';

@Component({
  selector: 'app-news-list',
  templateUrl: './news-list.component.html',
  styleUrls: ['./news-list.component.css']
})
export class NewsListComponent {

  @Input() news: NewsEntry[];

}
