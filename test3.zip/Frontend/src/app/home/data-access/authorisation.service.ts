import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthorisationList } from 'src/app/domain/ft-accesses';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class AuthorisationService {
  constructor(private http: HttpClient) { }

  public getAll(): Observable<AuthorisationList> {
    return this.http.get<AuthorisationList>(`${settings.apibaseUrl}/api/Authorisations/allFts`);
  }

}
