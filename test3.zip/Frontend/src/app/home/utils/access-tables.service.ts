import { Injectable } from '@angular/core';
import { SortType } from 'src/app/shared/models/sort-type';
import { AccessTable, Table } from 'src/app/shared/models/table';
import { ColumnStyleType, ColumnType } from 'src/app/shared/models/table/column-type';

export enum AccessTableEnum {
  BUEditLod1 = "editBU1",
  BUViewLod1 = "viewBU1",
  LEEditLod1 = "editLE1",
  LEViewLod1 = "viewLE1",
  GWLod1 = "groupWide1",
  BUEditLod2 = "editBU2",
  BUViewLod2 = "viewBU2",
  LEEditLod2 = "editLE2",
  LEViewLod2 = "viewLE2",
  GWLod2 = "groupWide2",
  GRMLod2 = "gRMAccess",
  GWLod3 = "thirdLoD"
}

@Injectable({
  providedIn: 'root'
})
export class AccessTablesService {
  constructor() { }

  getTableTitle(table: string) {
    switch (table) {
      case AccessTableEnum.BUEditLod1:
        return "Business Units Access Rights with Commenting Functionality (Legal entities excluded)"
      case AccessTableEnum.BUViewLod1:
        return "Business Units Access Rights with View Only Functionality (Legal entities excluded) + Tableau Reporting tool access View"
      case AccessTableEnum.LEEditLod1:
        return "Legal Entities Access Rights with Commenting Functionality (Branches excluded)"
      case AccessTableEnum.LEViewLod1:
        return "Legal Entities Access Rights with View Only Functionality (Branches excluded) and Tableau Reporting access tool"
      case AccessTableEnum.GWLod1:
        return "Group view of all observations access rights"
      case AccessTableEnum.BUEditLod2:
        return "Group Compliance Employees & Business Units Access-rights with Editing functionality (Legal entities excluded)"
      case AccessTableEnum.BUViewLod2:
        return "Group Compliance Employees & Business Units Access-rights with View Only functionality (Legal entities excluded) + Tableau –reporting tool access"
      case AccessTableEnum.LEEditLod2:
        return "Group Compliance Employees & Legal Entities Access Rights with Editing Functionality (Branches excluded)"
      case AccessTableEnum.LEViewLod2:
        return "Group Compliance Employees & Legal Entities Access Rights with View Only Functionality (Branches excluded) + Tableau –reporting tool access"
      case AccessTableEnum.GWLod2:
        return "Group Compliance Employees & Group view of all observations access rights"
      case AccessTableEnum.GRMLod2:
        return "Group Risk Management access rights"
      case AccessTableEnum.GWLod3:
        return "Business Units Access Rights with Commenting Functionality"

      default:
        return "";
    }
  }

  getTablebyEnum(access: string): AccessTable {
    if( access == AccessTableEnum.BUEditLod1 || access == AccessTableEnum.BUViewLod1 || access == AccessTableEnum.BUEditLod2 || access == AccessTableEnum.BUViewLod2
      || access == AccessTableEnum.GRMLod2 || access == AccessTableEnum.GWLod1 || access == AccessTableEnum.GWLod2 || access == AccessTableEnum.GWLod3)
      return this.getTableBU();
    return this.getTableLE();
  }

  getTableBU(): AccessTable {
    return {
      title: "",
      columns: [
        {
          headerStyle: 'common-header', for: 'name', header: 'Authorisation',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None
        },
        {
          headerStyle: 'common-header', for: 'role', header: 'Role',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'bold-column', sorted: SortType.None
        },
        {
          headerStyle: 'common-header', for: 'businessUnits', header: 'Business Unit',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None
        },
        {
          headerStyle: 'common-header', for: 'description', header: 'Description',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None
        },

      ],
      totalCount: 0,
      page: 1,
      rows: 100,//need to fix table to handle new refractor type columns
      first: 1
    };
  }

  getTableLE(): AccessTable {
    return {
      title: "",
      columns: [
        {
          headerStyle: 'common-header', for: 'name', header: 'Authorisation',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None
        },
        {
          headerStyle: 'common-header', for: 'role', header: 'Role',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'bold-column', sorted: SortType.None
        },
        {
          headerStyle: 'common-header', for: 'legalEntities', header: 'Legal Entity',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None
        },
        {
          headerStyle: 'common-header', for: 'description', header: 'Description',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None
        },

      ],
      totalCount: 0,
      page: 1,
      rows: 100,//need to fix table to handle new refractor type columns
      first: 1
    };
  }


}
