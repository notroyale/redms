import { TestBed } from '@angular/core/testing';

import { AccessTablesService } from './access-tables.service';

describe('AccessTablesService', () => {
  let service: AccessTablesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AccessTablesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
