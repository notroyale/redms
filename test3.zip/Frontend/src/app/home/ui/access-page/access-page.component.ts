import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Observable, map } from 'rxjs';
import { NewsEntry } from 'src/app/domain/news-entry';
import { NewsService } from '../../data-access/news.service';
import { AuthorisationService } from '../../data-access/authorisation.service';
import { Authorisation, AuthorisationList, LineOfDefence } from 'src/app/domain/ft-accesses';
import { AccessDataTable, DataTable } from 'src/app/shared/models/data-table';
import { AccessTableEnum, AccessTablesService } from '../../utils/access-tables.service';
import { AccessTable } from 'src/app/shared/models/table';

@Component({
  selector: 'app-access-page',
  templateUrl: './access-page.component.html',
  styleUrls: ['./access-page.component.css']
})
export class AccessPageComponent implements OnInit{

  lod1List$ = new BehaviorSubject<AccessDataTable[] | null>(null);
  lod2List$ = new BehaviorSubject<AccessDataTable[] | null>(null);
  lod3List$ = new BehaviorSubject<AccessDataTable[] | null>(null);

  constructor(private accessService: AuthorisationService, private accessTableService: AccessTablesService){  }

  ngOnInit(): void {
    this.accessService.getAll()
    // .pipe(
    //   map((fts: AuthorisationList)=>{
    //     const dataTable: AccessDataTable = {
    //       data: fts.firstLoD.editBU,
    //       formFilters: {
    //         fields: [],
    //         filters: {},
    //         selectedFilters: {},
    //       },
    //       table: {
    //         title: "Business Units Access Rights with Commenting Functionality (Legal entities excluded)",
    //         columns: this.lod1EditBUTable.columns,
    //         page: this.lod1EditBUTable.page,
    //         first: this.lod1EditBUTable.first,
    //         rows: this.lod1EditBUTable.rows,
    //         totalCount: this.lod1EditBUTable.totalCount
    //       },
    //     };
    //     // this.lod1EditBU$.next(dataTable);

    //   })
    // )
    .subscribe(response=>{
      this.mapAuthListToLods(response);
    }); 
  }
  
  mapAuthListToLods(AuthorisationList: AuthorisationList){
    const lod1=this.ListToLoD(AuthorisationList.firstLoD, 1);
    this.lod1List$.next(lod1);
    
    const lod2 = this.ListToLoD(AuthorisationList.secondLoD, 2);
    let title = this.accessTableService.getTableTitle(AccessTableEnum.GRMLod2);
    let table = this.accessTableService.getTablebyEnum(AccessTableEnum.GRMLod2);
    lod2.push(this.getDataTableFromList(title, AuthorisationList.grmAccess,table));
    this.lod2List$.next(lod2);

    title = this.accessTableService.getTableTitle(AccessTableEnum.GWLod3);
    table = this.accessTableService.getTablebyEnum(AccessTableEnum.GWLod3);
    const lod3 = [this.getDataTableFromList(title, AuthorisationList.thirdLoD,table)];

    this.lod3List$.next(lod3);
  }

  ListToLoD(list: LineOfDefence, lod: number): AccessDataTable[]{
    var datatables = [];
    for(var prop in list){
      const title = this.accessTableService.getTableTitle(prop+lod);
      const authorisations = list[prop as keyof LineOfDefence];
      const table = this.accessTableService.getTablebyEnum(prop+lod);
      datatables.push(this.getDataTableFromList(title, authorisations,table));
    }
    return datatables;
  }

  getDataTableFromList(title:string, list: Authorisation[], table: AccessTable): AccessDataTable{
    return {
      data: list,
      formFilters: {
        fields: [],
        filters: {},
        selectedFilters: {},
      },
      table: {
        title: title,
        columns: table.columns,
        page: table.page,
        first: table.first,
        rows: table.rows,
        totalCount: table.totalCount
      },
    };
  }

}
