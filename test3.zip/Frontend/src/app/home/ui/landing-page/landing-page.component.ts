import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { NewsEntry } from 'src/app/domain/news-entry';
import { NewsService } from '../../data-access/news.service';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css']
})
export class LandingPageComponent implements OnInit{

  news$: Observable<NewsEntry[]>;
  products: string[];

  ngOnInit(): void {
    this.products = ["Get started with RAMS", "How to navigate RAMS", "How to create an observation", "Editing observations", "Audit"];
  }

  constructor(private newsService: NewsService){
    this.news$ = this.newsService.getAll();
  }


}