import { NgModule } from '@angular/core';
import { ExtraOptions, RouterModule, Routes } from '@angular/router';
import { LoginScreenComponent } from './auth/login-screen/login-screen.component';
import { BusinessUnitDashboardComponent } from './admin-pages/business-units/ui/business-unit-dashboard/business-unit-dashboard.component';
import { BusinessAreaDashboardComponent } from './admin-pages/business-areas/ui/business-area-dashboard/business-area-dashboard.component';
import { LegalEntityDashboardComponent } from './admin-pages/legal-entities/ui/legal-entity-dashboard/legal-entity-dashboard.component';
import { TaxonomyDashboardComponent } from './admin-pages/taxonomies/ui/taxonomy-dashboard/taxonomy-dashboard.component';
import { ObservationDashboardComponent } from './observations-home-page/ui/observation-dashboard/observation-dashboard.component';
import { ObservationEditComponent } from './observation-edit-page/ui/observation-edit/observation-edit.component';
import { observationResolver } from './observation-edit-page/resolvers/observation.resolver';
import { StepActionPlanComponent } from './observation-edit-page/feature/step-action-plan/step-action-plan.component';
import { StepAdditionalDetailsComponent } from './observation-edit-page/feature/step-additional-details/step-additional-details.component';
import { LandingPageComponent } from './home/ui/landing-page/landing-page.component';
import { UnauthorizedComponent } from './shared/layouts/unauthorized/unauthorized.component';
import { StepDetailsComponent } from './observation-edit-page/feature/step-details/step-details.component';
import { StepResponsibilityCentreComponent } from './observation-edit-page/feature/step-responsibility-centre/step-responsibility-centre.component';
import { StepRiskCategorizationComponent } from './observation-edit-page/feature/step-risk-categorization/step-risk-categorization.component';
import { StepCollaborationFieldsComponent } from './observation-edit-page/feature/step-collaboration-fields/step-collaboration-fields.component';
import { isAuthenticated } from './auth/adfs/auth-guard.service';
import { AutoLoginPartialRoutesGuard } from 'angular-auth-oidc-client';
import { CallbackComponent } from './auth/adfs/callback/callback.component';
import { StepAdminFieldsComponent } from './observation-edit-page/feature/step-admin-fields/step-admin-fields.component';
import { StepAffectedFieldsComponent } from './observation-edit-page/feature/step-affected-fields/step-affected-fields.component';
import { StepObservationClosureComponent } from './observation-edit-page/feature/observation-closure/step-observation-closure.component';
import { ObservationFormComponent } from './observation-form/observation-form.component';
import { StepSupportingDocumentsComponent } from './observation-edit-page/feature/step-supporting-documents/step-supporting-documents.component';
import { AccessPageComponent } from './home/ui/access-page/access-page.component';
import { ObservationAuditLogComponent } from './observation-audit-log/ui/observation-audit-log/observation-audit-log.component';

const routes: Routes = [
  { path: '', component: LandingPageComponent,
  canActivate: [AutoLoginPartialRoutesGuard]
},
  { path: 'bu-dashboard', component: BusinessUnitDashboardComponent },
  { path: 'ba-dashboard', component: BusinessAreaDashboardComponent },
  { path: 'le-dashboard', component: LegalEntityDashboardComponent },
  { path: 'tax-dashboard', component: TaxonomyDashboardComponent },
  { path: 'login', component: LoginScreenComponent },
  { path: 'callback', component: CallbackComponent },
  { path: 'unauthorized', component: UnauthorizedComponent },
  { path: 'about', component: AccessPageComponent,
   canActivate: [AutoLoginPartialRoutesGuard]},
  { path: 'observation-dashboard', component: ObservationDashboardComponent,
   canActivate: [AutoLoginPartialRoutesGuard]},
  { path: 'observation-audit-log/:id', component: ObservationAuditLogComponent,
   canActivate: [AutoLoginPartialRoutesGuard]},
  {
    path: 'edit-observation/:id', component: ObservationEditComponent,
    canActivate: [AutoLoginPartialRoutesGuard],
    resolve: { observation: observationResolver },
    children: [
      { path: '', component: ObservationFormComponent },
      { path: 'details', component: StepDetailsComponent },
      { path: 'responsibility-centre', component: StepResponsibilityCentreComponent },
      { path: 'risk-categorization', component: StepRiskCategorizationComponent },
      { path: 'action-plan', component: StepActionPlanComponent },
      { path: 'additional-details', component: StepAdditionalDetailsComponent },
      { path: 'closure', component: StepObservationClosureComponent },
      { path: 'admin-fields', component: StepAdminFieldsComponent },
      { path: 'affected-fields', component: StepAffectedFieldsComponent },
      { path: 'collab-fields', component: StepCollaborationFieldsComponent },
      { path: 'supporting-documents', component: StepSupportingDocumentsComponent },

    ]
  }
];

const routerOptions: ExtraOptions = {
  // scrollPositionRestoration: 'enabled',
  anchorScrolling: 'enabled',
  onSameUrlNavigation: 'reload',
  scrollOffset: [0, 50]
};



@NgModule({
  imports: [RouterModule.forRoot(routes,routerOptions)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
