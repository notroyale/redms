import { Component, ElementRef, EventEmitter, HostListener, OnInit, Output, Renderer2, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-observation-form',
  templateUrl: './observation-form.component.html',
  styleUrls: ['./observation-form.component.css']
})
export class ObservationFormComponent implements OnInit {
  ngOnInit(): void {
    document.querySelector('#parentDiv')?.scrollTop;
    this.router.navigate([]);
  }

  @Output() currentSectionName = new EventEmitter<string>();
  currentSection = "";
  constructor(private router: Router) {

  }

  onSectionChange(sectionId: string) {
    this.currentSectionName.emit(sectionId)
    this.currentSection = sectionId;
    this.router.navigate([],{fragment: sectionId});
  }

  scrollTo(section: string) {
    document.querySelector("#"+ section)?.scrollIntoView();
    this.router.navigate([],{fragment: section});
  }

  @HostListener('window:scroll', ['$event'])
  onScroll(event: any) {
}

}
