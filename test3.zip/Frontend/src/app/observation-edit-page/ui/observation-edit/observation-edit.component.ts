import { Component, OnInit } from '@angular/core';
import { ObservationSteps } from '../../utils/observation-steps';
import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { Field } from 'src/app/shared/models/field';
import { DropdownField } from 'src/app/shared/models/dropdown-field';
import { DropdownLevelsField } from 'src/app/shared/models/dropdown-levels-field';
import {
  BehaviorSubject,
  EMPTY,
  Observable,
  combineLatest,
  finalize,
  map,
  mergeMap,
  of,
} from 'rxjs';
import { ObservationAccess, ObservationClosure, ObservationContainer, StatusFieldsStep } from 'src/app/domain/observation';
import { ObservationService } from '../../data-access/observation.service';
import { ValidationService} from '../../utils/observation-validation.service/observation-validation.service';
import { ObservationStatus } from 'src/app/domain/observation-status';
import { InformationModal } from 'src/app/shared/models/information-modal';
import { InformationMessagesService } from '../../utils/information-messages/information-messages.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-observation-edit',
  templateUrl: './observation-edit.component.html',
  animations: [
    trigger('openClose', [
      state(
        'open',
        style({
          height: '*',
          opacity: '1',
        })
      ),
      state(
        'closed',
        style({
          height: '0',
          opacity: '0',
        })
      ),
      transition('open => closed', [animate('0.2s')]),
      transition('closed => open', [animate('0.2s')]),
    ]),
  ],
  styleUrls: ['./observation-edit.component.css'],
})
export class ObservationEditComponent implements OnInit {
  fields: ObservationSteps;
  sectionStatus: boolean = false;
  submitButtonLabel: string = 'Submit';
  infoModalVisibleState = new BehaviorSubject<boolean>(false);
  closureModalVisibleState = new BehaviorSubject<boolean>(false);
  closureJustificationHelpText:string;
  infoModal: InformationModal;
  closureModal: InformationModal;
  closureJustification: string;
  closureDate:number;
  refresh: boolean = true;
  canSubmit: boolean = false;
  canClose: boolean = false;
  public showStatusCard: boolean = false;
  public showStatusSelectionCard: boolean = false;
  public submitted: boolean = false;
  public isLoading: boolean = false;

  canSave$ = combineLatest([
    this.observationSharedService.currentDataAccess$,
    this.observationSharedService.currentDataObsStatus$,
    this.observationSharedService.currentData$
  ])
  .pipe(
    map(([access, status, obs]) =>{
      this.isStatusCardVisible(access, status);
      this.showStatusSelection(access, obs);
      return this.submitAccessCheck(access, status);
    })
  );

  private observationId = this.observationSharedService.routeID;
  loading: boolean = false;

  private readonly params={
    firstLevel:   1,
    secondLevel:  2,
    thirdLevel:   3,
    statusClose:  1,
  }

  toggle() {
    this.infoModalVisibleState.next(!this.infoModalVisibleState.value);
  }

  refreshPage() {
    const url=this.router.url;
    this.router.navigateByUrl('/',{skipLocationChange:true}).then(()=>{
      this.router.navigate([`/${url}`]).then(()=>{
      })
    })
  }

  toggleClosure() {
    this.closureModalVisibleState.next(!this.closureModalVisibleState.value);
  }

  constructor(
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private observationService: ObservationService,
    private validationService: ValidationService,
    private infoMessagesService: InformationMessagesService,
    private router: Router,
  ) {  }

  ngOnInit(): void {
    this.observationSharedService.currentData$.subscribe(resp=>{
      if(!resp)
        return
 
      this.canClose = this.observationSharedService.getObservationStatus() !== ObservationStatus.Closed &&
      resp.observation.actionPlanStep.actionPlans.length > 0 &&
      resp.observation.actionPlanStep.actionPlans.every(x => x.actionStatus == 1);
});
    this.closureModal = this.infoMessagesService.getObservationClosureMessage();
    this.fields = this.observationFieldsService.getObservationSteps();
    this.observationService.getFieldHelpText().subscribe(response=>{
      if(!response)
        return EMPTY;
      this.closureJustificationHelpText = response.find(x=>x.forNames=="closureJustification")?.helpTextValue||'';
      return this.observationSharedService.setHelpTexts(response);
    });
    // this.submit();
  }

  public isStatusCardVisible(access: ObservationAccess | null, status: number | undefined){
    if(status !== ObservationStatus.Open && !access?.adminAccess){
      return this.showStatusCard = true;
    }
    return this.showStatusCard = false;
  }

  public showStatusSelection(access: ObservationAccess | null, obs: ObservationAccess | null){
    this.isSubmitted(obs);
    // checking is observation submitted because on observation creation admin access are set to false
    if(access?.adminAccess || (!access?.adminAccess && !obs?.observation.submitted)){
      return this.showStatusSelectionCard = true;
    }
    return this.showStatusSelectionCard = false;
  }

  public isSubmitted(obs: ObservationAccess | null){
    if(obs?.observation.submitted){
      return this.submitted = true;
    }
    return this.submitted = false;
  }

  asDropdownField = (field: Field) => field as DropdownField;
  asDropdownLevelsField = (field: Field) => field as DropdownLevelsField;

  submit(): void {
    this.observationSharedService.currentData$.subscribe((response) => {
      if (!response) {
        this.canSubmit = false;
        return;
      }

      let data = response;
      // if (data.submitted) {
      //   this.canSubmit = false;
      //   return;
      // }
      this.validationService.validateObservation(data.observation);

    }).unsubscribe();
  }

  toggleSection(): void {
    this.sectionStatus = !this.sectionStatus;
  }

  submitAccessCheck( access: ObservationAccess | null, status: number | undefined): boolean {

    if (!access) {
      return false;
    }
    if (access?.editAccess || access?.adminAccess || access?.commentAccess)
    {
      return true;
    }
    return false;
  }

  performSave(): Observable<any> {

    return combineLatest([
      this.observationSharedService.currentDataStepDetails$,
      this.observationSharedService.currentDataStepRespCenter$,
      this.observationSharedService.currentDataStepRiskCat$,
      this.observationSharedService.currentDataStepAffectedAreas$,
      this.observationSharedService.currentDataStepCollabFields$,
      this.observationSharedService.currentDataStepActionPlan$,
      this.observationSharedService.currentDataStatus$,
    ])
      .pipe(
        map(
          ([
            currentDataStepDetails,
            currentDataStepRespCenter,
            currentDataStepRiskCat,
            currentDataStepAffectedAreas,
            currentDataStepCollabFields,
            currentDataStepActionPlan,
            currentDataStatus,
          ]) => {
            if(!currentDataStepRiskCat || !currentDataStepCollabFields || !currentDataStepAffectedAreas
              || !currentDataStepDetails || !currentDataStepRespCenter || !currentDataStepActionPlan || !currentDataStatus) {
              return undefined;
            }

            const x: ObservationContainer = {
              actionPlanStep: currentDataStepActionPlan,
              detailsStep: currentDataStepDetails,
              responsibleCentreStep: currentDataStepRespCenter,
              riskCategorizationStep: {
                businessLine: currentDataStepRiskCat.businessLine,
                directive: currentDataStepRiskCat.directive,
                taxonomyLevel1: currentDataStepRiskCat.taxonomies[this.params.firstLevel][0],
                taxonomiesLevel2: currentDataStepRiskCat.taxonomies[this.params.secondLevel],
                taxonomiesLevel3: currentDataStepRiskCat.taxonomies[this.params.thirdLevel],
                conductRisk: currentDataStepRiskCat.conductRisk,
                esgRisk: currentDataStepRiskCat.esgRisk,
                conductJustification: currentDataStepRiskCat.conductJustification,
                esgJustification: currentDataStepRiskCat.esgJustification,
                regulations : currentDataStepRiskCat.regulations,
                regCategories: currentDataStepRiskCat.regulatoryCategories,
                regulationComment: currentDataStepRiskCat.regulationComment,
              },
              collabFieldsStep: {
                comment: currentDataStepCollabFields.comment,
                comment1LoD: currentDataStepCollabFields.comment1LoD,
                ragStatusID: currentDataStepCollabFields.ragStatus,
                ragJustification: currentDataStepCollabFields.ragJustification,
                closureSubmitted: currentDataStepCollabFields.closureSubmitted
              },
              affectedFieldsStep: {
                // affectedBusinessAreas: currentDataStepAffectedAreas.businessAreasAF,
                affectedLegalEntities: currentDataStepAffectedAreas.legalEntitiesAF,
                affectedBusinessUnits: currentDataStepAffectedAreas.businessUnitsAF,
                affectedCountries: currentDataStepAffectedAreas.countriesAF,
              },
              statusStep:{
                status:currentDataStatus.status,
                cancellationDate:currentDataStatus.cancellationDate,
                cancellationJustification:currentDataStatus.cancellationJustification,
                closureDate:currentDataStatus.closureDate,
                closureJustification:currentDataStatus.closureJustification,
                deadlineExtensionJustification:currentDataStatus.deadlineExtensionJustification,
                deadlineExtensionRegistrationDate: currentDataStatus.status === 5?currentDataStatus.deadlineExtensionRegistrationDate:null,
                riskAcceptanceDate:currentDataStatus.riskAcceptanceDate,
                riskAcceptanceJustification:currentDataStatus.riskAcceptanceJustification,
              }
            };

            return x;
          }
        ),
        mergeMap((response: ObservationContainer | undefined) => {
          if (!response) {
            return of(undefined);
          }

          this.infoModal=this.infoMessagesService.getObservationSavedMessage(this.observationSharedService.routeID, response.detailsStep?.title);

          return this.observationService.updateObservation(this.observationId, response);
        }),
        finalize(() => {
          this.isLoading = false;
          this.loading = false;
          this.toggle();
        })
      );
}

save(): void {

  this.submit();
  if(!this.validationService.isValid()){
    // this.validationService.toggleWarningMessage();
    return;
  }
  
  this.isLoading = true;

  let a = this.performSave().subscribe((response) => {
      if (!response) {
        this.toggle();
      }
      a.unsubscribe()
    });
}

  onBackToOverview(){
    this.router.navigate(['./observation-dashboard']);
  }

  onCloseClick(){
    this.observationSharedService.currentData$.subscribe((response) => {
      if (!response) {
        this.canSubmit = false;
        return;
      }

      let data = response;

      this.validationService.validateClosure(data.observation);
      
      if (this.validationService.isValid()){
        this.performSave().subscribe(saveResponse => {
            if(saveResponse) {
              this.updateStatusToClosed();
            }
          },
        );
      }
    });
  }

  updateStatusToClosed(): void {
      this.closureDate = Date.now();
      this.toggleClosure();
  }

  onObservationClosure(){
    const req: ObservationClosure = {
      closureJustification: this.closureJustification
    }
    this.infoModal=this.infoMessagesService.getObservationClosureSuccessMessage();
    this.observationService.closeObservation(this.observationId, req).subscribe(res=>{
      this.refresh=true;
      if(!res)
        this.infoModal=this.infoMessagesService.getObservationClosureErrorMessage();
      this.toggle();
    })
  }


}
