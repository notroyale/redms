import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StepAdminFieldsComponent } from './step-admin-fields.component';

describe('StepAdminFieldsComponent', () => {
  let component: StepAdminFieldsComponent;
  let fixture: ComponentFixture<StepAdminFieldsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StepAdminFieldsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StepAdminFieldsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
