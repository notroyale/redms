import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Subject, combineLatest, finalize, map, of, subscribeOn } from 'rxjs';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { GradeService } from 'src/app/admin-pages/grades/data-access/grade.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Form } from 'src/app/shared/models/form';
import { DataForm } from 'src/app/shared/models/data-form';
import {  DetailsStep, UpdateDetailsStepRequest } from 'src/app/domain/observation';
import { CategoryService } from 'src/app/admin-pages/categories/data-access/category.service';
import { ObservationService } from '../../data-access/observation.service';
import { StatusService } from '../../data-access/status.service';

@Component({
  selector: 'app-step-admin-fields',
  templateUrl: './step-admin-fields.component.html',
  styleUrls: ['./step-admin-fields.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StepAdminFieldsComponent implements OnInit {

  // dataForm$ = new Subject<DataForm>();
  // loading: boolean = false;
  // observationID: any;

  // modalHidden: Subject<boolean> = new Subject();

  // constructor(
  //   private observationService: ObservationService,
  //   private observationFieldsService: ObservationFieldsService,
  //   private observationSharedService: ObservationSharedService,
  //   private observationStatusService: StatusService,
  //   private router: Router) { }

  ngOnInit() {

  //   combineLatest([
  //     of(this.observationFieldsService.getObservationSteps().adminFieldStep),
  //     this.observationSharedService.currentData$,
  //     this.observationStatusService.getAll()
  //   ])
  //   .pipe(
  //     finalize(() => {
  //       this.loading = false;
  //     }),
  //     map(([form, formData, allStatus]) =>
  //       this.mapFormData(form, formData.adminFieldSetp, allStatus)
  //     )
  //   )
  //   .subscribe((response) => {

  //     this.dataForm$.next(response);
  //   });
   }

  // mapFormData(form: Form, data: any, allStatus: any[]) : DataForm {
  //   return {
  //     form: form,
  //     data: data,
  //     dropdownsData: {
  //       observationStatus:allStatus,
  //     }
  //   }
  // }

  // onUpdateForm(item: any){

  //   const response: AdminFieldsStep = {
  //     statusID: item.status.id,
  //     cancellationDate: item.cancellationDate,
  //     cancellationJustification : item.cancellationJustification,
  //     deadlineExtentionRegistrationDate : item.deadlineExtentionRegistrationDate,
  //     riskAcceptanceDate : item.riskAcceptanceDate
  //   }
  //   this.observationService.updateAdminFieldStep(this.observationSharedService.routeID,response).pipe(
  //     finalize(() => {
  //       this.loading = false;

  //     }),
  //   ).subscribe((response) => {
  //   });

  //   this.closeObservationModal();
  // }

  // closeObservationModal(){
  //   this.modalHidden.next(false);
  // }

}
