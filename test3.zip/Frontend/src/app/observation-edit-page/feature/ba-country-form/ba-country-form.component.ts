import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { DropdownField } from 'src/app/shared/models/dropdown-field';
import { Field } from 'src/app/shared/models/field';
import { FieldType } from 'src/app/shared/models/field-type';
import { FormField } from 'src/app/shared/models/form-field';

@Component({
  selector: 'app-ba-country-form',
  templateUrl: './ba-country-form.component.html',
  styleUrls: ['./ba-country-form.component.css']
})
export class BaCountryFormComponent implements OnInit {
  @Input() dropdowns: { [key: string] : any[] };
  @Input() formField: FormField;
  isSubmitDisabled: boolean = false;

  @Output() onSave = new EventEmitter<any>();

  labelClass: string = "label-custom";
  fieldType = FieldType;
  data : any = {};

  asDropdownField = (field: Field) => field as DropdownField;

  constructor() {
    // this.canAdd = !this.formField.form.fields[0].isDisabled;
  }
  ngOnInit(): void {
     this.isSubmitDisabled = this.formField.form.fields[0].isDisabled;
  }

  saveForm() {
    this.onSave.emit(this.data);
  }
}
