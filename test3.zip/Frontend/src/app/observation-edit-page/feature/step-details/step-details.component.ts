import { ChangeDetectionStrategy, Component, OnDestroy } from '@angular/core';
import { EMPTY, Subject, combineLatest, finalize, map, mergeMap, of, takeUntil } from 'rxjs';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { GradeService } from 'src/app/admin-pages/grades/data-access/grade.service';
import { Router } from '@angular/router';
import { Form } from 'src/app/shared/models/form';
import { DataForm } from 'src/app/shared/models/data-form';
import { DetailsStep, UpdateDetailsStepRequest } from 'src/app/domain/observation';
import { CategoryService } from 'src/app/admin-pages/categories/data-access/category.service';
import { ObservationService } from '../../data-access/observation.service';
import { ValidationService } from '../../utils/observation-validation.service/observation-validation.service';
import { Access } from 'src/app/shared/models/field';

@Component({
  selector: 'app-step-details',
  templateUrl: './step-details.component.html',
  styleUrls: ['./step-details.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StepDetailsComponent implements OnDestroy {
  loading: boolean = false;
  private ngUnsubscribe : Subject<void> = new Subject<void>();
  private observationId = this.observationSharedService.routeID;

  form$ = of(this.observationFieldsService.getObservationSteps().detailsStep).pipe(map((form)=> this.ValidationService.observationStepForm.value.detailsStep = form));
  grades$ = this.gradeService.getAll();
  categories$ = this.categoryService.getAll();
  dataForm$ = combineLatest([
    this.form$,
    this.observationSharedService.currentDataStepDetails$,
    this.grades$,
    this.categories$,
    this.observationSharedService.currentDataAccess$,
    this.observationSharedService.currentDataObsStatus$,
    this.observationSharedService.currentFieldHelpText$,
    this.observationSharedService.currentDataSubmitted$,
  ])
  .pipe(
    takeUntil(this.ngUnsubscribe),
    finalize(() => {
      this.loading = false;
    }),

    map(([form, data, gradesDropData, categoriesDropData, access, status, helpTexts, submitted]) =>{
      
      if(submitted != undefined)
        this.enableAdminFieldsOnCreate(form, submitted);
      this.observationSharedService.accessCheck(form,access, status);
      if(helpTexts&&form)
        this.observationFieldsService.mapFieldHelpTexts(form,helpTexts);
      return this.mapFormData(form, data, gradesDropData, categoriesDropData,helpTexts)
    })
  );

  constructor(
    private observationService: ObservationService,
    private ValidationService: ValidationService,
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private gradeService: GradeService,
    private categoryService: CategoryService,
    private router: Router) { }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }



  enableAdminFieldsOnCreate(form : Form, submitted: boolean){
    let fields = this.observationFieldsService.getEditableAdminAccessFields();
    return form.fields.map(field => {
      if(fields.some(x=> x==field.for) && !submitted){
        field.access = Access.EditAccess;
      }
    });
  }

  mapFormData(form: Form, data: any, gradesDropData: any[], categoriesDropData: any[], helpTexts: any) : DataForm {
    let dataForm : DataForm = {
      form: form,
      data: data,
      dropdownsData: {
        grades: gradesDropData,
        categoryId: categoriesDropData
      }
    }
    return dataForm;
  }

  onSave(){
    this.observationSharedService.currentDataStepDetails$.pipe(
      mergeMap((response : DetailsStep | undefined) => {
        if(!response){
          return EMPTY;
        }

        const request: UpdateDetailsStepRequest = {
          title: response.title,
          categoryId: response.categoryId,
          dateIdentified: response.dateIdentified,
          deadline: response.deadline,
          revisedDeadline: response.revisedDeadline,
          gradeID: response.gradeID,
          description: response.description,
          selfRaised : response.selfRaised,
          selfRaisedJustification: response.selfRaisedJustification
        }

        //return EMPTY;
        return this.observationService.updateDetailsStep(this.observationId, request);
      }),
      finalize(() => {
        this.loading = false;
        // this.nextPage();
        //-- need to add some notification.
      }),
    )
    .subscribe();
  }

  switchSelfRaisedJustification(form: Form){ //no need for this cocojumbo, use conditional fields
    return form.fields.map(field => {
      if(field.for == "selfRaisedJustification"){
        field.visible = !field.visible;
      }
    });
  }

  onSwitchChange(){
    this.form$.pipe(
      map(form => this.switchSelfRaisedJustification(form))
    )
    .subscribe();
  }

  nextPage() {
    this.router.navigate(['/edit-observation/'+ this.observationId +'/responsibility-centre']);
  }
}
