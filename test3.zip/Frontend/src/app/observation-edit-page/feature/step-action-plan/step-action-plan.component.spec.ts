import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StepActionPlanComponent } from './step-action-plan.component';
import { HttpClientModule } from '@angular/common/http';
import { FormComponent } from 'src/app/shared/components/form/form.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonComponent } from 'src/app/shared/components/button/button.component';
import { DynamicTableComponent } from 'src/app/shared/components/dynamic-table/dynamic-table.component';
import { TableModule } from 'primeng/table';
import { BehaviorSubject } from 'rxjs';
import { DataForm } from 'src/app/shared/models/data-form';

// describe('StepActionPlanComponent', () => {
//   let component: StepActionPlanComponent;
//   let fixture: ComponentFixture<StepActionPlanComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       imports: [HttpClientModule, BrowserAnimationsModule,TableModule],
//       declarations: [ StepActionPlanComponent, FormComponent, ButtonComponent, DynamicTableComponent ]
//     })
//     .compileComponents();

//     fixture = TestBed.createComponent(StepActionPlanComponent);
//     component = fixture.componentInstance;
//     component.dataForm$ = new BehaviorSubject<DataForm>({
//       data: {},
//       dropdownsData: {},
//       form: {
//         title: '',
//         subtitle: '',
//         fields: [],
//         btnLabel: '',
//       },
//     });

//     component.sideDataForm$ = new BehaviorSubject<DataForm>({
//       data: {},
//       dropdownsData: {},
//       form: {
//         title: '',
//         subtitle: '',
//         fields: [],
//         btnLabel: '',
//       },
//     });
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
