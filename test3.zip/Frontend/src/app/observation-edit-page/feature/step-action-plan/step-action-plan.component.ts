import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { BehaviorSubject, EMPTY, Observable, Subject, combineLatest, concatMap, finalize, map, mergeMap, of, take, tap } from 'rxjs';
import { DataForm } from 'src/app/shared/models/data-form';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { ActionPlanService } from '../../data-access/action-plan-service/action-plan.service';
import { ActionPlan, ActionPlanStatus } from 'src/app/domain/action-plan';
import { animate, state, style, transition, trigger} from '@angular/animations';
import { Router } from '@angular/router';
import { BusinessAreaService } from 'src/app/admin-pages/business-areas/data-access/business-area.service';
import { ObservationService } from '../../data-access/observation.service';
import { TaxonomyService } from 'src/app/admin-pages/taxonomies/data-access/taxonomy.service';
import { UpdateActionPlanStepRequest } from 'src/app/domain/requests/update-action-plan-step-request';
import { AddActionPlanRequest } from 'src/app/domain/requests/add-action-plan-request';
import { Taxonomy } from 'src/app/domain/taxonomy';
import { BusinessArea } from 'src/app/domain/business-area';
import { Action } from 'rxjs/internal/scheduler/Action';
import { UpdateActionPlanRequest } from 'src/app/domain/requests/update-action-plan-request';
import { ActionPlanStep, ObservationAccess } from 'src/app/domain/observation';
import { ValidationService } from '../../utils/observation-validation.service/observation-validation.service';
import { InformationMessagesService } from '../../utils/information-messages/information-messages.service';
import { InformationModal } from 'src/app/shared/models/information-modal';
import { DateTimeProvider } from 'angular-oauth2-oidc';

@Component({
  selector: 'app-step-action-plan',
  templateUrl: './step-action-plan.component.html',
  styleUrls: ['./step-action-plan.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('leftRight', [
      state('left', style({})),
      state(
        'right',
        style({
          transform: 'translateX(-100%)',
        })
      ),
      transition('left => right', [animate('0.2s')]),
      transition('right => left', [animate('0.2s')]),
    ]),
  ],
})
export class StepActionPlanComponent implements OnInit, OnDestroy {
  loading: boolean = false;
  private ngUnsubscribe : Subject<void> = new Subject<void>();
  private observationId = this.observationSharedService.routeID;
  form$ = of(this.observationFieldsService.getObservationSteps().actionPlanStep).pipe(map((form)=> this.ValidationService.observationStepForm.value.actionPlanStep = form));
  taxonomiesLevel3$ = this.taxonomyService.getAllByLevel(3);
  businessAreas$ = this.businessAreaService.getAll();
  actionPlan$ = new BehaviorSubject<ActionPlan | undefined>(undefined);
  private actionPlanCopy: ActionPlan;
  newActionPlan$ = new Subject<ActionPlan>;
  add$ = new BehaviorSubject<boolean>(false);
  modalVisibleState = new BehaviorSubject<boolean>(false)
  commentModalVisibleState = new BehaviorSubject<boolean>(false)
  infoModalVisibleState = new BehaviorSubject<boolean>(false)
  allTaxonomiesLevel3: Taxonomy[];
  allBusinessAreas: BusinessArea[];
  taxonomiesLevel3: Taxonomy[];
  businessAreas: BusinessArea[];
  canAdd: boolean;
  informationMessage: InformationModal;
  access: ObservationAccess | null;

  private userBnum =window.sessionStorage.getItem('userBnumber')||"";

  private actionPlanClosureMessage = this.informationMessageService.getActionPlanClosureMessage();
  private actionPlanDeleteMessage = this.informationMessageService.getActionPlanDeleteMessage();

  private firstLevel: number = 1;
  private secondLevel: number = 2;
  private thirdLevel: number = 3;

  private getActionPlanColumn(status: ActionPlanStatus){
    switch (status) {
      case ActionPlanStatus.open:
        return {value: ActionPlanStatus.open ,name:'Open', color:"#FFAA07"};
      case ActionPlanStatus.closed:
        return {value: ActionPlanStatus.closed ,name:'Closed', color:"#00D98B"};
      default:
        return {};
    }
  }

  dataForm$ = combineLatest([
    this.form$,
    this.observationSharedService.currentDataStepActionPlan$,
    this.taxonomiesLevel3$,
    this.businessAreas$,
    this.observationSharedService.currentDataStepRiskCat$,
    this.observationSharedService.currentDataStepRespCenter$,
    this.observationSharedService.currentDataAccess$,
    this.observationSharedService.currentDataObsStatus$,
    this.observationSharedService.currentFieldHelpText$

  ])
  .pipe(
    map(([
      form,
      dataActionPlan,
      taxonomies,
      businessareas,
      riskData,
      respData,
      access,
      status,
      helpTexts
    ]) => {

      this.allTaxonomiesLevel3 = taxonomies;
      this.allBusinessAreas = businessareas;

      if(riskData?.taxonomies[this.thirdLevel])
        this.taxonomiesLevel3 = taxonomies.filter(tax => riskData?.taxonomies[this.thirdLevel].includes(tax.id));
      this.businessAreas = businessareas.filter(ba => respData?.businessAreasCountries.map(x=>x.businessArea).includes(ba.name));

      if(!dataActionPlan){
        return null;
      }
      this.access = access
      this.observationSharedService.accessCheck(form,access, status);
      this.canAdd = this.observationSharedService.buttonAccessCheck(access,status);

      if(dataActionPlan.proposedPlan== null || dataActionPlan.proposedPlan=="")
        form.fields.map(x=>{if(x.for=="proposedPlan")x.visible=false});

      dataActionPlan.actionPlans.map(actionPlan =>{
        actionPlan.actionBusinessArea = this.businessAreas.find(x=>x.id==actionPlan.businessAreaID)?.name;
        actionPlan.taxonomyLevel3 = this.taxonomiesLevel3.find(x=>x.id==actionPlan.taxonomyLevel3ID)?.name;
        actionPlan.actionStatusColumn = this.getActionPlanColumn(actionPlan.actionStatus);
      });

      if(helpTexts&&form)
        this.observationFieldsService.mapFieldHelpTexts(form,helpTexts);

      const dataForm : DataForm = {
        form: form,
        data: dataActionPlan,
        dropdownsData: {
        }
      };
      return dataForm;
    }),
    finalize(() => {
      this.loading = false;
    }),
  );

  actionPlanDataForm$ = combineLatest([
    this.form$,
    this.actionPlan$,
    this.observationSharedService.currentFieldHelpText$,
    this.observationSharedService.currentDataStepRiskCat$,
    this.observationSharedService.currentDataStepRespCenter$
  ])
  .pipe(
    map(([
      form,
      dataActionPlan,
      helpTexts,
      riskData,            //need this for business logic - only observations business area and taxonomylvl3 should be selectble
      respData
    ]) => {
      if(!dataActionPlan){
        return null;
      }

      if(riskData?.taxonomies[this.thirdLevel])
        this.taxonomiesLevel3 = this.allTaxonomiesLevel3.filter(tax => riskData?.taxonomies[this.thirdLevel].includes(tax.id));
      this.businessAreas = this.allBusinessAreas.filter(ba => respData?.businessAreasCountries.map(x=>x.businessArea).includes(ba.name));

      if(helpTexts&&form)
        this.observationFieldsService.mapFieldHelpTexts(form,helpTexts);

      const dataForm : DataForm = {
        form: {
          btnLabel: form.btnLabel,
          title: form.sideFormTitle,
          subtitle: form.subtitle,
          fields: form.formFields
        },
        data: dataActionPlan,
        dropdownsData: {
          actionBusinessAreas: this.businessAreas,
          taxonomiesLevel3: this.taxonomiesLevel3,
        }
      };
      return dataForm;
    }),
    finalize(() => {
      this.loading = false;
    }),
  );

  isOpen: boolean = false;
  overlayPanelVisible: boolean = true;

  constructor(
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private ValidationService: ValidationService,
    private actionPlanService: ActionPlanService,
    private taxonomyService : TaxonomyService,
    private businessAreaService : BusinessAreaService,
    private informationMessageService: InformationMessagesService,
    private router: Router
  ) {

  }

  ngOnInit() {

    this.actionPlan$.subscribe(actionPlandata=>{
      if(!actionPlandata)
        return;
      this.actionPlanCopy = Object.assign({}, actionPlandata);
    })
    // combineLatest([                                                                          //neužima loading time ir viskas greičiau kraunas, bet nespėja pasikraut iki lentelės

    //   this.observationSharedService.currentDataStepRiskCat$,
    //   this.observationSharedService.currentDataStepRespCenter$,
    //   this.taxonomyService.getAllByLevel(3),
    //   this.businessAreaService.getAll(),
    // ]).subscribe(([riskData, respData, taxonomies, businessAreas])=>{
    //   this.taxonomiesLevel3 = taxonomies.filter(tax => riskData?.taxonomies[3].includes(tax.id));
    //   this.businessAreas = businessAreas.filter(ba => respData?.businessAreasCountries.map(x=>x.businessArea).includes(ba.name));
    // });
  }


  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }


  onSave() : void{
    //(removed)this is not necessary, as it subscribes to observable multiple times. Which triggers every time you add or edit something
    if(this.add$.getValue()){
      this.onAddSave();
      return;
    }
    this.onUpdateSave();
  }

  onCloseClicked(actionPlan: ActionPlan){
    this.informationMessage= this.actionPlanClosureMessage;
    this.infoModalVisibleState.next(true);
    this.actionPlan$.next(actionPlan);
  }

  onCloseAction(){
    this.informationMessage= this.actionPlanClosureMessage;
    this.infoModalVisibleState.next(true);
    if(!this.actionPlan$.value)
      return
    var closedaction = this.actionPlan$.value;
    closedaction.actionStatus=ActionPlanStatus.closed;
    this.actionPlan$.next(closedaction);
    this.closeActionplan();
  }

  onOkButton(){
    if(this.informationMessage == this.actionPlanClosureMessage)
     return this.onCloseAction();
    return this.onDeleteAction();

  }
  onDeleteAction(){
    if(!this.actionPlan$.value)
      return;
    var actionId= this.actionPlan$.value.id;
    this.actionPlanService.delete(actionId).pipe(
      concatMap(response =>
        this.observationSharedService.currentData$
        .pipe(
          take(1),
          map(currentData => {
            if(!response)
              return null;
            if(!currentData){
              return null;
            }

            currentData.observation.actionPlanStep.actionPlans = currentData.observation.actionPlanStep.actionPlans.filter(x=>x.id!=actionId);

            return currentData;
          }),
          tap(updatedData => {
            if(!updatedData){
              return;
            }

            this.observationSharedService.changeData(updatedData)
          })
        )),
    ).subscribe();
  }

  onDeleteClicked(actionPlan: ActionPlan){
    this.informationMessage= this.actionPlanDeleteMessage;
    this.infoModalVisibleState.next(true);
    this.actionPlan$.next(actionPlan);
  }

  onCancle() : void{
    this.actionPlan$.subscribe(actionPlan=>{
      if(actionPlan)
        Object.assign(actionPlan, this.actionPlanCopy);
    }).unsubscribe()
    this.toggleModal();
  }

  onAdd(): void {
    const activictyOwner = this.observationSharedService.getResponsibilityCentreStepData()?.activityOwner;
    const deadline = this.observationSharedService.getObservationDeadline();
    const actionPlan : ActionPlan = {
      id: 0,
      actionTitle: undefined,
      actionSummary: undefined,
      businessAreaID: undefined,
      assignee: undefined,
      actionDeadline: deadline,
      actionStatus: ActionPlanStatus.open,
      actionStatusColumn: 0,
      actionClosureDate: undefined,
      actionClosureUser: undefined,
      taxonomyLevel3ID: undefined,
      actionActivityOwner: activictyOwner,
      actionComment1LoD: undefined,
      actionBusinessArea:undefined,
      taxonomyLevel3:undefined,
    }
    
    this.add$.next(true);
    this.actionPlan$.next(actionPlan);
    this.toggleModal();
  }

  onEdit(actionPlan: ActionPlan): void {
    this.add$.next(false);
    this.actionPlan$.next(actionPlan);
    this.toggleModal();
  }

  private onAddSave(): void {
    const response = this.actionPlan$.getValue();
    if(!response){
      return;
    }

    if(!this.ValidationService.validateActionPlan(response))
      return;

    const request : AddActionPlanRequest = {
      actionTitle: response.actionTitle,
      actionSummary: response.actionSummary,
      businessAreaID: response.businessAreaID,
      assignee: response.assignee,
      taxonomyLevel3ID: response.taxonomyLevel3ID,
      activityOwner: response.actionActivityOwner,
      deadline: response.actionDeadline,
      observationID: this.observationId,
    };


    this.actionPlanService.add(request).pipe(
      concatMap(addedActionPlan =>
        this.observationSharedService.currentData$
        .pipe(
          take(1),
          map(currentData => {
            if(!currentData){
              return null;
            }
            currentData.observation.actionPlanStep.actionPlans =
                  [...currentData.observation.actionPlanStep.actionPlans, addedActionPlan];
            return currentData;
          }),
          tap(updatedData => {
            if(!updatedData){
              return;
            }

            this.observationSharedService.changeData(updatedData)
          })
        )),
        finalize(()=>{
          this.toggleModal();
        })
    ).subscribe();


    return;
  }

  private closeActionplan(): void{
    const response = this.actionPlan$.getValue();
    if(!response){
      return;
    }

    if(!this.ValidationService.validateActionPlan(response))
    return;

    this.actionPlanService.close(response.id).pipe(
      concatMap(() =>
      this.observationSharedService.currentData$
      .pipe(
        take(1),
        map(currentData => {
          if(!currentData){
            return null;
          }
          let actionPlan = currentData.observation.actionPlanStep.actionPlans.find(x=>x.id==response.id);
          if(!actionPlan)
            return
          actionPlan.actionStatus=ActionPlanStatus.closed;
          actionPlan.actionClosureUser = this.userBnum;
          actionPlan.actionClosureDate = new Date(Date.now());
          return currentData;
        }),
        tap(updatedData => {
          if(!updatedData){
            return;
          }

          this.observationSharedService.changeData(updatedData)
        })
      ))).subscribe()
  }

  private onUpdateSave(): void {
    const response = this.actionPlan$.getValue();
    if(!response){
      return;
    }


    if(!this.ValidationService.validateActionPlan(response))
      return;

    const request : UpdateActionPlanRequest = {
      id: response.id,
      actionTitle: response.actionTitle,
      actionSummary: response.actionSummary,
      businessAreaID: response.businessAreaID,
      assignee: response.assignee,
      taxonomyLevel3ID: response.taxonomyLevel3ID,
      activityOwner: response.actionActivityOwner,
      deadline: response.actionDeadline,
      actionComment: response.actionComment1LoD,
    };


    this.actionPlanService.update(request).pipe(
      concatMap((addedActionPlan: UpdateActionPlanRequest) =>
        this.observationSharedService.currentData$
        .pipe(
          take(1),
          map(currentData => {
            if(!currentData){
              return null;
            }
            return currentData;
          }),
          tap(updatedData => {
            if(!updatedData){
              return;
            }

            this.observationSharedService.changeData(updatedData)
          })
        )),
        finalize(()=>{
          this.toggleModal();
        })
    ).subscribe()

  }

  toggle() {
    this.isOpen = !this.isOpen;
    this.overlayPanelVisible = false;
  }

  toggleModal(){
    this.modalVisibleState.next(!this.modalVisibleState.value);
  }

  nextPage() {
    this.router.navigate(['/edit-observation/'+ this.observationId +'/closure']);
  }
}
