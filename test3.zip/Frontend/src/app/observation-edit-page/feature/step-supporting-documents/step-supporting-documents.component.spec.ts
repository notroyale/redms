import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StepSupportingDocumentsComponent } from './step-supporting-documents.component';

describe('StepSupportingDocumentsComponent', () => {
  let component: StepSupportingDocumentsComponent;
  let fixture: ComponentFixture<StepSupportingDocumentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StepSupportingDocumentsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StepSupportingDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
