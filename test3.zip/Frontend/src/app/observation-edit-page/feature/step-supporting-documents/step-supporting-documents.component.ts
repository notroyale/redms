import { Component } from '@angular/core';
import { BehaviorSubject, Subject, combineLatest, concatMap, finalize, map, mergeMap, of, switchMap, take, takeUntil, tap } from 'rxjs';
import { DropdownField } from 'src/app/shared/models/dropdown-field';
import { ObservationService } from '../../data-access/observation.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { Router } from '@angular/router';
import { DataForm } from 'src/app/shared/models/data-form';
import { Form } from 'src/app/shared/models/form';
import { ObservationAttachmentReq } from 'src/app/domain/requests/observation-attachment-req';
import { FileMetadata } from 'src/app/shared/models/file-metadata';
import { Attachment } from 'src/app/domain/attachment';

@Component({
  selector: 'app-step-supporting-documents',
  templateUrl: './step-supporting-documents.component.html',
  styleUrls: ['./step-supporting-documents.component.css']
})
export class StepSupportingDocumentsComponent {

  loading: boolean = false;
  private ngUnsubscribe : Subject<void> = new Subject<void>();
  files: any[] = [];
  form$ = of(this.observationFieldsService.getObservationSteps().supportingDocumentsStep);
  data$ = this.observationSharedService.currentDataStepSupportingDocuments$
  attachments$ = this.data$.pipe(map(x => x?.attachments));
  private observationId = this.observationSharedService.routeID;

  constructor(
    private observationService: ObservationService,
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private router: Router) { }

  dataForm$ = combineLatest([
    this.form$,
    this.data$,
    this.observationSharedService.currentDataAccess$,
    this.observationSharedService.currentDataObsStatus$,
    this.observationSharedService.currentFieldHelpText$

  ])
  .pipe(
    takeUntil(this.ngUnsubscribe),
    finalize(() => {
      this.loading = false;
    }),
    map(([form, data, access,status,helpTexts]) =>{
      this.observationSharedService.accessCheck(form,access,status);

      if(helpTexts&&form)
        this.observationFieldsService.mapFieldHelpTexts(form,helpTexts);

      return this.mapFormData(form, data)
    })
  );

  mapFormData(form: Form, data: any) : DataForm {
    let dataForm : DataForm = {
      form: form,
      data: data,
      dropdownsData: {}
    }

    return dataForm;
  }


  onDownload(request: Attachment) : void {
    this.observationService.downloadAttachment(request.id)
    .subscribe((response: any ) => {
      const blobUrl = URL.createObjectURL(response);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = request.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    });
  }

  onSave(event: ObservationAttachmentReq) : void {

    let metadata: FileMetadata = {
      id: this.observationId,
      uploaderRole: '1LOD'
    }

    this.observationService.uploadAttachments(metadata,event)
    .pipe(
      concatMap(addedAttachments =>
        this.observationSharedService.currentData$
        .pipe(
          take(1),
          map(currentData => {
            if(!currentData){
              return null;
            }

            currentData.observation.supportingDocumentsStep.attachments =
              [...currentData.observation.supportingDocumentsStep.attachments, ...addedAttachments];

            return currentData;
          }),
          tap(updatedData => {
            if(!updatedData){
              return;
            }

            this.observationSharedService.changeData(updatedData)
          })
        ))
      )
    .subscribe();

  }

  // onFileDelete($event: Event) {

    onFileDelete(request: any) {
      this.observationService.removeFile(request.id)
      .subscribe((response: any ) => {
      });
     // update table
     this.observationSharedService.currentData$
              .pipe(
                take(1),
                map(currentData => {
                  if (!currentData) {
                    return null;
                  }

                  currentData.observation.supportingDocumentsStep.attachments = currentData.observation.supportingDocumentsStep.attachments.filter(x=>x.id != request.id);

                  return currentData;
                })).subscribe();
    }
}



