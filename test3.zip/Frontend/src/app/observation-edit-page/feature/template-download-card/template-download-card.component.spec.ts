import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateDownloadCardComponent } from './template-download-card.component';

describe('TemplateDownloadCardComponent', () => {
  let component: TemplateDownloadCardComponent;
  let fixture: ComponentFixture<TemplateDownloadCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TemplateDownloadCardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TemplateDownloadCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
