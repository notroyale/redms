import { Component, Input } from '@angular/core';
import { ObservationService } from '../../data-access/observation.service';

@Component({
  selector: 'app-template-download-card',
  templateUrl: './template-download-card.component.html',
  styleUrls: ['./template-download-card.component.css'],
})
export class TemplateDownloadCardComponent {
  @Input() id: number;
  @Input() title: string;
  @Input() description: string;

  constructor(private observationService: ObservationService){}

  public downloadTemplate(): void {
    this.observationService.downloadAttachment(this.id).subscribe((res) =>{
      const blobUrl = URL.createObjectURL(res);
      const a = document.createElement('a');
      a.href = blobUrl;
      switch (this.id){
        case 6434: 
          a.download = 'Risk_Acceptance_Form_Template.docx';
          break;
        case 6431: 
          a.download = 'Cancellation_Form_Template.docx';
          break;
        case 6432: 
          a.download = 'Methodology_ClosureForm_Template.docx';
          break;
        case 6433: 
          a.download = 'Methodology_Template_Request_Deadline_Extension_Form.docx';
          break;
      }
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    })
  }
}
