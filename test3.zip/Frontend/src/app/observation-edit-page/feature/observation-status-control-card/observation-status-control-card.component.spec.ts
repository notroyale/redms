import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObservationStatusControlCardComponent } from './observation-status-control-card.component';

describe('ObservationStatusControlCardComponent', () => {
  let component: ObservationStatusControlCardComponent;
  let fixture: ComponentFixture<ObservationStatusControlCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ObservationStatusControlCardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ObservationStatusControlCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
