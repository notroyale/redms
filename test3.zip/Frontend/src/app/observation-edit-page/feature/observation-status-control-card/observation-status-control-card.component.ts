import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component } from '@angular/core';

@Component({
  selector: 'app-observation-status-control-card',
  animations: [
    trigger('openClose', [
      state('open', style({
        height: '*',
        opacity: '1'
      })),
      state('closed', style({
        height: '0',
        opacity: '0'
      })),
      transition('open => closed', [
        animate('0.2s')
      ]),
      transition('closed => open', [
        animate('0.2s')
      ]),
    ]),
  ],
  templateUrl: './observation-status-control-card.component.html',
  styleUrls: ['./observation-status-control-card.component.css']
})
export class ObservationStatusControlCardComponent {
  isOpen: boolean = false;



  toggle(){
    this.isOpen = !this.isOpen;
  }
}
