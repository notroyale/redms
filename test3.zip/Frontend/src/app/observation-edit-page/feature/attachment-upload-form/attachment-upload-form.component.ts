import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ObservationAttachmentReq } from 'src/app/domain/requests/observation-attachment-req';
import { BinaryDropdownField } from 'src/app/shared/models/binary-dropdown-options';
import { Field } from 'src/app/shared/models/field';
import { FieldType } from 'src/app/shared/models/field-type';
import { FileUploadFormField } from 'src/app/shared/models/file-upload-form';
import { ValidationService } from '../../utils/observation-validation.service/observation-validation.service';
import { InvalidType } from 'src/app/domain/validation';

@Component({
  selector: 'app-attachment-upload-form',
  templateUrl: './attachment-upload-form.component.html',
  styleUrls: ['./attachment-upload-form.component.css']
})
export class AttachmentUploadFormComponent {
  @Input() dropdowns: { [key: string]: any[] };
  @Input() field: FileUploadFormField;
  uploadedFiles: Array<any> = [];

  @Output() onSave = new EventEmitter<any>();

  labelClass: string = "label-custom";
  fieldType = FieldType;

  private gdprOption: boolean;

  data: ObservationAttachmentReq = {
    files: this.uploadedFiles,
    gdpr: false
  };

  asBinaryDropdownField = (field: Field) => field as BinaryDropdownField;

  constructor(private validationService: ValidationService) { }

  saveForm() {
    if (this.data.files.length == 0) {
      this.validationService.displayCustomValidationError({
        isValid: false,
        invalidField: [],
        invalidType: InvalidType.custom,
        invalidMessage: "Please add at least one attachment"
      });
      return console.log('No files uploaded');
    }
    if (this.gdprOption === undefined) {
      this.validationService.displayCustomValidationError({
        isValid: false,
        invalidField: [],
        invalidType: InvalidType.custom,
        invalidMessage: "Please select an option in contains GDPR data"
      });
      return console.log('GDPR option not selected');
    }
    this.data.files = this.data.files.filter(file => file.size !== 0);
    this.data.gdpr = this.gdprOption;
    this.onSave.emit(this.data);
    this.data.files = [];

  }

  onSelectGdpr(value: boolean) {
    this.gdprOption = value;
  }

  onFileUploaded(event: any) {
    this.data.files = event;
  }
}
