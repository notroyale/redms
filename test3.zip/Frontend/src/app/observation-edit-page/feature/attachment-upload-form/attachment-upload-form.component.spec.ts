import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttachmentUploadFormComponent } from './attachment-upload-form.component';

describe('AttachmentUploadFormComponent', () => {
  let component: AttachmentUploadFormComponent;
  let fixture: ComponentFixture<AttachmentUploadFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AttachmentUploadFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AttachmentUploadFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
