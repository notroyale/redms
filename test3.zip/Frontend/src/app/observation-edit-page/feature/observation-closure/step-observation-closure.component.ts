import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { BehaviorSubject , EMPTY, Subject, combineLatest, finalize, map, mergeMap, of, switchMap, take, takeUntil } from 'rxjs';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { Router } from '@angular/router';
import { DataForm } from 'src/app/shared/models/data-form';
import { StatusFieldsStep } from 'src/app/domain/observation';
import { ObservationService } from '../../data-access/observation.service';
import { StatusService } from '../../data-access/status.service';
import { StatusOptions } from 'src/app/domain/status';
import { Field } from 'src/app/shared/models/field';
import { UpdateObservationStatusRequest } from 'src/app/domain/requests/update-observation-status-request';
import { ValidationService } from '../../utils/observation-validation.service/observation-validation.service';

@Component({
  selector: 'app-observation-closure',
  templateUrl: './step-observation-closure.component.html',
  styleUrls: ['./step-observation-closure.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StepObservationClosureComponent implements OnInit, OnDestroy {
  loading: boolean = false;
  private ngUnsubscribe : Subject<void> = new Subject<void>();
  private observationId = this.observationSharedService.routeID;
  form$ = of(this.observationFieldsService.getObservationSteps().statusStep).pipe(map((form)=> this.ValidationService.observationStepForm.value.statusStep = form));
  status$ = this.observationStatusService.getAll();

  dataForm$ = combineLatest([
    this.form$,
    this.observationSharedService.currentDataStatus$,
    this.status$,
    this.observationSharedService.currentFieldHelpText$
  ])
  .pipe(
    map(([
      form, 
      dataClosure, 
      status,
      helpTexts
    ]) => {
      if(!dataClosure){
        return null;
      }

      if(helpTexts&&form)
        this.observationFieldsService.mapFieldHelpTexts(form,helpTexts);
      
      const dataForm : DataForm = {
        form: form,
        data: dataClosure,
        dropdownsData: {
          status: status,
        }
      };
      return dataForm;
    }),
    finalize(() => {
      this.loading = false;
    }),
    takeUntil(this.ngUnsubscribe)
  );

  constructor(
    private observationService: ObservationService,
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private ValidationService: ValidationService,
    private observationStatusService: StatusService,
    private router: Router) { }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  ngOnInit() {
  }
  
  onSave() : void {
    this.observationSharedService.currentDataStatus$.pipe(
      take(1),
      switchMap((response : StatusFieldsStep | undefined) => {
        if(!response){
          return EMPTY;
        }

        const cancellationDate = response.cancellationDate = "" || undefined || null ? null : response.cancellationDate;
        const deadlineExtensionRegistrationDate = response.deadlineExtensionRegistrationDate = "" || undefined || null ? null : response.deadlineExtensionRegistrationDate;
        const riskAcceptanceDate = response.riskAcceptanceDate = "" || undefined || null ?  null : response.riskAcceptanceDate;
        const closureDate = response.closureDate = "" || undefined || null ? null: response.closureDate;
        
        const request: UpdateObservationStatusRequest = {
          status: response.status,
          cancellationDate: cancellationDate,
          cancellationJustification: response.cancellationJustification,
          deadlineExtensionRegistrationDate: deadlineExtensionRegistrationDate,
          deadlineExtensionJustification: response.deadlineExtensionJustification,
          closureDate: closureDate,
          closureJustification: response.closureJustification,
          riskAcceptanceDate: riskAcceptanceDate,
          riskAcceptanceJustification: response.riskAcceptanceJustification
        }

        return this.observationService.updateStatusFieldStep(this.observationId, request);
        // return EMPTY;
      }),
      finalize(() => {
        this.loading = false;
        // this.nextPage();
        //-- need to add some notification.
      }),
      takeUntil(this.ngUnsubscribe),
    )
    .subscribe();
  }
}