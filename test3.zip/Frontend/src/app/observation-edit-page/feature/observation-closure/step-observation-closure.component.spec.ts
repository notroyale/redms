import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StepObservationClosureComponent } from './step-observation-closure.component';

describe('ObservationClosureComponent', () => {
  let component: StepObservationClosureComponent;
  let fixture: ComponentFixture<StepObservationClosureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StepObservationClosureComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StepObservationClosureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
