import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-ba-removal-button',
  templateUrl: './ba-removal-button.component.html',
  styleUrls: ['./ba-removal-button.component.css']
})
export class BaRemovalButtonComponent {

 @Output() onBaDeleteActionEvent = new EventEmitter();

  delete() {
     this.onBaDeleteActionEvent.emit();
  }
}
