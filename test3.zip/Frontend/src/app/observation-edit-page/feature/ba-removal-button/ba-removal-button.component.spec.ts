import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BaRemovalButtonComponent } from './ba-removal-button.component';

describe('BaRemovalButtonComponent', () => {
  let component: BaRemovalButtonComponent;
  let fixture: ComponentFixture<BaRemovalButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BaRemovalButtonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BaRemovalButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
