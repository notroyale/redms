import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { BehaviorSubject, EMPTY, Subject, combineLatest, finalize, forkJoin, map, mergeMap, of, switchMap, takeUntil, tap } from 'rxjs';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { Router } from '@angular/router';
import { DataForm } from 'src/app/shared/models/data-form';
import { AffectedFieldsStep } from 'src/app/domain/observation';
import { ObservationService } from '../../data-access/observation.service';
import { LegalEntityService } from 'src/app/admin-pages/legal-entities/data-access/legal-entity.service';
import { BusinessUnitService } from 'src/app/admin-pages/business-units/data-access/business-unit.service';
import { BusinessAreaService } from 'src/app/admin-pages/business-areas/data-access/business-area.service';
import { CountriesService } from '../../data-access/countries.service';
import { BusinessArea } from 'src/app/domain/business-area';
import { LegalEntity } from 'src/app/domain/legal-entity';
import { UpdateAffectedAreasStepRequest } from 'src/app/domain/requests/update-affected-areas-step-request';
import { ValidationService } from '../../utils/observation-validation.service/observation-validation.service';

@Component({
  selector: 'app-step-affected-fields',
  templateUrl: './step-affected-fields.component.html',
  styleUrls: ['./step-affected-fields.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StepAffectedFieldsComponent implements OnInit, OnDestroy {
  loading: boolean = false;
  private ngUnsubscribe : Subject<void> = new Subject<void>();
  private observationId = this.observationSharedService.routeID;
  form$ = of(this.observationFieldsService.getObservationSteps().affectedFieldsStep).pipe(map((form)=> this.ValidationService.observationStepForm.value.affectedFieldsStep = form));
  businessUnits$ = this.businessUnitService.getAll();
  countries$ = this.countriesService.getAll();

  businessAreas$ = new BehaviorSubject<BusinessArea[]>([]);
  legalEntities$ = new BehaviorSubject<LegalEntity[]>([]);

  dataForm$ = combineLatest([
    this.form$,
    this.observationSharedService.currentDataStepAffectedAreas$,
    this.businessUnits$,
    this.countries$,
    this.businessAreas$,
    this.legalEntities$,
    this.observationSharedService.currentDataAccess$,
    this.observationSharedService.currentDataObsStatus$,
    this.observationSharedService.currentFieldHelpText$
  ])
  .pipe(
    map(([
      form,
      dataAffectedAreas,
      businessUnits,
      countries,
      businessAreas,
      legalEntities,
      access,
      status,
      helpTexts
    ]) => {
      if(!dataAffectedAreas){
        return null;
      }
      this.observationSharedService.accessCheck(form,access,status);

      if(helpTexts&&form)
        this.observationFieldsService.mapFieldHelpTexts(form,helpTexts);
      
      const dataForm : DataForm = {
        form: form,
        data: dataAffectedAreas,
        dropdownsData: {
          businessUnitsAF: businessUnits,
          countriesAF: countries,
          // businessAreasAF: businessAreas,
          legalEntitiesAF: legalEntities
        }
      };
      return dataForm;
    }),
    finalize(() => {
      this.loading = false;
    }),
  );

  constructor(
    private observationService: ObservationService,
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private ValidationService: ValidationService,
    private legalEntityService : LegalEntityService,
    private businessUnitService : BusinessUnitService,
    private businessAreaService : BusinessAreaService,
    private countriesService : CountriesService,
    private router: Router) { }

  ngOnInit(): void {
    this.onBusinessUnitChange();
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  onDropdownChange() : void {
    this.onBusinessUnitChange();
  }

  private onBusinessUnitChange() : void{
    this.observationSharedService.currentDataStepAffectedAreas$
    .pipe(
      switchMap((currentData) => {
        if(!currentData){
          return EMPTY;
        }
        const ids : number[] = currentData.businessUnitsAF;
        if(ids.length == 0){
          currentData.businessAreasAF = [];
          currentData.legalEntitiesAF = [];
          this.businessAreas$.next([]);
          this.legalEntities$.next([]);
          return EMPTY;
        }

        return forkJoin([
          this.businessAreaService.getBusinessAreasByBusinessUnitsIds(ids),
          this.legalEntityService.getLegalEntitiesByBusinessUnitsIds(ids)
        ]);
      }),
      tap(([businessAreas, legalEntities]) => {
        this.businessAreas$.next(businessAreas);
        this.legalEntities$.next(legalEntities);
      }),
      takeUntil(this.ngUnsubscribe)
    )
    .subscribe();
  }

  onSave() : void {
    this.observationSharedService.currentDataStepAffectedAreas$.pipe(
      mergeMap((response : AffectedFieldsStep | undefined) => {
        if(!response){
          return EMPTY;
        }

        const request : UpdateAffectedAreasStepRequest = {
          // affectedBusinessAreas: response.businessAreasAF,
          affectedLegalEntities: response.legalEntitiesAF,
          affectedBusinessUnits: response.businessUnitsAF,
          affectedCountries: response.countriesAF,
        };

        return this.observationService.updateAffectedFieldStep(this.observationId, request);
      }),
      finalize(() => {
        this.loading = false;
        // this.nextPage();
        //-- need to add some notification.
      }),
    )
    .subscribe();
  }

  nextPage() {
    this.router.navigate(['/edit-observation/'+ this.observationId +'/collab-fields']);
  }
}
