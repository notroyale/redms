import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { Component, LOCALE_ID, Inject, OnInit, OnDestroy } from '@angular/core';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { StatusFieldsStep } from 'src/app/domain/observation';
import { Subscription } from 'rxjs';
import { ObservationStatus } from 'src/app/domain/observation-status';

@Component({
  selector: 'app-observation-status-card',
  animations: [
    trigger('openClose', [
      state(
        'open',
        style({
          height: '*',
          opacity: '1',
        })
      ),
      state(
        'closed',
        style({
          height: '0',
          opacity: '0',
        })
      ),
      transition('open => closed', [animate('0.2s')]),
      transition('closed => open', [animate('0.2s')]),
    ]),
  ],
  templateUrl: './observation-status-card.component.html',
  styleUrls: ['./observation-status-card.component.css'],
})
export class ObservationStatusCardComponent implements OnInit, OnDestroy {
  isOpen: boolean = true;
  public statusData: StatusFieldsStep | undefined;
  public closed: number = ObservationStatus.Closed;
  public cancelled: number = ObservationStatus.Cancelled;
  public riskAccepted: number = ObservationStatus.RiskAccepted;
  public deadlineExtendded: number = ObservationStatus.DeadlineExtended;
  private statusSub: Subscription;

  constructor(
    private observationSharedService: ObservationSharedService,
    @Inject(LOCALE_ID) public locale: string
  ) {}

  ngOnInit(): void {
    this.getStatusData();
  }

  ngOnDestroy(): void {
    this.unsubStatusData();
  }

  public getStatusData(): void {
    this.statusSub = this.observationSharedService.currentDataStatus$.subscribe(
      (response) => {
        this.statusData = response;
      }
    );
  }

  public toggle(): void {
    this.isOpen = !this.isOpen;
  }

  private unsubStatusData(): void {
    if (this.statusSub) {
      this.statusSub.unsubscribe();
    }
  }
}
