import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObservationStatusCardComponent } from './observation-status-card.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('ObservationStatusCardComponent', () => {
  let component: ObservationStatusCardComponent;
  let fixture: ComponentFixture<ObservationStatusCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule,BrowserAnimationsModule],
      declarations: [ ObservationStatusCardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ObservationStatusCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
