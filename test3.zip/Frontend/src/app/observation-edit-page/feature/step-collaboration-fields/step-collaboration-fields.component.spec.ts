import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StepCollaborationFieldsComponent } from './step-collaboration-fields.component';
import { HttpClientModule } from '@angular/common/http';

describe('StepCollaborationFieldsComponent', () => {
  let component: StepCollaborationFieldsComponent;
  let fixture: ComponentFixture<StepCollaborationFieldsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [ StepCollaborationFieldsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StepCollaborationFieldsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
