import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { EMPTY, Subject, combineLatest, finalize, map, mergeMap, of } from 'rxjs';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { Router } from '@angular/router';
import { DataForm } from 'src/app/shared/models/data-form';
import { CollabFieldsStep } from 'src/app/domain/observation';
import { RagStatusService } from 'src/app/admin-pages/rag-status/data-access/rag-status.service';
import { ObservationService } from '../../data-access/observation.service';
import { UpdateCollabFieldsStepRequest } from 'src/app/domain/requests/update-collab-fields-step-request';
import { ValidationService } from '../../utils/observation-validation.service/observation-validation.service';

@Component({
  selector: 'app-step-collaboration-fields',
  templateUrl: './step-collaboration-fields.component.html',
  styleUrls: ['./step-collaboration-fields.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StepCollaborationFieldsComponent implements OnInit, OnDestroy {
  loading: boolean = false;
  private ngUnsubscribe : Subject<void> = new Subject<void>();
  private observationId = this.observationSharedService.routeID;
  form$ = of(this.observationFieldsService.getObservationSteps().collabFieldsStep).pipe(map((form)=> this.ValidationService.observationStepForm.value.collabFieldsStep = form));
  ragStatus$ = this.ragStatusService.getAll();

  dataForm$ = combineLatest([
    this.form$,
    this.observationSharedService.currentDataStepCollabFields$,
    this.ragStatus$,
    this.observationSharedService.currentDataAccess$,
    this.observationSharedService.currentDataObsStatus$,
    this.observationSharedService.currentFieldHelpText$

  ])
  .pipe(
    map(([
      form,
      dataCollabFields,
      ragStatus,
      access,
      status,
      helpTexts
    ]) => {
      if(!dataCollabFields){
        return null;
      }
      this.observationSharedService.accessCheck(form,access,status);

      if(helpTexts&&form)
        this.observationFieldsService.mapFieldHelpTexts(form,helpTexts);
      
      const dataForm : DataForm = {
        form: form,
        data: dataCollabFields,
        dropdownsData: {
          ragStatus: ragStatus,
        }
      };
      return dataForm;
    }),
    finalize(() => {
      this.loading = false;
    }),
  );

  constructor(
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private ValidationService: ValidationService,
    private ragStatusService: RagStatusService,
    private observationService: ObservationService,
    private router: Router) { }

  ngOnInit() {
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  onSave() : void {
    this.observationSharedService.currentDataStepCollabFields$.pipe(
      mergeMap((response : CollabFieldsStep | undefined) => {
        if(!response){
          return EMPTY;
        }

        const request : UpdateCollabFieldsStepRequest = {
          comment: response.comment,
          comment1LoD: response.comment1LoD,
          ragStatusID: response.ragStatus,
          ragJustification: response.ragJustification,
          closureSubmitted: response.closureSubmitted
        };

        return this.observationService.updateCollaborationFieldStep(this.observationId, request);
      }),
      finalize(() => {
        this.loading = false;
        // this.nextPage();
        //-- need to add some notification.
      }),
    )
    .subscribe();
  }

  nextPage() {
    this.router.navigate(['/edit-observation/'+ this.observationId +'/action-plan']);
  }
}
