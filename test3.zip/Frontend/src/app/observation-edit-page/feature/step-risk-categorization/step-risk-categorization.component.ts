import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { BehaviorSubject, EMPTY, Subject, combineLatest, finalize, forkJoin, map, mergeMap, of, switchMap, takeUntil, tap} from 'rxjs';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { TaxonomyService } from 'src/app/admin-pages/taxonomies/data-access/taxonomy.service';
import { Taxonomy } from 'src/app/domain/taxonomy';
import { ObservationService } from '../../data-access/observation.service';
import { Router } from '@angular/router';
import { RegulationsService } from '../../data-access/regulations.service';
import { RegulatoryCategoriesService } from '../../data-access/regulatory-categories.service';
import { DataForm } from 'src/app/shared/models/data-form';
import { UpdateRiskCategorizationStepRequest } from 'src/app/domain/requests/update-risk-categorization-step-request';
import { RiskCategorizationStep } from 'src/app/domain/observation';
import { ValidationService } from '../../utils/observation-validation.service/observation-validation.service';
import { Form } from 'src/app/shared/models/form';
import { RegulatoryCategory } from 'src/app/domain/regulatory-category';

@Component({
  selector: 'app-step-risk-categorization',
  templateUrl: './step-risk-categorization.component.html',
  styleUrls: ['./step-risk-categorization.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StepRiskCategorizationComponent implements OnInit, OnDestroy {
  loading: boolean = false;
  private ngUnsubscribe : Subject<void> = new Subject<void>();
  private firstLevel: number = 1;
  private secondLevel: number = 2;
  private thirdLevel: number = 3;
  private observationId = this.observationSharedService.routeID;

  form$ = of(this.observationFieldsService.getObservationSteps().riskCategorizationStep).pipe(map((form)=> this.ValidationService.observationStepForm.value.riskCategorizationStep = form));

  taxonomiesLevel1$ = this.taxonomyService.getAllByLevel(this.firstLevel);
  taxonomiesLevel2$ = new BehaviorSubject<Taxonomy[]>([]);
  taxonomiesLevel3$ = new BehaviorSubject<Taxonomy[]>([]);
  regulatoryCategories$ = new BehaviorSubject<RegulatoryCategory[]>([]);
  regulations$ = this.regulationService.getAll();

  dataForm$ = combineLatest([
    this.form$,
    this.observationSharedService.currentDataStepRiskCat$,
    this.taxonomiesLevel1$,
    this.taxonomiesLevel2$,
    this.taxonomiesLevel3$,
    this.regulatoryCategories$,
    this.regulations$,
    this.observationSharedService.currentDataAccess$,
    this.observationSharedService.currentDataObsStatus$,
    this.observationSharedService.currentFieldHelpText$

  ])
  .pipe(
      map(([
        form,
        dataRiskCategorization,
        taxonomiesLevel1,
        taxonomiesLevel2,
        taxonomiesLevel3,
        regulatoryCategories,
        regulations,
        access,
        status,
        helpTexts
      ]) => {
        if(!dataRiskCategorization){
          return null;
        }
        dataRiskCategorization.taxonomyLevel1 = dataRiskCategorization.taxonomies[this.firstLevel][0];

        if(helpTexts&&form)
        this.observationFieldsService.mapFieldHelpTexts(form,helpTexts);
      
        this.observationSharedService.accessCheck(form,access, status);
        const dataForm : DataForm = {
          form: form,
          data: dataRiskCategorization,
          dropdownsData: {
            taxonomyLevel1: taxonomiesLevel1,
            taxonomies2: taxonomiesLevel2,
            taxonomies3: taxonomiesLevel3,
            regulatoryCategories: regulatoryCategories,
            regulations: regulations
          }
        };
        return dataForm;
      }),
      finalize(() => {
        this.loading = false;
        // this.nextPage();
      }),
    );

  constructor(
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private ValidationService: ValidationService,
    private taxonomyService: TaxonomyService,
    private observationService: ObservationService,
    private regulationService: RegulationsService,
    private regulatoryCategoryService: RegulatoryCategoriesService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.onMultiSelectLevelsChange();
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  onSave(): void {
    this.observationSharedService.currentDataStepRiskCat$.pipe(
      mergeMap((response : RiskCategorizationStep | undefined) => {
        if(!response){
          return EMPTY;
        }

        const request : UpdateRiskCategorizationStepRequest = {
          businessLine: response.businessLine,
          directive: response.directive,
          taxonomyLevel1: response.taxonomies[this.firstLevel][0],
          taxonomiesLevel2: response.taxonomies[this.secondLevel],
          taxonomiesLevel3: response.taxonomies[this.thirdLevel],
          conductRisk: response.conductRisk,
          esgRisk: response.esgRisk,
          conductJustification: response.conductJustification,
          esgJustification: response.esgJustification,
          regulations : response.regulations,
          regCategories: response.regulatoryCategories,
          regulationComment: response.regulationComment,
        };

        return this.observationService.updateRiskCategorizationStep(this.observationId, request);
      }),
      finalize(() => {
        this.loading = false;
        // this.nextPage();
        //-- need to add some notification.
      }),
    )
    .subscribe(); 
  }

  onDropdownSelectLevelsChange(data: any) {
    this.observationSharedService.currentDataStepRiskCat$
    .pipe(
      switchMap((currentData) => {
        if(!currentData || currentData.taxonomies[this.firstLevel][0] == currentData.taxonomyLevel1){
          return EMPTY;
        }
        currentData.taxonomies[this.firstLevel] = [currentData.taxonomyLevel1];
  
        currentData.taxonomies[this.secondLevel] = [];
        currentData.taxonomies[this.thirdLevel] = [];
        currentData.regulatoryCategories = [];
        this.taxonomiesLevel3$.next([]);
        this.regulatoryCategories$.next([]);
  
        return forkJoin([
          this.taxonomyService.getChildrenByIds(currentData.taxonomies[this.firstLevel]),
        ]);
      }),
      tap(([taxonomiesLevel2]) => {
        this.taxonomiesLevel2$.next(taxonomiesLevel2);
      }),
      takeUntil(this.ngUnsubscribe)
    )
    .subscribe();
  }

  onMultiSelectChange(data: any){
    this.form$.pipe(
      map((data:Form)=>{
      })
    )
  .subscribe();
  }

  onMultiSelectLevelsChange() {
    this.observationSharedService.currentDataStepRiskCat$
    .pipe(
      switchMap((currentData) => {
        if(!currentData){
          return EMPTY;
        }

        const idsLevel1 : number[] = currentData.taxonomies[this.firstLevel] || [];
        const idsLevel2 : number[] = currentData.taxonomies[this.secondLevel];
        const idsLevel3 : number[] = currentData.taxonomies[this.thirdLevel];


        if(idsLevel1.length === 0){
          currentData.taxonomies[this.firstLevel] = [];
          currentData.taxonomies[this.secondLevel] = [];
          currentData.taxonomies[this.thirdLevel] = [];
          currentData.regulatoryCategories = [];
          this.taxonomiesLevel2$.next([]);
          this.taxonomiesLevel3$.next([]);
          this.regulatoryCategories$.next([]);
          return EMPTY;
        }

        if(idsLevel2.length == 0){
          currentData.taxonomies[this.thirdLevel] = [];
          currentData.regulatoryCategories = [];
          this.taxonomiesLevel3$.next([]);
          this.regulatoryCategories$.next([]);

          const level2Length = currentData.taxonomies[this.secondLevel].length;

          if(level2Length > 0){
            return EMPTY;
          }

          return forkJoin([
            this.taxonomyService.getChildrenByIds(idsLevel1),
            this.taxonomyService.getChildrenByIds(idsLevel2),
            this.regulatoryCategoryService.getAllByTaxonomyId(idsLevel3)
          ]);
        }

        if(idsLevel3.length === 0){
          currentData.regulatoryCategories = [];
          this.regulatoryCategories$.next([]);
        }

        return forkJoin([
          this.taxonomyService.getChildrenByIds(idsLevel1),
          this.taxonomyService.getChildrenByIds(idsLevel2),
          this.regulatoryCategoryService.getAllByTaxonomyId(idsLevel3)
        ]);
      }),
      tap(([taxonomiesLevel2, taxonomiesLevel3, regulatoryCategories]) => {
        this.taxonomiesLevel2$.next(taxonomiesLevel2);
        taxonomiesLevel3 = taxonomiesLevel3.filter((value, index, self) =>
          index === self.findIndex((t) => (
            t.id === value.id)))
        this.taxonomiesLevel3$.next(taxonomiesLevel3);
        this.regulatoryCategories$.next(regulatoryCategories);
      }),
      takeUntil(this.ngUnsubscribe)
    )
    .subscribe();
  }

  nextPage() {
    this.router.navigate(['/edit-observation/'+ this.observationId +'/collab-fields']);
  }
}
