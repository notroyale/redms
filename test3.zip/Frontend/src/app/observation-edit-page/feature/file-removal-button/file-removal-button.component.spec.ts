import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FileRemovalButtonComponent } from './file-removal-button.component';

describe('FileRemovalButtonComponent', () => {
  let component: FileRemovalButtonComponent;
  let fixture: ComponentFixture<FileRemovalButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FileRemovalButtonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FileRemovalButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
