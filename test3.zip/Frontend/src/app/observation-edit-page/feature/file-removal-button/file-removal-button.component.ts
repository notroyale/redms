import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-file-removal-button',
  templateUrl: './file-removal-button.component.html',
  styleUrls: ['./file-removal-button.component.css']
})
export class FileRemovalButtonComponent {

  @Output() onFileDeleteActionEvent = new EventEmitter();

  delete() {
    this.onFileDeleteActionEvent.emit();
  }
}
