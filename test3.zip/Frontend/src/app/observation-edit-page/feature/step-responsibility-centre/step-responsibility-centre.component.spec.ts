import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StepResponsibilityCentreComponent } from './step-responsibility-centre.component';
import { HttpClientModule } from '@angular/common/http';

describe('StepResponsibilityCentreComponent', () => {
  let component: StepResponsibilityCentreComponent;
  let fixture: ComponentFixture<StepResponsibilityCentreComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [ StepResponsibilityCentreComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StepResponsibilityCentreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
