import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { BehaviorSubject, EMPTY, Observable, Subject, combineLatest, concatMap, finalize, forkJoin, map, mergeMap, of, switchMap, take, takeUntil, tap } from 'rxjs';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { BusinessUnitService } from 'src/app/admin-pages/business-units/data-access/business-unit.service';
import { DataForm } from 'src/app/shared/models/data-form';
import { BusinessAreaService } from 'src/app/admin-pages/business-areas/data-access/business-area.service';
import { LegalEntityService } from 'src/app/admin-pages/legal-entities/data-access/legal-entity.service';
import { CountriesService } from '../../data-access/countries.service';
import { Observation, ObservationAccess, ResponsibilityCentreStep } from 'src/app/domain/observation';
import { ObservationBaCountryReq } from 'src/app/domain/requests/observation-ba-country-req';
import { UpdateResponsibilityCentreStepRequest } from 'src/app/domain/requests/update-responsibility-center-step-request';
import { Router } from '@angular/router';
import { ObservationService } from '../../data-access/observation.service';
import { ObservationBusinessAreaCountry } from 'src/app/domain/observation-business-area-country';
import { BusinessArea } from 'src/app/domain/business-area';
import { LegalEntity } from 'src/app/domain/legal-entity';
import { ValidationService } from '../../utils/observation-validation.service/observation-validation.service';
import { InvalidType } from 'src/app/domain/validation';

@Component({
  selector: 'app-step-responsibility-centre',
  templateUrl: './step-responsibility-centre.component.html',
  styleUrls: ['./step-responsibility-centre.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StepResponsibilityCentreComponent implements OnInit, OnDestroy {
  loading: boolean = false;
  private ngUnsubscribe: Subject<void> = new Subject<void>();
  private observationId = this.observationSharedService.routeID;

  access: ObservationAccess | null;
  form$ = of(this.observationFieldsService.getObservationSteps().responsibleCentreStep).pipe(map((form) => this.ValidationService.observationStepForm.value.responsibleCentreStep = form));
  businessUnits$ = this.businessUnitService.getAll();
  countries$ = this.countriesService.getAll();

  private defaultBusinessArea: BusinessArea;

  businessAreas$ = new BehaviorSubject<BusinessArea[]>([]);
  legalEntities$ = new BehaviorSubject<LegalEntity[]>([]);


  dataForm$ = combineLatest([
    this.form$,
    this.observationSharedService.currentDataStepRespCenter$,
    this.businessUnits$,
    this.countries$,
    this.businessAreas$,
    this.legalEntities$,
    this.observationSharedService.currentDataAccess$,
    this.observationSharedService.currentDataObsStatus$,
    this.observationSharedService.currentFieldHelpText$
  ])
    .pipe(
      map(([
        form,
        dataResponsabilityCenter,
        businessUnits,
        countries,
        businessAreas,
        legalEntities,
        access,
        status,
        helpTexts
      ]) => {
        this.access = access;
        this.observationSharedService.accessCheck(form, access, status);
        if (!dataResponsabilityCenter) {
          return null;
        }

        if(helpTexts&&form)
        this.observationFieldsService.mapFieldHelpTexts(form,helpTexts);

        const dataForm: DataForm = {
          form: form,
          data: dataResponsabilityCenter,
          dropdownsData: {
            businessUnits: businessUnits,
            countries: countries,
            businessAreas: businessAreas,
            legalEntities: legalEntities,
            businessAreasCountries: dataResponsabilityCenter.businessAreasCountries
          }
        };

        return dataForm;
      }),
      finalize(() => {
        this.loading = false;
      }),
    );

  constructor(
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private ValidationService: ValidationService,
    private businessUnitService: BusinessUnitService,
    private countriesService: CountriesService,
    private businessAreaService: BusinessAreaService,
    private legalEntityService: LegalEntityService,
    private observationService: ObservationService,
    private validationService: ValidationService,
    private router: Router) { }

  ngOnInit(): void {
    this.onBusinessUnitChange();

  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  onSave(): void {
    this.observationSharedService.currentDataStepRespCenter$.pipe(
      mergeMap((response: ResponsibilityCentreStep | undefined) => {
        if (!response) {
          return EMPTY;
        }
        const request: UpdateResponsibilityCentreStepRequest = {
          activityOwner: response.activityOwner,
          riskOwner: response.riskOwner,
          assignee: response.assignee,
          businessUnit: response.businessUnit,
          legalEntities: response.legalEntities
        };

        return this.observationService.updateResposabilityCenterStep(this.observationId, request);
      }),
      finalize(() => {
        this.loading = false;
        // this.nextPage();
        //-- need to add some notification.
      }),
    )
      .subscribe();
  }

  onDropdownChange(): void {
    this.onBusinessUnitChange();
  }

  private onBusinessUnitChange(): void {
    this.observationSharedService.currentDataStepRespCenter$
      .pipe(
        switchMap((currentData) => {
          if (!currentData) {
            return EMPTY;
          }


          const ids: number[] = [currentData.businessUnit];
          if (ids.length == 0) {
            return EMPTY;
          }

          return forkJoin([
            this.businessAreaService.getBusinessAreasByBusinessUnitsIds(ids),
            this.legalEntityService.getLegalEntitiesByBusinessUnitsIds(ids),
            this.businessAreaService.getDefaultBusinessArea()
          ]);
        }),
        tap(([businessAreas, legalEntities, defaultBusinessArea]) => {
          this.defaultBusinessArea = defaultBusinessArea;
          if(!businessAreas.some(x=>x.id == defaultBusinessArea.id))
            businessAreas.unshift(defaultBusinessArea);
          this.businessAreas$.next(businessAreas);
          this.legalEntities$.next(legalEntities);
        }),
        takeUntil(this.ngUnsubscribe)
      )
      .subscribe();
  }


  onBaCountryUpdate(data: any): void {
    if (this.observationId == 0
      || !data
      || !data.countries) {
      this.validationService.displayCustomValidationError({
        isValid: false,
        invalidField: ['Country'],
        invalidType: InvalidType.custom,
        invalidMessage: "Please select a"
      });
      return console.log("Invalid data. NOT saved!");;
    }

    if (!data.businessAreas)
      data.businessAreas = this.defaultBusinessArea.id;

    const observationBaCountryReq: ObservationBaCountryReq = {
      observationID: this.observationId,
      businessAreaID: data.businessAreas,
      countryID: data.countries
    };

    this.observationService.addBaCountry(observationBaCountryReq)
      .pipe(
        concatMap(addedBusinessAreaCountry =>
          this.observationSharedService.currentData$
            .pipe(
              take(1),
              map(currentData => {
                if (!currentData) {
                  return null;
                }

                currentData.observation.responsibleCentreStep.businessAreasCountries =
                  [...currentData.observation.responsibleCentreStep.businessAreasCountries, addedBusinessAreaCountry];

                return currentData;
              }),
              tap(updatedData => {
                if (!updatedData) {
                  return;
                }

                this.observationSharedService.changeData(updatedData)
              })
            ))
      )
      .subscribe();

    //  var oi = of({
    //     "observationID": 7062,
    //     "businessArea": "Legacy Country Data",
    //     "country": "Poland"
    //   }).pipe(
    //     delay(5000)
    //   );

    // this.observationService.addBaCountry(observationBaCountryReq)
    // let x: ObservationBusinessAreaCountry = {
    //   businessArea: '',
    //   country: '',
    //   observationID: 0
    // };
    // oi
    // .pipe(
    //   finalize(() => {
    //     this.loading = false;
    //     //-- need to add some notification, that business area was successfuly added.
    //   }),
    //   map((response) => {
    //     var currentData = this.observationSharedService.getResponsibilityCentreStepData();
    //     if(!currentData){
    //       return currentData;
    //     }
    //     x = response;
    //     currentData?.responsibleCentreStep.businessAreasCountries.push(response);
    //     //this.observationSharedService.changeData(currentData);

    //     return currentData;
    //   }))
    // .subscribe();
  }

  onNestedFormSave(obsBaCountry: ObservationBusinessAreaCountry): Observable<ObservationAccess | null> {
    return this.observationSharedService.currentData$
      .pipe(
        map((obs: ObservationAccess | null) => {
          if (!obs) {
            return obs;
          }
          const copy = { ...obs };
          copy.observation.responsibleCentreStep.businessAreasCountries.push(obsBaCountry);
          return copy;
        })
      );

  }

  onBaDelete(request: any) {
    this.observationService.removeBaCountry(request.id)
    .subscribe((response: any ) => {
    });
   // update table
   this.observationSharedService.currentData$
            .pipe(
              take(1),
              map(currentData => {
                if (!currentData) {
                  return null;
                }

                currentData.observation.responsibleCentreStep.businessAreasCountries =currentData.observation.responsibleCentreStep.businessAreasCountries.filter(x=>x.id != request.id);

                return currentData;
              })).subscribe();
  }

  nextPage(): void {
    this.router.navigate(['/edit-observation/' + this.observationId + '/risk-categorization']);
  }
}

