import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, ResolveFn, Router, RouterStateSnapshot } from '@angular/router';
import { ObservationService } from '../data-access/observation.service';
import { Observation, ObservationAccess } from 'src/app/domain/observation';
import { EMPTY, Observable, catchError, map } from 'rxjs';
import { ObservationSharedService } from '../data-access/observation-shared.service';

export const observationResolver: ResolveFn<Observable<ObservationAccess | null>> =
  (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {
    const observationService = inject(ObservationService);
    const observationSharedService = inject(ObservationSharedService);
    const router = inject(Router);

    let cachedObservation : ObservationAccess | null = null;

    const parameterKey = Object.keys(route.params)[0];
    const observationId = route.params[parameterKey];

    observationSharedService.currentData$.subscribe((response) => {
      if(response != null && response.observation.id == observationId) {
        cachedObservation = response;
        return response;
      }

      return cachedObservation;
    });

    if(cachedObservation){
      return cachedObservation;
    }

    // const parameterKey = Object.keys(route.params)[0];

    // return observationService.get(route.params[parameterKey]).pipe(
    return observationService.get(observationId).pipe(
      catchError(() => {
        router.navigate(['']);
        return EMPTY;
      }),
      map((result) => {
        observationSharedService.setID(route.params[parameterKey]);
        observationSharedService.changeData(result);
        return result;
      })
    );
  };
