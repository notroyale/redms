import { DataForm } from "src/app/shared/models/data-form";
import { DataTable } from "src/app/shared/models/data-table";

export interface StepActionPlanObservation{
    dataForm: DataForm;
    dataTable: DataTable;
}
