import { Injectable, OnInit, LOCALE_ID, Inject } from '@angular/core';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { BehaviorSubject, Subject, map } from 'rxjs';
import { FieldType } from 'src/app/shared/models/field-type';
import { Field } from 'src/app/shared/models/field';
import { DropdownField } from 'src/app/shared/models/dropdown-field';
import { DropdownLevelsField } from 'src/app/shared/models/dropdown-levels-field';
import { Form, SideForm } from "src/app/shared/models/form";
import { ObservationFieldsService } from '../observation-fields.service/observation-fields.service';
import { ObservationSteps } from '../observation-steps';
import { ActionPlanStep, Observation } from 'src/app/domain/observation';
import { InvalidType, ValidationInformation, DateValidationRule, CustomValidationRule } from 'src/app/domain/validation';
import { observableToBeFn } from 'rxjs/internal/testing/TestScheduler';
import { ActionPlan } from 'src/app/domain/action-plan';
import { FormsModule, NG_ASYNC_VALIDATORS } from '@angular/forms';
import { DateTimeProvider } from 'angular-oauth2-oidc';
import { ActionPlanService } from '../../data-access/action-plan-service/action-plan.service';
import { formatDate } from '@angular/common';
import { HtmlParser } from '@angular/compiler';
import { StatusOptions } from 'src/app/domain/status';


@Injectable({
  providedIn: 'root'
})

export class ValidationService {

  observationStepForm = new BehaviorSubject({
    statusStep: {},
    affectedFieldsStep: {},
    detailsStep: {},
    responsibleCentreStep: {},
    riskCategorizationStep: {},
    collabFieldsStep: {},
    actionPlanStep: {},
  } as ObservationSteps);


  private validationInfo: ValidationInformation = {
    isValid: true,
    invalidField: [],
    invalidType: InvalidType.none,
    invalidMessage: ""
  };

  private isFieldValid: boolean;

  validationSubject = new BehaviorSubject<ValidationInformation>(this.validationInfo);
  warningModalSwitch = new BehaviorSubject<boolean>(false);

  //refactor this ?
  observationDateValidation: DateValidationRule[] = [
    { mainDate: 'dateIdentified', greaterThan: [], lesserThan: ['creationDate'] },
    // { mainDate: 'creationDate', greaterThan: [], lesserThan: ['deadline', 'closureDate', 'cancellationDate', 'riskAcceptanceDate', 'revisedDeadline'] },
    { mainDate: 'deadline', greaterThan: ['creationDate'], lesserThan: [] },
    { mainDate: 'revisedDeadline', greaterThan: ['deadline'], lesserThan: [] },
    { mainDate: 'closureDate', greaterThan: ['creationDate'], lesserThan: [] }, //If observation's status is Open - Deadline Extended, Closure Date should be later than "original" Deadline.
    { mainDate: 'cancellationDate', greaterThan: ['creationDate'], lesserThan: [] },
    { mainDate: 'riskAcceptanceDate', greaterThan: ['creationDate'], lesserThan: [] },
    { mainDate: 'revisedDeadline', greaterThan: ['creationDate', 'deadline'], lesserThan: [] },
  ]

  private readonly params = {
    deadlineField: "deadline",
    actionPlanClosedStatus: 1,
    categoryNotSetId: 12,
    businessUnitSelectId: 19,
  };

  asDropdownField = (field: Field) => field as DropdownField;
  asDropdownLevelsField = (field: Field) => field as DropdownLevelsField;

  constructor(
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    @Inject(LOCALE_ID) public locale: string
  ) {
    this.validationSubject.subscribe(validationData => {
      if (!validationData.isValid)
        this.toggleWarningMessage();
    })
  }


  getValidationInformation(): ValidationInformation {
    return this.validationSubject.value;
  }

  isValid(): boolean {
    return this.validationSubject.value.isValid;
  }

  toggleWarningMessage() {
    this.warningModalSwitch.next(!this.warningModalSwitch.value);
  }

  displayCustomValidationError(information: ValidationInformation) {
    this.validationSubject.next(information);
  }

  validateClosure(data: Observation): boolean {

    if (!this.validateObservation(data))
      return false;
    if (!this.validateActionPlanClosure(data.actionPlanStep))
      return false;
    return true;
  }

  validateObservation(data: Observation): boolean {
    this.isFieldValid = true;

    this.validationInfo.isValid = true;
    this.validationInfo.invalidField = [];
    this.validationInfo.invalidType = InvalidType.none;
    this.validationInfo.invalidMessage = "";
    this.validationSubject.next(this.validationInfo);

    if (!this.validateManditoryStep(data)){
      this.validationInfo.isValid = false;
      this.validationInfo.invalidType = InvalidType.mandatory;
      this.validationInfo.invalidMessage = "";
      this.validationSubject.next(this.validationInfo);
      return false;
    }

    if (!this.validateDateStep(data)) {
      return false;
    }

    if (!this.validateCustomRules(data)) {
      this.validationInfo.isValid = false;
      this.validationInfo.invalidType = InvalidType.custom;
      this.validationSubject.next(this.validationInfo);
      return false;
    }

    return true;
  }

  validateCustomRules(data: any){
    const descriptionLengthValidation = { field: "description", value: 50 } as CustomValidationRule;
    const categoryIdNotSelectedValidation = { field: "categoryId", value: this.params.categoryNotSetId } as CustomValidationRule;
    const businessUnitNotSelectedValidation = { field: "businessUnits", value: this.params.businessUnitSelectId } as CustomValidationRule;

    const descriptionField = this.observationStepForm.value.detailsStep.fields.find(x => x.for == descriptionLengthValidation.field);
    if (descriptionField && !this.validateDescriptionLength(data.detailsStep[descriptionField.for], descriptionLengthValidation.value as number)) {
      this.validationInfo.invalidMessage = " is too short, minimal characters: " + descriptionLengthValidation.value;
      this.validationInfo.invalidField.push(descriptionField.display);
      return false;
    }

    const categoryField = this.observationStepForm.value.detailsStep.fields.find(x => x.for == categoryIdNotSelectedValidation.field) as DropdownField;
    if (categoryField && this.validateId(data.detailsStep[categoryField.key], categoryIdNotSelectedValidation.value as number)) {
      this.validationInfo.invalidMessage = " is not selected. Please make sure all mandatory fields marked with red star are filled.";
      this.validationInfo.invalidField.push(categoryField.display);
      return false;
    }

    const businessUnitField = this.observationStepForm.value.responsibleCentreStep.fields.find(x => x.for == businessUnitNotSelectedValidation.field) as DropdownField;
    if (businessUnitField && this.validateId(data.responsibleCentreStep[businessUnitField.key], businessUnitNotSelectedValidation.value as number)) {
      this.validationInfo.invalidMessage = " is not selected. Please make sure all mandatory fields marked with red star are filled.";
      this.validationInfo.invalidField.push(businessUnitField.display);
      return false;
    }

    return true;
  }

  validateManditoryStep(data: any): boolean {
    this.validateManditoryFields(data.detailsStep,this.observationStepForm.value.detailsStep.fields)
    this.validateManditoryFields(data.responsibleCentreStep,this.observationStepForm.value.responsibleCentreStep.fields)
    this.validateManditoryFields(data.riskCategorizationStep,this.observationStepForm.value.riskCategorizationStep.fields)
    this.validateManditoryFields(data.affectedFieldsStep,this.observationStepForm.value.affectedFieldsStep.fields)
    this.validateManditoryFields(data.collabFieldsStep,this.observationStepForm.value.collabFieldsStep.fields)
    this.validateManditoryFields(data.actionPlanStep,this.observationStepForm.value.actionPlanStep.fields)

    if (!this.isFieldValid) return false

    return true;
  }


  validateManditoryFields(data: any, fields: Field[]): boolean {
    for (let field of fields) {

      if ((field.type == FieldType.DropdownLevels)
        && field.mandatory
        && (data[this.asDropdownField(field).for][this.asDropdownField(field).key] == 0)) {
        this.validationInfo.invalidField.push(field.display);
        this.isFieldValid = false
      }

      if ((field.type == FieldType.Dropdown
        || field.type == FieldType.Multiselect)
        && field.mandatory
        && (data[this.asDropdownField(field).key] == 0 || data[this.asDropdownField(field).key] == null)) {
        this.validationInfo.invalidField.push(field.display);
        this.isFieldValid = false
      }

      if (field.type == FieldType.BinaryDropdown && field.mandatory && field.visible && data[field.for] == null) {
        this.validationInfo.invalidField.push(field.display);
        this.isFieldValid = false
      }

      if ((field.type == FieldType.TextArea || field.type == FieldType.Input || field.type == FieldType.UserInfo || field.type == FieldType.Table)
        && field.mandatory
        && field.visible
        && (data[field.for] == null || Object.keys(data[field.for]).length == 0)) {
        this.validationInfo.invalidField.push(field.display);
        this.isFieldValid = false
      }

    }

    return true;
  }

  validateDateStep(data: Observation) {
    //adding up details and status data and form fields because these are only two steps with dates
    if (!this.validateDateField(Object.assign(data.detailsStep, data.statusStep), this.observationStepForm.value.detailsStep.fields.concat(this.observationStepForm.value.statusStep.fields), this.observationDateValidation))
      return false;
    if (!this.validateActionPlanDeadlines(data.actionPlanStep))
      return false;

    return true;
  }

  validateActionPlanDeadlines(actionplanData: any): boolean {
    const observationDeadline = this.observationSharedService.getObservationDeadline();
    const observationRevisedDeadline = this.observationSharedService.getObservationRevisedDeadline();
    
    if (!observationDeadline)
      return false;


    var deadline = formatDate(observationRevisedDeadline? observationRevisedDeadline : observationDeadline, 'yyyy-MM-dd', this.locale);
    var actionplanDeadlines: String[] = actionplanData.actionPlans.map((el: any) => formatDate(el.actionDeadline, 'yyyy-MM-dd', this.locale));
    if (actionplanDeadlines.some(x => x > deadline)) {
      let ValidationMessage = observationRevisedDeadline? 'are set before Observation Revised Deadline' : 'are set before Observation Deadline';
      this.setValidationInfo(false, 'Action Plan Deadlines', ValidationMessage, InvalidType.date);
      return false
    }

    return true
  }

  validateActionPlanClosure(actionplanData: ActionPlanStep): boolean {
    var actionplanDeadlines: number[] = actionplanData.actionPlans.map((el: ActionPlan) => el.actionStatus);
    if (actionplanDeadlines.some(x => x != this.params.actionPlanClosedStatus)) {
      this.setValidationInfo(false, '', 'You have not closed all mitigation actions', InvalidType.custom);
      return false
    }
    return true
  }

  validateDateField(data: any, fields: Field[], dateRules: DateValidationRule[]): boolean {
    for (const field of dateRules) {
      var maindate = data[field.mainDate];
      if (maindate && (fields.find(x => x.for == field.mainDate)?.visible) && field.greaterThan.length > 0) {
        var greaterDates = field.greaterThan.map((item) => {
          if (data[item] && data[item] > maindate) {
            let invalidField  = fields.find(x => x.for == item)?.display || item;
            let ValidationMessage = ' is set in the future of ' + invalidField;
            this.setValidationInfo(false, fields.find(x => x.for == field.mainDate)?.display || field.mainDate, ValidationMessage, InvalidType.date);
            return false;
          }
          return true
        });

        if(!greaterDates.every((el) => el == true))
          return false;
      }
      if (maindate && (fields.find(x => x.for == field.mainDate)?.visible) && field.lesserThan.length > 0) {
        let lesserDates = field.lesserThan.map((item) => {
          if (data[item] && data[item] < maindate) {
            let invalidField  = fields.find(x => x.for == item)?.display || item;
            let ValidationMessage = ' is set in the past of ' + invalidField;
            this.setValidationInfo(false, fields.find(x => x.for == field.mainDate)?.display || field.mainDate, ValidationMessage, InvalidType.date);
            return false;
          }
          return true
        });

        if(!lesserDates.every((el) => el == true))
          return false;
      }
    }
    return true;
  }

  validateActionPlan(data: ActionPlan) {
    if (!this.validateManditoryFields(
      data,
      this.observationStepForm.value.actionPlanStep.formFields
    )) {
      this.validationInfo.isValid = false;
      this.validationInfo.invalidType = InvalidType.mandatory;
      this.validationInfo.invalidMessage = "";
      this.validationSubject.next(this.validationInfo);
      return false;
    }

    const observationStatus = this.observationSharedService.getObservationStatus();
    const observationCreationDate = this.observationSharedService.getObservationCreationDate();
    const observationDeadline = observationStatus == StatusOptions.DeadlineExt ? this.observationSharedService.getObservationRevisedDeadline() : this.observationSharedService.getObservationDeadline();

    if (observationDeadline == undefined) {
      let ValidationMessage = observationStatus == StatusOptions.DeadlineExt ? 'You must set the Observation Revised Deadline before you add Action' :
        'You must set the Observation Deadline before you add Action';
      this.setValidationInfo(false, '', ValidationMessage, InvalidType.custom);
      return false;
    }

    if (data.actionDeadline &&
      !this.validateActionPlanDeadline(
        data.actionDeadline,
        observationDeadline
      )) {
      let ValidationMessage = observationStatus == StatusOptions.DeadlineExt ? 'You must set the Action Deadline date earlier than the Observation Revised Deadline' :
        'You must set the Action Deadline date earlier than the Observation Deadline';
      this.setValidationInfo(false, '', ValidationMessage, InvalidType.custom);

      return false;
    }
    
    if (data.actionDeadline && observationCreationDate &&
      (data.actionDeadline < observationCreationDate)) {
      let ValidationMessage = 'You must set the Action Deadline date later than the Observation Date of Creation in RAMS';
      this.setValidationInfo(false, '', ValidationMessage, InvalidType.custom);

      return false;
    }

    this.validationInfo.isValid = true;
    this.validationInfo.invalidField = [];
    this.validationInfo.invalidType = InvalidType.none;
    this.validationInfo.invalidMessage = "";
    this.validationSubject.next(this.validationInfo);

    return true;
  }

  validateActionPlanDeadline(actionDeadline: Date, observationDeadline: Date) {
    return (observationDeadline >= actionDeadline);
  }

  //need to add closure validation (closureDate > creation date)
  //need to add cancelation validation (cancelationDate > creation date)
  //need to add riskAcceptance validation (risk acceptance date > creation date)

  validateDescriptionLength(data: string, minValue: number): boolean {
    if (data.length < minValue)
      return false;
    return true;
  }

  validateId(data: number, id: number): boolean {
    if (data == id)
      return true;
    return false;
  }

  setValidationInfo(isValid: boolean, invalidField: string, invalidMessage: string, invalidType: InvalidType) {
    this.validationInfo.isValid = isValid;
    this.validationInfo.invalidField.push(invalidField);
    this.validationInfo.invalidMessage = invalidMessage;
    this.validationInfo.invalidType = invalidType;
    this.validationSubject.next(this.validationInfo);
  }
}
