import { Injectable } from '@angular/core';
import { ObservationSteps } from '../observation-steps';
import { FieldType } from 'src/app/shared/models/field-type';
import { InputType } from 'src/app/shared/models/input-type';
import {
  ColumnStyleType,
  ColumnType,
} from 'src/app/shared/models/table/column-type';
import { Access } from 'src/app/shared/models/field';
import { SortType } from 'src/app/shared/models/sort-type';
import { Form, SideForm } from 'src/app/shared/models/form';
import { FieldHelpText } from 'src/app/domain/field-help-text';
import { FormField } from 'src/app/shared/models/form-field';

@Injectable({
  providedIn: 'root',
})
export class ObservationFieldsService {

  mapFieldHelpTexts(form:Form, helpTexts:FieldHelpText[]){
    const formid = FieldType.Form as number;
    form.fields.map(field=>field.helpText = helpTexts.find(y=>y.forNames==field.for)?.helpTextValue);
    form.fields.filter(field => field.type == formid).map(x=>(x as FormField).form.fields.map(field=>field.helpText = helpTexts.find(y=>y.forNames==field.for)?.helpTextValue));
    if( 'formFields' in form)
      (form as SideForm).formFields.map(field=>field.helpText = helpTexts.find(y=>y.forNames==field.for)?.helpTextValue);
  }

  getEditableAdminAccessFields(): string[]{
    return ['dateIdentified', 'deadline'];
  }

  getObservationSteps(): ObservationSteps {
    return {
      id: { for: "for", display: "for", type: FieldType.Input, placeholder:"", inputType: InputType.Text, conditional: false, dependsOn: "",access: Access.EditAccess,
       styleClass:"", mandatory:false, isDisabled: false, visible:true  },
      detailsStep: {
        title: 'General',
        subtitle: '',
        fields: [
          { for: "grades", display: "Observation Grade", type: FieldType.Dropdown, displayAttribute: "name", conditional: false, dependsOn: "",access: Access.EditAccess,
           styleClass:"", filterAttribute:"id", key:"gradeID", mandatory:true, isDisabled: false, visible:true,disableAttribute:"isActive"  },
          { for: "title", display: "Observation Title", type: FieldType.Input, conditional: false, dependsOn: "",access: Access.EditAccess,
           placeholder:"", inputType: InputType.Text, styleClass:"input-custom", mandatory:true, isDisabled: false, visible:true},
          { for: "categoryId", display: "Source of Observations", type: FieldType.Dropdown, conditional: true, dependsOn: "",access: Access.EditAccess,
           displayAttribute: "description", styleClass:"", filterAttribute:"id", key:"categoryId", mandatory:true, isDisabled: false, visible:true,disableAttribute:"isActive"  },
          { for: "observationCategoryExplanation", display: "Please provide clarification (Source of Observations)", conditional: true, dependsOn: "11",access: Access.EditAccess,
           type: FieldType.TextArea, styleClass:"", mandatory: true, isDisabled: false, visible: false, placeholder:"Clarification..." },
          { for: "dateIdentified", display: "Date Identified", type: FieldType.Input, conditional: false, dependsOn: "",access: Access.AdminAccess,
           placeholder:"", inputType: InputType.Date, styleClass:"", mandatory:false, isDisabled: false, visible:true },
          { for: "creationDate", display: "Date of Creation in RAMS", type: FieldType.Input, conditional: false, dependsOn: "",access: Access.AdminAccess,
           placeholder:"", inputType: InputType.Date, styleClass:"", mandatory:true, isDisabled: true, visible:true},
          { for: "deadline", display: "Deadline", type: FieldType.Input, placeholder:"", inputType: InputType.Date, conditional: false, dependsOn: "",access: Access.AdminAccess,
           styleClass:"", mandatory:true, isDisabled: false, visible:true},
          { for: "revisedDeadline", display: "Revised Deadline", type: FieldType.Input, placeholder:"", inputType: InputType.Date, conditional: false, dependsOn: "",access: Access.AdminAccess,
           styleClass:"", mandatory:false, isDisabled: false, visible:true },
          { for: "description", display: "Description of Observation Identified", type: FieldType.TextArea, conditional: false, dependsOn: "",access: Access.EditAccess,
           styleClass:"", mandatory:true, isDisabled: false, visible:true, placeholder:"" },
          { for: "selfRaised", justificationField: "selfRaisedJustification", display: "Is the Observation related to a Self-Raised Issue?", displayAttribute: "title", type: FieldType.BinaryDropdown, conditional: false, dependsOn: "",access: Access.EditAccess,
           styleClass:"", filterAttribute:"value", mandatory:true, isDisabled: false, visible:true},
          { for: "selfRaisedJustification", display: "Please provide clarification (Self-Raised Issue)", conditional: false, dependsOn: "",access: Access.EditAccess,
           styleClass:"", type: FieldType.TextArea, mandatory:true , isDisabled: false, visible:false, placeholder:"Clarification..." },
        ],
        btnLabel: 'Next',
      },
      // adminFieldStep: {
      //   title: "Admin fields",
      //   subtitle: "Enter the general information",
      //   fields: [
      //     { for: "observationStatus", display: "Status", type: FieldType.Dropdown, displayAttribute: "name", styleClass:"", filterAttribute:"id", key:"status", mandatory:true  },
      //     { for: "cancellationDate", display: "Cancellation Date", type: FieldType.Input, placeholder:"", inputType: InputType.Date, styleClass:"", mandatory:false },
      //     { for: "riskAcceptanceDate", display: "Risk Acceptance Date", type: FieldType.Input, placeholder:"", inputType: InputType.Date, styleClass:"", mandatory:true },
      //     { for: "deadlineExtentionRegistrationDate", display: "Deadline Extension Registered", type: FieldType.Input, placeholder:"", inputType: InputType.Date, styleClass:"", mandatory:false },
      //     { for: "cancellationJustification", display: "Justification for cancellation", type: FieldType.TextArea, styleClass:"", mandatory:false },
      //   ],
      //   btnLabel: 'Close Observation'
      // },
      statusStep: {
        title: 'Closure',
        subtitle: '',
        fields: [
          { for: "status", display: "Status", type: FieldType.Dropdown, conditional: true, dependsOn: "",access: Access.EditAccess,
            displayAttribute: "name", styleClass: "", filterAttribute: "id", key: "status", mandatory: true, isDisabled: false, visible: true, disableAttribute:"isActive"  },
          { for: "closureDate", display: "Closure Date", type: FieldType.Input, conditional: true, dependsOn: "1",access: Access.EditAccess,
            placeholder:"", inputType: InputType.Date, styleClass: "", mandatory: false, isDisabled: false, visible: false },
          { for: "closureJustification", display: "Justification for closure", conditional: true, dependsOn: "1",access: Access.EditAccess,
            type: FieldType.TextArea, styleClass: "", mandatory: false, isDisabled: false, visible: false, placeholder:"Justify..." },
          { for: "cancellationDate", display: "Cancellation Date", type: FieldType.Input, conditional: true, dependsOn: "3",access: Access.EditAccess,
            placeholder:"", inputType: InputType.Date, styleClass: "", mandatory: false, isDisabled: false, visible: false },
          { for: "cancellationJustification", display: "Justification for cancellation", conditional: true, dependsOn: "3",access: Access.EditAccess,
            type: FieldType.TextArea, styleClass: "justification", mandatory: false, isDisabled: false, visible:false, placeholder:"Justify..." },
          { for: "riskAcceptanceDate", display: "Risk Acceptance Date", type: FieldType.Input, conditional: true, dependsOn: "4",access: Access.EditAccess,
            placeholder:"", inputType: InputType.Date, styleClass: "", mandatory: false, isDisabled: false, visible: false },
          { for: "riskAcceptanceJustification", display: "Justification for risk acceptance", conditional: true, dependsOn: "4",access: Access.EditAccess,
          type: FieldType.TextArea, styleClass: "", mandatory: false, isDisabled: false, visible: false, placeholder:"Justify..." },
          { for: "deadlineExtensionRegistrationDate", display: "Deadline Extension Registered", conditional: true, dependsOn: "5",access: Access.EditAccess,
            type: FieldType.InputPreFilledDate, placeholder:"", inputType: InputType.Date, styleClass: "", mandatory: false, isDisabled: false, visible: false },
          { for: "deadlineExtensionJustification", display: "Justification for deadline extension", conditional: true, dependsOn: "5",access: Access.EditAccess,
            type: FieldType.TextArea, styleClass:"", mandatory: false, isDisabled: false, visible: false, placeholder:"Justify..." },
        ],
        btnLabel: 'Submit',
      },
      affectedFieldsStep: {
        title: 'Affected Areas',
        subtitle: '',
        fields: [
          { for: "businessUnitsAF", display: "Affected Business Units", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.EditAccess,
            type: FieldType.Multiselect, styleClass:"", filterAttribute:"id", key:"businessUnitsAF", mandatory:true, isDisabled: false, visible:true, disableAttribute:"isActive"  },
          // { for: "businessAreasAF", display: "Affected Business Areas", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.EditAccess,
          //   type: FieldType.Multiselect, styleClass:"", filterAttribute:"id", key:"businessAreasAF", mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive"  },
            { for: "countriesAF", display: "Affected Countries", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.EditAccess,
            type: FieldType.Multiselect, styleClass:"", filterAttribute:"id", key:"countriesAF", mandatory:true, isDisabled: false, visible:true, disableAttribute:"isActive"  },
            { for: "legalEntitiesAF", display: "Affected Legal Entities", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.EditAccess,
              type: FieldType.Multiselect, styleClass:"", filterAttribute:"id", key:"legalEntitiesAF", mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive"  },
        ],
        btnLabel: 'Next',
      },
      responsibleCentreStep: {
        title: 'Responsibility Centre',
        subtitle: '',
        fields: [
          { for: "assignee", access: Access.EditAccess,display: "Compliance Responsible Person", conditional: false, dependsOn: "", type: FieldType.UserInfo, styleClass:"input-custom", mandatory:true, isDisabled: false, visible:true },
          { for: "riskOwner", access: Access.EditAccess,display: "Observation Owner", conditional: false, dependsOn: "", type: FieldType.UserInfo, styleClass:"input-custom", mandatory:true, isDisabled: false, visible:true},
          { for: "activityOwner",access: Access.EditAccess, display: "Activity Owner", conditional: false, dependsOn: "", type: FieldType.UserInfo, styleClass:"input-custom", mandatory:true, isDisabled: false, visible:true},
          { for: "businessUnits", display: "Activity Owner's Business Unit / 1st LoD Owner of Observation", conditional: false, dependsOn: "",access: Access.EditAccess,
           displayAttribute: "name", type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key: "businessUnit", mandatory:true, isDisabled: false, visible:true,disableAttribute:"isActive" },
          { for: "businessAreasCountries", display: "Activity Owner's Business Area & Country", conditional: false, dependsOn: "", type: FieldType.Form, styleClass:"", mandatory:false, isDisabled: true, visible:true,access: Access.EditAccess,
          form: {
            title: 'observationBusinessAreas',
            subtitle: '',
            fields: [
              { for: "businessAreas", display: "Activity Owner's Business Area (owning the risk/mitigation)", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.EditAccess,
               type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key: "businessArea", mandatory:false, isDisabled: false, visible:true,disableAttribute:"isActive"},
              { for: "countries", display: "Activity Owner's Country (owning the risk/mitigation)", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.EditAccess,
               type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key: "country", mandatory:true, isDisabled: false, visible:true ,disableAttribute:"isActive"  }
            ],
            btnLabel: 'Add'
          }},

          // { for: "businessAreas", display: "Business Area", displayAttribute: "name", type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key: "businessArea"},
          // { for: "countries", display: "Country", displayAttribute: "name", type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key: "country"   },
          // { for: "button", display: "btn", displayAttribute: "name", type: FieldType.Modal, styleClass:"" },

          { for: "businessAreasCountries", display: "Activity Owner's Country & Business Area Relations", conditional: false, dependsOn: "",access: Access.EditAccess,
           displayAttribute: "name", type: FieldType.Table, styleClass:"", key:"", mandatory:false, isDisabled: false, visible:true,
            table: {
              columns: [
                // { headerStyle:'common-header', for: 'id', header: 'ID',
                // columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                // type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
              { headerStyle:'common-header', for: 'country', header: 'Country (owning the risk/mitigation)',
                columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
              { headerStyle:'common-header', for: 'businessArea', header: 'Business Area (owning the risk/mitigation)',
                columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None},
                { headerStyle:'common-header', for: '', header: 'Delete',
                columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                type: ColumnType.BARemovalColumn, styleClass: 'common-column', sorted: SortType.None },
            ],
            totalCount: 0,
            page: 1,
            rows: 5,
            first: 0
          }
        },
          { for: "legalEntities", access: Access.EditAccess,display: "Activity Owner's Legal Entities (Subsidiaries) (owning the risk/mitigation)", displayAttribute: "name", conditional: false, dependsOn: "",
            type: FieldType.Multiselect, styleClass:"", filterAttribute:"id", key:"legalEntities", mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive" },
        ],
        btnLabel: 'Next',
      },
      riskCategorizationStep: {
        title: 'Risk Categorization',
        subtitle: '',
        fields: [
          { for: "taxonomyLevel1", access: Access.EditAccess,display: "Risk Level 1",displayAttribute: "name", conditional: false, dependsOn: "",
           type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key:"taxonomyLevel1", mandatory:true, isDisabled: false, visible:true, disableAttribute:"isActive"    },
          { for: "taxonomies", access: Access.EditAccess,display: "Risk Level 2",displayAttribute: "name", conditional: false, dependsOn: "",
           type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"2", mandatory:true, isDisabled: false, visible:true, disableAttribute:"isActive"    },
          { for: "taxonomies", display: "Risk Level 3",displayAttribute: "name", conditional: false, dependsOn: "",
           type: FieldType.DropdownLevels,access: Access.EditAccess, styleClass:"", filterAttribute:"id", key:"3", mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive"    },
          { for: "businessLine", display: "Assessment Unit (AU) / Line of Business", conditional: false, dependsOn: "",
           type: FieldType.Input,access: Access.EditAccess, placeholder:"", inputType: InputType.Text, styleClass:"input-custom", mandatory:false, isDisabled: false, visible:true },
           { for: "conductRisk", access: Access.EditAccess,justificationField: "conductJustification", conditional: false, dependsOn: "", display: "Is the Observation related to Conduct Risk?",displayAttribute: "title", type: FieldType.BinaryDropdown, styleClass:"", filterAttribute:"value", mandatory:true, isDisabled: false, visible:true   },
           { for: "conductJustification",access: Access.EditAccess, display: "Please provide justification (Conduct Risk)", conditional: false, dependsOn: "", type: FieldType.TextArea, styleClass:"input-custom", mandatory:true , isDisabled: false, visible:false, placeholder:"Clarification..."  },
           { for: "esgRisk",access: Access.EditAccess, justificationField: "esgJustification", conditional: false, dependsOn: "", display: "Is the observation related to ESG Risk?",displayAttribute: "title", type: FieldType.BinaryDropdown, styleClass:"", filterAttribute:"value", mandatory:true , isDisabled: false, visible:true  },
           { for: "esgJustification", display: "Please provide justification (ESG Risk)",access: Access.EditAccess, conditional: false, dependsOn: "", type: FieldType.TextArea, styleClass:"input-custom", mandatory:true, isDisabled: false, visible:false, placeholder:"Clarification..."   },
           { for: "directive",access: Access.EditAccess, display: "Internal Policy / Business Procedure / SOP / Governing Information", conditional: false, dependsOn: "", type: FieldType.Input, placeholder:"", inputType: InputType.Text, styleClass:"input-custom", mandatory:false, isDisabled: false, visible:true },
           { for: "regulatoryCategories",access: Access.EditAccess, display: "Regulatory Category", conditional: false, dependsOn: "", displayAttribute: "name", type: FieldType.Multiselect, styleClass:"", filterAttribute:"id", key:"regulatoryCategories", mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive"    },
           { for: "regulations", display: "Relevant Regulations", displayAttribute: "name", access: Access.EditAccess,conditional: true, dependsOn: "",  type: FieldType.Multiselect, styleClass:"", filterAttribute:"id", key:"regulations" , mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive"    },
           { for: "regulationComment", display: "Please define (Relevant Regulations)",access: Access.EditAccess, conditional: true, dependsOn: "30", type: FieldType.Input, placeholder:"Specify...", inputType: InputType.Text, styleClass:"input-custom", mandatory:true, isDisabled: false, visible:false   },
        ],
        btnLabel: 'Next',
      },
      // supportingDocumentsStep:{
      //   title: "Supporting documents",
      //   subtitle: "",
      //   fields: [
      //     { for: "attachments", display: "Attachments", displayAttribute: "name", type: FieldType.Table, styleClass:"", key:"", mandatory:false,
      //       table: {
      //         columns: [
      //           { headerStyle:'common-header', for: 'filename', header: 'Filename',
      //             columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
      //             type: ColumnType.TextColumn,  styleClass: 'bold-column' },
      //           { headerStyle:'common-header', for: 'description', header: 'Description',
      //             columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
      //             type: ColumnType.TextColumn, styleClass: 'common-column' },
      //           { headerStyle:'common-header', for: 'uploadedBy', header: 'Uploaded By',
      //             columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
      //             type: ColumnType.TextColumn, styleClass: 'common-column' },
      //           { headerStyle:'common-header', for: 'gdpr', header: 'Contains GDPR Data',
      //             columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
      //             type: ColumnType.TextColumn, styleClass: 'common-column' },
      //           { headerStyle:'common-header', for: 'uploadDate', header: 'Retention Date',
      //             columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
      //             type: ColumnType.TextColumn, styleClass: 'common-column' },
      //             { headerStyle:'common-header', for: '', header: 'Action',
      //             columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
      //             type: ColumnType.ActionButtonColumn, styleClass: 'common-column' },
      //         ],
      //         totalCount: 0,
      //         page: 1,
      //         rows: 5,
      //         first: 0
      //       }
      //     }
      //   ],
      //   formFields: [
      //     { for: "file", display: "Upload Document???", type: FieldType.Input, placeholder:"", inputType: InputType.Text, styleClass:"input-custom", mandatory:true },
      //     { for: "description", display: "Description", type: FieldType.Input, placeholder:"", inputType: InputType.Text, styleClass:"input-custom", mandatory:true },
      //     { for: "gdprData", display: "Does the file contain GDPR data ", type: FieldType.InputSwitch, styleClass:"", mandatory:false, },
      //   ],
      //   btnLabel: 'Next'
      // },
      collabFieldsStep: {
        title: 'Collaboration Fields',
        subtitle: '',
        fields: [
          { for: "comment", display: "Comment", conditional: false, dependsOn: "", access: Access.CommentAccess,
          type: FieldType.TextArea, styleClass:"", mandatory:false, isDisabled: false, visible:true, placeholder:"" },
          { for: "comment1LoD", access: Access.CommentAccess, display: "Observation Owners Comment Box", conditional: false, dependsOn: "",
          type: FieldType.TextArea, styleClass:"", mandatory:false, isDisabled: false, visible:true, placeholder:"This is a comment field for 1st Line of Defence (LoD)"  },
          { for: "ragStatus", access: Access.EditAccess, display: "RAG Status", displayAttribute: "name", conditional: false, dependsOn: "",
           type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key:"ragStatus", mandatory:false, isDisabled: false, visible:true,disableAttribute:"isActive"   },
          { for: "ragJustification", access: Access.CommentAccess, display: "Justification (RAG status)", conditional: false, dependsOn: "",
           type: FieldType.TextArea, styleClass:"", mandatory:false, isDisabled: false, visible:true, placeholder:""  },
          { for: "closureSubmitted", access: Access.EditAccess, justificationField: "", display: "Submitted for Closure", conditional: false, dependsOn: "",
          displayAttribute: "title", type: FieldType.BinaryDropdown, styleClass:"",filterAttribute:"value", mandatory:false, isDisabled: false, visible:true }
        ],
        btnLabel: 'Next',
      },
      actionPlanStep: {
        title: 'Action Plans',
        sideFormTitle: 'Create Mitigating Action ',
        subtitle: 'Define the actions needed for mitigation before this observation can be closed.',
        fields: [
          { for: "actionPlans", display: "Action Plans", displayAttribute: "name", conditional: false, dependsOn: "",
          type: FieldType.Table, styleClass:"", key:"", mandatory:true, isDisabled: false, visible:true,access: Access.EditAccess,
            table: {
              columns: [
                { headerStyle:'common-header', for: 'actionTitle', header: 'Title',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.TextColumn,  styleClass: 'bold-column', sorted: SortType.None },
                { headerStyle:'common-header', for: 'actionBusinessArea', header: 'Business Area',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
                { headerStyle:'common-header', for: 'taxonomyLevel3', header: 'Risk level 3',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
                { headerStyle:'common-header', for: 'actionStatusColumn', header: 'Status',
                  columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.ChipColumn,
                  displayAttribute:"name",colorAttribute:"color", styleClass: 'common-column', sorted: SortType.None },
                { headerStyle:'common-header', for: 'actionDeadline', header: 'Deadline',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.DateColumn, styleClass: 'common-column', sorted: SortType.None },
                { headerStyle:'common-header', for: 'actionActivityOwner', header: 'Action Owner',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
                { headerStyle:'common-header', for: 'actionClosureUser', header: 'Closed By',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
                { headerStyle:'common-header', for: 'actionClosureDate', header: 'Closure Date',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.DateColumn, styleClass: 'common-column', sorted: SortType.None },
               { headerStyle:'common-header', for: '', header: 'Action',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.ActionButtonColumn, styleClass: 'common-column', sorted: SortType.None },
              ],
              totalCount: 0,
              page: 1,
              rows: 5,
              first: 0,
            },
          },
          { for: "recommendation", display: "Mitigation Action Plan Summary", type: FieldType.TextArea, conditional: false, dependsOn: "",
          placeholder:"", styleClass:"input-custom",access: Access.EditAccess, mandatory:false, isDisabled: false, visible:true },
          { for: "proposedPlan", display: "Proposed Plan (Legacy)", type: FieldType.Input, conditional: false, dependsOn: "",
          placeholder:"", inputType: InputType.Text, styleClass:"input-custom",access: Access.ViewAccess, mandatory:false, isDisabled: true, visible:true }
        ],
        formFields: [
          { for: "actionStatus", display: "Status", type: FieldType.Input, conditional: true, dependsOn: "",
           placeholder:"", inputType: InputType.Text, styleClass:"input-custom",access: Access.EditAccess, mandatory:false, isDisabled: false, visible:false },
          { for: "actionTitle", display: "Action Title", type: FieldType.Input, conditional: true, dependsOn: "0",
           placeholder:"", inputType: InputType.Text, styleClass:"input-custom",access: Access.EditAccess, mandatory:true, isDisabled: false, visible:true },
          { for: "actionSummary", display: "Action Summary",access: Access.EditAccess, type: FieldType.TextArea, conditional: true, dependsOn: "0",
           placeholder:"", styleClass:"input-custom", mandatory:true, isDisabled: false, visible:true },
          { for: "actionBusinessAreas", display: "Business Area", displayAttribute: "name", conditional: true, dependsOn: "0",
           type: FieldType.Dropdown, styleClass:"", filterAttribute:"id",access: Access.EditAccess, key: "businessAreaID", mandatory:false, isDisabled: false, visible:true,disableAttribute:""   },
          { for: "taxonomiesLevel3", display: "Risk Level 3", displayAttribute: "name", conditional: true, dependsOn: "0",
           type: FieldType.Dropdown, styleClass:"", filterAttribute:"id",access: Access.EditAccess, key: "taxonomyLevel3ID", mandatory:false, isDisabled: false, visible:true,disableAttribute:""   },
          { for: "actionActivityOwner", display: "Action Owner", type: FieldType.Input, conditional: true, dependsOn: "0",
           placeholder:"", inputType: InputType.Text, styleClass:"input-custom", mandatory:false,access: Access.EditAccess, isDisabled: false, visible:true },
          { for: "actionDeadline", display: "Action Deadline", type: FieldType.Input, conditional: true, dependsOn: "0",
          placeholder:"", inputType: InputType.Date, styleClass:"", mandatory:true, isDisabled: false,access: Access.EditAccess, visible:true },
          { for: "actionComment1LoD", display: "Action Owner Comment", type: FieldType.Input, conditional: true, dependsOn: "1",
          placeholder:"", inputType: InputType.Text, styleClass:"", mandatory:false, isDisabled: false,access: Access.EditAccess, visible:true }
        ],
        btnLabel: 'Next',
      },
      supportingDocumentsStep: {
        title: 'Supporting Documents',
        subtitle: '',
        fields: [
          // {
          //   for: 'containGDPR',
          //   justificationField: 'retentionPeriod',
          //   conditional: false,
          //   dependsOn: '',
          //   display: 'Is the Observation related to Conduct Risk?',
          //   displayAttribute: 'title',
          //   type: FieldType.BinaryDropdown,
          //   styleClass: '',
          //   filterAttribute: 'value',
          //   mandatory: false,
          //   visible: true,
          // },
          // {
          //   for: 'retentionPeriod',
          //   display: 'Retention Period',
          //   displayAttribute: 'name',
          //   conditional: false,
          //   dependsOn: '',
          //   type: FieldType.Dropdown,
          //   styleClass: '',
          //   filterAttribute: 'id',
          //   key: '',
          //   mandatory: false,
          //   visible: true,
          // },
          {
            for: 'fileUploadForm',
            display: '',
            conditional: false,
            dependsOn: '',
            type: FieldType.FileUploadForm,
            styleClass: '',
            mandatory: false,
            access: Access.EditAccess,
            visible: true,
            isDisabled: false,
            form: {
              title: 'observationAttachments',
              subtitle: '',
              fields: [
                {
                  for: 'fileUpload',
                  display: '',
                  conditional: false,
                  dependsOn: '',
                  access: Access.EditAccess,
                  type: FieldType.FileUpload,
                  styleClass: '',
                  mandatory: false,
                  visible: true,
                  isDisabled: false
                },
                {
                  for: 'gdpr',
                  justificationField: '',
                  conditional: false,
                  dependsOn: '',
                  access: Access.EditAccess,
                  display: 'Is the observation related to GDPR Risk?',
                  displayAttribute: 'title',
                  type: FieldType.BinaryDropdown,
                  styleClass: '',
                  filterAttribute: 'value',
                  mandatory: true,
                  visible: true,
                  isDisabled: false,
                },
              ],
              btnLabel: 'Add',
            },
          },

          {
            for: 'attachments',
            display: '',
            displayAttribute: 'name',
            conditional: false,
            dependsOn: '',
            type: FieldType.Table,
            styleClass: '',
            access: Access.EditAccess,
            key: '',
            mandatory: false,
            visible: true,
            isDisabled: false,
            table: {
              columns: [
                {
                  headerStyle: 'common-header',
                  for: 'filename',
                  header: 'FileName',
                  columnStyle: ColumnStyleType.Frozen,
                  alignFrozen: 'left',
                  type: ColumnType.TextColumn,
                  styleClass: 'bold-column', sorted: SortType.None
                },
                {
                  headerStyle: 'common-header',
                  for: 'gdpr',
                  header: 'Contains GDPR?',
                  columnStyle: ColumnStyleType.Frozen,
                  alignFrozen: 'left',
                  type: ColumnType.TextColumn,
                  styleClass: 'common-column', sorted: SortType.None
                },
                {
                  headerStyle: 'common-header',
                  for: 'loD',
                  header: 'LoD',
                  columnStyle: ColumnStyleType.Frozen,
                  alignFrozen: 'left',
                  type: ColumnType.TextColumn,
                  styleClass: 'common-column', sorted: SortType.None
                },
                {
                  headerStyle: 'common-header',
                  for: '',
                  header: '',
                  columnStyle: ColumnStyleType.Frozen,
                  alignFrozen: 'right',
                  type: ColumnType.DownloadFileColumn,
                  styleClass: 'common-column',
                  sorted: SortType.None
                },
                {
                  headerStyle: 'common-header',
                  for: '',
                  header: '',
                  columnStyle: ColumnStyleType.Frozen,
                  alignFrozen: 'right',
                  type: ColumnType.DeleteFileColumn,
                  styleClass: 'common-column',
                  sorted: SortType.None
                }
              ],
              totalCount: 0,
              page: 1,
              rows: 5,
              first: 0,
            },
          },
        ],
        btnLabel: '',
      },
    };
  }

  //need to decide the right step for the following attributes
  onHold(): any[] {
    return [
      { for: 'proposedPlan', display: 'Proposed Plan', type: FieldType.Input },
      {
        for: 'registrationNumber',
        display: 'Registration Number',
        type: FieldType.Input,
      },
      { for: 'directive', display: 'Directive', type: FieldType.Input },
      // { for: "submitted", display: "Submitted", type: FieldType.Input },
      { for: 'deleted', display: 'Deleted', type: FieldType.Input },
      {
        for: 'mitigationActionComment',
        display: 'Mitigation Action Comment',
        type: FieldType.Input,
      },
      {
        for: 'riskAssessmentId',
        display: 'Risk Assessment for',
        type: FieldType.Input,
      },
      // { for: "comment1LoDId", display: "Comment 1 LoD for", type: FieldType.Input },
      // { for: "businessUnit", display: "Business Unit", type: FieldType.Input },
      // { for: "statusID", display: "Status", type: FieldType.Dropdown, displayAttribute: "name",inputField: InputType.Text, styleClass:"", filterAttribute:"", key:"" },
      {
        for: 'groupObservationId',
        display: 'Group Observation',
        type: FieldType.Input,
        inputField: InputType.Text,
        styleClass: 'input-custom',
      },
      {
        for: 'businessLine',
        display: 'Business Line',
        type: FieldType.Input,
        inputField: InputType.Text,
        styleClass: 'input-custom',
      },
      {
        for: 'categoryId',
        display: 'Category',
        type: FieldType.Dropdown,
        inputField: InputType.Text,
        styleClass: 'input-custom',
        filterAttribute: '',
        key: '',
        displayAttribute: '',
      },
      // { for: "regulations", display: "Regulations", displayAttribute: "name",  type: FieldType.Dropdown,inputField: InputType.Text, styleClass:"", filterAttribute:"", key:""   },
      // { for: "regulatoryCategories", display: "Regulatory Categories", displayAttribute: "name", type: FieldType.Dropdown,inputField: InputType.Text, styleClass:"", filterAttribute:"", key:""   },
      {
        for: 'taxonomies',
        display: 'Taxonomies',
        displayAttribute: 'name',
        type: FieldType.Dropdown,
        inputField: InputType.Text,
        styleClass: '',
        filterAttribute: '',
        key: '',
      },
    ];
  }
}
