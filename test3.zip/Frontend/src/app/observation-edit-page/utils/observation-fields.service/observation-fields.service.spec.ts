import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { ObservationFieldsService } from './observation-fields.service';

describe('ObservationFieldsService', () => {
  let service: ObservationFieldsService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(ObservationFieldsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
