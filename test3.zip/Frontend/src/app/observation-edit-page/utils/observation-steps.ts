import { Form, SideForm } from "src/app/shared/models/form";
import { InputField } from "src/app/shared/models/input-field";

export interface ObservationSteps {
    id: InputField;
    // adminFieldStep: Form;
    statusStep: Form;
    affectedFieldsStep: Form;
    detailsStep: Form;
    responsibleCentreStep: Form;
    riskCategorizationStep: Form;
    collabFieldsStep: Form;
    actionPlanStep: SideForm;
    supportingDocumentsStep: Form;
    // supportingDocumentsStep:SideForm;
}
