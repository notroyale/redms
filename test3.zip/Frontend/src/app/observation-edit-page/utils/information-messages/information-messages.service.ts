import { Injectable } from '@angular/core';
import { InfoButtons, InformationModal } from 'src/app/shared/models/information-modal';

@Injectable({
  providedIn: 'root'
})
export class InformationMessagesService {

  constructor() { }

  getObservationSavedMessage(id:number, title:string=""):InformationModal{
    return {
      header: `The observation has been successfully saved.`,
      body: 
`Observation id:  ${id}
Observation title: ${title}`,
      buttonType: InfoButtons.okCancelNormal,
      okButtonTitle: "Edit observation",
      cancelButtonTitle: "Back to overview",
    }
  }

  getObservationSavedErrorMessage():InformationModal{
    return {
      header: `The observation has failed to saved.`,
      body: "Error has occured during saving.",
      buttonType: InfoButtons.ok,
      okButtonTitle: "Back to observation",
    }
  }

  getObservationClosureErrorMessage():InformationModal{
    return {
      header: `The observation has failed to close.`,
      body: "Error has occured during closure.",
      buttonType: InfoButtons.ok,
      okButtonTitle: "Back to observation",
    }
  }
  
  getObservationClosureSuccessMessage():InformationModal{
    return {
      header: `The observation has been successfully closed.`,
      body: ``,
      buttonType: InfoButtons.okCancelNormal,
      okButtonTitle: "View observation",
      cancelButtonTitle: "Back to overview",
    }
  }


  getObservationClosureMessage():InformationModal{
    return {
      header: `Are you sure you want to close this observation?`,
      body: "Please note, that after pressing \"Close Observation\", you are no longer able to edit the observation or attach documents to the closed observation.",
      buttonType: InfoButtons.okCancel,
      okButtonTitle: "Close Observation",
      cancelButtonTitle: "Cancel"
    }
  }

  getActionPlanClosureMessage():InformationModal{
    return {
      header: "Are you sure you want to close this Mitigation action?",
      body: "Please note, that after pressing \"Close Mitigation Action\", you are no longer able to edit the Mitigation Action.",
      buttonType: InfoButtons.okCancel,
      okButtonTitle: "Close Mitigation Action",
      cancelButtonTitle: "Cancel",
    }
  }


  getActionPlanDeleteMessage():InformationModal{
    return {
      header: "Are you sure you want to delete this observation action?",
      body: "",
      buttonType: InfoButtons.okCancel,
      okButtonTitle: "Delete",
      cancelButtonTitle: "Cancel",
    }
  }
}
