import { TestBed } from '@angular/core/testing';

import { InformationMessagesService } from './information-messages.service';

describe('InformationMessagesService', () => {
  let service: InformationMessagesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InformationMessagesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
