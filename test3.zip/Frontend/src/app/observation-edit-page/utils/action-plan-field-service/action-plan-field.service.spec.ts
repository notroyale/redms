import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { ActionPlanFieldService } from './action-plan-field.service';

describe('ActionPlanFieldService', () => {
  let service: ActionPlanFieldService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(ActionPlanFieldService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
