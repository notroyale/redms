import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RegulatoryCategory } from 'src/app/domain/regulatory-category';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class RegulatoryCategoriesService {
  constructor(private http: HttpClient) { }

  public getAll(): Observable<RegulatoryCategory[]> {
    return this.http.get<RegulatoryCategory[]>(`${settings.apibaseUrl}/api/RegulatoryCategory/all`);
  }

  public getAllByTaxonomyId(ids: number[]): Observable<RegulatoryCategory[]> {
    let queryParams = new HttpParams();
    queryParams = queryParams.appendAll({'ids': ids});

    return this.http.get<RegulatoryCategory[]>(`${settings.apibaseUrl}/api/RegulatoryCategory/allByTaxonomy?${queryParams.toString()}`)
  }
}
