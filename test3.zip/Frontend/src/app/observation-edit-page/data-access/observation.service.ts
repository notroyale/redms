import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Result } from 'src/app/domain/result';
import { ActionPlanStep, AffectedFieldsStep, StatusFieldsStep, UpdateDetailsStepRequest, Observation, ObservationClosure, ObservationContainer, ResponsibilityCentreStep, RiskCategorizationStep, ObservationAccess } from 'src/app/domain/observation';
import { settings } from 'src/utils/appsettings.service';
import { ObservationBaCountryReq } from 'src/app/domain/requests/observation-ba-country-req';
import { UpdateRiskCategorizationStepRequest } from 'src/app/domain/requests/update-risk-categorization-step-request';
import { ActionPlanService } from './action-plan-service/action-plan.service';
import { ObservationBusinessAreaCountry } from 'src/app/domain/observation-business-area-country';
import { UpdateResponsibilityCentreStepRequest } from 'src/app/domain/requests/update-responsibility-center-step-request';
import { UpdateAffectedAreasStepRequest } from 'src/app/domain/requests/update-affected-areas-step-request';
import { UpdateCollabFieldsStepRequest } from 'src/app/domain/requests/update-collab-fields-step-request';
import { UpdateActionPlanStepRequest } from 'src/app/domain/requests/update-action-plan-step-request';
import { UpdateObservationStatusRequest } from 'src/app/domain/requests/update-observation-status-request';
import { ObservationAttachmentReq } from 'src/app/domain/requests/observation-attachment-req';
import { Attachment } from 'src/app/domain/attachment';
import { FileMetadata } from 'src/app/shared/models/file-metadata';
import { FieldHelpText } from 'src/app/domain/field-help-text';

@Injectable({
  providedIn: 'root'
})
export class ObservationService {
  constructor(private http: HttpClient) { }

  public get(id: any): Observable<ObservationAccess> {
    const url = `${settings.apibaseUrl}/api/Observation/get?id=${id}`;
    return this.http.get<ObservationAccess>(url);
  }

  public getFieldHelpText():Observable<FieldHelpText[]>{
    return this.http.get<FieldHelpText[]>(`${settings.apibaseUrl}/api/FieldHelpText/all`);
  }

  public updateObservation(id: number, observation: ObservationContainer): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/update?id=${id}`,observation);
  }

  public updateDetailsStep(id: number, detailsStep: UpdateDetailsStepRequest): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/update-details?id=${id}`,detailsStep);
  }

  public updateAffectedFieldStep(id: number, affectedFieldsStep: UpdateAffectedAreasStepRequest): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/update-affected-fields?id=${id}`,affectedFieldsStep);
  }


  public updateStatusFieldStep(id: number, StatusFieldsStep: UpdateObservationStatusRequest): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/update-closure-fields?id=${id}`,StatusFieldsStep);
  }

  public updateActionPlanStep(id: number, actionPlanStep: UpdateActionPlanStepRequest): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/update-action-plan-step?id=${id}`,actionPlanStep);
  }

  public updateResposabilityCenterStep (id: number, request: UpdateResponsibilityCentreStepRequest): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/update-responsibility-center?id=${id}`, request);
  }

  public updateCollaborationFieldStep (id: number, collabFieldsStep: UpdateCollabFieldsStepRequest): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/update-collaboration-fields?id=${id}`, collabFieldsStep);
  }

  public updateRiskCategorizationStep (id: number, request: UpdateRiskCategorizationStepRequest): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/update-risk-categorization?id=${id}`, request);
  }

  public closeObservation (id: number, request: ObservationClosure): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/observation-closure?id=${id}`, request);
  }

  public addBaCountry (newBaCountry: ObservationBaCountryReq) : Observable<ObservationBusinessAreaCountry> {
    return this.http.post<ObservationBusinessAreaCountry>(`${settings.apibaseUrl}/api/ObservationBusinessAreaCountry/add`, newBaCountry);
  }
  public removeBaCountry (id: number) {
    return this.http.delete(`${settings.apibaseUrl}/api/ObservationBusinessAreaCountry/delete?id=${id}`);
  }
  public removeFile (id: number) {
    return this.http.delete(`${settings.apibaseUrl}/api/Attachment/delete?id=${id}`);
  }

  public downloadAttachment(attachmentId: number){
    return this.http.get(`${settings.apibaseUrl}/api/Attachment/download-attachments?attachmentID=${attachmentId}`, {responseType: 'blob'});
  }

  public uploadAttachments(metadata: FileMetadata, attachments: ObservationAttachmentReq) : Observable<Attachment[]> {
    const formData = new FormData();

    for (let i = 0; i < attachments.files.length; i++) {
      formData.append('files', attachments.files[i]);
    }

    let headers = new HttpHeaders();
    headers.append('enctype', 'multipart/form-data');
    const options = { headers};

    return this.http.post<Attachment[]>(`${settings.apibaseUrl}/api/Attachment/upload-attachments?id=${metadata.id}&role=${metadata.uploaderRole}&gdpr=${attachments.gdpr}`,
       formData, options );

  }
}

