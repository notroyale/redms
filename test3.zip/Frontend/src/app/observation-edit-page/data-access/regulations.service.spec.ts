import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { RegulationsService } from './regulations.service';

describe('RegulationsService', () => {
  let service: RegulationsService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(RegulationsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
