import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ActionPlan } from 'src/app/domain/action-plan';
import { AddActionPlanRequest } from 'src/app/domain/requests/add-action-plan-request';
import { UpdateActionPlanRequest } from 'src/app/domain/requests/update-action-plan-request';
import { UpdateActionPlanStepRequest } from 'src/app/domain/requests/update-action-plan-step-request';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class ActionPlanService {
  constructor(private http: HttpClient) { }

  public get(id: number): Observable<ActionPlan> {
    return this.http.get<ActionPlan>(`${settings.apibaseUrl}/api/ActionPlan/get?id=${id}`);
  }

  public add( data : AddActionPlanRequest): Observable<any> {
    return this.http.post<ActionPlan>(`${settings.apibaseUrl}/api/ActionPlan/add`,data);
  }

  public close(id: number): Observable<any> {
    return this.http.post<any>(`${settings.apibaseUrl}/api/ActionPlan/close?id=${id}`,null);
  }

  public delete(id: number): Observable<any> {
    return this.http.delete<any>(`${settings.apibaseUrl}/api/ActionPlan/delete?Id=${id}`);
  }

  public update( data : UpdateActionPlanRequest): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/ActionPlan/update`,data);
  }
}
