import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { ActionPlanService } from './action-plan.service';

describe('ActionPlanService', () => {
  let service: ActionPlanService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(ActionPlanService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
