import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Regulation } from 'src/app/domain/regulation';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class RegulationsService {
  constructor(private http: HttpClient) { }

  public getAll(): Observable<Regulation[]> {
    return this.http.get<Regulation[]>(`${settings.apibaseUrl}/api/Regulation/all`);
  }
}
