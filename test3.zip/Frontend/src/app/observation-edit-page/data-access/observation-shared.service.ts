import { Injectable } from '@angular/core';
import { BehaviorSubject, map } from 'rxjs';
import { FieldHelpText } from 'src/app/domain/field-help-text';
import {
  ActionPlanStep,
  Observation,
  ObservationAccess,
  ResponsibilityCentreStep,
} from 'src/app/domain/observation';
import { ObservationBusinessAreaCountry } from 'src/app/domain/observation-business-area-country';
import { ObservationStatus } from 'src/app/domain/observation-status';
import { Access, Field } from 'src/app/shared/models/field';
import { FieldType } from 'src/app/shared/models/field-type';
import { Form } from 'src/app/shared/models/form';

@Injectable({
  providedIn: 'root',
})
export class ObservationSharedService {
  private dataSource = new BehaviorSubject<ObservationAccess | null>(null);
  private fieldHelpTextSource = new BehaviorSubject<FieldHelpText[] | undefined>(undefined);

  currentFieldHelpText$ = this.fieldHelpTextSource.asObservable();
  currentData$ = this.dataSource.asObservable();
  currentDataStepDetails$ = this.currentData$.pipe(
    map((observationAccess) => observationAccess?.observation.detailsStep)
  );
  currentDataObsStatus$ = this.currentData$.pipe(
    map((observationAccess) => observationAccess?.observation.statusStep.status)
  );
  currentDataStatus$ = this.currentData$.pipe(
    map((observationAccess) => observationAccess?.observation.statusStep)
  );
  currentDataAccess$ = this.currentData$.pipe(
    map((observationAccess) => observationAccess)
  );
  currentDataStepRespCenter$ = this.currentData$.pipe(
    map(
      (observationAccess) =>
        observationAccess?.observation.responsibleCentreStep
    )
  );
  currentDataStepRiskCat$ = this.currentData$.pipe(
    map(
      (observationAccess) =>
        observationAccess?.observation.riskCategorizationStep
    )
  );
  currentDataStepCollabFields$ = this.currentData$.pipe(
    map((observationAccess) => observationAccess?.observation.collabFieldsStep)
  );
  currentDataStepActionPlan$ = this.currentData$.pipe(
    map((observationAccess) => observationAccess?.observation.actionPlanStep)
  );
  currentDataStepAffectedAreas$ = this.currentData$.pipe(
    map(
      (observationAccess) => observationAccess?.observation.affectedFieldsStep
    )
  );
  currentDataStepSupportingDocuments$ = this.currentData$.pipe(
    map(
      (observationAccess) =>
        observationAccess?.observation.supportingDocumentsStep
    )
  );
  currentDataSubmitted$ = this.currentData$.pipe(
    map((observationAccess) => observationAccess?.observation.submitted)
  );

  routeID: number;

  getFieldHelpTexts() : FieldHelpText[] {
    if(!this.fieldHelpTextSource.value)
      return [];
    return this.fieldHelpTextSource.value;
  }

  setHelpTexts(helpTexts: FieldHelpText[]){
    this.fieldHelpTextSource.next(helpTexts);
  }

  changeData(observationAccess: ObservationAccess) {
    this.dataSource.next(observationAccess);
  }

  getResponsibilityCentreStepData(): ResponsibilityCentreStep | undefined {
    return this.dataSource.getValue()?.observation.responsibleCentreStep;
  }

  setID(id: number) {
    this.routeID = id;
  }

  refreshData() {
    this.currentData$.subscribe((currentData) => {
      this.dataSource.next(currentData);
    });
  }

  getObservationCreationDate(): Date|undefined{
    let creationDate = this.dataSource.value?.observation.detailsStep.creationDate || undefined;
    return creationDate;
  }

  getObservationDeadline(): Date|undefined{
    let deadline = this.dataSource.value?.observation.detailsStep.deadline || undefined;
    return deadline;
  }

  getObservationRevisedDeadline(): Date|undefined{
    let revisedDeadline = this.dataSource.value?.observation.detailsStep.revisedDeadline || undefined;
    return revisedDeadline;
  }

  getObservationStatus(): number {
    if(this.dataSource.value)
      return this.dataSource.value?.observation.statusStep.status;
    else return 0;
  }

  buttonAccessCheck(access: ObservationAccess | null,status: number | undefined): boolean {

    if (!access) {
      return false ;
    }
    if (!access.editAccess || (status == ObservationStatus.Closed || status == ObservationStatus.Cancelled)) {
      return false ;
    }
    return true;

  }

   accessCheck(form: Form, access: ObservationAccess | null, status: number | undefined) {

    if (!access) {
      return ;
    }

    form.fields.forEach((field) => {
      if ( status == ObservationStatus.Closed ||
        (field.access == Access.EditAccess  && !access?.editAccess  &&
        (access?.viewAccess || access?.commentAccess)) ||
        (field.access == Access.AdminAccess && !access?.adminAccess && 
        (access?.viewAccess || access?.commentAccess || access?.editAccess)) 
      ) {
        field.isDisabled = true;
      }
      this.checkSubLevels(field, status, access);
    });

  }



  private checkSubLevels(field: Field, status: number | undefined, access: ObservationAccess) {
    if (field.type == FieldType.Form) {
      field.form.fields.forEach((subfield) => {
        if (status == ObservationStatus.Closed ||
          subfield.access == Access.EditAccess && !access?.editAccess  &&
          (access?.viewAccess || access?.commentAccess) || 
          (subfield.access == Access.AdminAccess && !access?.adminAccess && 
          (access?.viewAccess || access?.commentAccess || access?.editAccess))
        ) {
          subfield.isDisabled = true;
        }
      });
    }
  }
}