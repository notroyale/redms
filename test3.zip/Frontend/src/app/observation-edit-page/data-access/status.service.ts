import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Status } from 'src/app/domain/status';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class StatusService {
  constructor(private http: HttpClient) { }

  public getAll(): Observable<Status[]> {
    return this.http.get<Status[]>(`${settings.apibaseUrl}/api/Status/all`);
  }
}
