export interface AddCommentActionPlanStepRequest{
    id: number;
    actionComment1LoD: string | undefined;
    actionComment1LoDDate: Date | undefined;
    actionComment1LODUser: string | undefined;
}