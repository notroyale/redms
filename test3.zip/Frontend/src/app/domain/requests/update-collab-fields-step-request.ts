export interface UpdateCollabFieldsStepRequest{
  ragStatusID: number;
  comment: string;
  comment1LoD: number;
  ragJustification: string | null;
  closureSubmitted: boolean;
}