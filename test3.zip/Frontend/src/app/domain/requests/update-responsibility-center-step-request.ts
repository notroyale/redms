export interface UpdateResponsibilityCentreStepRequest {
  activityOwner: string
  riskOwner: string
  assignee: string
  businessUnit: number
  legalEntities: number[];
}