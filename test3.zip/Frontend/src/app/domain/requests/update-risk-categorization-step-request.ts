export interface UpdateRiskCategorizationStepRequest {
  directive: string;
  businessLine: string;
  taxonomyLevel1: number;
  taxonomiesLevel2: number[];
  taxonomiesLevel3: number[];
  esgRisk : boolean;
  conductRisk : boolean;
  esgJustification : string | undefined;
  conductJustification: string | undefined;
  regulations: number[];
  regCategories: number[];
  regulationComment: string | undefined;
}