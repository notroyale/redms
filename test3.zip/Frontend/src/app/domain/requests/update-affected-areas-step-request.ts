export interface UpdateAffectedAreasStepRequest {
    affectedBusinessUnits: number[];
    // affectedBusinessAreas: number[];
    affectedLegalEntities: number[];
    affectedCountries: number[];
}