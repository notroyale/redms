export interface ObservationBaCountryReq {
  observationID: number
  businessAreaID: number
  countryID: number
}
export interface ObservationBaCountryDeleteReq {
 id:number;
 observationID: number
 businessAreaID: number
 countryID: number
}
