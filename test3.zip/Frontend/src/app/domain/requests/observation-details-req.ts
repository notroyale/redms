export interface DetailsStepReq {
  title: string;
  dateIdentified: Date | null;
  deadline: Date | null;
  categoryId: number;
  revisedDeadline: Date | null;
  gradeID: number;
  description: string | null;
  selfRaised: boolean | null;
}
