export interface ObservationAttachmentReq {
  files: Array<File>
  gdpr: boolean
}
