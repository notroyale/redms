export interface UpdateActionPlanRequest{
    id: number;
    actionTitle: string | undefined;
    actionSummary: string | undefined;
    businessAreaID: number | undefined;
    assignee: string | undefined;
    deadline: Date | undefined;
    taxonomyLevel3ID: number | undefined;
    activityOwner: string | undefined;
    actionComment: string | undefined;
    // creationUser: string | undefined;
    // creationDate: Date;
    // modifiedUser: string | undefined;
    // modifiedDate: Date;
}