export interface CloseActionPlanStepRequest{
    id: number;
    observationID: number;
    actionStatus: number; // open = 0 / close = 1
    closureUser: string | undefined;
}