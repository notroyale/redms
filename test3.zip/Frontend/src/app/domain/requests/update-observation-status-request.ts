export interface UpdateObservationStatusRequest{
    status: number;
    cancellationDate: Date | null;
    cancellationJustification: string | null;
    closureDate: Date | null;
    closureJustification: string | null
    deadlineExtensionRegistrationDate: Date | null;
    deadlineExtensionJustification: string | null;
    riskAcceptanceDate: Date | null;
    riskAcceptanceJustification: string | null;
}