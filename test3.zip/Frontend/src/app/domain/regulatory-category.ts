export interface RegulatoryCategory {
    id: number
    name:string
    taxonomyLevel3ID: number
    isActive: boolean
    appliedRegulation: string
}