import { ActionPlan } from "./action-plan";
import { Attachment } from "./attachment";
import { BusinessUnit } from "./business-unit";
import { Category } from "./category";
import { Grade } from "./grade";
import { ObservationBusinessAreaCountry } from "./observation-business-area-country";
import { ObservationLegalEntity } from "./observation-legal-entity";
import { RagStatus } from "./rag-status";
import { UpdateAffectedAreasStepRequest } from "./requests/update-affected-areas-step-request";
import { UpdateCollabFieldsStepRequest } from "./requests/update-collab-fields-step-request";
import { UpdateObservationStatusRequest } from "./requests/update-observation-status-request";
import { UpdateResponsibilityCentreStepRequest } from "./requests/update-responsibility-center-step-request";
import { UpdateRiskCategorizationStepRequest } from "./requests/update-risk-categorization-step-request";

export interface Observation {
  id: number;
  detailsStep: DetailsStep;
  responsibleCentreStep: ResponsibilityCentreStep;
  riskCategorizationStep: RiskCategorizationStep;
  collabFieldsStep: CollabFieldsStep;
  actionPlanStep: ActionPlanStep;
  affectedFieldsStep: AffectedFieldsStep;
  supportingDocumentsStep: SupportingDocuments;
  statusStep: StatusFieldsStep;
  recommendation: string | null;
  proposedPlan: string | null;
  registrationNumber: string | null;
  directive: string;
  submitted: boolean;
  deleted: boolean;
  mitigationActionComment: string | null;
  riskAssessmentId: number | null;
  ragStatusID: number;
}

export interface ObservationAccess {
  observation: Observation;
  adminAccess: boolean;
  approverAccess: boolean;
  commentAccess: boolean;
  editAccess: boolean;
  viewAccess: boolean
}

export interface UserAccess {
  adminAccess: boolean;
  approverAccess: boolean;
  commentAccess: boolean;
  editAccess: boolean;
  viewAccess: boolean
}

export interface ObservationContainer {
  detailsStep: UpdateDetailsStepRequest | undefined;
  responsibleCentreStep: UpdateResponsibilityCentreStepRequest | undefined;
  riskCategorizationStep: UpdateRiskCategorizationStepRequest | undefined;
  collabFieldsStep: UpdateCollabFieldsStepRequest | undefined;
  actionPlanStep: ActionPlanStep | undefined;
  affectedFieldsStep: UpdateAffectedAreasStepRequest | undefined;
  statusStep: UpdateObservationStatusRequest | undefined; 
}


export interface DetailsStep {
  [key: string]: any;
  title: string;
  categoryId: number;
  category: Category;
  dateIdentified: Date | null;
  creationDate: Date;
  deadline: Date | null;
  revisedDeadline: Date | null;
  gradeID: number;
  description: string | null;
  selfRaised: boolean;
  selfRaisedJustification: string | null;
}

export interface UpdateDetailsStepRequest {
  title: string;
  dateIdentified: Date | null;
  deadline: Date | null;
  categoryId: number;
  revisedDeadline: Date | null;
  gradeID: number;
  description: string | null;
  selfRaised: boolean | null;
  selfRaisedJustification: string | null;
}

export interface ResponsibilityCentreStep {
  [key: string]: any;
  businessUnit: number;
  businessAreasCountries: ObservationBusinessAreaCountry[];
  legalEntities: number[];
  activityOwner: string;
  riskOwner: string;
  assignee: string;
}

// export interface RelationshipStep {
//   [key: string]: any;
//   businessUnitId: number;
//   categoryId: number;
//   businessAreas: any;
//   legalEntities:any;
//   regulations:any;
//   regulatoryCategories:any;
//   taxonomies: any;
//   countries: any;
// }

export interface RiskCategorizationStep {
  [key: string]: any;
  taxonomies: { [key: number] : number[] };
  taxonomyLevel1: number
  businessLine: string;
  directive: string;
  regulationComment: string | undefined;
  esgRisk: boolean;
  esgJustification: string | undefined;
  conductRisk: boolean;
  conductJustification: string | undefined;
  regulations: number[];
  regulatoryCategories: number[];
}

export interface AffectedFieldsStep {
  [key: string]: any;
  businessUnitsAF: number[];
  businessAreasAF: number[];
  legalEntitiesAF: number[];
  countriesAF: number[];
}
export interface SupportingDocuments {
  [key: string]: any;
  attachments: Attachment[];
}


export interface StatusFieldsStep {
  [key: string]: any;
  status: number;
  cancellationDate: Date | null;
  cancellationJustification: string | null;
  closureDate: Date | null;
  closureJustification: string | null
  deadlineExtensionRegistrationDate: Date | null;
  deadlineExtensionJustification: string | null;
  riskAcceptanceDate: Date | null;
  riskAcceptanceJustification: string | null;
}

export interface CollabFieldsStep {
  [key: string]: any;
  ragStatus: number;
  comment: string;
  comment1LoD: number;
  ragJustification: string | null;
  closureSubmitted: boolean;

}

export interface ActionPlanStep {
  [key: string]: any;
  recommendation: string | null;
  proposedPlan: string | null;
  actionPlans: ActionPlan[];
}

export interface ObservationClosure {
  [key: string]: any;
  closureJustification: string;

}


export interface ObservationDeletion{
  [key: string]: any;
  title: string;
  description: string | null;
  assignee: string;
  deadline: Date | null;
  creationUser: Date;
  creationDate: Date;
  modifiedUser: Date;
  modifiedDate: Date;
}
