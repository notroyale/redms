export interface ActionPlan {
    id: number;
    actionTitle: string | undefined;
    actionSummary: string | undefined;
    businessAreaID: number | undefined;
    assignee: string | undefined;
    actionDeadline: Date | undefined;
    actionStatus: number;
    actionStatusColumn: any;
    actionClosureDate: Date | undefined;
    actionClosureUser: string | undefined;
    taxonomyLevel3ID: number | undefined;
    actionComment1LoD: string | undefined;
    actionActivityOwner: string | undefined;
    actionBusinessArea: string | undefined;
    taxonomyLevel3: string | undefined;
}

export enum ActionPlanStatus{
    open,
    closed
}