export interface Regulation {
    id: number
    name:string
    isActive: boolean
    hasComment: boolean
}