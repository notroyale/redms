export interface FieldHelpText {
    fieldName: string;
    helpTextValue: string;
    forNames: string;
}