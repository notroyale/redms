export interface LoginRequest {
  username: string;
}
