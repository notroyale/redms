export enum ObservationStatus {
Open = 2,
Closed = 1,
Cancelled = 3,
RiskAccepted = 4,
DeadlineExtended = 5
}
