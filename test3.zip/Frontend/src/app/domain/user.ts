export interface User {
  password: string;
  userName: string;

}
export interface UserInfo {
  bNumber:string;
  name: string;
  departament: string;
}
