export interface ObservationBusinessAreaCountry {
    id: number;
    observationID: number;
    businessArea: string;
    country: string;
}
