export interface Grade {
    id: number;
    name: string;
    isActive: boolean;
}