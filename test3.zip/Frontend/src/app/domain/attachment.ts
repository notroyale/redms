export interface Attachment {
  id: number,
  filename: string,
  deleted: boolean,
  gdpr: boolean,
  loD: string,
  observationID: number
}
