export interface ValidationInformation {
    isValid: boolean;
    invalidField: string[];
    invalidMessage: string;
    invalidType: InvalidType;
}

export enum InvalidType {
    none = 0,
    mandatory,
    date,
    custom,
}

export interface DateValidationRule {
  mainDate: string,
  greaterThan: string[],
  lesserThan: string[],
}

export interface CustomValidationRule {
  field: string,
  value: string|number|boolean
}