export interface RagStatus {
  id: number
  name:string
  color: string
  isActive: boolean
}