export interface TaxonomyLevel {
  id:number
  level: number
  name: string
  isMandatory: boolean
  isActive: boolean
}


