export interface Status {
  id: number
  name:string
  color: string
  isActive: boolean
}

export enum StatusOptions{
  Closed = 1,
  Open,
  Cancelled,
  RiskAccepted,
  DeadlineExt
}