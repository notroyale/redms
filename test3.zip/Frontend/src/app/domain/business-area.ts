import { BusinessUnit } from "./business-unit"

export interface BusinessArea {
  id: number
  name:string
  isActive:boolean
  businessUnitID: number
  businessUnit: BusinessUnit
}