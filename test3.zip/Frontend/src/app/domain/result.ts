export interface Result<T>{
    isSuccess: boolean;
    isFailure: boolean;
    value: T;
}

export interface AuthorisationResult<T>{
    AdminAccess: boolean;
    ApproverAccess: boolean;
    CommentAccess: boolean;
    EditAccess: boolean;
    ViewAccess: boolean;
    observation: T;
}