export interface Authorisation{
    name: string;
    isActive: boolean;
    shortName: string;
    description: string;
    businessUnits: string;
    legalEntities: string;
    role: string;
}

export interface LineOfDefence{
    editBU : Authorisation[];
    viewBU : Authorisation[];
    editLE : Authorisation[];
    viewLE : Authorisation[];
    groupWide : Authorisation[];
}

export interface AuthorisationList{
    firstLoD : LineOfDefence;
    secondLoD : LineOfDefence;
    thirdLoD : Authorisation[];
    grmAccess : Authorisation[];

}