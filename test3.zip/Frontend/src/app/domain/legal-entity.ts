import { BusinessUnit } from "./business-unit"

export interface LegalEntity {
  id: number
  name:string
  isActive:boolean
  businessUnitID: number
  businessUnits: BusinessUnit[]
}