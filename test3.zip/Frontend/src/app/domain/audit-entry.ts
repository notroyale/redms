export interface AuditEntry {

}