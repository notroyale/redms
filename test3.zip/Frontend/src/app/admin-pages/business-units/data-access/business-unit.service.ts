import { Injectable } from '@angular/core';
import { BusinessUnit } from 'src/app/domain/business-unit';
import { Observable } from 'rxjs';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { HttpClient } from '@angular/common/http';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class BusinessUnitService {
  constructor(private http: HttpClient) {}

  public getAll(): Observable<BusinessUnit[]> {
    return this.http.get<BusinessUnit[]>(`${settings.apibaseUrl}/api/BusinessUnit/all`);
  }

  public getAllWithFilters(skip: number, rows: number): Observable<DataTableRequest> {
    return this.http.get<DataTableRequest>(`${settings.apibaseUrl}/api/BusinessUnit/allBase/options?page=${skip}&pageSize=${rows}`);
  }

  public add(businessUnit : BusinessUnit): Observable<any>{
    return this.http.post<any>(`${settings.apibaseUrl}/api/BusinessUnit/add`, businessUnit);
  }

  public delete(businessUnitId : number): Observable<any>{
    return this.http.delete<any>(`${settings.apibaseUrl}/api/BusinessUnit/delete?Id=`+businessUnitId);
  }

  public update(businessUnit : BusinessUnit): Observable<any>{
    return this.http.put<any>(`${settings.apibaseUrl}/api/BusinessUnit/update`, businessUnit);
  }
}
