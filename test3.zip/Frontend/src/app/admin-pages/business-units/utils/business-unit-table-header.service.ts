import { Injectable } from '@angular/core';
import { Access } from 'src/app/shared/models/field';
import { FieldType } from 'src/app/shared/models/field-type';
import { Form } from 'src/app/shared/models/form';
import { InputType } from 'src/app/shared/models/input-type';
import { SortType } from 'src/app/shared/models/sort-type';
import { Table } from 'src/app/shared/models/table';
import { ColumnStyleType, ColumnType } from 'src/app/shared/models/table/column-type';

@Injectable({
  providedIn: 'root'
})
export class BusinessUnitTableHeaderService {
  getTable(): Table {
    return {
      columns: [
        { headerStyle:'common-header', for: 'id', header: 'Id',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
        { headerStyle:'common-header', for: 'code', header: 'Code',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
        { headerStyle:'common-header', for: 'name', header: 'Name',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'bold-column', sorted: SortType.None },
        { headerStyle:'common-header', for: 'isActive', header: 'Active',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.InputSwitchColumn, styleClass: 'bold-column', sorted: SortType.None
        },
        {  headerStyle:'actions-header', for: 'actions', header: 'Actions',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'right',
          type: ColumnType.ActionButtonColumn, styleClass: 'actions-column', sorted: SortType.None }
        // { headerStyle:'actions-header', for: 'actions', header: 'Actions', type: ColumnType.ActionButtonColumn,
        //   columnStyle: ColumnStyleType.Frozen, alignFrozen: 'right', styleClass: 'actions-column' }
      ],
      totalCount: 0,
      page: 1,
      rows: 5,
      first: 0
    };
  }

  getForm(): Form {
    return {
      title: 'Edit Business Unit',
      subtitle: 'Edit form',
      fields: [
        { for: "id", display: "Id", type: FieldType.Input, conditional: false, dependsOn: "",access: Access.None,
         placeholder:"", inputType: InputType.Text, styleClass: "input-custom" , mandatory:false, isDisabled: false, visible:true }, //remove it
        { for: "code", display: "Code", type: FieldType.Input, conditional: false, dependsOn: "",access: Access.None,
         placeholder:"", inputType: InputType.Text, styleClass: "input-custom", mandatory:true, isDisabled: false, visible:true },
        { for: "name", display: "Name", type: FieldType.Input, conditional: false, dependsOn: "", placeholder:"", inputType: InputType.Text, styleClass: "input-custom", mandatory:true, isDisabled: false, visible:true,access: Access.None, },
        { for: "isActive", display: "Active", type: FieldType.InputSwitch, conditional: false, dependsOn: "", styleClass: "input-custom", mandatory:true, isDisabled: false, visible:true,access: Access.None,  }
      ],
      btnLabel: 'Save'
    }
  }
}
