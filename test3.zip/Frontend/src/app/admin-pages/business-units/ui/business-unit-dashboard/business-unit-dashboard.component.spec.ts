import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessUnitDashboardComponent } from './business-unit-dashboard.component';
import { HttpClientModule } from '@angular/common/http';

describe('BusinessUnitDashboardComponent', () => {
  let component: BusinessUnitDashboardComponent;
  let fixture: ComponentFixture<BusinessUnitDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [ BusinessUnitDashboardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BusinessUnitDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
