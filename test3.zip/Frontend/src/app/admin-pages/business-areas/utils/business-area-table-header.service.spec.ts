import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { BusinessAreaTableHeaderService } from './business-area-table-header.service';

describe('BusinessAreaTableHeaderService', () => {
  let service: BusinessAreaTableHeaderService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(BusinessAreaTableHeaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
