import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BusinessArea } from 'src/app/domain/business-area';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { HttpClient, HttpParams } from '@angular/common/http';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class BusinessAreaService {
  constructor(private http: HttpClient) { }

  public update(businessArea: BusinessArea): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/BusinessArea/update`, businessArea);
  }

  public getAll(): Observable<BusinessArea[]> {
    return this.http.get<BusinessArea[]>(`${settings.apibaseUrl}/api/BusinessArea/all`);
  }

  public getBusinessAreasByBusinessUnitsIds(ids: number[]): Observable<BusinessArea[]> {
    let queryParams = new HttpParams();
    queryParams = queryParams.appendAll({'ids': ids});
 
    return this.http.get<BusinessArea[]>(`${settings.apibaseUrl}/api/BusinessArea/allByBusinessUnit?${queryParams.toString()}`);
  }
  public getDefaultBusinessArea(): Observable<BusinessArea> {
     return this.http.get<BusinessArea>(`${settings.apibaseUrl}/api/BusinessArea/default`);
  }

  public getAllWithFilters(skip: number, rows: number): Observable<DataTableRequest> {
    return this.http.get<DataTableRequest>(`${settings.apibaseUrl}/api/BusinessArea/allBase/options?page=${skip}&pageSize=${rows}`);
  }

  public add(businessArea: BusinessArea): Observable<any> {
    return this.http.post<any>(`${settings.apibaseUrl}/api/BusinessArea/add`, businessArea);
  }

  public delete(businessAreaId: number): Observable<any> {
    return this.http.delete<any>(`${settings.apibaseUrl}/api/BusinessArea/delete?Id=`+businessAreaId);
  }
}
