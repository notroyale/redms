import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { BusinessAreaService } from './business-area.service';

describe('BusinessAreaService', () => {
  let service: BusinessAreaService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });
         service = TestBed.inject(BusinessAreaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
