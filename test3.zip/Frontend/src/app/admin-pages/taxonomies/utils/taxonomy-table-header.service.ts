import { Injectable } from '@angular/core';
import { Access } from 'src/app/shared/models/field';
import { FieldType } from 'src/app/shared/models/field-type';
import { Form } from 'src/app/shared/models/form';
import { InputType } from 'src/app/shared/models/input-type';
import { SortType } from 'src/app/shared/models/sort-type';
import { Table } from 'src/app/shared/models/table';
import { ColumnStyleType, ColumnType } from 'src/app/shared/models/table/column-type';

@Injectable({
  providedIn: 'root'
})
export class TaxonomyTableHeaderService {
  getTable(): Table {
    return {
      columns: [
        { headerStyle:'common-header', for: 'id', header: 'Id',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
        { headerStyle:'common-header', for: 'name', header: 'Name',
          columnStyle: ColumnStyleType.CommonColumn,
          type: ColumnType.TextColumn, styleClass: 'bold-column min-w-small', sorted: SortType.None },
        { headerStyle:'common-header', for: 'levelID', header: 'Level',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },

        // { headerStyle:'common-header', for: 'description', header: 'Description', isFrozen: false, alignFrozen: 'left', type: ColumnType.TextColumn, styleClass: 'common-column' },
        { headerStyle:'common-header', for: 'subTaxonomies', header: 'Related Taxonomies',
          columnStyle: ColumnStyleType.DropdownInfoColumn,
          type: ColumnType.BadgeListColumn, styleClass: 'common-column max-w-large', displayAttribute:'name', sorted: SortType.None },
        { headerStyle:'common-header', for: 'isActive', header: 'Active',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.InputSwitchColumn, styleClass: 'common-column', sorted: SortType.None },
        { headerStyle:'actions-header', for: 'actions', header: 'Actions', type: ColumnType.ActionButtonColumn,
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'right', styleClass: 'actions-column', sorted: SortType.None }
      ],
      totalCount: 0,
      page: 1,
      rows: 5,
      first: 0
    };
  }

  getForm(): Form {
    return {
      title: 'Edit Taxonomy',
      subtitle: '',
      fields: [
        {
          for: "levelID", display: "Level", type: FieldType.Input, conditional: false, dependsOn: "", placeholder:"", inputType: InputType.Text, styleClass: "input-custom", mandatory:false, isDisabled: false, visible:true,access: Access.None,
        },
        {
          for: "name", display: "Name", type: FieldType.Input, placeholder:"", inputType: InputType.Text, conditional: false, dependsOn: "", styleClass: "input-custom", mandatory:false, isDisabled: false, visible:true,access: Access.None,
        },
        {
          for: "description", display: "Description", type: FieldType.Input, conditional: false, dependsOn: "", placeholder:"", inputType: InputType.Text, styleClass: "input-custom", mandatory:false, isDisabled: false, visible:true,access: Access.None,
        },
        {
          key: "subTaxonomies", displayAttribute: 'name', for: "subTaxonomies", conditional: false, dependsOn: "", display: "Related Taxonomies", type: FieldType.Multiselect, styleClass: "", filterAttribute: 'id', mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive",access: Access.None,
        },
        {
          for: "isActive", display: "Active", type: FieldType.InputSwitch, conditional: false, dependsOn: "",access: Access.None,
          styleClass: "", mandatory:false, isDisabled: false, visible:true
        }
      ],
      btnLabel: 'Save'
    }
  }
}
