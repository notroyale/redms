import {inject} from '@angular/core';
import {ActivatedRouteSnapshot, ResolveFn, Router} from '@angular/router';
import {EMPTY, of} from 'rxjs';
import {mergeMap} from 'rxjs/operators';

import { BusinessUnit } from '../domain/business-unit';
import { BusinessUnitService } from './business-units/data-access/business-unit.service';

export const businessUnitsResolver: ResolveFn<BusinessUnit[]> = (route: ActivatedRouteSnapshot) => {
  const router = inject(Router);
  const cs = inject(BusinessUnitService);
  const id = route.paramMap.get('id')!;

  return cs.getAll().pipe(mergeMap(crisis => {
    if (crisis) {
      return of(crisis);
    } else {
      router.navigate(['/']);
      return EMPTY;
    }
  }));
};
