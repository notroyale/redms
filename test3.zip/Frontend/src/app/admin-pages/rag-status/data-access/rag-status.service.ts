import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RagStatus } from 'src/app/domain/rag-status';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class RagStatusService {
  constructor(private http: HttpClient) { }

  public getAll(): Observable<RagStatus[]> {
    const url = `${settings.apibaseUrl}/api/RAGStatus/all`;
    return this.http.get<RagStatus[]>(url);
  }
}
