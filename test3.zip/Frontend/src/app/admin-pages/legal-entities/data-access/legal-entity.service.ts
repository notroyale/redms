import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { LegalEntity } from 'src/app/domain/legal-entity';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class LegalEntityService {
  constructor(private http: HttpClient) { }

  public update(legalEntity: LegalEntity): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/LegalEntity/update`, legalEntity);
  }


  public getAllWithFilters(skip: number, rows: number): Observable<DataTableRequest> {
    return this.http.get<DataTableRequest>(`${settings.apibaseUrl}/api/LegalEntity/allBase/options?page=${skip}&pageSize=${rows}`);
  }

  public getAll(): Observable<LegalEntity[]> {
    return this.http.get<LegalEntity[]>(`${settings.apibaseUrl}/api/LegalEntity/all`);
  }

  public getLegalEntitiesByBusinessUnitsIds(ids: number[]): Observable<LegalEntity[]> {
    let queryParams = new HttpParams();
    queryParams = queryParams.appendAll({'ids': ids});
 
    return this.http.get<LegalEntity[]>(`${settings.apibaseUrl}/api/LegalEntity/allByBusinessUnit?${queryParams.toString()}`);
  }

  public add(legalEntity: LegalEntity): Observable<any> {
    return this.http.post<any>(`${settings.apibaseUrl}/api/LegalEntity/add`, legalEntity);
  }

  
  public delete(legalEntityId: number): Observable<any> {
    return this.http.delete<any>(`${settings.apibaseUrl}/api/LegalEntity/delete?Id=`+legalEntityId);
  }
}
