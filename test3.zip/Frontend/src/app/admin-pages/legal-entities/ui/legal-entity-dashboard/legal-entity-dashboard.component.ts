import { ChangeDetectionStrategy, Component } from '@angular/core';
import { Observable, Subject, combineLatest, finalize, map, of } from 'rxjs';
import { LegalEntityService } from '../../data-access/legal-entity.service';
import { BusinessUnit } from 'src/app/domain/business-unit';
import { BusinessUnitService } from 'src/app/admin-pages/business-units/data-access/business-unit.service';
import { LazyLoadEvent } from 'primeng/api';
import { LegalEntityTableHeaderService } from '../../utils/legal-entity-table-header.service';
import { SideBySide } from 'src/app/shared/models/side-by-side';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { DataForm } from 'src/app/shared/models/data-form';
import { Form } from 'src/app/shared/models/form';
import { Table } from 'src/app/shared/models/table';
import { FieldType } from 'src/app/shared/models/field-type';
import { SideBySideComponent } from 'src/app/shared/components/side-by-side/side-by-side.component';
import { DataTable } from 'src/app/shared/models/data-table';
import { TableType } from 'src/app/shared/models/table-type';
import { Access } from 'src/app/shared/models/field';

@Component({
  selector: 'app-legal-entity-dashboard',
  templateUrl: './legal-entity-dashboard.component.html',
  styleUrls: ['./legal-entity-dashboard.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LegalEntityDashboardComponent {
  sideBySide$ = new Subject<SideBySide>();
  table: Table;
  form: Form;

  onInit = true; // Flag to prevent onInit lazy load
  loading = true; // Flag to prevent multiple requests

  businessUnits$: Observable<BusinessUnit[]>;

  constructor(
    private businessUnitService: BusinessUnitService,
    private legalEntityService: LegalEntityService,
    private legalEntityTableHeaderService: LegalEntityTableHeaderService
  ) {}

  lazyObservationsLoad($event: LazyLoadEvent) {
    if (this.onInit) {
      this.onInit = false;
      return;
    }

    const first = $event.first || this.table.first;
    const rows = $event.rows || this.table.rows;

    this.fetchData(first, rows);
  }

  ngOnInit(): void {
    this.table = this.legalEntityTableHeaderService.getTable();
    this.form = this.legalEntityTableHeaderService.getForm();
    this.fetchData(this.table.first, this.table.rows);
  }

  fetchData(first: number, rows: number) {
    this.loading = true;

    combineLatest([
      this.legalEntityService.getAllWithFilters(first + 1, rows),
      this.businessUnitService.getAll(),
    ])
      .pipe(
        finalize(() => {
          this.loading = false;
        }),
        map(([data, dropdownData]) => ({
          dataTable: this.mapTableData(this.table, data, dropdownData),
          dataForm: this.mapFormData(this.form, dropdownData),
          type: TableType.filtered
        }))
      )
      .subscribe((response) => {
        this.sideBySide$.next(response);
      });
  }

  mapTableData(table: Table, request: DataTableRequest, leDropData: any[]): DataTable {
    return {
      data: request.values,
      formFilters: {
        fields: [{
          key: 'bus',
          access: Access.None,
          display: 'Name',
          for: 'name',
          type: FieldType.Dropdown,
          conditional: false,
          dependsOn: "",
          styleClass: '',
          filterAttribute: 'id',
          displayAttribute: 'name',
          mandatory:false,
          isDisabled:false,
          visible:true,
          disableAttribute:""
        }],
        filters:
        {
          legalEntities: leDropData
        },
        selectedFilters: {}
      },
      table: {
        totalCount: request.totalCount,
        page: request.page,
        columns: table.columns,
        rows: table.rows,
        first: table.first,
      },
    };
  }

  mapFormData(form: Form, dropdownsData: any[]): DataForm {
    return {
      form: form,
      data: {},
      dropdownsData: {
        businessUnits: dropdownsData,
      },
    };
  }
  editEntry(data:any){
    this.legalEntityService.update(data).subscribe();
  }
}
