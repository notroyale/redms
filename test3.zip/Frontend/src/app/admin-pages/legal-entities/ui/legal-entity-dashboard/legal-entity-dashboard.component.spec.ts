import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LegalEntityDashboardComponent } from './legal-entity-dashboard.component';
import { HttpClientModule } from '@angular/common/http';

describe('LegalEntityDashboardComponent', () => {
  let component: LegalEntityDashboardComponent;
  let fixture: ComponentFixture<LegalEntityDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [ LegalEntityDashboardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LegalEntityDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
