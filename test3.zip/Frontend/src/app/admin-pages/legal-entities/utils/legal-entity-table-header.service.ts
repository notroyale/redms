import { Injectable } from '@angular/core';
import { Access } from 'src/app/shared/models/field';
import { FieldType } from 'src/app/shared/models/field-type';
import { Form } from 'src/app/shared/models/form';
import { InputType } from 'src/app/shared/models/input-type';
import { SortType } from 'src/app/shared/models/sort-type';
import { Table } from 'src/app/shared/models/table';
import { ColumnStyleType, ColumnType } from 'src/app/shared/models/table/column-type';

@Injectable({
  providedIn: 'root'
})
export class LegalEntityTableHeaderService {
  getTable(): Table {
    return {
        columns: [
        {
          headerStyle:'common-header', for: 'id', header: 'Id',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None
        },
        {
          headerStyle:'common-header', for: 'name', header: 'Name',
          columnStyle: ColumnStyleType.CommonColumn,
          type: ColumnType.TextColumn, styleClass: 'bold-column', sorted: SortType.None
        },
        {
          headerStyle:'common-header', for: 'businessUnits', header: 'Business Units',
          columnStyle: ColumnStyleType.DropdownInfoColumn,
          type: ColumnType.BadgeListColumn, styleClass: 'common-column', displayAttribute: 'name', sorted: SortType.None


        },
        {
          headerStyle:'common-header', for: 'isActive', header: 'Active',
          columnStyle: ColumnStyleType.CommonColumn,
          type: ColumnType.InputSwitchColumn, styleClass: 'bold-column',
          sorted: SortType.None
        },
        {
          headerStyle:'actions-header', for: 'actions', header: 'Actions',
          type: ColumnType.ActionButtonColumn, columnStyle:
          ColumnStyleType.Frozen, alignFrozen: 'right', styleClass: 'actions-column', sorted: SortType.None
        }
      ],
      totalCount: 0,
      page: 1,
      rows: 5,
      first: 0
    }
  }

  getForm(): Form {
    return {
      title: 'Edit Legal Entity',
      subtitle: '',
      fields: [
        {
          for: "id", display: "Id", type: FieldType.Input, placeholder:"", inputType: InputType.Text, conditional: false, dependsOn: "",access: Access.None,
           styleClass: "input-custom", mandatory:false, isDisabled: false, visible:true, //remove it
        },
        {
          for: "name", display: "Name", type: FieldType.Input, placeholder:"", inputType: InputType.Text, conditional: false, dependsOn: "",access: Access.None,
           styleClass: "input-custom", mandatory:true, isDisabled: false, visible:true,
        },
        {
          key: "businessUnits", displayAttribute: 'name', for: "businessUnits", conditional: false, dependsOn: "",access: Access.None,
           display: "Business Unit", type: FieldType.Multiselect, styleClass: "", filterAttribute: 'id', mandatory:true, isDisabled: false, visible:true, disableAttribute:"isActive"
        },
        {
          for: "isActive", display: "Active", type: FieldType.InputSwitch, conditional: false, dependsOn: "",access: Access.None,
           styleClass: "",mandatory:true, isDisabled: false, visible:true        }
      ],
      btnLabel: 'Save'
    }
  }
}
