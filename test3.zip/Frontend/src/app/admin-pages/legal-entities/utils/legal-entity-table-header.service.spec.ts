import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { LegalEntityTableHeaderService } from './legal-entity-table-header.service';

describe('LegalEntityTableHeaderService', () => {
  let service: LegalEntityTableHeaderService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(LegalEntityTableHeaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
