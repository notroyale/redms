import { Injectable } from '@angular/core';
import { OidcClientNotification, UserDataResult } from 'angular-auth-oidc-client';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdfsService {
  userDataChanged$: Observable<OidcClientNotification<any>>;
  userData$: Observable<UserDataResult>;

  public constructor() {
    this.configureSingleSignOn();
  }

  configureSingleSignOn() {
    
  }

  getToken(){
    
  }
}