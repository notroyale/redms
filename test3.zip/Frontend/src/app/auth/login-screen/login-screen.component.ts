import { Component, OnInit } from '@angular/core';
import { AuthService } from '../data-access/auth.service';
import { Router } from '@angular/router';
import { StorageService } from 'src/app/storage/data-access/storage.service';
import { LoginRequest } from 'src/app/domain/login-request';
import { User } from 'src/app/domain/user';
import { FormBuilder } from '@angular/forms';
import { OidcSecurityService } from 'angular-auth-oidc-client';

@Component({
  selector: 'app-login-screen',
  templateUrl: './login-screen.component.html',
  styleUrls: ['./login-screen.component.css']
})
export class LoginScreenComponent implements OnInit {

  // form: any = {
  //   username: null,
  //   password: null
  // };

  loginForm = this.formBuilder.group({
    username: null,
    password: null
  });


  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
  roles: string[] = [];
  user: User;

  public loginRequest: LoginRequest;
    public loginResponse: string = "";
  constructor(private authService: AuthService, private storageService: StorageService, private router: Router,private formBuilder: FormBuilder,
    private oidcSecurityService: OidcSecurityService) { }

  ngOnInit(): void {
    //this.oidcSecurityService.authorize();
    // if (this.storageService.isLoggedIn()) {
    //   this.isLoggedIn = true;
    //   // this.roles = this.storageService.getUser().roles;
    //   this.router.navigate(['./observation-dashboard']);
    // }
  }
  onSubmit(): void {
    this.oidcSecurityService.authorize();
    // if (this.loginForm.valid) {
    //   let formData = Object.assign({});
    //   formData = Object.assign(formData, this.loginForm.value);
    //   this.user = (this.loginForm.value.username ,formData.password );
    //   this.authService.login(this.user);
    // }
    // this.loginRequest = this.form;

  }
  reloadPage(): void {
    window.location.reload();
  }


}
