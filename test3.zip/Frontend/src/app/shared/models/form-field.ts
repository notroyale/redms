import { BaseField } from "./field";
import { FieldType } from "./field-type";
import { Form } from "./form";

export interface FormField extends BaseField {
  type: FieldType.Form;
  form: Form;
}
