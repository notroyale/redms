import { DataTable } from "./data-table";
import { BaseField } from "./field";
import { FieldType } from "./field-type";
import { Table } from "./table";
import { Column } from "./table/column";

export interface TableField extends BaseField {
    displayAttribute: string;
    key: string;
    type: FieldType.Table;
    table: Table;
}