import { BaseField } from "./field";
import { FieldType } from "./field-type";

export interface FileUploadField extends BaseField {
    type: FieldType.FileUpload;
}
