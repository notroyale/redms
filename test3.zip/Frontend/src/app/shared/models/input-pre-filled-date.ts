import { BaseField } from "./field";
import { FieldType } from "./field-type";
import { InputType } from "./input-type";

export interface InputPreFilledDate extends BaseField {
  type: FieldType.InputPreFilledDate;
  inputType: InputType;
  placeholder: string;
}