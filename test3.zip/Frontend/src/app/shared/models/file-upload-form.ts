import { BaseField } from "./field";
import { FieldType } from "./field-type";
import { FileUploadForm } from "./file-upload-form-field";

export interface FileUploadFormField extends BaseField {
  type: FieldType.FileUploadForm;
  form: FileUploadForm;
}
