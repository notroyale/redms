export enum InputType {
    Text = "text",
    Date = "date",
    Number = "number",
  }