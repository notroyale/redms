import { FieldHelpText } from "src/app/domain/field-help-text";
import { Form } from "./form";

export interface DataForm{
    form: Form;
    data : any;
    dropdownsData: { [key: string] : any[] };
  }