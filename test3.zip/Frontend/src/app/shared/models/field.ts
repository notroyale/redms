import { DropdownField } from "./dropdown-field";
import { DropdownLevelsField } from "./dropdown-levels-field";
import { FieldType } from "./field-type";
import { InputField } from "./input-field";
import { InputSwitch } from "./input-switch";
import { MultiselectField } from "./multiselect-field";
import { MultiselectLevelsField } from "./multiselect-levels-field";
import { TableField } from "./table-field";
import { TextareaField } from "./textarea-field";
import { ModalField } from "./modal";
import { InputDatepickerField } from "./input-datepicker-field";
import { FormField } from "./form-field";
import { BinaryDropdownField } from "./binary-dropdown-options";
import { FileUploadField } from "./file-upload";
import { FileUploadFormField } from "./file-upload-form";
import { UserinfoService } from "../services/user-info/user-info.service";
import { UserInfoField } from "./user-info";
import { CheckboxField } from "./checkbox";
import { InputPreFilledDate } from "./input-pre-filled-date";

export interface BaseField {
    for: string;
    display: string;
    type: FieldType;
    styleClass: string;
    mandatory:boolean;
    visible: boolean;
    dependsOn: string;
    conditional: boolean;
    isDisabled: boolean;
    access: Access;
    helpText?:string;
}

export enum Access {
  AdminAccess,
  ApproverAccess,
  CommentAccess,
  EditAccess,
  ViewAccess,
  None
}

export type Field = DropdownField | TextareaField |
    InputField | InputSwitch | MultiselectField |
    TableField | MultiselectLevelsField | DropdownLevelsField |
    ModalField | InputDatepickerField | FormField | 
    BinaryDropdownField | FileUploadField | FileUploadFormField | 
    UserInfoField | CheckboxField | InputPreFilledDate;
