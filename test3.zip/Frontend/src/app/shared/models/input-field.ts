import { BaseField } from "./field";
import { FieldType } from "./field-type";
import { InputType } from "./input-type";

export interface InputField extends BaseField {
  type: FieldType.Input;
  inputType: InputType;
  placeholder: string;
}