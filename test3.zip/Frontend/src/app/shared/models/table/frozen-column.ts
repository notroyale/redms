import { BaseColumn } from "./base-column";
import { ColumnStyleType, ColumnType } from "./column-type";

export interface FrozenColumn extends BaseColumn {
  columnStyle: ColumnStyleType.Frozen;
  alignFrozen: "left" | "right";
}

export interface FrozenDropdownInfoColumn extends FrozenColumn {
  display: string;
  type: ColumnType.BadgeListColumn;
}