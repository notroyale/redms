export enum ColumnType {
  TextColumn,
  DateColumn,
  DropdownOptLabelColumn,
  ChipColumn,
  BadgeColumn,
  ActionButtonColumn,
  ActionButtonObs,
  InputSwitchColumn,
  BadgeListColumn,
  ButtonColumn,
  DownloadFileColumn,
  BARemovalColumn,
  DeleteFileColumn
}

export enum ColumnStyleType {
  Frozen,
  DropdownInfoColumn,
  CommonColumn,
  FrozenDropdownInfoColumn
}
