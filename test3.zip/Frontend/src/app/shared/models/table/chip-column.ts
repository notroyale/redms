import { BaseColumn } from "./base-column";
import { ColumnType } from "./column-type";

export interface ChipColumn extends BaseColumn {
  displayAttribute: string;
  colorAttribute: string;
  type: ColumnType.ChipColumn;
}
