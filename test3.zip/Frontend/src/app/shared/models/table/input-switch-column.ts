import { BaseField } from "../field";

export interface InputSwitchColumn extends BaseField  {

}