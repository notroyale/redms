import { BaseField } from "../field";

export interface ButtonColumn extends BaseField  {

}