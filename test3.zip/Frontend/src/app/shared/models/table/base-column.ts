import { SortType } from "../sort-type";
import { ColumnStyleType, ColumnType } from "./column-type";

export interface BaseColumn {
    headerStyle: string;
    for: string;
    header: string;
    columnStyle: ColumnStyleType;
    type: ColumnType;
    styleClass: string;
    sorted: SortType;

}
