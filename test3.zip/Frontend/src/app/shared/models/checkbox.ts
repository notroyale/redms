import { BaseField } from "./field";
import { FieldType } from "./field-type";

export interface CheckboxField extends BaseField {
  type: FieldType.Checkbox;

}