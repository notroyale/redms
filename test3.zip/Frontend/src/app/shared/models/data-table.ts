import { Filter, FormFilter } from "./filter";
import { AccessTable, Table } from "./table";

export interface DataTable{
    data: any[];
    formFilters: FormFilter;
    table: Table;
}

export interface AccessDataTable{
    data: any[];
    formFilters: FormFilter;
    table: AccessTable;
}