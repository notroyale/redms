
export interface FileMetadata  {
  id: number
  uploaderRole:string
}
