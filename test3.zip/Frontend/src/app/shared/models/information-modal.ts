export interface InformationModal{
    header: string;
    body: string;
    buttonType: InfoButtons;
    okButtonTitle: string;
    cancelButtonTitle?: string;
}

export enum InfoButtons{
    ok,
    okCancel,
    okCancelNormal
}