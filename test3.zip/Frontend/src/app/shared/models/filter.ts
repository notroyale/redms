import { FiltersModel } from "src/app/observations-home-page/data-access/repository.service";
import { Field } from "./field";
import { UserAccess } from "src/app/domain/observation";

export interface Filter{
    field: Field;
    data: any[];
}

export interface FormFilter{
    access?: UserAccess;
    fields: Field[];
    filters: { [key: string] : any[] };
    selectedFilters : any;
}