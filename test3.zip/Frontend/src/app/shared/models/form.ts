import { Field } from "./field";

export interface Form{
    title: string;
    subtitle: string;
    fields: Field[];
    btnLabel: string;
    isDisabled?: boolean;
}

export interface SideForm extends Form {
  sideFormTitle: string;
  formFields: Field[];
}
