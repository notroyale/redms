import { BaseField } from "./field";
import { FieldType } from "./field-type";

export interface MultiselectField extends BaseField {
    displayAttribute: string;
    key: string;
    disableAttribute: string;
    filterAttribute: any;
    type: FieldType.Multiselect;
    selectedFilters?:any;
    hasNone?: boolean;
}