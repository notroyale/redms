export interface BinaryDropdownOption {
    title: string;
    value: boolean;
}

import { BaseField } from "./field";
import { FieldType } from "./field-type";

export interface BinaryDropdownField extends BaseField {
    displayAttribute: string;
    filterAttribute: any;
    justificationField: string;
    type: FieldType.BinaryDropdown;
    selectedFilters? : [];
    hasNone?: boolean;
}