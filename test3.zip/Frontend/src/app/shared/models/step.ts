export interface Step {
    index: number;
    title: string;
    subtitle: string;
    status: string;
    route: string;
}