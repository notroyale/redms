import { BaseField } from "./field";
import { FieldType } from "./field-type";

export interface DropdownField extends BaseField {
    displayAttribute: string;
    disableAttribute:string;
    key: string;
    filterAttribute: any;
    type: FieldType.Dropdown;
    selectedFilters? : [];
    hasNone?: boolean;
}
