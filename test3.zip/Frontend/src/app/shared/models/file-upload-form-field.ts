import { Field } from "./field";

export interface FileUploadForm {
  title: string;
  subtitle: string;
  fields: Field[];
  btnLabel: string;
}
