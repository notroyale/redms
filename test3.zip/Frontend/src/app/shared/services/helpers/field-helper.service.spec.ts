import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { FieldHelperService } from './field-helper.service';

describe('FieldHelperService', () => {
  let service: FieldHelperService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(FieldHelperService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
