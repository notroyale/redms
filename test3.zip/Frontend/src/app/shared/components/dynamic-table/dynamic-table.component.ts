import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, ViewEncapsulation } from '@angular/core';
import { DataTable } from '../../models/data-table';
import { ColumnStyleType, ColumnType } from '../../models/table/column-type';
import { LazyLoadEvent } from 'primeng/api';
import { ObservationAccess } from 'src/app/domain/observation';

@Component({
  selector: 'app-dynamic-table',
  templateUrl: './dynamic-table.component.html',
  styleUrls: ['./dynamic-table.component.css'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DynamicTableComponent {
  @Input() tableData: DataTable;
  @Input() loading: boolean;
  @Input() overlayPanelVisible: boolean;
  @Input() access: ObservationAccess | null;

  @Output() lazyEvent = new EventEmitter();
  @Output() onEditItemEvent = new EventEmitter();
  @Output() onCloseItemEvent = new EventEmitter();
  @Output() onDeleteItemEvent = new EventEmitter();
  @Output() onDownloadActionEvent = new EventEmitter();
  @Output() onBaDeleteActionEvent = new EventEmitter();
  @Output() onFileDeleteActionEvent = new EventEmitter();

  isMenuVisible: boolean = false;
  columnType = ColumnType;
  columnStyleType = ColumnStyleType;

  lazyLoad($event: LazyLoadEvent) {
    $event.first = ($event.first || 0) / this.tableData.table.rows + 1;
    this.lazyEvent.emit($event);
  }

  on($isMenuVisible: boolean) {
    this.isMenuVisible = $isMenuVisible;
  }
  test() {
  }

}
