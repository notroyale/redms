import { Component, EventEmitter, Input, Output } from '@angular/core';
import { DataTable } from '../../models/data-table';
import { DataForm } from '../../models/data-form';

@Component({
  selector: 'app-filtered-table',
  templateUrl: './filtered-table.component.html',
  styleUrls: ['./filtered-table.component.css']
})
export class FilteredTableComponent {
  @Input() dataTable: DataTable;
  @Input() dataForm: DataForm;

  @Input() loading: boolean;
  @Input() overlayPanelVisible: boolean;

  @Output() lazyEvent = new EventEmitter();
  @Output() onEditItemEvent = new EventEmitter();
  @Output() filtersChange = new EventEmitter<any>();

  isMenuVisible: boolean = false;

  on($isMenuVisible: boolean) {
    this.isMenuVisible = $isMenuVisible;
  }

  onFiltersChange(filters:any) {
    this.filtersChange.emit(filters);
  }

}
