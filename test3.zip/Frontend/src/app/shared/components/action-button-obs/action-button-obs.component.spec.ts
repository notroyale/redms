import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionButtonObsComponent } from './action-button-obs.component';
import { MessageService } from 'primeng/api';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { MenuModule } from 'primeng/menu';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';



describe('ActionButtonObsComponent', () => {
  let component: ActionButtonObsComponent;
  let fixture: ComponentFixture<ActionButtonObsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[OverlayPanelModule,MenuModule,BrowserAnimationsModule],
      declarations: [ ActionButtonObsComponent ],
      providers:[MessageService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ActionButtonObsComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
