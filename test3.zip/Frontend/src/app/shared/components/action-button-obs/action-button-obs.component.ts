import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem, MessageService } from 'primeng/api';

@Component({
  selector: 'app-action-button-obs',
  templateUrl: './action-button-obs.component.html',
  styleUrls: ['./action-button-obs.component.css']
})
export class ActionButtonObsComponent implements OnInit {
  @Input() item: any;
  @Input() overlayPanelVisible: boolean;
  isMenuVisible : boolean = false;
  @Output() onEditActionEvent = new EventEmitter();
  @Output() onDeleteActionEvent = new EventEmitter();
  items: MenuItem[];

  constructor(private messageService: MessageService, private router: Router) { }

  ngOnInit() {
    this.items = [
      {
        label: 'Options',
        items: [
          {
            label: 'Update',
            icon: 'pi pi-refresh',
            command: () => {
              this.update(this.item.id);
            }
          },
          // {
          //   label: 'Delete',
          //   icon: 'pi pi-times',
          //   command: () => {
          //     this.delete(this.item.id);
          //   }
          // }
          {
            label: 'Audit',
            icon: 'pi pi-eye',
            command: () => {
              this.audit(this.item.id);
            }
          },
        ]
      }
    ];
  }

  toggle(){
    if(!this.overlayPanelVisible){
      this.overlayPanelVisible = true;
    }
  }

  update(observationId: any) {
    this.overlayPanelVisible = false;
    const url = `/edit-observation/${observationId}`;
    this.router.navigate([url]);

    // this.onEditActionEvent.emit(this.overlayPanelVisible);
  }

  audit(observationId: any) {
    this.overlayPanelVisible = false;
    const url = `/observation-audit-log/${observationId}`;
    this.router.navigate([url]);
  }

  delete(observationId: any) {
    this.onDeleteActionEvent.emit();
    const summary = `Deleted observation ${observationId}`;
    this.messageService.add({ severity: 'warn', summary: summary, detail: 'Observation Deleted' });
  }
}

