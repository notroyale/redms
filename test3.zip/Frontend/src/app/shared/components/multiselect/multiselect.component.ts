import { ChangeDetectionStrategy, Component, ElementRef, EventEmitter, HostListener, Input, OnInit, Output, Renderer2 } from '@angular/core';
import { MultiselectField } from '../../models/multiselect-field';

@Component({
  selector: 'app-multiselect',
  templateUrl: './multiselect.component.html',
  styleUrls: ['./multiselect.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MultiselectComponent implements OnInit {
  @Input() field: MultiselectField;
  @Input() options: any[] = [];
  @Input() selectedOptions: any[] = [];
  
  @Output() selectedOptionOnChange = new EventEmitter<any[]>();

  show: boolean = false;


  constructor(private elRef: ElementRef, private renderer: Renderer2) { }

  ngOnInit(): void {
    this.emitSelectedOptionOnChange();
  }

  private isClickInsideComponent(target: any): boolean {
    const clickedInside = this.elRef.nativeElement.contains(target);
    return clickedInside;
   }

   @HostListener('document:click', ['$event'])
    handleClick(event: Event) {
      if (!this.isClickInsideComponent(event.target) && this.show == true) {
        this.show = false;
      }
    }
    
  displaySelectedItems() : any[] {
    if(!this.options || !this.selectedOptions){
      this.selectedOptions = [];
      return this.selectedOptions;
    }
    
    return this.options.filter(opt => this.selectedOptions
      .some(selOpt => opt[this.field.filterAttribute] === selOpt))
    .map(opt => opt[this.field.displayAttribute]);
  }

  toggleSelection(option: any) : void {
    if(!this.selectedOptions){
      this.selectedOptions = [];
      this.selectedOptions.push(option[this.field.filterAttribute]);
      return;
    }

    const exists = 
      this.selectedOptions
        .some(opt => opt === option[this.field.filterAttribute]);

    if(exists){
      var index = this.selectedOptions.findIndex((elt) => elt === option[this.field.filterAttribute]);
      this.selectedOptions.splice(index, 1);
      this.emitSelectedOptionOnChange();
      
      return;
    }

    this.selectedOptions.push(option[this.field.filterAttribute]);
    this.emitSelectedOptionOnChange();
  }

  emitSelectedOptionOnChange() : void{
    this.selectedOptionOnChange.emit(this.selectedOptions);
  }

  isInvalid() : boolean{
    return this.field.mandatory && this.selectedOptions && this.selectedOptions.length == 0;
  }

  public isEmpty() : boolean{
    return this.options.length === 0;
  }

  hasAnySelection() : boolean{
    return this.selectedOptions && this.selectedOptions.length > 0;
  }

  isChecked(option: any) : boolean{
    return this.selectedOptions && this.selectedOptions.some(opt => opt === option[this.field.filterAttribute]);
  }

  toggle() : void {
    this.show = !this.show;
  }
}