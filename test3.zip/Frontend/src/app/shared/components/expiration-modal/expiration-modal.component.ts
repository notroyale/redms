import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-expiration-modal',
  templateUrl: './expiration-modal.component.html',
  styleUrls: ['./expiration-modal.component.css']
})
export class ExpirationModalComponent {
  @Input() showDialog: boolean;

  constructor(){}

  toggleSwitch() {
    window.location.reload();
  }
}
