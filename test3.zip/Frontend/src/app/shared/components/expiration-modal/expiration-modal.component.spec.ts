import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpirationModalComponent } from './expiration-modal.component';

describe('ExpirationModalComponent', () => {
  let component: ExpirationModalComponent;
  let fixture: ComponentFixture<ExpirationModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExpirationModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ExpirationModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
