import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChipColumnComponent } from './chip-column.component';

describe('ChipColumnComponent', () => {
  let component: ChipColumnComponent;
  let fixture: ComponentFixture<ChipColumnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChipColumnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChipColumnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
