import { Component, Input } from '@angular/core';
import { Step } from '../../models/step';
import { Router } from '@angular/router';

@Component({
  selector: 'app-steps',
  templateUrl: './steps.component.html',
  styleUrls: ['./steps.component.css'],
})
export class StepsComponent {
  @Input() fields: any;
  @Input() data: any;
  isStepActive: boolean;
  @Input() currentSectionName: string;

  setActive($event: any) {
  }


  currentSection = "";
  constructor(private router: Router) {

  }

  onSectionChange(sectionId: string) {
    this.currentSection = sectionId
    this.steps.filter(step => step.route !== sectionId).map(step => step.status = "upcoming")
    this.steps.filter(step => step.route === sectionId).map(step => step.status = "current")
    this.router.navigate([],{fragment: sectionId});
  }

  scrollTo(section: string, index: number) {
    document.querySelector("#"+ section)?.scrollIntoView();
    this.router.navigate([],{fragment: section});
    this.steps.filter(step => step.index !== index).map(step => step.status = "upcoming")
    this.steps.filter(step => step.index === index).map(step => step.status = "current")
  }

  steps: Step[] = [
    {
      index: 1,
      title: 'General',
      subtitle: 'Add basic information',
      status: 'current',
      route: 'details',
    },
    {
      index: 2,
      title: 'Responsibility Centre',
      subtitle: 'Add ownership related information',
      status: 'upcoming',
      route: 'responsibility-centre',
    },
    {
      index: 3,
      title: 'Risk Categorization',
      subtitle: 'Add Risk Categorization related information',
      status: 'upcoming',
      route: 'risk-categorization',
    },
    {
      index: 4,
      title: 'Affected Areas',
      subtitle: 'Add affected fields by this observation',
      status: 'upcoming',
      route: 'affected-fields',
    },
    {
      index: 5,
      title: 'Collaboration Fields',
      subtitle: 'Collaboration Fields details & information',
      status: 'upcoming',
      route: 'collab-fields',
    },
    {
      index: 6,
      title: 'Action Plan',
      subtitle: 'Action plans for risk mitigation',
      status: 'upcoming',
      route: 'action-plan',
    }
    // {
    //   index: 7,
    //   title: 'Supporting Documents',
    //   subtitle: 'Attachments & Supporting Documents',
    //   status: 'upcoming',
    //   route: 'additional-details',
    // }
    // {
    //   index: 8,
    //   title: 'AD',
    //   subtitle: 'Fields for admin editing',
    //   status: 'upcoming',
    //   route: 'admin-fields',
    // },

  ];
}
