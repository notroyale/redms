import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { InputField } from '../../models/input-field';
import { InputType } from '../../models/input-type';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InputComponent implements OnInit {

  ngOnInit(): void {
    if(this.field.conditional && this.field.dependsOn==="")
      this.onChange();
  }

  @Input() field: InputField;
  @Input() data: any = {};
  
  @Output() dataChange = new EventEmitter<any>();
  
  inputType = InputType;

  onDateChange(date: string) {
    this.data = date;
    this.dataChange.emit(date);
  }

  onChange(){
    this.dataChange.emit(this.data);
  }

  onKey(event: any) { // without type info
  }
}