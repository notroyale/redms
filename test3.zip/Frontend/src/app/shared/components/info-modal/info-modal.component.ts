import { Component, EventEmitter, Input, Output } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { InfoButtons, InformationModal } from 'src/app/shared/models/information-modal';

@Component({
  selector: 'app-info-modal',
  templateUrl: './info-modal.component.html',
  styleUrls: ['./info-modal.component.css']
})
export class InfoModalComponent {
  
  @Input() isVisable: BehaviorSubject<boolean>;
  @Input() infoFields: InformationModal;
  @Output() onOkButtonEvent= new EventEmitter();
  @Output() onCancelButtonEvent= new EventEmitter();

  toggleModal(){
    this.isVisable.next(!this.isVisable)
  }

  onCancel(){
    this.onCancelButtonEvent.emit();
    this.toggleModal();
  }

  onOk(){
    this.onOkButtonEvent.emit();
    this.toggleModal();
  }
}
