import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, ViewEncapsulation } from '@angular/core';
import { LazyLoadEvent } from 'primeng/api';
import { BusinessUnit } from 'src/app/domain/business-unit';
import { FrozenColumn } from '../../models/table/frozen-column';
import { Column } from '../../models/table/column';

@Component({
  selector: 'app-editable-table',
  templateUrl: './editable-table.component.html',
  styleUrls: ['./editable-table.component.css'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EditableTableComponent {
  @Input() columns: Column[] = [];
  @Input() data: any[] = [];
  @Input() totalRecords: number;
  @Input() rows: number;
  @Input() first: number;
  @Input() loading: boolean;
  @Input() idField: any;
  inputElem: string = "text";
  optionLabel2: string = "year";
  addRowEnabled: boolean;
  editing: boolean;
  private clonedItems: { [s: string]: BusinessUnit } = {};

  @Output() lazyEvent = new EventEmitter();
  @Output() editItemEvent = new EventEmitter();


  loadLazyData($event: LazyLoadEvent) {
    $event.first = ($event.first || 0) / this.rows +1;
    this.lazyEvent.emit($event);
  }

  // onRowSaveEmit(businessArea: BusinessUnit){
  //   this.onRowSave.emit(businessArea);
  // }

  onRowEditInitEmit(item: BusinessUnit){
    this.clonedItems[item.id] = { ...item };
    this.editItemEvent.emit(item);
    // if (item.id == 0)
    //   this.setAddRowEnabled(false);
  }


  onRowDeleteEmit(selectedItemID: number){
    this.data = this.data.filter(
      (val) => val.id !== selectedItemID
    );

    //this.setAddRowEnabled(true);
    this.onRowDeleteEmit(selectedItemID);
  }


  onRowEditCancelEmit(selectedItemID: number){
    if (!this.addRowEnabled) {
      this.data = this.data.filter(
        (val) => val.id !== selectedItemID
      );

      // if (selectedItemID == 0)
      //   this.setAddRowEnabled(true);
    }
  }
}
