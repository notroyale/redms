import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.css']
})
export class CheckboxComponent {
  @Input() label: string;
  @Input() isChecked: boolean = false;

  @Output() dataChange = new EventEmitter<any>();
  
  @Output() isCheckedChange = new EventEmitter<boolean>();
 
  toggleCheck() {
    this.isChecked = !this.isChecked;
    this.dataChange.emit(this.isChecked);
    this.isCheckedChange.emit(this.isChecked);
  }

}
