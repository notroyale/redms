import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-download-file-column',
  templateUrl: './download-file-column.component.html',
  styleUrls: ['./download-file-column.component.css']
})
export class DownloadFileColumnComponent {

  @Output() onDownloadActionEvent = new EventEmitter();

  download() {
    this.onDownloadActionEvent.emit();
  }

}
