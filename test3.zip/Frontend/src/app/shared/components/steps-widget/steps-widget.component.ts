import { Component, Input, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Step } from '../../models/step';

@Component({
  selector: 'app-steps-widget',
  templateUrl: './steps-widget.component.html',
  styleUrls: ['./steps-widget.component.css']
})
export class StepsWidgetComponent implements OnInit {
  @Input() fields: any;
  @Input() data: any;
  @Input() currentSectionName: string;

  isStepActive: boolean;
  entryCount = 0;
  trackedDivsCount = 0;
  currentSection = "";

  ngOnInit(){
    this.getDivs();
  }

  setActive($event: any) {
  }

  constructor(private router: Router) {}

  onSectionChange(sectionId: string) {
    this.currentSection = sectionId
    this.steps.filter(step => step.route !== sectionId).map(step => step.status = "upcoming")
    this.steps.filter(step => step.route === sectionId).map(step => step.status = "current")
    // this.router.navigate([],{fragment: sectionId});
  }

  scrollTo(section: string, index: number) {
    document.querySelector("#"+ section)?.scrollIntoView({ behavior: "smooth", block: "end" });
    this.router.navigate([],{fragment: section});
    this.steps.filter(step => step.index !== index).map(step => step.status = "upcoming")
    this.steps.filter(step => step.index === index).map(step => step.status = "current")
  }

  public observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      this.entryCount += 1;
        if(entry.isIntersecting && this.entryCount >= this.trackedDivsCount + 1){
            this.onSectionChange(entry.target.id);
        }
    });
  },
  {
    threshold: 0.4,
  });

  public getDivs(){
    const divs = document.querySelectorAll('.scroll-container');
    this.trackedDivsCount = divs.length;
    divs.forEach(div =>{
      this.observer.observe(div);
    });
  }

  steps: Step[] = [
    {
      index: 1,
      title: 'General',
      subtitle: 'General details of the Compliance Observation',
      status: 'current',
      route: 'details',
    },
    {
      index: 2,
      title: 'Responsibility Centre',
      subtitle: 'Identification of individuals and teams owning the observation/mitigation',
      status: 'upcoming',
      route: 'responsibility-centre',
    },
    {
      index: 3,
      title: 'Risk Categorization',
      subtitle: 'Identification of the Risk Levels and other Risk related parameters',
      status: 'upcoming',
      route: 'risk-categorization',
    },
    {
      index: 4,
      title: 'Affected Areas',
      subtitle: 'Identification of who is affected by the observation/risk',
      status: 'upcoming',
      route: 'affected-fields',
    },
    {
      index: 5,
      title: 'Collaboration Fields',
      subtitle: 'Fields dedicated for enhancing the collaboration amongst stakeholders',
      status: 'upcoming',
      route: 'collab-fields',
    },
    {
      index: 6,
      title: 'Action Plans',
      subtitle: 'Section dedicated for Action Plan inputting',
      status: 'upcoming',
      route: 'action-plan',
    },
    //,
    // {
    //   index: 7,
    //   title: 'Closure',
    //   subtitle: 'Closure step',
    //   status: 'upcoming',
    //   route: 'closure',
    // }
    {
      index: 7,
      title: 'Supporting Documents',
      subtitle: 'Section dedicated for uploading attachments',
      status: 'upcoming',
      route: 'supporting-documents',
    }
    // {
    //   index: 8,
    //   title: 'AD',
    //   subtitle: 'Fields for admin editing',
    //   status: 'upcoming',
    //   route: 'admin-fields',
    // },

  ];
}
