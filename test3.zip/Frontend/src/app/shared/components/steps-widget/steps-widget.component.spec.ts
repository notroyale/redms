import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StepsWidgetComponent } from './steps-widget.component';

describe('StepsWidgetComponent', () => {
  let component: StepsWidgetComponent;
  let fixture: ComponentFixture<StepsWidgetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StepsWidgetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StepsWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
