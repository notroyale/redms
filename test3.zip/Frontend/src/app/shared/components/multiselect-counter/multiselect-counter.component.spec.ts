import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiselectCounterComponent } from './multiselect-counter.component';

describe('MultiselectCounterComponent', () => {
  let component: MultiselectCounterComponent;
  let fixture: ComponentFixture<MultiselectCounterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MultiselectCounterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MultiselectCounterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
