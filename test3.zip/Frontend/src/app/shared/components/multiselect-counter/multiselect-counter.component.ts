import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-multiselect-counter',
  templateUrl: './multiselect-counter.component.html',
  styleUrls: ['./multiselect-counter.component.css']
})
export class MultiselectCounterComponent {
  @Input() items: any[];
}
