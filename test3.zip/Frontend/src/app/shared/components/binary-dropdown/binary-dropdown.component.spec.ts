import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BinaryDropdownComponent } from './binary-dropdown.component';

describe('BinaryDropdownComponent', () => {
  let component: BinaryDropdownComponent;
  let fixture: ComponentFixture<BinaryDropdownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BinaryDropdownComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BinaryDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
