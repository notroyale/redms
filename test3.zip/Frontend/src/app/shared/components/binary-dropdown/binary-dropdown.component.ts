import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BinaryDropdownField, BinaryDropdownOption } from '../../models/binary-dropdown-options';

@Component({
  selector: 'app-binary-dropdown',
  templateUrl: './binary-dropdown.component.html',
  styleUrls: ['./binary-dropdown.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BinaryDropdownComponent implements OnInit {
  @Input() field: BinaryDropdownField;
  @Input() data: any = {};

  @Output() dataChange = new EventEmitter<any>();

  private defaultOptionDisplay: string = 'Select an option';
  optionDisplay: string = this.defaultOptionDisplay;
  selectedOption: any = {title: "Yes", value: true};

  options: BinaryDropdownOption[] = [
    {title: "Yes", value: true},
    {title: "No", value: false}
  ];

  isOpen: boolean = false;

  ngOnInit(): void {
    if(!this.options){
      return;
    }

    this.options.forEach(opt=> {
      if(opt.value == this.data){
        this.optionDisplay = opt.title;
      }

      return this.defaultOptionDisplay;
    });
    let foundOption = this.options.find(opt=> opt.value == this.data);
    if(!foundOption) return;
    this.selectedOption = foundOption;
    this.onChange(this.selectedOption);
  }

  public trackById(index: number, item: any) {
    if(!this.field){
      return;
    }

    return item[this.field.filterAttribute];
  }

  toggleDropdown() {
    this.isOpen = !this.isOpen;
  }

  onChange(option: any) {
    if(!option) return;
    this.optionDisplay = option[this.field.displayAttribute];
    this.selectedOption = option;

    this.isOpen = false;

    this.dataChange.emit(option.value);
  }

  checkSelected(option: any) {
    if(!option) return;
    return option[this.field.filterAttribute] === this.selectedOption[this.field.filterAttribute];
  }
}
