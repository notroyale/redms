import { Component } from '@angular/core';
import { AuthService } from 'src/app/auth/data-access/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {

  adminFields: boolean = false;

  public href: string = "";
  constructor(private authService: AuthService) { }


  subOptions: any = [
    {
      name: "Business Units",
      reference: "./bu-dashboard"
    },
    {
      name: "Business Areas",
      reference: "./ba-dashboard"
    },
    {
      name: "Legal Entities",
      reference: "./le-dashboard"
    }
  ];

  menuOptions: typeof MenuOptions = MenuOptions;
}

enum MenuOptions {
  Home = "Home",
  Observations = "Observations",
  Help = "Help",
  Admin = "Admin"
}
