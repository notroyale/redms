import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormComponent } from './form.component';
import { ButtonComponent } from '../button/button.component';

describe('FormComponent', () => {
  let component: FormComponent;
  let fixture: ComponentFixture<FormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      // imports:[ButtonComponent],
      declarations: [ FormComponent,ButtonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormComponent);
    component = fixture.componentInstance;
    component.dataForm = {
      form: {
        title: '',
        subtitle: '',
        fields: [],
        btnLabel: ''
      },
      data: {},
      dropdownsData: {}
    }
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
