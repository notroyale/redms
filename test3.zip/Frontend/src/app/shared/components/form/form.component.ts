import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DropdownField } from '../../models/dropdown-field';
import { TextareaField } from '../../models/textarea-field';
import { DataForm } from '../../models/data-form';
import { Field } from '../../models/field';
import { MultiselectField } from '../../models/multiselect-field';
import { InputSwitch } from '../../models/input-switch';
import { InputField } from '../../models/input-field';
import { FieldType } from '../../models/field-type';
import { TableField } from '../../models/table-field';
import { DataTable } from '../../models/data-table';
import { ModalField } from '../../models/modal';
import { FormField } from '../../models/form-field';
import { BinaryDropdownField } from '../../models/binary-dropdown-options';
import { DropdownLevelsField } from '../../models/dropdown-levels-field';
import { FileUploadField } from '../../models/file-upload';
import { FileUploadFormField } from '../../models/file-upload-form';
import { UserInfoField } from '../../models/user-info';
import { CheckboxField } from '../../models/checkbox';
import { ImplicitFlowCallbackHandlerService } from 'angular-auth-oidc-client/lib/flows/callback-handling/implicit-flow-callback-handler.service';
import { FieldHelpText } from 'src/app/domain/field-help-text';
import { ObservationAccess } from 'src/app/domain/observation';
import { InputPreFilledDate } from '../../models/input-pre-filled-date';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FormComponent{
  @Input() dataForm: DataForm;
  @Input() loading: boolean;
  @Input() overlayPanelVisible: boolean;
  @Input() accessObs: ObservationAccess | null;


  @Output() lazyEvent = new EventEmitter();
  @Output() onEditItemEvent = new EventEmitter();
  @Output() onDeleteItemEvent = new EventEmitter();
  @Output() onCloseItemEvent = new EventEmitter();
  @Output() onDownloadActionEvent = new EventEmitter();
  @Output() onBaDeleteActionEvent = new EventEmitter();
  @Output() onFileDeleteActionEvent = new EventEmitter();


  @Output() onFormSubmit = new EventEmitter();
  @Output() onNestedFormSubmit = new EventEmitter();
  @Output() onFileFormSubmit = new EventEmitter();

  @Output() onMultiselectLevelsChange = new EventEmitter();
  @Output() onMultiselectChange = new EventEmitter();
  @Output() onDropdownChange = new EventEmitter();
  @Output() onSwitchChange = new EventEmitter();
  @Output() onCheckboxChange = new EventEmitter();

  labelClass: string = "label-custom";
  fieldType = FieldType;
  showDialog: boolean = false;

  asDropdownField = (field: Field) => field as DropdownField;
  asBinaryDropdownField = (field: Field) => field as BinaryDropdownField;
  asTextareaField = (field: Field) => field as TextareaField;
  asInputField = (field: Field) => field as InputField;
  asInputPreFilledDate = (field: Field) => field as InputPreFilledDate;
  asInputSwitchField = (field: Field) => field as InputSwitch;
  asMultiselectField = (field: Field) => field as MultiselectField;
  asDropdownLevelsField = (field: Field) => field as DropdownLevelsField;
  asModalField = (field: Field) => field as ModalField;
  asFileUploadField = (field: Field) => field as FileUploadField;
  asCheckboxField = (field: Field) => field as CheckboxField;

  asUserInfoField = (field: Field) => field as UserInfoField;
  asFormField = (field: Field) => field as FormField;
  asFileUploadFormField = (field: Field) => field as FileUploadFormField;

  dropDownLevelsFieldKey(field: Field) : any{
    return this.asDropdownLevelsField(field).for +
      "" + this.asDropdownLevelsField(field).key;
  }

  closeDialog() {
    this.showDialog = !this.showDialog;
  }

  asTableField = (field: Field) : DataTable => {
    return {
      data: this.dataForm.data[field.for],
      table: (field as TableField).table,
      formFilters: {
        fields: [],
        filters: {},
        selectedFilters: {}
      }
    }
  };

  onBinarySwitch(field: BinaryDropdownField, value : boolean){
    const justificationField = this.dataForm.form.fields.find(f => f.for === field.justificationField );
    if(!justificationField){
      return;
    }

    if(justificationField.visible == value)
      return;
    if(value == false)
      this.dataForm.data[field.justificationField] = "";
    justificationField.visible = value;
  }

  onInputSwitch(dependsOnField: Field){
    this.dataForm.form.fields
      .filter(field => field.conditional
        && field.dependsOn !== ""
        && field.dependsOn !== "" + this.dataForm.data[dependsOnField.for])
      .map(field => {
        field.visible = false;
        return field;
      });

    this.dataForm.form.fields
      .filter(field => field.conditional
        && field.dependsOn === "" + this.dataForm.data[dependsOnField.for])
      .map(field => field.visible = true);
  }

  onConditionalSwitch(dependsOnField: Field){
    this.dataForm.form.fields
      .filter(field => field.conditional
        && field.dependsOn !== ""
        && field.dependsOn !== "" + this.dataForm.data[dependsOnField.for])
      .map(field => {
        field.visible = false;
        if(field.for !== 'deadlineExtensionRegistrationDate'){
          this.dataForm.data[field.for] = null;
        }
        
        return field;
      });

    this.dataForm.form.fields
      .filter(field => field.conditional
        && field.dependsOn === "" + this.dataForm.data[dependsOnField.for])
      .map(field => field.visible = true);
  }

  onConditionalMultiSwitch(dependsOnField: Field){
    this.dataForm.form.fields
      .filter(field => field.conditional
        && field.dependsOn !== ""
        && !this.dataForm.data[dependsOnField.for].some((x: number) =>field.dependsOn === ""+x))
      .map(field => {
        field.visible = false;
        this.dataForm.data[field.for] = null;
        return field;
      });

    this.dataForm.form.fields
      .filter(field => field.conditional
        && this.dataForm.data[dependsOnField.for].some((x: number) =>field.dependsOn === ""+x))
      .map(field => field.visible = true);
  }

  onSave(){
    let isValid: boolean = true;
    this.dataForm.form.fields.forEach(element => {
      if(element.type == FieldType.Dropdown
        && element.mandatory
        && (this.dataForm.data[this.asDropdownField(element).key] == 0))
      {
        this.showDialog = !this.showDialog;
        isValid = false;

        return;
      }

      if(element.type != FieldType.Dropdown
        && element.type != FieldType.BinaryDropdown
        && element.mandatory
        && element.visible
        && (this.dataForm.data[element.for] == null || Object.keys(this.dataForm.data[element.for]).length == 0))
      {
        this.showDialog = !this.showDialog;
        isValid = false;
        return;
      }
    });

    if(!isValid){
      return;
    }

    this.onFormSubmit.emit();
  }


}
