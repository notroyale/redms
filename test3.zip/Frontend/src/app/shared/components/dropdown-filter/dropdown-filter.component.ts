import { Component, EventEmitter, Input, OnInit, Output,ElementRef, Renderer2, HostListener } from '@angular/core';
import { MultiselectField } from '../../models/multiselect-field';

@Component({
  selector: 'app-dropdown-filter',
  templateUrl: './dropdown-filter.component.html',
  styleUrls: ['./dropdown-filter.component.css'],
})
export class DropdownFilterComponent{
  @Input() field: MultiselectField;
  @Input() options: any[];
  @Input() selectedOptions: any[] = [];

  @Output() selectedOptionOnChange = new EventEmitter<any[]>();

  show: boolean = false;

  placeholder: string = "Select options";


  constructor(private elRef: ElementRef, private renderer: Renderer2) { }

  isClickInsideComponent(target: any): boolean {
    const clickedInside = this.elRef.nativeElement.contains(target);
    return clickedInside;
   }

   @HostListener('document:click', ['$event'])
    handleClick(event: Event) {
      if (!this.isClickInsideComponent(event.target) && this.show == true) {

        this.show = false;
      }
    }

    displaySelectedItems() : any[] {
      if(!this.options || !this.selectedOptions){
        this.selectedOptions = [];
        return this.selectedOptions;
      }

      return this.options.filter(opt => this.selectedOptions
        .some(selOpt => opt[this.field.filterAttribute] === selOpt))
      .map(opt => opt[this.field.displayAttribute]);
    }

    toggleSelection(option: any) : void {
      if(!this.selectedOptions){
        this.selectedOptions = [];
        this.selectedOptions.push(option[this.field.filterAttribute]);
        return;
      }

      const exists =
        this.selectedOptions
          .some(opt => opt === option[this.field.filterAttribute]);
      if(exists){
        var index = this.selectedOptions.findIndex((elt) => elt === option[this.field.filterAttribute]);
        this.selectedOptions.splice(index, 1);
        this.emitSelectedOptionOnChange();

        return;
      }

      this.selectedOptions.push(option[this.field.filterAttribute]);
      this.emitSelectedOptionOnChange();
    }

    emitSelectedOptionOnChange() : void{
      // if(!this.hasAnySelection()){
      //   return;
      // }

      this.selectedOptionOnChange.emit(this.selectedOptions.map(opt => opt[this.field.filterAttribute]));
    }

    isInvalid() : boolean{
      return this.field.mandatory && this.selectedOptions && this.selectedOptions.length == 0;
    }

    hasAnySelection() : boolean{
      return this.selectedOptions && this.selectedOptions.length > 0;
    }

    isChecked(option: any) : boolean{
      return this.selectedOptions && this.selectedOptions.some(opt => opt === option[this.field.filterAttribute]);
    }

    toggle() : void {
      if(!this.show && !this.options || this.options.length == 0){
        return;
      }
      this.show = !this.show;
    }
}
