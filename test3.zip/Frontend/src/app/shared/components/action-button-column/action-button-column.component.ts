import { Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem, MessageService } from 'primeng/api';
import { Access } from '../../models/field';
import { ObservationAccess } from 'src/app/domain/observation';

@Component({
  selector: 'app-action-button-column',
  templateUrl: './action-button-column.component.html',
  styleUrls: ['./action-button-column.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ActionButtonColumnComponent implements OnInit {
  @Input() itemId: any;
  @Input() item: any;
  @Input() overlayPanelVisible: boolean;
  isMenuVisible : boolean = false;
  @Output() onEditActionEvent = new EventEmitter();
  @Output() onDeleteActionEvent = new EventEmitter();
  @Output() onCloseActionEvent = new EventEmitter();
  items: MenuItem[];
  @Input() access: ObservationAccess | null;

  constructor(private messageService: MessageService, private router: Router) { }

  ngOnInit() {
    if(this.item.actionStatus == 1 && (this.access?.editAccess || this.access?.commentAccess || this.access?.viewAccess)){
      this.items = [
        {
          label: 'Options',
          items: [
            {
              label: '1st LoD Comment',
              icon: 'pi pi-pencil',
              command: () => {
                this.onEditActionEvent.emit(this.overlayPanelVisible);
              }
            }
          ]
        }
      ];
      return;
    }
    if(this.item.actionStatus !=1 && this.access?.editAccess){
    this.items = [
      {
        label: 'Options',
        items: [
          {
            label: 'Update',
            icon: 'pi pi-refresh',
            command: () => {
              this.onEditActionEvent.emit(this.overlayPanelVisible);
            }
          },
          {
            label: 'Delete',
            icon: 'pi pi-times',
            command: () => {
              this.onDeleteActionEvent.emit();
            }
          },
          {
            label: 'Close Action',
            icon: 'pi pi-times',
            command: () => {
              this.onCloseActionEvent.emit();
            }
          }
        ]
      }
    ];
  }
  }

  toggle(){
    if(!this.overlayPanelVisible){
      this.overlayPanelVisible = true;
    }
  }

  update() {
  }

  delete(observationId: any) {
    const summary = `Deleted observation ${observationId}`;
    this.messageService.add({ severity: 'warn', summary: summary, detail: 'Observation Deleted' });
  }
}
