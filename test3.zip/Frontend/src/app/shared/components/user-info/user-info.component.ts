import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Observable, Subject, Subscription, map } from 'rxjs';
import { User, UserInfo } from 'src/app/domain/user';
import { UserinfoService } from '../../services/user-info/user-info.service';
import { InputField } from '../../models/input-field';
import { UserInfoField } from '../../models/user-info';

@Component({
  selector: 'app-user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.css']
})
export class UserInfoComponent {

  userData$: Subject<UserInfo> = new Subject();

  constructor(private userinfoService: UserinfoService){}

  @Input() field: UserInfoField;
  @Input() data: string = "";

  @Output() dataChange = new EventEmitter<any>();

  ngOnInit(): void {
    this.userData$.subscribe(response =>this.dataChange.emit(response.bNumber))
    this.onChange();
  }

  onChange(){
    if(this.data.length == 0 ){
      return this.userData$.next({bNumber: '',name: 'Please enter valid B-number.',departament: ''});
    }
    if(this.data.length == 6 )
      this.getUserByBNumber();
    else
      this.userData$.next({bNumber: this.data,name: 'Please enter valid B-number.',departament: ''});
  }

  getUserByBNumber(){
    this.userinfoService.get(this.data).subscribe(
      {
        next: (res) => {
          if(res.bNumber==null)
            this.userData$.next({bNumber: '',name: 'Please enter valid B-number.',departament: ''});
          else if(res.departament=="NA")
            this.userData$.next({bNumber: '',name: 'The user does not exist.',departament: ''});
          else
            this.userData$.next(res);
        },
        error: (err) => {
          this.userData$.next({bNumber: '',name: 'Please enter valid B-number.',departament: ''});
        }
  })
  }
}
