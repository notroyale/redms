import { ChangeDetectionStrategy, Component, ElementRef, EventEmitter, HostListener, Input, OnInit, Output, Renderer2 } from '@angular/core';
import { DropdownField } from '../../models/dropdown-field';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DropdownComponent implements OnInit {
  @Input() field: DropdownField;
  @Input() options: any[] = [];
  @Input() data: number = 0;

  @Output() dataChange = new EventEmitter<number>();

  private defaultOptionDisplay: string = 'Select an option';

  optionDisplay: string = this.defaultOptionDisplay;

  isOpen: boolean = false;

  constructor(private elRef: ElementRef, private renderer: Renderer2) { }

  private isClickInsideComponent(target: any): boolean {
    const clickedInside = this.elRef.nativeElement.contains(target);
    return clickedInside;
   }

   @HostListener('document:click', ['$event'])
    handleClick(event: Event) {
      if (!this.isClickInsideComponent(event.target) && this.isOpen == true) {
        this.isOpen = false;
      }
    }

  ngOnInit(): void {
    if (this.data == 0 || !this.options || this.options.length == 0) {
      return;
    }

    const defaultOptionDisplay = this.options.find(opt => this.data == opt[this.field.filterAttribute]);

    if(!defaultOptionDisplay){
      return;
    }

    this.optionDisplay = defaultOptionDisplay[this.field.displayAttribute]
    
    this.onChange(defaultOptionDisplay);
  }
    
  public trackById(index: number, item: any) {
    if(!this.field){
      return;
    }

    return item;
  }

  toggleDropdown() {
    this.isOpen = !this.isOpen;
  }

  onChange(option: any) {
    this.optionDisplay = this.options.find(opt => option[this.field.filterAttribute] === opt[this.field.filterAttribute])[this.field.displayAttribute];
    this.data = option[this.field.filterAttribute];

    this.isOpen = false;

    this.dataChange.emit(option[this.field.filterAttribute]);
  }

  isInvalid() : boolean{
    return this.field.mandatory && this.data == 0;
  }

  checkSelected(option: any) {
    return option[this.field.filterAttribute] === this.data;
  }
}
