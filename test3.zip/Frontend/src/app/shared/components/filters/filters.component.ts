import { ChangeDetectionStrategy, Component, EventEmitter, HostListener, Input, Output } from '@angular/core';
import { FormFilter } from '../../models/filter';
import { Field } from '../../models/field';
import { FieldType } from '../../models/field-type';
import { MultiselectField } from '../../models/multiselect-field';
import { InputField } from '../../models/input-field';

@Component({
  selector: 'app-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FiltersComponent {
  @Input() formFilters: FormFilter;

  // @Output() filtersChange = new EventEmitter<any[]>();
  @Output() onMultiselectLevelsChange = new EventEmitter();
  @Output() onResetFilters = new EventEmitter();
  @Output() onClickCreate = new EventEmitter();

  labelClass: string = "label-custom";
  searchTerm: string = '';

  asInputField = (field: Field) => field as InputField;
  asMultiselectField = (field: Field) => field as MultiselectField;

  filterLabel: string = "Filter";
  fieldType = FieldType;

  asMultiselectFilter = (field: Field) => field as MultiselectField;

  filtersSelected(filters : any){
    this.formFilters.selectedFilters[filters.key] = filters.selectedOptions //maybe unnecessary

    // this.onMultiselectLevelsChange.emit(this.formFilters.selectedFilters);
  }

  onResetFiltersClicked(){
    this.searchTerm="";
    this.onResetFilters.emit()
  }

  onFieldClickedOff(filters : any){
    this.onMultiselectLevelsChange.emit(this.formFilters.selectedFilters);
  }

  save(){
  }
  onChange(){
    this.formFilters.selectedFilters["searchTerm"] = this.searchTerm;
  }

  @HostListener('window:keydown.enter', ['$event'])
  handleKeyDown(event: KeyboardEvent) {
    if(this.searchTerm !== ''){
      this.onMultiselectLevelsChange.emit(this.formFilters.selectedFilters);
    }
  }
}
