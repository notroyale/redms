import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
  ViewEncapsulation,
} from '@angular/core';
import { LazyLoadEvent } from 'primeng/api';
import { DataTable } from '../../models/data-table';
import { ColumnStyleType, ColumnType } from '../../models/table/column-type';
import { SortType } from '../../models/sort-type';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TableComponent {
  @Input() tableData: DataTable;
  @Input() loading: boolean;
  @Input() overlayPanelVisible: boolean;
  @Input() paginationVisible: boolean;

  @Output() lazyEvent = new EventEmitter();
  @Output() onEditItemEvent = new EventEmitter();
  @Output() onDeleteItemEvent = new EventEmitter();
  @Output() sortEvent = new EventEmitter();

  isMenuVisible: boolean = false;
  columnType = ColumnType;
  columnStyleType = ColumnStyleType;
  sortNone: SortType = SortType.None;
  sortAsc: SortType = SortType.Asc;
  sortDesc: SortType = SortType.Desc;

  lazyLoad($event: LazyLoadEvent) {
    $event.first = ($event.first || 0) / this.tableData.table.rows + 1;
    this.lazyEvent.emit($event);
  }

  on($isMenuVisible: boolean) {
    this.isMenuVisible = $isMenuVisible;
  }

  sort(columnId: string) {
    this.tableData.table.columns
      .filter((x) => x.for !== columnId)
      .map((x) => {
        x.sorted = SortType.None;
      });

    this.tableData.table.columns
      .filter((x) => x.for === columnId)
      .map((x) => {
        switch (x.sorted) {
          case SortType.Asc: {
            x.sorted = SortType.Desc;
            break;
          }
          case SortType.Desc: {
            x.sorted = SortType.None;
            break;
          }
          default: {
            x.sorted = SortType.Asc;
            break;
          }
        }
      });
    this.sortEvent.emit(this.tableData.table.columns);
  }
  toggle(rowData: any){
    this.onEditItemEvent.emit(rowData.id)
  }
}
