import { Component } from '@angular/core';
import { ValidationService } from 'src/app/observation-edit-page/utils/observation-validation.service/observation-validation.service';

@Component({
  selector: 'app-warning-modal',
  templateUrl: './warning-modal.component.html',
  styleUrls: ['./warning-modal.component.css']
})
export class WarningModalComponent {
  
  showDialog$ = this.validationService.warningModalSwitch.asObservable();
  validationInformation$ = this.validationService.validationSubject.asObservable();
  
  constructor(private validationService:ValidationService){}

  toggleSwitch() {
    this.validationService.toggleWarningMessage();
  }

}
