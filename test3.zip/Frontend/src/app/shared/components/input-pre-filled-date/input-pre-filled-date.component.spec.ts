import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputPreFilledDateComponent } from './input-pre-filled-date.component';

describe('InputPreFilledDateComponent', () => {
  let component: InputPreFilledDateComponent;
  let fixture: ComponentFixture<InputPreFilledDateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InputPreFilledDateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InputPreFilledDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
