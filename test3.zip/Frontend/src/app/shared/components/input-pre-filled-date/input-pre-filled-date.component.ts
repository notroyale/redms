import { Component, Input, EventEmitter, Output } from '@angular/core';
import { InputType } from '../../models/input-type';
import { InputPreFilledDate } from '../../models/input-pre-filled-date';

@Component({
  selector: 'app-input-pre-filled-date',
  templateUrl: './input-pre-filled-date.component.html',
  styleUrls: ['./input-pre-filled-date.component.css']
})
export class InputPreFilledDateComponent {
  ngOnInit(): void {
    if(this.field.conditional && this.field.dependsOn==="")
      this.onChange();
    
    if(!this.data){
      this.data = new Date();
      this.onChange();
    }
  }

  @Input() field: InputPreFilledDate;
  @Input() data: any = {};
  
  @Output() dataChange = new EventEmitter<any>();
  
  inputType = InputType;

  onDateChange(date: string) {
    this.data = date;
    this.dataChange.emit(date);
  }

  onChange(){
    this.dataChange.emit(this.data);
  }

  onKey(event: any) { // without type info
  }

}
