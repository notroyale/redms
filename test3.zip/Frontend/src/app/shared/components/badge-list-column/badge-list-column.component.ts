import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
  selector: 'app-badge-list-column',
  templateUrl: './badge-list-column.component.html',
  styleUrls: ['./badge-list-column.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BadgeListColumnComponent {
  @Input() items: any[];

  hasAnySelection() : boolean {
    return this.items && this.items.length > 0;
  }
}