import { Component, Input } from '@angular/core';
import { SortType } from 'src/app/shared/models/sort-type';

@Component({
  selector: 'app-audit-table',
  templateUrl: './audit-table.component.html',
  styleUrls: ['./audit-table.component.css'],
})
export class AuditTableComponent {
  @Input() headers: any[];
  @Input() rows: any[];
  sortNone: SortType = SortType.None;
  sortAsc: SortType = SortType.Asc;
  sortDesc: SortType = SortType.Desc;

  sort(columnId: string) {
    this.headers
      .filter((x) => x.for !== columnId)
      .map((x) => {
        x.sorted = SortType.None;
      });
      
    this.headers
      .filter((x) => x.for === columnId)
      .map((x) => {
        switch (x.sorted) {
          case SortType.Asc: {
            x.sorted = SortType.Desc;
            this.rows = this.rows.sort((a, b) => {
              if (b[columnId] > a[columnId]) return 1;
              if (b[columnId] < a[columnId]) return -1;
              return 0;
            });
            break;
          }
          case SortType.Desc: {
            x.sorted = SortType.None;
            this.rows = this.rows.sort((a, b) => {
              if (b.modifiedDate > a.modifiedDate) return 1;
              if (b.modifiedDate < a.modifiedDate) return -1;
              return 0;
            });
            break;
          }
          default: {
            x.sorted = SortType.Asc;
            this.rows = this.rows.sort((a, b) => {
              if (b[columnId] < a[columnId]) return 1;
              if (b[columnId] > a[columnId]) return -1;
              return 0;
            });
            break;
          }
        }
      });
  }
}
