import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObservationAuditLogComponent } from './observation-audit-log.component';

describe('ObservationAuditLogComponent', () => {
  let component: ObservationAuditLogComponent;
  let fixture: ComponentFixture<ObservationAuditLogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ObservationAuditLogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ObservationAuditLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
