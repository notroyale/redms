import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuditLogService } from '../../data-access/audit-log.service';
import { AuditLog } from '../../models/audit-log';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-observation-audit-log',
  templateUrl: './observation-audit-log.component.html',
  styleUrls: ['./observation-audit-log.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class ObservationAuditLogComponent implements OnInit, OnDestroy {
  observationLog$ = new BehaviorSubject<AuditLog[] | null>(null);

  constructor(
    private router: Router,
    private auditLogService: AuditLogService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.getObservationLog(params['id']);
    });
  }

  ngOnDestroy() {
    this.observationLog$.unsubscribe();
  }

  back() {
    const url = `/observation-dashboard`;
    this.router.navigate([url]);
  }

  private getObservationLog(id: number) {
    this.auditLogService.getAll(id).subscribe((res) => {
      this.observationLog$.next(res);
    });
  }

  public tableHeaders = [
    {
      for: 'action',
      title: 'Action',
      sorted: 0,
    },
    {
      for: 'field',
      title: 'Field',
      sorted: 0,
    },
    {
      for: 'oldValue',
      title: 'Old Value',
      sorted: 0,
    },
    {
      for: 'newValue',
      title: 'New Value',
      sorted: 0,
    },
    {
      for: 'modifiedDate',
      title: 'Date',
      sorted: 0,
    },
    {
      for: 'modifiedUser',
      title: 'Modified By',
      sorted: 0,
    },
  ];
}
