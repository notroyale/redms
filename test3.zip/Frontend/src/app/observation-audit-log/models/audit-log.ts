export interface AuditLog {
  logID: number;
  observationID: number;
  modifiedUser: string;
  modifiedDate: string;
  action: string;
  field: string;
  oldValue: string;
  newValue: string;
}
