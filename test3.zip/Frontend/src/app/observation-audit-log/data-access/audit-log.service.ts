import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { settings } from 'src/utils/appsettings.service';
import { HttpClient } from '@angular/common/http';
import { AuditLog } from '../models/audit-log';

@Injectable({
  providedIn: 'root'
})
export class AuditLogService {

  constructor(private http: HttpClient) { }

  public getAll(id: number): Observable<AuditLog[]>{
    return this.http.get<AuditLog[]>(`${settings.apibaseUrl}/api/Audit/all/?observationID=${id}`);
  }
}
