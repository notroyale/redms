import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { AuditEntry } from 'src/app/domain/audit-entry';

@Component({
  selector: 'app-observation-audit',
  templateUrl: './observation-audit.component.html',
  styleUrls: ['./observation-audit.component.css']
})
export class ObservationAuditComponent {
  logs$: Observable<AuditEntry[]>;

  // constructor(private auditService: AuditService) {
  //   this.logs$ = this.auditService.getAuditLog();
  // }


}
