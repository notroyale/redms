import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObservationAuditComponent } from './observation-audit.component';

describe('ObservationAuditComponent', () => {
  let component: ObservationAuditComponent;
  let fixture: ComponentFixture<ObservationAuditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ObservationAuditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ObservationAuditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
