import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { observableToBeFn } from 'rxjs/internal/testing/TestScheduler';
import { BusinessArea } from 'src/app/domain/business-area';
import { BusinessUnit } from 'src/app/domain/business-unit';
import { Category } from 'src/app/domain/category';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { LegalEntity } from 'src/app/domain/legal-entity';
import { Status } from 'src/app/domain/status';
import { Taxonomy } from 'src/app/domain/taxonomy';
import { Column } from 'src/app/shared/models/table/column';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class FilterService {
  constructor(private http: HttpClient) {}

  public getBusinessUnits(): Observable<BusinessUnit[]> {
    return this.http.get<BusinessUnit[]>(`${settings.apibaseUrl}/api/BusinessUnit/all`);
  }

  public getBusinessAreas(): Observable<BusinessArea[]> {
    return this.http.get<BusinessArea[]>(`${settings.apibaseUrl}/api/BusinessArea/all`);
  }

  public getLegalEntities(): Observable<LegalEntity[]> {
    return this.http.get<LegalEntity[]>(`${settings.apibaseUrl}/api/LegalEntity/all`);
  }

  public getStatus(): Observable<Status[]> {
    return this.http.get<Status[]>(`${settings.apibaseUrl}/api/Status/all`);
  }

  public getCategories(): Observable<Category[]> {
    return this.http.get<Category[]>(`${settings.apibaseUrl}/api/Category/all`);
  }
  public getLvl1Taxonomies(): Observable<Taxonomy[]> {
    return this.http.get<Taxonomy[]>(`${settings.apibaseUrl}/api/Taxonomy/getByLevel?level=1`);
  }

  public getBusinessAreasByBusinessUnitsIds(ids: number[]): Observable<BusinessArea[]> {
    let queryParams = new HttpParams();
    queryParams = queryParams.appendAll({'ids': ids});

    return this.http.get<BusinessArea[]>(`${settings.apibaseUrl}/api/BusinessArea/allByBusinessUnit?${queryParams.toString()}`);
  }

  public getTaxonomiesByIDs(taxIds : string): Observable<Taxonomy[]> {
    return this.http.get<any>(`${settings.apibaseUrl}/api/Taxonomy/getChildrenByIds?`+taxIds).pipe(
      map(response => response.values)
    );
  }



}
