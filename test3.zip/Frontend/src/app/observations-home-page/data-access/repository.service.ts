import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { Observable } from 'rxjs';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { Observation, ObservationAccess } from 'src/app/domain/observation';
import { Result } from 'src/app/domain/result';
import { SortType } from 'src/app/shared/models/sort-type';
import { Column } from 'src/app/shared/models/table/column';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class RepositoryService {

  constructor(private http: HttpClient, private oidcSecurityServices: OidcSecurityService) {}

  public getAll(skip: number, rows: number, sortColumn: string | undefined, filters :(FiltersModel | undefined)): Observable<DataTableRequest> {


    let url = `${settings.apibaseUrl}/api/Observation/allBase/options`;

    if(filters == null) {
      return this.http.get<DataTableRequest>(url);
    }
    if(sortColumn != null) {
      // filters.sortedColumns =  sortedColumns.filter(column => column.sorted != 0);
      filters.sortColumn = sortColumn.substring(0,sortColumn.indexOf(";"));
      filters.sortOrder = parseInt(sortColumn.substring(sortColumn.indexOf(";") + 1, sortColumn.length))
    }
    filters.page= skip;
    filters.pageSize = rows;

    return this.http.post<DataTableRequest>(url, filters);

  }



  public createObservation ():Observable<ObservationAccess>  {
    return this.http.post<ObservationAccess>(`${settings.apibaseUrl}/api/Observation/add`, {});
  }

  // public getAllWithFilters(skip: number, rows: number, filters :any): Observable<DataTableRequest> {
  //   return this.http.post<DataTableRequest>(`${settings.apibaseUrl}/api/Observation/allBaseFiltered/options?page=${skip}&pageSize=${rows}`,filters);
  // }
  // public addToken() {
  //   this.oidcSecurityServices.getAccessToken().subscribe((token) => {
  //     const httpOptions = {
  //       headers: new HttpHeaders({
  //         Authorization: 'Bearer ' + token,
  //       }),
  //     };
  //   });
  // }
}


export interface FiltersModel{
  searchTerm?: string,
  statusIDs: number[];
  businessUnitIDs: number[];
  businessAreaIDs: number[];
  legalEntityIDs: number[];
  categoryIDs: number[];
  taxonomyLevel1IDs: number[];
  taxonomyLevel2IDs: number[];
  taxonomyLevel3IDs: number[];
  countries: number[];
  gradeIDs: number[];
  sortColumn: string;
  sortOrder: SortType;
  page: number;
  pageSize: number;
}
