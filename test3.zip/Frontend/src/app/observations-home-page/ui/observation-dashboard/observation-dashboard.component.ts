import { Component, Input, OnInit } from '@angular/core';
import { LazyLoadEvent } from 'primeng/api';
import { Subject, BehaviorSubject, combineLatest, finalize, map, tap, switchMap, EMPTY, forkJoin, takeUntil, of} from 'rxjs';
import { FiltersModel, RepositoryService } from '../../data-access/repository.service';
import { ObservationListTableHeaderService } from '../../utils/observation-list-table-header.service';
import { Router } from '@angular/router';
import { DataTable } from 'src/app/shared/models/data-table';
import { LegalEntity } from 'src/app/domain/legal-entity';
import { BusinessArea } from 'src/app/domain/business-area';
import { Taxonomy } from 'src/app/domain/taxonomy';
import { FormFilter } from 'src/app/shared/models/filter';
import { DataForm } from 'src/app/shared/models/data-form';
import { ObservationSharedService } from 'src/app/observation-edit-page/data-access/observation-shared.service';
import { TaxonomyService } from 'src/app/admin-pages/taxonomies/data-access/taxonomy.service';
import { GradeService } from 'src/app/admin-pages/grades/data-access/grade.service';
import { CategoryService } from 'src/app/admin-pages/categories/data-access/category.service';
import { CountriesService } from 'src/app/observation-edit-page/data-access/countries.service';
import { BusinessUnitService } from 'src/app/admin-pages/business-units/data-access/business-unit.service';
import { BusinessAreaService } from 'src/app/admin-pages/business-areas/data-access/business-area.service';
import { LegalEntityService } from 'src/app/admin-pages/legal-entities/data-access/legal-entity.service';
import { StatusService } from 'src/app/observation-edit-page/data-access/status.service';
import { ObservationAccess, ObservationDeletion, UserAccess } from 'src/app/domain/observation';
import { Column } from 'src/app/shared/models/table/column';

@Component({
  selector: 'app-observation-dashboard',
  templateUrl: './observation-dashboard.component.html',
  styleUrls: ['./observation-dashboard.component.css'],
})
export class ObservationDashboardComponent implements OnInit {

  private ngUnsubscribe: Subject<void> = new Subject<void>();
  private firstLevel: number = 1;
  modalVisibleState$ = new BehaviorSubject<boolean>(false);
  deletionObservation$ = new BehaviorSubject<ObservationDeletion | null>(null);
  observations$ = new BehaviorSubject<DataTable | null>(null);
  filters = this.observationsTableHeaderService.getFilters();
  countries$ = this.countriesService.getAll();
  status$ = this.statusService.getAll();
  categories$ = this.categoryService.getAll();
  businessUnits$ = this.businessUnitService.getAll();
  grade$ = this.gradeService.getAll();
  businessAreas$ = new BehaviorSubject<BusinessArea[]>([]);
  legalEntities$ = new BehaviorSubject<LegalEntity[]>([]);
  taxonomiesLevel1$ = this.taxonomyService.getAllByLevel(this.firstLevel);
  taxonomiesLevel2$ = new BehaviorSubject<Taxonomy[]>([]);
  taxonomiesLevel3$ = new BehaviorSubject<Taxonomy[]>([]);
  userAccess$ = new BehaviorSubject<UserAccess>({adminAccess:false, approverAccess:false, commentAccess:false, editAccess:false, viewAccess:false});
  selectedFilters$ = new BehaviorSubject<FiltersModel>({
    businessAreaIDs: [],
    businessUnitIDs: [],
    categoryIDs: [],
    legalEntityIDs: [],
    statusIDs: [],
    taxonomyLevel1IDs: [],
    taxonomyLevel2IDs: [],
    taxonomyLevel3IDs: [],
    countries: [],
    gradeIDs: [],
    searchTerm: '',
    sortColumn:'',
    sortOrder: 1,
    page: 0,
    pageSize:10
  });


  filterForm$ = combineLatest([
    this.selectedFilters$,
    this.countries$,
    this.status$,
    this.categories$,
    this.businessUnits$,
    this.businessAreas$,
    this.legalEntities$,
    this.taxonomiesLevel1$,
    this.taxonomiesLevel2$,
    this.taxonomiesLevel3$,
    this.grade$,
    this.userAccess$
  ]).pipe(
    map(
      ([
        selectedFilters,
        countries,
        status,
        categories,
        businessUnits,
        businessAreas,
        legalEntities,
        taxonomiesLevel1,
        taxonomiesLevel2,
        taxonomiesLevel3,
        grades,
        userAccess
      ]) => {
        const formFilter: FormFilter = {
          access: userAccess,
          fields: this.filters,
          selectedFilters: selectedFilters,
          filters: {
            countries: countries,
            status: status,
            categories: categories,
            businessUnits: businessUnits,
            businessAreas: businessAreas,
            legalEntities: legalEntities,
            taxonomiesLevel1: taxonomiesLevel1,
            taxonomiesLevel2: taxonomiesLevel2,
            taxonomiesLevel3: taxonomiesLevel3,
            grades: grades,
          },
        };
        return formFilter;
      }
    ),
    finalize(() => {
      // this.loading = false;
    }),
    takeUntil(this.ngUnsubscribe)
  );

  deletionForm$ = this.deletionObservation$.pipe(
    map((observation) => {
      if (!observation) {
        return null;
      }
      this.observationsTableHeaderService.getDeletionForm();
      const dataForm: DataForm = {
        form: this.observationsTableHeaderService.getDeletionForm(),
        data: observation,
        dropdownsData: {},
      };
      return dataForm;
    }),
    finalize(() => {
      this.loading = false;
    })
  );

  table$ = of(this.observationsTableHeaderService.getTable());

  onInit = true; // Flag to prevent onInit lazy load
  loading = true; // Flag to prevent multiple requests
  idField: any = 'title';
  // searchTerm: string = '';

  constructor(
    private repositoryService: RepositoryService,
    private businessUnitService: BusinessUnitService,
    private businessAreaService: BusinessAreaService,
    private legalEntityService: LegalEntityService,
    private statusService: StatusService,
    private taxonomyService: TaxonomyService,
    private gradeService: GradeService,
    private categoryService: CategoryService,
    private countriesService: CountriesService,
    private observationsTableHeaderService: ObservationListTableHeaderService,
    private router: Router,
    private observationSharedService: ObservationSharedService  ) {}

  lazyLoad($event: LazyLoadEvent) {
    if (this.onInit) {
      this.onInit = false;
      return;
    }

    if (!$event.first) {
      this.onTableRefresh(1, "");
      return;
    }

    this.onTableRefresh($event.first, "");
  }

  ngOnInit(): void {
    this.idField = this.observationsTableHeaderService.getIdField();
    this.onTableRefresh(1, "");
  }

  onTableRefresh(page: number, sortedColumns?: string | undefined) {
     this.selectedFilters$
      .pipe(
        switchMap((selectedFilters) => {
          return this.fetchData(selectedFilters,sortedColumns, page);
        }),
        map((response) => {
          if (response.data.values.length > 0) {
            let observationAccess: ObservationAccess = response.data.values[0];
            this.userAccess$.next({
              adminAccess: observationAccess.adminAccess,
              approverAccess: observationAccess.approverAccess,
              commentAccess: observationAccess.commentAccess,
              editAccess: observationAccess.editAccess,
              viewAccess: observationAccess.viewAccess
            });
          }
          const dataTable: DataTable = {
            data: response.data.values.map((data) => data.observation),
            formFilters: {
              fields: [],
              filters: {},
              selectedFilters: {},
            },
            table: {
              columns: response.table.columns,
              page: response.table.page,
              first: response.table.first,
              rows: response.data.pageSize,
              totalCount: response.data.totalCount,
            },
          };
          return dataTable;
        }),
        tap((dataTable) => {
          this.loading = false;
          this.observations$.next(dataTable);
        })
      )
      .subscribe();
      return this.selectedFilters$;
  }

  fetchData(selectedFilters: FiltersModel, sortedColumns: string | undefined, page: number) {
    return this.table$.pipe(
      switchMap((table) => {
        this.loading = true;
        return this.repositoryService
          .getAll(page, table.rows,sortedColumns, selectedFilters)
          .pipe(
            map((data) => {
              return { data: data, table: table };
            })
          );
      })
    );
  }

  onResetFilter(){
    this.selectedFilters$.next({
      businessAreaIDs: [],
      businessUnitIDs: [],
      categoryIDs: [],
      legalEntityIDs: [],
      statusIDs: [],
      taxonomyLevel1IDs: [],
      taxonomyLevel2IDs: [],
      taxonomyLevel3IDs: [],
      gradeIDs: [],
      countries: [],
      searchTerm: '',
      sortColumn:'',
      sortOrder: 1,
      page: 0,
      pageSize:10
    });
  }

  onFilterChange(sortedColumns?: string){
    combineLatest([
      this.onTableRefresh(1,sortedColumns),
      this.onBusinessUnitChange(),
      this.ontaxonomiesChange()
    ]).pipe(
      tap((response) => console.log('onFilter Change',response))
    )
    .subscribe();
  }

  private ontaxonomiesChange() {
    return this.selectedFilters$.pipe(
      switchMap((currentData) => {
        if (!currentData) {
          return EMPTY;
        }

        const idsLevel1: number[] = currentData.taxonomyLevel1IDs;
        const idsLevel2: number[] = currentData.taxonomyLevel2IDs;

        if (idsLevel1.length === 0) {
          this.businessAreas$.next([]);
          this.legalEntities$.next([]);
          return EMPTY;
        }

        if (idsLevel2.length == 0) {
          currentData.taxonomyLevel3IDs = [];
          this.taxonomiesLevel3$.next([]);

          const level2Length = currentData.taxonomyLevel2IDs.length;

          if (level2Length > 0) {
            return EMPTY;
          }

          return forkJoin([
            this.taxonomyService.getChildrenByIds(idsLevel1),
            this.taxonomyService.getChildrenByIds(idsLevel2),
          ]);
        }

        return forkJoin([
          this.taxonomyService.getChildrenByIds(idsLevel1),
          this.taxonomyService.getChildrenByIds(idsLevel2),
        ]);
      }),
      tap(([taxonomiesLevel2, taxonomiesLevel3]) => {
        this.taxonomiesLevel2$.next(taxonomiesLevel2);
        this.taxonomiesLevel3$.next(taxonomiesLevel3);
      }),
      takeUntil(this.ngUnsubscribe)
    );
  }

  private onBusinessUnitChange() {
    return this.selectedFilters$.asObservable().pipe(
      switchMap((currentData) => {
        if (!currentData) {
          return EMPTY;
        }

        const ids: number[] = currentData.businessUnitIDs;
        if (ids.length == 0) {
          currentData.businessAreaIDs = [];
          currentData.legalEntityIDs = [];
          return EMPTY;
        }

        return forkJoin([
          this.businessAreaService.getBusinessAreasByBusinessUnitsIds(ids),
          this.legalEntityService.getLegalEntitiesByBusinessUnitsIds(ids),
        ]);
      }),
      tap(([businessAreas, legalEntities]) => {
        this.businessAreas$.next(businessAreas);
        this.legalEntities$.next(legalEntities);
      }),
      takeUntil(this.ngUnsubscribe)
    );
  }

  onUpdate(observationId: number) {
    const url = `/edit-observation/${observationId}`;
    this.router.navigate([url]);
  }

  onCreate() {
    this.repositoryService.createObservation().subscribe((response) => {
      this.observationSharedService.setID(response.observation.id);
      this.observationSharedService.changeData(response);
      this.router.navigate([
        '/edit-observation/' + response.observation.id + '/details',
      ]);
    });
  }

  onDeleteItemInvoke(observationData: any) {
    this.deletionObservation$.next(observationData);
    this.toggleModal();
  }

  toggleModal() {
    this.modalVisibleState$.next(!this.modalVisibleState$.value);
  }


  sort(sortedColumns: Column[]) {
    sortedColumns =  sortedColumns.filter(column => column.sorted != 0);
    var column = sortedColumns[sortedColumns.length-1]?.for + ";" +sortedColumns[sortedColumns.length-1]?.sorted;
  this.onFilterChange(column);
  }

  // search() {
  //   this.onTableRefresh(1);
  // }

  // searchTermUpdate($event: any) {
  //   this.searchTerm=$event.target.value;
  // }
}
