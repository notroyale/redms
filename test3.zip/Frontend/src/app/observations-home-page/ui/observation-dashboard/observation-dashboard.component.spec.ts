import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObservationDashboardComponent } from './observation-dashboard.component';
import { HttpClientModule } from '@angular/common/http';

describe('ObservationDashboardComponent', () => {
  let component: ObservationDashboardComponent;
  let fixture: ComponentFixture<ObservationDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [ ObservationDashboardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ObservationDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
