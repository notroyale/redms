import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { ObservationListTableHeaderService } from './observation-list-table-header.service';

describe('ObservationListTableHeaderService', () => {
  let service: ObservationListTableHeaderService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(ObservationListTableHeaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
