import { Injectable } from '@angular/core';
import { BusinessArea } from 'src/app/domain/business-area';
import { BusinessUnit } from 'src/app/domain/business-unit';
import { LegalEntity } from 'src/app/domain/legal-entity';
import { Taxonomy } from 'src/app/domain/taxonomy';

@Injectable({
  providedIn: 'root'
})
export class FilterFormatService {

  private statusIDs: [];
  private buIDs: [];
  private baIDs: [];
  private leIDs: [];
  private categoryIDs: [];
  private tax1: [];
  private tax2: [];
  private tax3: [];
  private allTax: Taxonomy[];

  constructor (){
    this.statusIDs = [];
    this.categoryIDs = [];
    this.buIDs = [];
    this.baIDs = [];
    this.leIDs = [];
    this.tax1 = [];
    this.tax2 = [];
    this.tax3 = [];

  }
  
  addFilter(filters:any){
    switch(filters[0]){
      case 'Status':
        this.statusIDs=filters[1];
        break;
      case 'Business Unit':
        this.buIDs=filters[1] as [];
        this.deselectBUsFilters();
        break;
      case 'Business Area':
        this.baIDs=filters[1] as [];
        break;
      case 'Legal Entity':
        this.leIDs=filters[1] as [];
        break;
      case 'Category':
        this.categoryIDs=filters[1] as [];
        break;
      case 'Risk Level 1':
        this.tax1=filters[1] as [];
        this.tax2=[];                     //čia laikinai
        this.tax3=[];
        break;
        case 'Risk Level 2':
        this.tax2=filters[1] as [];
        this.tax3=[];
        break;
      case 'Risk Level 3':
        this.tax3=filters[1] as [];
        break;
      default:
        break;
    }
  }

  deselectBUsFilters(){
    var selectedBus = this.buIDs?.map(x => x['id']) as number[];
  
    this.baIDs = (this.baIDs as BusinessArea[]).filter(x =>selectedBus.includes(x.businessUnitID)) as [];
    this.leIDs = (this.leIDs as LegalEntity[]).filter(x=> x.businessUnits.map(x => x['id']).some(r => selectedBus.includes(r))) as [];

    return;
  }


  formatFilters(){
    return {
      "status" : this.statusIDs.length>0? this.statusIDs.map(x => x['id']) : null,
      'BusinessUnits' :  this.buIDs.length>0? this.buIDs.map(x => x['id']) : null,
      'BusinessAreas' :  this.baIDs.length>0? this.baIDs.map(x => x['id']) : null,
      'LegalEntities' :  this.leIDs.length>0? this.leIDs.map(x => x['id']) : null,
      'Category' :  this.categoryIDs.length>0? this.categoryIDs.map(x => x['id']) : null,
      'Taxonomy' : (this.tax1.length + this.tax2.length + this.tax3.length)>0 ? (this.tax1.concat(this.tax2).concat(this.tax3)).map(x => x['id']) : null,
    }
  }

  formatTaxonomyIDs(){
    return 'Ids=0'+(this.tax1.concat(this.tax2) as Taxonomy[]).map(x => x.id).join("&Ids=");
  }

  getLEsOnSelectedBUs(legalEntities: LegalEntity[]){
    var selectedBus = this.buIDs?.map(x => x['id']) as number[];
    if(selectedBus.length >0)
      return legalEntities.filter(x=>x.businessUnits.map(x => x['id']).some(r => selectedBus.includes(r)));
    return [];
  }

  getBAsOnSelectedBUs(businessAreas: BusinessArea[]){
    var selectedBus = this.buIDs?.map(x => x['id']) as number[];
    if(selectedBus.length >0)
      return businessAreas.filter(x=>selectedBus.includes(x.businessUnitID));
    return [];
  }

  getTaxonomiesByLevel(level : number, tax : Taxonomy[]){
    this.allTax = tax;
    return tax.filter(x=>x.levelID == level);
  }

  deselectTaxonomies(){
    this.tax2 = (this.tax2 as Taxonomy[]).filter(x=> this.allTax.map(x => x['id']).includes(x.id)) as [];
    this.tax3 = (this.tax3 as Taxonomy[]).filter(x=> this.allTax.map(x => x['id']).includes(x.id)) as [];
  }

  getSelectedStatus(){
    return this.statusIDs;
  }
  getSelectedBUs(){
    return this.buIDs;
  }
  getSelectedBAs(){
    return this.baIDs;
  }
  getSelectedLEs(){
    return this.leIDs;
  }
  getSelectedCategories(){
    return this.categoryIDs;
  }
  getSelectedTaxonomies(level : number){
    switch (level){
      case 2:
        return this.tax2;
      case 3:
        return this.tax3;
      default:
        return this.tax1;
        
    }
  }
}
