import { TestBed } from '@angular/core/testing';

import { FilterFormatService } from './filter-format.service';

describe('FilterService', () => {
  let service: FilterFormatService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FilterFormatService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
