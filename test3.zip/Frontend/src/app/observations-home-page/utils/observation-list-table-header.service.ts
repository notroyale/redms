import { Injectable } from '@angular/core';
import { Access, Field } from 'src/app/shared/models/field';
import { FieldType } from 'src/app/shared/models/field-type';
import { FormFilter } from 'src/app/shared/models/filter';
import { Form } from 'src/app/shared/models/form';
import { InputType } from 'src/app/shared/models/input-type';
import { SortType } from 'src/app/shared/models/sort-type';
import { Table } from 'src/app/shared/models/table';
import { ColumnStyleType, ColumnType } from 'src/app/shared/models/table/column-type';

@Injectable({
  providedIn: 'root'
})
export class ObservationListTableHeaderService {
  getGlobalFilters(): any[] {
    return [
      'id', 'title', 'businessUnitName', 'origin', 'registrationDate'
    ];
  }

  getIdField(): any{
    return "id";
  }

  getDeletionForm() : Form{
    return {
      title: "Are you sure you want to delete this Observation?",
      subtitle: "",
      fields: [
        { for: "title", display: "Title", conditional: false, dependsOn: "",
        type: FieldType.Input, placeholder:"", inputType: InputType.Text, styleClass:"",access: Access.None, mandatory:false, visible:true, isDisabled:true },
        { for: "description", display: "Summary", conditional: false, dependsOn: "",
        type: FieldType.TextArea, styleClass:"", access: Access.None,mandatory:false, visible:true, isDisabled:true, placeholder:""},
        { for: "assignee", display: "Compliance Unit - Sign-Off", conditional: false, dependsOn: "",
        type: FieldType.Input, placeholder:"", inputType: InputType.Text, styleClass:"",access: Access.None, mandatory:false, visible:true, isDisabled:true,},
        { for: "deadline", display: "Deadline", conditional: false, dependsOn: "",
        type: FieldType.Input, placeholder:"", inputType: InputType.Text, styleClass:"",access: Access.None, mandatory:false,  visible:true, isDisabled:true,},
        { for: "creationUser", display: "Created by", conditional: false, dependsOn: "",
        type: FieldType.Input, placeholder:"", inputType: InputType.Text, styleClass:"",access: Access.None, mandatory:false,  visible:true, isDisabled:true,},
        { for: "creationDate", display: "Creation date", conditional: false, dependsOn: "",
        type: FieldType.Input, placeholder:"", inputType: InputType.Text, styleClass:"",access: Access.None, mandatory:false,  visible:true, isDisabled:true,},
        { for: "modifiedUser", display: "Last updated by", conditional: false, dependsOn: "",
        type: FieldType.Input, placeholder:"", inputType: InputType.Text, styleClass:"",access: Access.None, mandatory:false, visible:true, isDisabled:true,},
        { for: "modifiedDate", display: "Last updated", conditional: false, dependsOn: "",
        type: FieldType.Input, placeholder:"", inputType: InputType.Text, styleClass:"",access: Access.None, mandatory:false, visible:true, isDisabled:true,},
      ],
      btnLabel: 'Delete'
    }
  }

  getFilters() : Field[]{
    return [
      { for: "businessUnitIDs", display: "Business Unit", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.None,
        type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"businessUnits", mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive" },
      { for: "countries", display: "Country", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.None,
        type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"countries", mandatory:false, isDisabled: false, visible:true, disableAttribute:""  },
      { for: "businessAreaIDs", display: "Business Areas", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.None,
        type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"businessAreas", mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive"  },
      { for: "legalEntityIDs", display: "Legal Entities", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.None,
        type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"legalEntities", mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive"  },
      { for: "statusIDs", display: "Status", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.None,
        type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"status", mandatory:false, isDisabled: false, visible:true, disableAttribute:""  },
      { for: "gradeIDs", display: "Grade", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.None,
        type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"grades", mandatory:false, isDisabled: false, visible:true, disableAttribute:""  },
      { for: "taxonomyLevel1IDs", display: "Risk Level 1", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.None,
        type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"taxonomiesLevel1", mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive"  },
      { for: "taxonomyLevel2IDs", display: "Risk Level 2", displayAttribute: "name", conditional: false, dependsOn: "", access: Access.None,
        type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"taxonomiesLevel2", mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive"  },
      { for: "taxonomyLevel3IDs", display: "Risk Level 3", displayAttribute: "name", conditional: false, dependsOn: "",access: Access.None,
        type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"taxonomiesLevel3", mandatory:false, isDisabled: false, visible:true, disableAttribute:"isActive"  },
      { for: "categoryIDs", display: "Source", displayAttribute: "description", conditional: false, dependsOn: "",access: Access.None,
        type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"categories", mandatory:false, isDisabled: false, visible:true, disableAttribute:""  },
      
      ]
  }

  getObservatioNRepoFilters(): Form {
    return {
      title:"",
      subtitle:"",
      btnLabel:"Filter",
      fields: [
        { for: "businessUnits", display: "Business Unit", displayAttribute: "name", conditional: false, dependsOn: "", access: Access.None,
        type: FieldType.Multiselect, styleClass:"", filterAttribute:"id", key:"businessUnits", mandatory:false, isDisabled: false, visible:true, disableAttribute:"" },
      ]
    }
  }

  getTable(): Table {
    return {
      columns: [
        { headerStyle:'common-header', for: 'id', header: 'Id',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
        { headerStyle:'common-header', for: 'title', header: 'Title',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'bold-column', sorted: SortType.None },
          { headerStyle:'common-header', for: 'status', header: 'Status',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.ChipColumn, styleClass: 'common-column', colorAttribute:"color",displayAttribute:"name", sorted: SortType.None },
        { headerStyle:'common-header', for: 'businessUnit', header: 'Business Unit',
          columnStyle: ColumnStyleType.DropdownInfoColumn,
          type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
        { headerStyle:'common-header', for: 'category', header: 'Source',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.DropdownOptLabelColumn, styleClass: 'common-column', display: 'description', sorted: SortType.None },
        { headerStyle:'common-header', for: 'creationDate', header: 'Reg. Date', 
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
        { headerStyle:'common-header', for: 'level', header: 'Grade',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
        { headerStyle:'common-header', for: 'deadline', header: 'Deadline',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
        { headerStyle:'common-header', for: 'riskOwner', header: 'Owner',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
        { headerStyle:'common-header', for: 'creationUser', header: 'Created By',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
        { headerStyle:'common-header', for: 'closureDate', header: 'Closure Date',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'common-column', sorted: SortType.None },
        { headerStyle:'common-header', for: 'ragStatus', header: 'RAG Status',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.BadgeColumn, styleClass: 'common-column',displayAttribute:"name",colorAttribute:"color", sorted: SortType.None },
        { headerStyle:'actions-header', for: 'actions', header: 'Actions',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'right',
          type: ColumnType.ActionButtonObs, styleClass: 'actions-column', sorted: SortType.None }
      ],
      totalCount: 0,
      page: 1,
      rows: 10,//need to fix table to handle new refractor type columns
      first: 1
    };
  }
}
