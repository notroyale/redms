import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthenticatedResult, LoginResponse, OidcSecurityService } from 'angular-auth-oidc-client';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent implements OnInit {
  isAuthenticated$: Observable<AuthenticatedResult>;
  constructor(private oidcSecurityService: OidcSecurityService) {}
  isAuth: boolean;
  isExpired: boolean = false;

  ngOnInit() {
    this.oidcSecurityService
    .checkAuth()
    .subscribe(({ isAuthenticated, userData, accessToken }) => {
      this.checkTokenExpired(accessToken);

      this.setUser(userData.unique_name);
    });
  }
  checkTokenExpired( tokenId: String) {
    var interval = setInterval( async () => {
        var currentTime = (new Date).getTime();
        var expireSessionTime = (JSON.parse(atob(tokenId.split('.')[1]))).exp * 1000;
        var exp = new Date(expireSessionTime);
        var cur = new Date(currentTime);
        if(cur > exp) {
          this.isExpired = true;
          // tokenId = await this.getToken();
          clearInterval(interval);

        }
    }, 10000);
}

  login() {
    this.oidcSecurityService.authorize();
  }

  logout() {
    this.oidcSecurityService
      .logoff()
      .subscribe((result) => console.log(result));
  }

  async getToken(){
    let token: string;
    const promise = new Promise<string>((resolve, reject) => {
      this.oidcSecurityService.getAccessToken().subscribe(
        x => {
          resolve(x);
        },
        error => reject(error)
      );
    });

    token = await promise;
    return token;
  }
  setUser(uniqueBnum:string){
    if(!uniqueBnum)
      return;
    const index = uniqueBnum.indexOf('\\B');
    if(index==-1)
      return;
    const bnum = uniqueBnum.substring(index+1);
    window.sessionStorage.setItem("userBnumber",bnum);
  }
}
