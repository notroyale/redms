import { Component } from '@angular/core';

@Component({
  selector: 'app-network-error-page',
  templateUrl: './network-error-page.component.html',
  styleUrls: ['./network-error-page.component.css']
})
export class NetworkErrorPageComponent {

}
