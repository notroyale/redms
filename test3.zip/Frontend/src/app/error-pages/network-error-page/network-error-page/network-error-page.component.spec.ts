import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NetworkErrorPageComponent } from './network-error-page.component';

describe('NetworkErrorPageComponent', () => {
  let component: NetworkErrorPageComponent;
  let fixture: ComponentFixture<NetworkErrorPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NetworkErrorPageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NetworkErrorPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
