import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { Observable } from 'rxjs';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class RepositoryService {

  constructor(private http: HttpClient, private oidcSecurityServices: OidcSecurityService) {}

  public getAll(skip: number, rows: number): Observable<DataTableRequest> {
    return this.http.get<DataTableRequest>(`${settings.apibaseUrl}/api/Observation/allBase/options?page=${skip}&pageSize=${rows}`);
  }

  // public addToken() {
  //   this.oidcSecurityServices.getAccessToken().subscribe((token) => {
  //     const httpOptions = {
  //       headers: new HttpHeaders({
  //         Authorization: 'Bearer ' + token,
  //       }),
  //     };
  //   });
  // }
}
