import { Component, OnInit } from '@angular/core';
import { LazyLoadEvent } from 'primeng/api';
import { Subject, combineLatest, finalize, map, of } from 'rxjs';
import { RepositoryService } from '../../data-access/repository.service';
import { ObservationListTableHeaderService } from '../../utils/observation-list-table-header.service';
import { AuthService } from 'src/app/auth/data-access/auth.service';
import { StorageService } from 'src/app/storage/data-access/storage.service';
import { Router } from '@angular/router';
import { DataTable } from 'src/app/shared/models/data-table';
import { DropdownField } from 'src/app/shared/models/dropdown-field';
import { Field } from 'src/app/shared/models/field';
import { Table } from 'src/app/shared/models/table';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { FieldType } from 'src/app/shared/models/field-type';
import { Observation } from 'src/app/domain/observation';
import { ObservationRepo } from 'src/app/domain/observation-repo';

@Component({
  selector: 'app-observation-dashboard',
  templateUrl: './observation-dashboard.component.html',
  styleUrls: ['./observation-dashboard.component.css'],
})
export class ObservationDashboardComponent implements OnInit {
  observations$ = new Subject<DataTable>();
  table: Table;

  onInit = true; // Flag to prevent onInit lazy load
  loading = true; // Flag to prevent multiple requests
  idField: any = "title";
  field: DropdownField = { for: "title", display: "Title", type: FieldType.Dropdown, styleClass: "", displayAttribute:"", filterAttribute:"",key:""};
  filters: DropdownField;

  constructor(
    private repositoryService: RepositoryService,
    private observationsTableHeaderService: ObservationListTableHeaderService,
    private authService: AuthService,
    private storageService: StorageService,
    private router: Router
  ) { }

  lazyLoad($event: LazyLoadEvent) {
    if (this.onInit) {
      this.onInit = false;
      return;
    }

    const first = $event.first || this.table.first;
    const rows = $event.rows || this.table.rows;

    this.fetchData(first, rows); //first/rows +1
  }

  ngOnInit(): void {

    // this.roles = this.storageService.getUser().roles;
    this.idField = this.observationsTableHeaderService.getIdField();
    this.table = this.observationsTableHeaderService.getTable();
    this.fetchData(this.table.first, this.table.rows);
  }

  fetchData(first: number, rows: number) {
    this.loading = true;

    combineLatest([
      this.repositoryService.getAll(first, rows)
    ])
      .pipe(
        finalize(() => {
          this.loading = false;
        }),
        map(([data]) =>
          this.mapTableData(this.table, data),
        )
      )
      .subscribe((response) => {
        const x: DataTable = {
          data : response.data.map(x => x.observation),
          filters: response.filters,
          table: response.table
        };
        console.log(x);

        this.observations$.next(x);
      });
  }

  onEditItem(item: any){

  }

  mapTableData(table: Table, request: DataTableRequest): DataTable {
    return {
      data: request.values,
      filters: [],
      table: {
        totalCount: request.totalCount,
        page: request.page,
        columns: table.columns,
        rows: table.rows,
        first: table.first
      }
    }
  }
}
