import { Injectable } from '@angular/core';
import { Table } from 'src/app/shared/models/table';
import { ColumnStyleType, ColumnType } from 'src/app/shared/models/table/column-type';

@Injectable({
  providedIn: 'root'
})
export class ObservationListTableHeaderService {
  getGlobalFilters(): any[] {
    return [
      'id', 'title', 'businessUnitName', 'origin', 'registrationDate'
    ];
  }

  getIdField(): any{
    return "id";
  }

  getTable(): Table {
    return {
      columns: [
        { headerStyle:'common-header', for: 'id', header: 'Id',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column' },
        { headerStyle:'common-header', for: 'title', header: 'Title',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'bold-column' },
          { headerStyle:'common-header', for: 'status', header: 'Status',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.ChipColumn, styleClass: 'common-column', colorAttribute:"color",displayAttribute:"name" },
        { headerStyle:'common-header', for: 'businessUnit', header: 'Business Unit',
          columnStyle: ColumnStyleType.DropdownInfoColumn,
          type: ColumnType.TextColumn, styleClass: 'common-column' },
        { headerStyle:'common-header', for: 'category', header: 'Origin',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.DropdownOptLabelColumn, styleClass: 'common-column', display: 'description' },
        // { headerStyle:'common-header', field: 'registrationDate', header: 'Reg. Date', type: 'text', styleClass: 'common-column' },
        { headerStyle:'common-header', for: 'level', header: 'Grade',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'common-column' },
        { headerStyle:'common-header', for: 'deadline', header: 'Deadline',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'common-column' },
        { headerStyle:'common-header', for: 'riskOwner', header: 'Owner',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'common-column' },
        { headerStyle:'common-header', for: 'creationUser', header: 'Created By',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'common-column' },
        { headerStyle:'common-header', for: 'closureDate', header: 'Closure Date',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.TextColumn, styleClass: 'common-column' },
        { headerStyle:'common-header', for: 'ragStatus', header: 'RAG Status',
          columnStyle: ColumnStyleType.CommonColumn, type: ColumnType.BadgeColumn, styleClass: 'common-column',displayAttribute:"name",colorAttribute:"color" },
        { headerStyle:'actions-header', for: 'actions', header: 'Actions',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'right',
          type: ColumnType.ActionButtonObs, styleClass: 'actions-column' }
      ],
      totalCount: 0,
      page: 1,
      rows: 10,//need to fix table to handle new refractor type columns
      first: 1
    };
  }
}
