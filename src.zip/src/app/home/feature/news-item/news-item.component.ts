import { Component, Input } from '@angular/core';
import { NewsEntry } from 'src/app/domain/news-entry';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-news-item',
  templateUrl: './news-item.component.html',
  styleUrls: ['./news-item.component.css']
})
export class NewsItemComponent {
  @Input() newsEntry: NewsEntry;

}
