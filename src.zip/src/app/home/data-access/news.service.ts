import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { NewsEntry } from 'src/app/domain/news-entry';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class NewsService {
  constructor(private http: HttpClient) { }

  public getAll(): Observable<NewsEntry[]>{
    return this.http.get<NewsEntry[]>(`${settings.apibaseUrl}/api/News/all`);
  }
}
