import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Subject, combineLatest, finalize, map, of } from 'rxjs';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { GradeService } from 'src/app/admin-pages/grades/data-access/grade.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Form } from 'src/app/shared/models/form';
import { DataForm } from 'src/app/shared/models/data-form';
import { DetailsStep, DetailsStepResponse } from 'src/app/domain/observation';
import { CategoryService } from 'src/app/admin-pages/categories/data-access/category.service';
import { ObservationService } from '../../data-access/observation.service';

@Component({
  selector: 'app-step-details',
  templateUrl: './step-details.component.html',
  styleUrls: ['./step-details.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StepDetailsComponent implements OnInit {
  step: Form;
  dataForm$ = new Subject<DataForm>();
  data: DetailsStep;
  loading: boolean = false;
  observationID: any;
  constructor(
    private observationService: ObservationService,
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private gradeService: GradeService,
    private categoryService: CategoryService,
    private router: Router) { }

  ngOnInit() {
    const steps = this.observationFieldsService.getObservationSteps();
    this.step = steps.detailsStep;


    combineLatest([
      of(this.observationFieldsService.getObservationSteps().detailsStep),
      this.observationSharedService.currentData$,
      this.gradeService.getAll(),
      this.categoryService.getAll()
    ])
    .pipe(
      finalize(() => {
        this.loading = false;
      }),
      map(([form, formData, gradesDropData, categoriesDropData]) =>
        this.mapFormData(form, formData.detailsStep, gradesDropData, categoriesDropData)
      )
    )
    .subscribe((response) => {
      console.log(response);

      this.dataForm$.next(response);
    });
  }

  mapFormData(form: Form, data: any, gradesDropData: any[], categoriesDropData: any[]) : DataForm {
    return {
      form: form,
      data: data,
      dropdownsData: {
        grades: gradesDropData,
        categories: categoriesDropData
      }
    }
  }

  onUpdateForm(item: any){

    const response: DetailsStepResponse = {
      title: item.title,
      categoryId: item.category.id,
      dateIdentified: item.dateIdentified,
      deadline: item.deadline,
      revisedDeadline: item.revisedDeadline,
      gradeID: item.grade.id,
      description: item.description
    }
    this.observationService.updateDetailsStep(this.observationSharedService.routeID,response).pipe(
      finalize(() => {
        this.loading = false;
      }),
    ).subscribe((response) => {
      console.log(response);
    });
    this.nextPage(this.observationSharedService.routeID);
  }

  nextPage(id: number) {
    this.router.navigate(['/edit-observation/'+ id +'/responsibility-centre']);
  }
}
