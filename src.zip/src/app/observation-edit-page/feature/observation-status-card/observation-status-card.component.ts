import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component } from '@angular/core';

@Component({
  selector: 'app-observation-status-card',
  animations: [
    trigger('openClose', [
      state('open', style({
        height: '*',
        opacity: '1'
      })),
      state('closed', style({
        height: '0',
        opacity: '0'
      })),
      transition('open => closed', [
        animate('0.2s')
      ]),
      transition('closed => open', [
        animate('0.2s')
      ]),
    ]),
  ],
  templateUrl: './observation-status-card.component.html',
  styleUrls: ['./observation-status-card.component.css']
})
export class ObservationStatusCardComponent {
  isOpen: boolean = false;



  toggle(){
    this.isOpen = !this.isOpen;
  }
}
