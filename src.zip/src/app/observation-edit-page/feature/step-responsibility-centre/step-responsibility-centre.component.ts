import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Subject, combineLatest, finalize, map, of } from 'rxjs';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { BusinessUnitService } from 'src/app/admin-pages/business-units/data-access/business-unit.service';
import { Form } from 'src/app/shared/models/form';
import { DataForm } from 'src/app/shared/models/data-form';
import { BusinessAreaService } from 'src/app/admin-pages/business-areas/data-access/business-area.service';
import { LegalEntityService } from 'src/app/admin-pages/legal-entities/data-access/legal-entity.service';
import { CountriesService } from '../../data-access/countries.service';
import { Observation, ResponsibilityCentreStep } from 'src/app/domain/observation';
import { ObservationBaCountryReq } from 'src/app/domain/requests/observation-ba-country-req';
import { ObservationService } from '../../data-access/observation.service';
import { ObservationResponsibilityCenterReq } from 'src/app/domain/requests/observation-responsibility-center-req';
import { Router } from '@angular/router';

@Component({
  selector: 'app-step-responsibility-centre',
  templateUrl: './step-responsibility-centre.component.html',
  styleUrls: ['./step-responsibility-centre.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StepResponsibilityCentreComponent implements OnInit {
  dataForm$ = new Subject<DataForm>();

  loading: boolean = false;

  constructor(
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private businessUnitService: BusinessUnitService,
    private countriesService: CountriesService,
    private businessAreaService: BusinessAreaService,
    private legalEntityService: LegalEntityService,
    private observationService: ObservationService,
    private router: Router) { }

  ngOnInit() {
    combineLatest([
      of(this.observationFieldsService.getObservationSteps().responsibleCentreStep),
      this.observationSharedService.currentData$,
      this.businessUnitService.getAll(),
      this.countriesService.getAll(),
      this.businessAreaService.getAll(),
      this.legalEntityService.getAll()
    ])
    .pipe(
      finalize(() => {
        this.loading = false;
      }),
      map(([form, formData, busDropData, countriesDropData, basDropData, lesDropData]) =>
        this.mapFormData(form, formData.responsibleCentreStep, busDropData, countriesDropData, basDropData, lesDropData)
      )
    )
    .subscribe((response) => {
      console.log(response);

      this.dataForm$.next(response);
    });
  }

  mapFormData(form: Form, data: any, busDropData: any[], countriesDropData: any[], basDropData: any[], lesDropData: any[]) : DataForm {
    return {
      form: form,
      data: data,
      dropdownsData: {
        businessUnits: busDropData,
        countries: countriesDropData,
        businessAreas: basDropData,
        legalEntities: lesDropData,
        businessAreasCountries: data.businessAreasCountries
      }
    }
  }

  onUpdateForm(item: ResponsibilityCentreStep){
    // console.log(item);
    const responsibilityCentreStepData: ObservationResponsibilityCenterReq = {
      businessUnitID: item.businessUnit.id,
      activityOwner: item.activityOwner,
      assignee: item.assignee,
      riskOwner: item.riskOwner,
      legalEntities: item.legalEntities};
    console.log(responsibilityCentreStepData);
    this.observationService.updateResposibilityCenterStep(this.observationSharedService.routeID, responsibilityCentreStepData).pipe().subscribe(response => response);;
    this.nextPage(this.observationSharedService.routeID);
  }


  nextPage(id: number) {
    this.router.navigate(['/edit-observation/'+ id +'/risk-categorization']);
  }
  onBaCountryUpdate(data: any) {

    if(!data || !data.businessAreaID || !data.countryID || !data.observationID) {
      console.log("business area is NOT saved");
      return;
    }
    const observationBaCountryReq: ObservationBaCountryReq = {
      observationID: data.observationID,
      businessAreaID: data.businessAreaID,
      countryID: data.countryID
    };

    console.log(data);
    this.observationService.addBaCountry(observationBaCountryReq).subscribe(data=>console.log(data));
    //-- need to add some notification, that business area was successfuly added.
  }
}
