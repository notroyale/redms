import { Component } from '@angular/core';
import {
  BehaviorSubject,
  Subject,
  combineLatest,
  finalize,
  forkJoin,
  map,
  switchMap,
} from 'rxjs';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { Form } from 'src/app/shared/models/form';
import { DataForm } from 'src/app/shared/models/data-form';
import { ResponsibilityCentreStep, RiskCategorizationStep } from 'src/app/domain/observation';
import { TaxonomyService } from 'src/app/admin-pages/taxonomies/data-access/taxonomy.service';
import { Taxonomy } from 'src/app/domain/taxonomy';
import { ObservationRiskCategorizationReq } from 'src/app/domain/requests/observation-risk-categorization';
import { ObservationService } from '../../data-access/observation.service';
import { Router } from '@angular/router';
import { TaxonomyLevel } from 'src/app/domain/taxonomy-level';

@Component({
  selector: 'app-step-risk-categorization',
  templateUrl: './step-risk-categorization.component.html',
  styleUrls: ['./step-risk-categorization.component.css'],
})
export class StepRiskCategorizationComponent {
  step: Form;
  dataForm$ = new BehaviorSubject<DataForm>({
    data: {},
    dropdownsData: {},
    form: {
      title: '',
      subtitle: '',
      fields: [],
      btnLabel: '',
    },
  });
  data: StepRiskCategorizationComponent;
  temp$ = new Subject<any>();
  levels$ = new BehaviorSubject<TaxonomyLevel[]>([]);
  loading: boolean = false;

  constructor(
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private taxonomyService: TaxonomyService,
    private observationService: ObservationService,
    private router: Router
  ) {}

  ngOnInit() {
    const firstLevel = 1;
    this.taxonomyService.getTaxonomyLevels().subscribe(x => this.levels$.next(x));
    combineLatest([
      this.observationSharedService.currentData$.pipe(
        map((formData) => formData.riskCategorizationStep)
      ),
      this.taxonomyService.getAllByLevel(firstLevel),
      this.levels$
    ])
      .pipe(
        map(([data, firstLevelTax, allLevels]) => {
          let dropdownsData : { [key: string] : any[] } = {};
          dropdownsData[firstLevel] = firstLevelTax;

          allLevels.forEach(level => {
            if(!data.taxonomies[level.level]) {
              console.log("Level : " + level.level + " does not exist");
              data.taxonomies[level.level] = [];
              return;
            }

            const itemsIDs: number[] = data.taxonomies[level.level].map(
              (tax: Taxonomy) => tax.id
            );

              if(level.level == allLevels.length) {
                return;
              }
            this.taxonomyService.getChildrenByIds(itemsIDs)
              .subscribe((childrenTax) => {
                dropdownsData[+level.level+1] = childrenTax.values;
              });
          });



          // for (const key in data.taxonomies) {
          //   const itemsIDs: number[] = data.taxonomies[key].map(
          //     (tax: Taxonomy) => tax.id
          //   );

          //   this.taxonomyService.getChildrenByIds(itemsIDs)
          //     .subscribe((childrenTax) => {
          //       dropdownsData[+key+1] = childrenTax.values;
          //     });
          // }
          return {
            form: this.observationFieldsService.getObservationSteps().riskCategorizationStep,
            data: data,
            dropdownsData: dropdownsData
          };
        })
      )
      .subscribe((response) => {
        console.log(response);
        this.dataForm$.next(response);
      });
  }

  onUpdateForm(item: any) {
    console.log(item);

    const riskCategorizationStepData: ObservationRiskCategorizationReq = {
      businessLine: item.businessLine,
      directive: item.directive,
      taxonomyLevel1: item.taxonomies[1][0].id,
      taxonomiesLevel2: item.taxonomies[2].map((x: Taxonomy) => x.id),
      taxonomiesLevel3: item.taxonomies[3].map((x: Taxonomy) => x.id)
    };
    console.log(riskCategorizationStepData);
    this.observationService.updateRiskCategorizationStep(this.observationSharedService.routeID, riskCategorizationStepData).pipe().subscribe(response => response);;
    this.nextPage(this.observationSharedService.routeID);
  }

  onMultiSelectChange(item: any) {
     console.log(item);

    const level: number = +item.key + 1;
    console.log("level is: "+level);
    let taxLimit = false;
    this.levels$.subscribe(x => {
      console.log("lenght: " + x.length)
      if(x.length < level){
        taxLimit = true;
        return;
      }
    });
    if(taxLimit) {return;}
    if (!item || item.selectedOptions.length === 0) {
      this.dataForm$.pipe(
        map((dataForm) => {
          for (const key in dataForm.dropdownsData) {
            if (+key >= level) {
              dataForm.dropdownsData[key] = [];
              dataForm.data.taxonomies[key] = [];
            }
          }

          return dataForm;
        })
      ).subscribe();

      return;
    }

    const itemsIDs: number[] = item.selectedOptions.map(
      (tax: Taxonomy) => tax.id
    );

    combineLatest([
      this.dataForm$,
      this.taxonomyService.getChildrenByIds(itemsIDs).pipe(
        map((req) => req.values)
      ),
    ])
      .pipe(
        map(([dataForm, taxLev]) => {
          console.log(dataForm);
          if(!taxLev) {
            return dataForm;
          }

          dataForm.dropdownsData[level] = taxLev;
          dataForm.data.taxonomies[level] =
            dataForm.data.taxonomies[level].filter((element: Taxonomy) =>
              dataForm.dropdownsData[level].some((item) => item.id === element.id)
            );
            console.log(dataForm.dropdownsData[level])

          return dataForm;
        })
      )
      .subscribe();
  }

  loadTaxonomyLevels() {

  }

  nextPage(id: number) {
    this.router.navigate(['/edit-observation/'+ id +'/collab-fields']);
  }
}
