import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StepRiskCategorizationComponent } from './step-risk-categorization.component';
import { HttpClientModule } from '@angular/common/http';
import { FormComponent } from 'src/app/shared/components/form/form.component';
import { ButtonComponent } from 'src/app/shared/components/button/button.component';

describe('StepRiskCategorizationComponent', () => {
  let component: StepRiskCategorizationComponent;
  let fixture: ComponentFixture<StepRiskCategorizationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [ StepRiskCategorizationComponent, FormComponent, ButtonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StepRiskCategorizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
