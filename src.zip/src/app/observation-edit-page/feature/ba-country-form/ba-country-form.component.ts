import { Component, Input, Output, EventEmitter } from '@angular/core';
import { DropdownField } from 'src/app/shared/models/dropdown-field';
import { Field } from 'src/app/shared/models/field';
import { FieldType } from 'src/app/shared/models/field-type';
import { FormField } from 'src/app/shared/models/form-field';
import { ObservationService } from '../../data-access/observation.service';
import { ObservationBusinessAreaCountry } from 'src/app/domain/observation-business-area-country';
import { ObservationBaCountryReq } from 'src/app/domain/requests/observation-ba-country-req';
import { ObservationSharedService } from '../../data-access/observation-shared.service';

@Component({
  selector: 'app-ba-country-form',
  templateUrl: './ba-country-form.component.html',
  styleUrls: ['./ba-country-form.component.css']
})
export class BaCountryFormComponent {
 data : any = {   dropdownsData: {
    businessAreas: {},
    countries: {}
  }};
  @Input() dropdowns: any;
  @Input() formField: FormField;
  @Output() onSave = new EventEmitter<any>();
  @Input() dataTest: any;

  fieldType = FieldType;
  asDropdownField = (field: Field) => field as DropdownField;
  labelClass: string = "label-custom";

  constructor(
    private observationService: ObservationService,
    private observationSharedService: ObservationSharedService
  ) { }

  saveForm() {
    console.log("reaching");
    console.log(this.dataTest);
    
    this.dataTest.push({
              observationID: +this.observationSharedService.routeID,
              businessAreaID: this.data.dropdownsData.businessAreas.id,
              countryID: this.data.dropdownsData.countries.id
            });
    this.onSave.emit({
            observationID: +this.observationSharedService.routeID,
            businessAreaID: this.data.dropdownsData.businessAreas.id,
            countryID: this.data.dropdownsData.countries.id
          });

//     if(!this.data || !this.data.dropdownsData || !this.data.dropdownsData.businessAreas || !this.data.dropdownsData.countries) {
//       return;
//     }
//     const observationBaCountryReq: ObservationBaCountryReq = {
//       observationID: +this.observationSharedService.routeID,
//       businessAreaID: this.data.dropdownsData.businessAreas.id,
//       countryID: this.data.dropdownsData.countries.id
//     };
// console.log(this.data);
//     this.data.businessAreasCountries.push(observationBaCountryReq);
//     this.observationService.addBaCountry(observationBaCountryReq).subscribe(data=>console.log(data));
  }


}
