import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BaCountryFormComponent } from './ba-country-form.component';

describe('BaCountryFormComponent', () => {
  let component: BaCountryFormComponent;
  let fixture: ComponentFixture<BaCountryFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BaCountryFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BaCountryFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
