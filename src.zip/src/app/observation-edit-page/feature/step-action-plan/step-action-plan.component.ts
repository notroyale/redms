import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import {
  BehaviorSubject,
  Subject,
  combineLatest,
  finalize,
  map,
  of,
} from 'rxjs';
import { Form } from 'src/app/shared/models/form';
import { DataForm } from 'src/app/shared/models/data-form';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { ActionPlanStep } from 'src/app/domain/observation';
import { ActionPlanService } from '../../data-access/action-plan-service/action-plan.service';
import { ActionPlan } from 'src/app/domain/action-plan';
import { formatCurrency, formatDate } from '@angular/common';
import { Field } from 'src/app/shared/models/field';
import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { Router } from '@angular/router';
import { BusinessAreaService } from 'src/app/admin-pages/business-areas/data-access/business-area.service';
import { BusinessArea } from 'src/app/domain/business-area';
import { ObservationBaCountryReq } from 'src/app/domain/requests/observation-ba-country-req';
import { Taxonomy } from 'src/app/domain/taxonomy';

@Component({
  selector: 'app-step-action-plan',
  templateUrl: './step-action-plan.component.html',
  styleUrls: ['./step-action-plan.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('leftRight', [
      state('left', style({})),
      state(
        'right',
        style({
          transform: 'translateX(-100%)',
        })
      ),
      transition('left => right', [animate('0.2s')]),
      transition('right => left', [animate('0.2s')]),
    ]),
  ],
})
export class StepActionPlanComponent implements OnInit {
  step: Form;
  dataForm$ = new BehaviorSubject<DataForm>({
    data: {},
    dropdownsData: {},
    form: {
      title: '',
      subtitle: '',
      fields: [],
      btnLabel: '',
    },
  });

  sideDataForm$ = new BehaviorSubject<DataForm>({
    data: {},
    dropdownsData: {},
    form: {
      title: '',
      subtitle: '',
      fields: [],
      btnLabel: '',
    },
  });

  isOpen: boolean = false;
  loading: boolean = false;
  overlayPanelVisible: boolean = true;

  constructor(
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private actionPlanService: ActionPlanService,
    private businessAreaService : BusinessAreaService,
    private router: Router
  ) {}

  ngOnInit() {
    combineLatest([
      of(this.observationFieldsService.getObservationSteps().actionPlanStep),
      this.observationSharedService.currentData$
    ])
      .pipe(
        finalize(() => {
          this.loading = false;
        }),
        map(([form, formData]) => this.mapFormData(form, formData.actionPlanStep)
        )
      )
      .subscribe((response) => {
        console.log(response);

        this.dataForm$.next(response);
      });
  }

  mapFormData(form: Form, data: any): DataForm {
    return {
      form: form,
      data: data,
      dropdownsData: {},
    };
  }

  mapSideFormData(fields: Field[], data: any, dropdownBA : any[], dropdownTax: any[]): DataForm {
    data.modifiedDate = new Date().toISOString();
    return {
      form: {
        title: '',
        subtitle: '',
        fields: fields,
        btnLabel: '',
      },
      data: data as ActionPlan,
      dropdownsData: {
        actionbusinessAreas : dropdownBA,
        actionTaxonomyLevel3s : dropdownTax
      },
    };
  }

  onUpdateForm(item: any) {
    if(item.businessArea)
      item.businessAreaID = item.businessArea.id;
    if(item.taxonomyLvl3)
      item.taxonomyLevel3ID = item.taxonomyLvl3.id;

    if(item.id) {
      this.actionPlanService.update(item).pipe().subscribe(response => response);
    }
    else {
      this.actionPlanService.add(item).pipe().subscribe(response => response);
    }
    
    this.toggle();
  }

  onBusinessAreaChange(item: any) {
    console.log(item);
  }

  nextPage() {
    this.router.navigate(['/edit-observation/'+ this.observationSharedService.routeID +'/additional-details']);
  }

  onEdit(item: ActionPlan) {
    this.isOpen = !this.isOpen;
    this.overlayPanelVisible = false;
    combineLatest([
      of(
        this.observationFieldsService.getObservationSteps().actionPlanStep
          .formFields
      ),
      this.actionPlanService.get(item.id),
      this.observationSharedService.currentData$,
      this.businessAreaService.getAll()
    ])
      .pipe(
        finalize(() => {
          this.loading = false;
        }),
        map(([form, formData, observationData, businessArea]) => {
          var dropdownBusinessAreas = businessArea.filter(x=> observationData.responsibleCentreStep.businessAreasCountries.some((y: ObservationBaCountryReq)=> y.businessAreaID == x.id ));
          var dropdownTaxonomies = observationData.riskCategorizationStep.taxonomies[3];
          return this.mapSideFormData(form, formData,dropdownBusinessAreas, dropdownTaxonomies);
        })
        
      )
      .subscribe((response) => {
        console.log(response);

        this.sideDataForm$.next(response);
      });
  }

  toggle() {
    this.isOpen = !this.isOpen;
    this.overlayPanelVisible = false;
  }

  onCreate() {
    this.isOpen = !this.isOpen;
    this.overlayPanelVisible = false;
    
    combineLatest([
      of(
        this.observationFieldsService.getObservationSteps().actionPlanStep
          .formFields
      ),
      this.observationSharedService.currentData$,
      this.businessAreaService.getAll()
    ])
      .pipe(
        finalize(() => {
          this.loading = false;
        }),
        map(([form, observationData, businessArea]) => {
          var dropdownBusinessAreas = businessArea.filter(x=> observationData.responsibleCentreStep.businessAreasCountries.some((y: ObservationBaCountryReq)=> y.businessAreaID == x.id ));
          var dropdownTaxonomies = observationData.riskCategorizationStep.taxonomies[3];
          var newData = {
            activityOwner : observationData.responsibleCentreStep.activityOwner,
            deadline : observationData.detailsStep.deadline,
            observationID : observationData.id,            
            creationDate : new Date().toISOString(),
            actionStatus : "1"
          } 
          return this.mapSideFormData(form, newData, dropdownBusinessAreas, dropdownTaxonomies);
        })
        
      )
      .subscribe((response) => {
        console.log(response);

        this.sideDataForm$.next(response);
      });
      return;

  }

}
