import { Component } from '@angular/core';

@Component({
  selector: 'app-step-additional-details',
  templateUrl: './step-additional-details.component.html',
  styleUrls: ['./step-additional-details.component.css']
})
export class StepAdditionalDetailsComponent {

}
