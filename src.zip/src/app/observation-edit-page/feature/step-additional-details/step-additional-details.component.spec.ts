import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StepAdditionalDetailsComponent } from './step-additional-details.component';

describe('StepAdditionalDetailsComponent', () => {
  let component: StepAdditionalDetailsComponent;
  let fixture: ComponentFixture<StepAdditionalDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StepAdditionalDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StepAdditionalDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
