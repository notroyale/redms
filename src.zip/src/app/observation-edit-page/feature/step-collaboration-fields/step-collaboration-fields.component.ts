import { Component } from '@angular/core';
import { BusinessUnit } from 'src/app/domain/business-unit';
import { Observable, Subject, combineLatest, finalize, map, of } from 'rxjs';
import { Grade } from 'src/app/domain/grade';
import { ObservationSharedService } from '../../data-access/observation-shared.service';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { BusinessUnitService } from 'src/app/admin-pages/business-units/data-access/business-unit.service';
import { GradeService } from 'src/app/admin-pages/grades/data-access/grade.service';
import { Router } from '@angular/router';
import { Fields } from 'src/app/shared/models/fields';
import { Step } from 'src/app/shared/models/step';
import { DropdownField } from 'src/app/shared/models/dropdown-field';
import { TextareaField } from 'src/app/shared/models/textarea-field';
import { Form } from 'src/app/shared/models/form';
import { DataForm } from 'src/app/shared/models/data-form';
import { CollabFieldsStep, DetailsStep } from 'src/app/domain/observation';
import { RagStatusService } from 'src/app/admin-pages/rag-status/data-access/rag-status.service';
import { ObservationService } from '../../data-access/observation.service';
@Component({
  selector: 'app-step-collaboration-fields',
  templateUrl: './step-collaboration-fields.component.html',
  styleUrls: ['./step-collaboration-fields.component.css']
})
export class StepCollaborationFieldsComponent {
  step: Form;
  dataForm$ = new Subject<DataForm>();
  data: DetailsStep;
  businessUnits$: Observable<BusinessUnit[]>;
  grades$: Observable<Grade[]>;
  loading: boolean = false;

  asDropdownField = (fields: Fields) => fields as DropdownField;
  asTextareaField = (fields: Fields) => fields as TextareaField;

  constructor(
    private observationFieldsService: ObservationFieldsService,
    private observationSharedService: ObservationSharedService,
    private ragStatusService: RagStatusService,
    private observationService: ObservationService,
    private router: Router) { }

  ngOnInit() {


    combineLatest([
      of(this.observationFieldsService.getObservationSteps().collabFieldsStep),
      this.observationSharedService.currentData$,
      this.ragStatusService.getAll()
    ])
    .pipe(
      finalize(() => {
        this.loading = false;
      }),
      map(([form, formData, ragStatusesDropData]) =>
        this.mapFormData(form, formData.collabFieldsStep, ragStatusesDropData)
      )
    )
    .subscribe((response) => {
      console.log(response);

      this.dataForm$.next(response);
    });
  }

  mapFormData(form: Form, data: any, ragStatusesDropData: any[]) : DataForm{
    return {
      form: form,
      data: data,
      dropdownsData: {
        ragStatuses: ragStatusesDropData
      }
    }
  }
  onUpdateForm(item: any){
    console.log(item);

    const response: CollabFieldsStep = {
      comment: item.comment,
      comment1LoD: item.comment1LoD,
      ragStatusID: item.ragStatus.id
    }
    this.observationService.updateCollaborationFieldStep(this.observationSharedService.routeID, response).pipe(
      finalize(() => {
        this.loading = false;
      }),
    ).subscribe((response) => {
      console.log(response);
    });
    this.nextPage(this.observationSharedService.routeID);
  }
  nextPage(id: number) {
    this.router.navigate(['/edit-observation/'+ id +'/action-plan']);
  }
}
