import { Component, OnInit } from '@angular/core';
import { Observable, Subject, map } from 'rxjs';
import { Observation } from 'src/app/domain/observation';
import { ActivatedRoute } from '@angular/router';
import { ObservationSteps } from '../../utils/observation-steps';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ObservationFieldsService } from '../../utils/observation-fields.service/observation-fields.service';
import { StorageService } from 'src/app/storage/data-access/storage.service';
import { AuthService } from 'src/app/auth/data-access/auth.service';
import { ObservationSharedService } from '../../data-access/observation-shared.service';

@Component({
  selector: 'app-observation-edit',
  templateUrl: './observation-edit.component.html',
  animations: [
    trigger('openClose', [
      state('open', style({
        height: '*',
        opacity: '1'
      })),
      state('closed', style({
        height: '0',
        opacity: '0'
      })),
      transition('open => closed', [
        animate('0.2s')
      ]),
      transition('closed => open', [
        animate('0.2s')
      ]),
    ]),
  ],
  styleUrls: ['./observation-edit.component.css']
})
export class ObservationEditComponent implements OnInit {
  fields: ObservationSteps;
  sectionStatus: boolean = false;

  isOpen: boolean = false;

  toggle(){
    this.isOpen = !this.isOpen;
  }

  constructor(
    private observationFieldsService: ObservationFieldsService,
    private route: ActivatedRoute, private storageService: StorageService, private authService: AuthService ) { }

  ngOnInit(): void {
    // if (!this.storageService.isLoggedIn()) {
    //   this.authService.routeToLogin();
    //   return;
    // }
    this.fields = this.observationFieldsService.getObservationSteps();
  }
  toggleSection():void {
    this.sectionStatus = !this.sectionStatus;
  }
}