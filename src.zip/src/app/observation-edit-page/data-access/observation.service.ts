import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Result } from 'src/app/domain/result';
import { CollabFieldsStep, DetailsStep, DetailsStepResponse, Observation, ResponsibilityCentreStep, RiskCategorizationStep } from 'src/app/domain/observation';
import { settings } from 'src/utils/appsettings.service';
import { ObservationBaCountryReq } from 'src/app/domain/requests/observation-ba-country-req';
import { ObservationResponsibilityCenterReq } from 'src/app/domain/requests/observation-responsibility-center-req';
import { ObservationRiskCategorizationReq } from 'src/app/domain/requests/observation-risk-categorization';

@Injectable({
  providedIn: 'root'
})
export class ObservationService {
  constructor(private http: HttpClient) { }

  public get(id: any): Observable<Result<Observation>> {
    const url = `${settings.apibaseUrl}/api/Observation/get?id=${id}`;
    return this.http.get<Result<Observation>>(url);
  }

  public updateDetailsStep(id: number, detailsStep: DetailsStepResponse): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/update-details?id=${id}`,detailsStep);
  }

  public updateResposibilityCenterStep (id: number, responsibilityCenterStep: ObservationResponsibilityCenterReq): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/update-responsibility-center?id=${id}`, responsibilityCenterStep);
  }
  public updateCollaborationFieldStep (id: number, collabFieldsCenterStep: CollabFieldsStep): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/update-collaboration-fields?id=${id}`, collabFieldsCenterStep);
  }
  public updateRiskCategorizationStep (id: number, riskCategorizationStep: ObservationRiskCategorizationReq): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/Observation/update-risk-categorization?id=${id}`, riskCategorizationStep);
  }

  public addBaCountry (newBaCountry: ObservationBaCountryReq) {
    console.log(newBaCountry);
    return this.http.post<any>(`${settings.apibaseUrl}/api/ObservationBusinessAreaCountry/add`, newBaCountry);
  }
}

