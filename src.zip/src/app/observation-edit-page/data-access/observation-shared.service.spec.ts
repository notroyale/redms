import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { ObservationSharedService } from './observation-shared.service';

describe('ObservationSharedService', () => {
  let service: ObservationSharedService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(ObservationSharedService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
