import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ActionPlan } from 'src/app/domain/action-plan';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class ActionPlanService {
  constructor(private http: HttpClient) { }

  public get(id: number): Observable<ActionPlan> {
    return this.http.get<ActionPlan>(`${settings.apibaseUrl}/api/ActionPlan/get?id=${id}`);
  }

  public add( data : ActionPlan): Observable<any> {
    return this.http.post<any>(`${settings.apibaseUrl}/api/ActionPlan/add`,data);
  }

  public update( data : ActionPlan): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/ActionPlan/update?id=${data.id}`,data);
  }
}
