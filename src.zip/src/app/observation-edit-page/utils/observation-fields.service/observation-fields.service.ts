import { Injectable } from '@angular/core';
import { ObservationSteps } from '../observation-steps';
import { FieldType } from 'src/app/shared/models/field-type';
import { InputType } from 'src/app/shared/models/input-type';
import { ColumnStyleType, ColumnType } from 'src/app/shared/models/table/column-type';

@Injectable({
  providedIn: 'root'
})
export class ObservationFieldsService {
  getObservationSteps(): ObservationSteps {
    return {
      id: { for: "for", display: "for", type: FieldType.Input, inputType: InputType.Text, styleClass:""  },
      detailsStep: {
        title: "Observation Details",
        subtitle: "Enter the general information",
        fields: [
          { for: "title", display: "Title", type: FieldType.Input, inputType: InputType.Text, styleClass:"input-custom"},
          { for: "categories", display: "Category", type: FieldType.Dropdown, displayAttribute: "description", styleClass:"", filterAttribute:"id", key:"category"  },

          { for: "dateIdentified", display: "Date Identified", type: FieldType.Input, inputType: InputType.Date, styleClass:"" },
          { for: "creationDate", display: "Date of Creation", type: FieldType.Input, inputType: InputType.Date, styleClass:"" },
          { for: "deadline", display: "Deadline", type: FieldType.Input, inputType: InputType.Date, styleClass:"" },
          { for: "revisedDeadline", display: "Revised Deadline", type: FieldType.Input, inputType: InputType.Date, styleClass:"" },
          { for: "grades", display: "Grade", type: FieldType.Dropdown, displayAttribute: "name", styleClass:"", filterAttribute:"id", key:"grade"  },
          { for: "description", display: "Description", type: FieldType.TextArea, styleClass:"" }
        ],
        btnLabel: 'Next'
      },
      responsibleCentreStep: {
        title: "Resposibility Centre",
        subtitle: "Responsible related data fields",
        fields: [
          { for: "businessUnits", display: "Business Unit", displayAttribute: "name", type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key: "businessUnit" },
          { for: "businessAreasCountries", display: "Business Area/Country", type: FieldType.Form, styleClass:"",
          form: {
            title: 'observationBusinessAreas',
            subtitle: '',
            fields: [
              { for: "businessAreas", display: "Business Area", displayAttribute: "name", type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key: "businessArea"},
              { for: "countries", display: "Country", displayAttribute: "name", type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key: "country"   }
            ],
            btnLabel: 'Add'
          }},

          // { for: "businessAreas", display: "Business Area", displayAttribute: "name", type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key: "businessArea"},
          // { for: "countries", display: "Country", displayAttribute: "name", type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key: "country"   },
          // { for: "button", display: "btn", displayAttribute: "name", type: FieldType.Modal, styleClass:"" },

          { for: "businessAreasCountries", display: "Country/Business Area Relations", displayAttribute: "name", type: FieldType.Table, styleClass:"", key:"",
            table: {
              columns: [
              { headerStyle:'common-header', for: 'countryID', header: 'Country',
                columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                type: ColumnType.TextColumn, styleClass: 'common-column' },
              { headerStyle:'common-header', for: 'businessAreaID', header: 'Business Area',
                columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                type: ColumnType.TextColumn, styleClass: 'common-column' }
            ],
            totalCount: 0,
            page: 1,
            rows: 5,
            first: 0
          }
        },
          { for: "legalEntities", display: "Legal Entities", displayAttribute: "name",
            type: FieldType.Multiselect, styleClass:"", filterAttribute:"name", key:"legalEntities" },
          { for: "assignee", display: "Compliance Responsible Person", type: FieldType.Input, inputType: InputType.Text, styleClass:"input-custom" },
          { for: "activityOwner", display: "Activity Owner", type: FieldType.Input, inputType: InputType.Text, styleClass:"input-custom"},
          { for: "riskOwner", display: "Observation Owner", type: FieldType.Input, inputType: InputType.Text, styleClass:"input-custom"}
        ],
        btnLabel: 'Next'
      },
      riskCategorizationStep: {
        title: "Risk Categorization",
        subtitle: "",
        fields: [
          { for: "taxonomies", display: "Taxonomy Level 1",displayAttribute: "name", type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"1"   },
          { for: "taxonomies", display: "Taxonomy Level 2",displayAttribute: "name", type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"2"   },
          { for: "taxonomies", display: "Taxonomy Level 3",displayAttribute: "name", type: FieldType.DropdownLevels, styleClass:"", filterAttribute:"id", key:"3"   },
          { for: "businessLine", display: "Assessment Unit (AU) / Line of Business", type: FieldType.Input, inputType: InputType.Text, styleClass:"input-custom" },
          { for: "directive", display: "Internal Policy / Business Procedure / SOP / Governing Information", type: FieldType.Input, inputType: InputType.Text, styleClass:"input-custom" }
        ],
        btnLabel: 'Next'
      },
      collabFieldsStep: {
        title: "Collaboration Fields",
        subtitle: "",
        fields: [
          { for: "comment", display: "CRP Comment", type: FieldType.TextArea, styleClass:"" },
          { for: "comment1LoD", display: "Comment1LoD", type: FieldType.TextArea, styleClass:""  },
          { for: "ragStatuses", display: "RAG Status", displayAttribute: "name", type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key:"ragStatus"   },
        ],
        btnLabel: 'Next'
      },
      actionPlanStep: {
        title: "Action Plan",
        subtitle: "",
        fields: [
          { for: "actionPlans", display: "Action Plans", displayAttribute: "name", type: FieldType.Table, styleClass:"", key:"",
            table: {
              columns: [
                { headerStyle:'common-header', for: 'actionTitle', header: 'Title',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.TextColumn,  styleClass: 'bold-column' },
                { headerStyle:'common-header', for: 'businessAreaID', header: 'Business Area',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.TextColumn, styleClass: 'common-column' },
                { headerStyle:'common-header', for: 'taxonomyLevel3ID', header: 'Taxonomy level 3',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.TextColumn, styleClass: 'common-column' },
                { headerStyle:'common-header', for: 'actionStatus', header: 'Status',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.TextColumn, styleClass: 'common-column' },
                { headerStyle:'common-header', for: 'deadline', header: 'Deadline',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.TextColumn, styleClass: 'common-column' },
                { headerStyle:'common-header', for: 'activityOwner', header: 'Action Owner',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.TextColumn, styleClass: 'common-column' },
                { headerStyle:'common-header', for: '', header: 'Action',
                  columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
                  type: ColumnType.ActionButtonColumn, styleClass: 'common-column' },
              ],
              totalCount: 0,
              page: 1,
              rows: 5,
              first: 0
            }
          },
        ],
        formFields: [
          { for: "actionTitle", display: "Title", type: FieldType.Input, inputType: InputType.Text, styleClass:"input-custom" },
          { for: "actionSummary", display: "Summary", type: FieldType.Input, inputType: InputType.Text, styleClass:"input-custom" },
          { for: "actionbusinessAreas", display: "Business Area", displayAttribute: "name", type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key: "businessArea"   },
          { for: "actionTaxonomyLevel3s", display: "Risk Level 3", displayAttribute: "name", type: FieldType.Dropdown, styleClass:"", filterAttribute:"id", key: "taxonomyLvl3"   },
          { for: "activityOwner", display: "Action Owner", type: FieldType.Input, inputType: InputType.Text, styleClass:"input-custom" },
          { for: "deadline", display: "Deadline", type: FieldType.Input, inputType: InputType.Date, styleClass:"" }
        ],
        btnLabel: 'Next'
      }
    }
  }

  //need to decide the right step for the following attributes
  onHold(): any[] {
    return [
      { for: "recommendation", display: "Recommendation", type: FieldType.Input },{ for: "proposedPlan", display: "Proposed Plan", type: FieldType.Input },
      { for: "registrationNumber", display: "Registration Number", type: FieldType.Input },
      { for: "directive", display: "Directive", type: FieldType.Input },
      { for: "submitted", display: "Submitted", type: FieldType.Input },
      { for: "deleted", display: "Deleted", type: FieldType.Input },
      { for: "mitigationActionComment", display: "Mitigation Action Comment", type: FieldType.Input },
      { for: "riskAssessmentId", display: "Risk Assessment for", type: FieldType.Input },
      // { for: "comment1LoDId", display: "Comment 1 LoD for", type: FieldType.Input },
      { for: "businessUnit", display: "Business Unit", type: FieldType.Input },
      { for: "statusID", display: "Status", type: FieldType.Dropdown, displayAttribute: "name",inputField: InputType.Text, styleClass:"", filterAttribute:"", key:"" },
      { for: "groupObservationId", display: "Group Observation", type: FieldType.Input,inputField: InputType.Text, styleClass:"input-custom"  },
      { for: "businessLine", display: "Business Line", type: FieldType.Input,inputField: InputType.Text, styleClass:"input-custom"  },
      { for: "categoryId", display: "Category", type: FieldType.Dropdown,inputField: InputType.Text, styleClass:"input-custom", filterAttribute:"", key:"",displayAttribute:""  },
      { for: "regulations", display: "Regulations", displayAttribute: "name",  type: FieldType.Dropdown,inputField: InputType.Text, styleClass:"", filterAttribute:"", key:""   },
      { for: "regulatoryCategories", display: "Regulatory Categories", displayAttribute: "name", type: FieldType.Dropdown,inputField: InputType.Text, styleClass:"", filterAttribute:"", key:""   },
      { for: "taxonomies", display: "Taxonomies",displayAttribute: "name", type: FieldType.Dropdown,inputField: InputType.Text, styleClass:"", filterAttribute:"", key:""   }
    ];
  }
}
