import { Injectable } from '@angular/core';
import { FieldType } from 'src/app/shared/models/field-type';
import { Fields } from 'src/app/shared/models/fields';
import { InputType } from 'src/app/shared/models/input-type';

@Injectable({
  providedIn: 'root'
})
export class ActionPlanFieldService {


  getColumnHeaders(): any[] {
    return [
      { headerStyle:'common-header', field: 'for', header: 'for', isFrozen: true, alignFrozen: 'left', type: 'text', styleClass: 'common-column' },
      { headerStyle:'common-header', field: 'code', header: 'Code', type: 'text', styleClass: 'common-column' },
      { headerStyle:'common-header', field: 'name', header: 'Name', isFrozen: false, alignFrozen: 'left', type: 'text', styleClass: 'bold-column' },
      { headerStyle:'common-header', field: 'isActive', header: 'Active', isFrozen: false, alignFrozen: 'left', type: 'input-switch', styleClass: 'bold-column' },
      { headerStyle:'actions-header', field: 'actions', header: 'Actions', type: 'action-button', isFrozen: true, alignFrozen: 'right', styleClass: 'actions-column' }
    ];
  }

  getFields(): Fields[] {
    return [
      { for: "for", display: "for", type: FieldType.Input, inputType: InputType.Text, styleClass:""  },
      { for: "code", display: "Code", type: FieldType.Input, inputType: InputType.Text, styleClass:"" },
      { for: "name", display: "Name", type: FieldType.Input, inputType: InputType.Text, styleClass:""  },
      { for: "isActive", display: "Active", type: FieldType.InputSwitch, styleClass:""  }
    ]
  }

}
