import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, ResolveFn, Router, RouterStateSnapshot } from '@angular/router';
import { ObservationService } from '../data-access/observation.service';
import { Observation } from 'src/app/domain/observation';
import { EMPTY, catchError, map } from 'rxjs';
import { ObservationSharedService } from '../data-access/observation-shared.service';


export const observationResolver: ResolveFn<Observation> =
  (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {
    const observationService = inject(ObservationService);
    const observationSharedService = inject(ObservationSharedService);
    const router = inject(Router);

    const parameterKey = Object.keys(route.params)[0];

    return observationService.get(route.params[parameterKey]).pipe(
      catchError(() => {
        router.navigate(['']);
        return EMPTY;
      }),
      map((obs) => {
        console.log(obs);
        observationSharedService.setID(route.params[parameterKey]);
        observationSharedService.changeData(obs.value);
        return obs.value;
      })
    );
  };
