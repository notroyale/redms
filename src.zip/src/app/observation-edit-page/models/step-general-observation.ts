export interface StepGeneralObservation{
    title: string;
    summary: string;
    // creationDate: Date;
    level: number;
    deadline: Date;
    categoryId :number;
    riskOwner : string;
    statusID : number;
    ragStatusID : number;
    groupObservationId : number;
  }

  export interface StepGeneralField{
    label: string;
    input: string;
    type: 'text' | 'dropdown' | 'button' | 'chip' | 'badge' | 'action-button';
  }
