import { DropdownField } from "./dropdown-field";
import { Field } from "./field";
import { TextareaField } from "./textarea-field";

export type Fields = DropdownField | TextareaField | Field;