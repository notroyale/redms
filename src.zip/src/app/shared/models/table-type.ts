export enum TableType {
  dynamic,
  filtered
}
