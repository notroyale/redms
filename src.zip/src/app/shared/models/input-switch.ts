import { BaseField } from "./field";
import { FieldType } from "./field-type";

export interface InputSwitch extends BaseField {
  type: FieldType.InputSwitch;

}