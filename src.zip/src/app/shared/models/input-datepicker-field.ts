import { BaseField } from "./field";
import { FieldType } from "./field-type";
import { InputType } from "./input-type";

export interface InputDatepickerField extends BaseField {
  type: FieldType.DatePicker;
  inputType: InputType.Date;
}