import { Column } from "./table/column";

export interface Table{
    columns: Column[];
    totalCount: number;
    page: number;
    rows: number; // Number of rows per page
    first: number; // First row index for pagination
}