import { Form } from "./form";

export interface DataForm{
    form: Form;
    data : any;
    dropdownsData: { [key: string] : any[] };
  }