import { BaseField } from "../field";
import { FieldType } from "../field-type";
import { BaseColumn } from "./base-column";
import { ColumnType } from "./column-type";

export interface BadgeColumn extends BaseColumn  {
  displayAttribute: string;
  colorAttribute: string;
  type: ColumnType.BadgeColumn;
}
