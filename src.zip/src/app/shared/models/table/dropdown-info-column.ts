import { BaseColumn } from "./base-column";
import { ColumnStyleType, ColumnType } from "./column-type";

export interface DropdownInfoColumn extends BaseColumn {
  display: string;
  type: ColumnType.DropdownOptLabelColumn;


}
