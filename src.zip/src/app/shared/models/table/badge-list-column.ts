import { BaseColumn } from "./base-column";
import { ColumnType } from "./column-type";

export interface BadgeListColumn extends BaseColumn {
  displayAttribute: string;
  type: ColumnType.BadgeListColumn;
}
