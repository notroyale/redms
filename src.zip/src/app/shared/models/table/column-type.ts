export enum ColumnType {
  TextColumn,
  DropdownOptLabelColumn,
  ChipColumn,
  BadgeColumn,
  ActionButtonColumn,
  ActionButtonObs,
  InputSwitchColumn,
  BadgeListColumn,
  ButtonColumn,
}

export enum ColumnStyleType {
  Frozen,
  DropdownInfoColumn,
  CommonColumn,
  FrozenDropdownInfoColumn
}
