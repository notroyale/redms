import { BaseColumn } from "./base-column";
import { ColumnStyleType } from "./column-type";

export interface CommonColumn extends BaseColumn {
  columnStyle: ColumnStyleType.CommonColumn;
}