import { BaseField } from "../field";

export interface DropdownOptLabelColumn extends BaseField  {

}