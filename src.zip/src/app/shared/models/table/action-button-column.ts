import { BaseField } from "../field";

export interface ActionButtonColumn extends BaseField  {

}