import { DropdownOptLabelColumn } from "./dropdown-opt-label-column";
import { ChipColumn } from "./chip-column";
import { TextColumn } from "./text-column";
import { BadgeColumn } from "./badge-column";
import { ActionButtonColumn } from "./action-button-column";
import { InputSwitchColumn } from "./input-switch-column";
import { BadgeListColumn } from "./badge-list-column";
import { ButtonColumn } from "./button-column";
import { CommonColumn } from "./common-column";
import { DropdownInfoColumn } from "./dropdown-info-column";
import { FrozenColumn } from "./frozen-column";

export type Column =
    FrozenColumn |
    CommonColumn |
    BadgeColumn |
    BadgeListColumn |
    ChipColumn |
    TextColumn |
    DropdownInfoColumn;
    // TextColumn |
    // DropdownOptLabelColumn |


    // ActionButtonColumn |
    // InputSwitchColumn |
    // BadgeListColumn |
    // ButtonColumn;

// export type Column =
//     TextColumn |
//     DropdownOptLabelColumn |
//     ChipColumn |
//     BadgeColumn |
//     ActionButtonColumn |
//     InputSwitchColumn |
//     BadgeListColumn |
//     ButtonColumn;
