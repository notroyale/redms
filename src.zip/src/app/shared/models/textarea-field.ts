import { BaseField } from "./field";
import { FieldType } from "./field-type";

export interface TextareaField extends BaseField {
  type: FieldType.TextArea;

}