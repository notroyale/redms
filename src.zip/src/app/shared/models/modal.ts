import { BaseField } from "./field";
import { FieldType } from "./field-type";

export interface ModalField extends BaseField {
     displayAttribute: string;
    // key: string;
    // filterAttribute: any;
    type: FieldType.Modal;
}
