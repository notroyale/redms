import { DataForm } from "./data-form";
import { DataTable } from "./data-table";
import { TableType } from "./table-type";

export interface SideBySide{
    dataTable: DataTable;
    dataForm: DataForm;
    type: TableType;
}
