export enum FieldType {
  Input,
  Dropdown,
  TextArea,
  InputSwitch,
  Multiselect,
  MultiselectLevels,
  DropdownLevels,
  Table,
  Modal,
  Badge,
  DatePicker,
  Form
}
