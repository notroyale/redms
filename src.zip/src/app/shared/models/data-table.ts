import { Filter } from "./filter";
import { Table } from "./table";

export interface DataTable{
    data: any[];
    filters: Filter[];
    table: Table;
}