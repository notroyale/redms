import { BaseField } from "./field";
import { FieldType } from "./field-type";

export interface DropdownLevelsField extends BaseField {
    displayAttribute: string;
    key: string;
    filterAttribute: any;
    type: FieldType.DropdownLevels;
}