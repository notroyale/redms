import { Field } from "./field";

export interface Form{
    title: string;
    subtitle: string;
    fields: Field[];
    btnLabel: string;
}

export interface SideForm extends Form {

  formFields: Field[];
}
