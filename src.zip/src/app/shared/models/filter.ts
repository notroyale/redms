import { Field } from "./field";

export interface Filter{
    field: Field;
    data: any[];
}