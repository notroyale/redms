import { BaseField } from "./field";
import { FieldType } from "./field-type";

export interface DropdownField extends BaseField {
    displayAttribute: string;
    key: string;
    filterAttribute: any;
    type: FieldType.Dropdown;
}
