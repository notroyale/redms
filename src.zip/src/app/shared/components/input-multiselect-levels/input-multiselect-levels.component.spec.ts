import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputMultiselectLevelsComponent } from './input-multiselect-levels.component';

describe('InputMultiselectLevelsComponent', () => {
  let component: InputMultiselectLevelsComponent;
  let fixture: ComponentFixture<InputMultiselectLevelsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InputMultiselectLevelsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InputMultiselectLevelsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
