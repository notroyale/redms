import { Component, Input } from '@angular/core';
import { MultiselectField } from '../../models/multiselect-field';

@Component({
  selector: 'app-input-multiselect-levels',
  templateUrl: './input-multiselect-levels.component.html',
  styleUrls: ['./input-multiselect-levels.component.css']
})
export class InputMultiselectLevelsComponent {
  @Input() field: MultiselectField[];
  @Input() options: any[];
  @Input() selectedOptions: any[] = [];
}
