import { Component, Input } from '@angular/core';
import { Filter } from '../../models/filter';
import { Field } from '../../models/field';
import { FieldType } from '../../models/field-type';
import { MultiselectField } from '../../models/multiselect-field';

@Component({
  selector: 'app-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.css']
})
export class FiltersComponent {
  @Input() filters : Filter[];
  fieldType = FieldType;

  asMultiselectFilter = (field: Field) => field as MultiselectField;

}