import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SideBySideComponent } from './side-by-side.component';
import { FilteredTableComponent } from '../filtered-table/filtered-table.component';
import { DynamicTableComponent } from '../dynamic-table/dynamic-table.component';
import { ButtonComponent } from '../button/button.component';
import { FormComponent } from '../form/form.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TableType } from '../../models/table-type';
import { TableModule } from 'primeng/table';

describe('SideBySideComponent', () => {
  let component: SideBySideComponent;
  let fixture: ComponentFixture<SideBySideComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[BrowserAnimationsModule,TableModule],
      declarations: [ SideBySideComponent, FilteredTableComponent, DynamicTableComponent, ButtonComponent, FormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SideBySideComponent);
    component = fixture.componentInstance;
    component.sideBySide = {
      dataTable: {
        data: [],
        filters: [],
        table: {
          columns: [],
          totalCount: 0,
          page: 0,
          rows: 0,
          first: 0
        }
      },
      dataForm: {
        form: {
          title: '',
          subtitle: '',
          fields: [],
          btnLabel: ''
        },
        data: undefined,
        dropdownsData: {}
      },
      type: TableType.dynamic
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
