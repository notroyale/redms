import { Component, EventEmitter, Input, Output } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { SideBySide } from '../../models/side-by-side';
import { TableType } from '../../models/table-type';

@Component({
  selector: 'app-side-by-side',
  animations: [
    trigger('leftRight', [
      state('left', style({
      })),
      state('right', style({
        transform: 'translateX(-100%)'
      })),
      transition('left => right', [
        animate('0.2s')
      ]),
      transition('right => left', [
        animate('0.2s')
      ]),
    ]),
  ],
  templateUrl: './side-by-side.component.html',
  styleUrls: ['./side-by-side.component.css']
})
export class SideBySideComponent {
  @Input() sideBySide: SideBySide;
  @Input() loading: boolean;

  @Output() editItemEvent = new EventEmitter();
  @Output() lazyLoadEvent = new EventEmitter();

  isOpen: boolean = false;
  overlayPanelVisible: boolean = true;
  tableType = TableType;

  onEditItem(item: any){
    console.log(item);
    this.isOpen = !this.isOpen;
    this.overlayPanelVisible = false;
    this.sideBySide.dataForm.data = item;
  }

  toggle() {
    this.isOpen = !this.isOpen;
    this.overlayPanelVisible = false;
  }

  onFormSubmit(data : any)
  {
    this.editItemEvent.emit(data);
    this.toggle();
  }
}
