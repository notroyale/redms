import { Component, EventEmitter, Input, Output } from '@angular/core';
import { DataTable } from '../../models/data-table';

@Component({
  selector: 'app-filtered-table',
  templateUrl: './filtered-table.component.html',
  styleUrls: ['./filtered-table.component.css']
})
export class FilteredTableComponent {
  @Input() dataTable: DataTable;
  @Input() loading: boolean;
  @Input() overlayPanelVisible: boolean;

  @Output() lazyEvent = new EventEmitter();
  @Output() onEditItemEvent = new EventEmitter();

  isMenuVisible: boolean = false;

  on($isMenuVisible: boolean) {
    this.isMenuVisible = $isMenuVisible;
  }
}