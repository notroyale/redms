import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiselectComponent } from './multiselect.component';
import { FormsModule } from '@angular/forms';
import { FieldType } from '../../models/field-type';
import { BadgeListColumnComponent } from '../badge-list-column/badge-list-column.component';

describe('MultiselectComponent', () => {
  let component: MultiselectComponent;
  let fixture: ComponentFixture<MultiselectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormsModule],
      declarations: [ MultiselectComponent, BadgeListColumnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MultiselectComponent);
    component = fixture.componentInstance;
    component.field = {
      displayAttribute: '',
      key: '',
      filterAttribute: undefined,
      type: FieldType.Multiselect,
      for: '',
      display: '',
      styleClass: ''
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
