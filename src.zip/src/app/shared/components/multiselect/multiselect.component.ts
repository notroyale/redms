import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { MultiselectField } from '../../models/multiselect-field';

@Component({
  selector: 'app-multiselect',
  templateUrl: './multiselect.component.html',
  styleUrls: ['./multiselect.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MultiselectComponent {
  @Input() field: MultiselectField;
  @Input() options: any[];
  @Input() 
  set selectedOptions(value: any[]){
    this._selectedOptions = value || [];
  }
  get selectedOptions(): any[] {
    return this._selectedOptions;
  }

  private _selectedOptions: any[] = [];
  
  placeholder: string = "Select options";
  show: boolean = false;
  checked: boolean = false;

  @Output() selectedOptionOnChange = new EventEmitter<any>();

  toggleSelection(option: any, comparedAttr: any) {
    const index = this.selectedOptions.findIndex(item => item[comparedAttr] === option[comparedAttr]);
    if (index === -1) {
      this.checked = true;
      this.selectedOptions.push(option);
      this.selectedOptionOnChange.emit({key: this.field.key, selectedOptions: this.selectedOptions});

      return;
    } 
    
    this.checked = false;
    this.selectedOptions.splice(index, 1);
    this.selectedOptionOnChange.emit({key: this.field.key, selectedOptions: this.selectedOptions});
  }

  isChecked(option: any, attributeCompared: any){
    // console.log(this.selectedOptions);
    //console.log(option);
    return this.selectedOptions.some(opt => opt[attributeCompared] === option[attributeCompared]);
  }

  toggle() {
    this.show = !this.show;
  }
}