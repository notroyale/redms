import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { DropdownField } from '../../models/dropdown-field';
import { TextareaField } from '../../models/textarea-field';
import { DataForm } from '../../models/data-form';
import { Field } from '../../models/field';
import { MultiselectField } from '../../models/multiselect-field';
import { InputSwitch } from '../../models/input-switch';
import { InputField } from '../../models/input-field';
import { FieldType } from '../../models/field-type';
import { TableField } from '../../models/table-field';
import { DataTable } from '../../models/data-table';
import { ModalField } from '../../models/modal';
import { FormField } from '../../models/form-field';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css'],
  // changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormComponent {
  @Input() dataForm: DataForm;
  @Input() loading: boolean;
  @Input() overlayPanelVisible: boolean;

  @Output() lazyEvent = new EventEmitter();
  @Output() onEditItemEvent = new EventEmitter();
  @Output() onFormSubmit = new EventEmitter();
  @Output() onNestedFormSubmit = new EventEmitter();

  @Output() onMultiselectLevelsChange = new EventEmitter();

  labelClass: string = "label-custom";
  fieldType = FieldType;

  asDropdownField = (field: Field) => field as DropdownField;
  asTextareaField = (field: Field) => field as TextareaField;
  asInputField = (field: Field) => field as InputField;
  asInputSwitchField = (field: Field) => field as InputSwitch;
  asMultiselectField = (field: Field) => field as MultiselectField;
  asModalField = (field: Field) => field as ModalField;
  asFormField = (field: Field) => field as FormField;


  asTableField = (field: Field) : DataTable => {
    return {
      data: this.dataForm.data[field.for],
      table: (field as TableField).table,
      filters: []
    }
  };

  save(){
    // console.log(this.dataForm.data);
    this.onFormSubmit.emit(this.dataForm.data);
  }
}
