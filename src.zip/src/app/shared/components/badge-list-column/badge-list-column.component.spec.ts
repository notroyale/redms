import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BadgeListColumnComponent } from './badge-list-column.component';

describe('BadgeListColumnComponent', () => {
  let component: BadgeListColumnComponent;
  let fixture: ComponentFixture<BadgeListColumnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BadgeListColumnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BadgeListColumnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
