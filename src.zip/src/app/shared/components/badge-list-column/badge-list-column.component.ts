import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-badge-list-column',
  templateUrl: './badge-list-column.component.html',
  styleUrls: ['./badge-list-column.component.css']
})
export class BadgeListColumnComponent {
  @Input() items: any[];
  @Input() displayAttribute: string;

  logthis(item:any){
    console.log(item);
  }
}