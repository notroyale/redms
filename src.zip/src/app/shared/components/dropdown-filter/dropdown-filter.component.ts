import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MultiselectField } from '../../models/multiselect-field';

@Component({
  selector: 'app-dropdown-filter',
  templateUrl: './dropdown-filter.component.html',
  styleUrls: ['./dropdown-filter.component.css'],
})
export class DropdownFilterComponent {
  @Input() field: MultiselectField;
  @Input() options: any[];
  @Output() selectionChange = new EventEmitter<any[]>();

  selectedOptions: any[] = [];
  placeholder: string = "Select options";
  show: boolean = false;

  toggleSelection(option: any) {
    const index = this.selectedOptions.indexOf(option);
    if (index === -1) {
      this.selectedOptions.push(option);
    } else {
      this.selectedOptions.splice(index, 1);
    }
    this.selectionChange.emit(this.selectedOptions);
  }
  
  toggle() {
    this.show = !this.show;
  }
}
