import { Component, Input } from '@angular/core';
import { InputDatepickerField } from '../../models/input-datepicker-field';

@Component({
  selector: 'app-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.css']
})
export class DatepickerComponent {
  @Input() field: InputDatepickerField;
  @Input() dateVal: Date;
}