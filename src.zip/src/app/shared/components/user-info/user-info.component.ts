import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Observable, Subject, map } from 'rxjs';
import { UserInfo } from 'src/app/domain/user';
import { UserinfoService } from '../../services/user-info/user-info.service';

@Component({
  selector: 'app-user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.css']
})
export class UserInfoComponent {

  bnum:string="";
  data$: Subject<UserInfo> = new Subject();

  constructor(private userinfoService: UserinfoService){}

  onChange(){
    console.log(this.bnum)
    this.userinfoService.get(this.bnum).pipe().subscribe((response)=>{
      console.log(response);
      this.data$.next(response.value);
    })
  }

}
