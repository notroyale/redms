import { Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem, MessageService } from 'primeng/api';

@Component({
  selector: 'app-action-button-column',
  templateUrl: './action-button-column.component.html',
  styleUrls: ['./action-button-column.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ActionButtonColumnComponent implements OnInit {
  @Input() itemId: any;
  @Input() item: any;
  @Input() overlayPanelVisible: boolean;
  isMenuVisible : boolean = false;
  @Output() onEditActionEvent = new EventEmitter();
  items: MenuItem[];

  constructor(private messageService: MessageService, private router: Router) { }

  ngOnInit() {
    this.items = [
      {
        label: 'Options',
        items: [
          {
            label: 'Update',
            icon: 'pi pi-refresh',
            command: () => {
              this.update();
            }
          },
          {
            label: 'Delete',
            icon: 'pi pi-times',
            command: () => {
              this.delete(this.itemId);
            }
          }
        ]
      }
    ];
  }

  toggle(){
    if(!this.overlayPanelVisible){
      this.overlayPanelVisible = true;
    }
  }

  update() {
    // this.overlayPanelVisible = false;
    // const url = `/edit-observation/${this.itemId}`;
    // this.router.navigate([url]);

    this.onEditActionEvent.emit(this.overlayPanelVisible);
  }

  delete(observationId: any) {
    const summary = `Deleted observation ${observationId}`;
    this.messageService.add({ severity: 'warn', summary: summary, detail: 'Observation Deleted' });
  }
}
