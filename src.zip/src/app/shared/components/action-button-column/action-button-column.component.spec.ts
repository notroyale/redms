import { ComponentFixture, TestBed } from '@angular/core/testing';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { MenuModule } from 'primeng/menu';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActionButtonColumnComponent } from './action-button-column.component';
import { MessageService } from 'primeng/api';

describe('ActionButtonColumnComponent', () => {
  let component: ActionButtonColumnComponent;
  let fixture: ComponentFixture<ActionButtonColumnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[OverlayPanelModule,MenuModule,BrowserAnimationsModule],
      declarations: [ ActionButtonColumnComponent ],
      providers:[MessageService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ActionButtonColumnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
