import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DropdownField } from '../../models/dropdown-field';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DropdownComponent implements OnInit {
  @Input() field: DropdownField;
  @Input() options: any[] = [];
  @Input() data: any = {};

  @Output() dataChange = new EventEmitter<any>();
  private defaultOptionDisplay: string = 'Select an option';
  private readonly isEmpty: boolean = Object.keys(this.data).length === 0;
  key: string;
  optionDisplay: string = this.defaultOptionDisplay;
  selectedOption: any = {};

  isSelected: boolean = false;
  isOpen: boolean = false;
  component: {};

  ngOnInit(): void {
    if (this.data === undefined || this.isEmpty) {
      return;
    }

    console.log(this.data);
    this.optionDisplay = this.data[this.field.displayAttribute];
    this.selectedOption = this.data;
  }

  public trackById(index: number, item: any) {
    if(!this.field){
      return;
    }

    return item[this.field.filterAttribute];
  }

  toggleDropdown() {
    this.isOpen = !this.isOpen;
  }

  onChange(option: any) {
    this.optionDisplay = option[this.field.displayAttribute];
    this.selectedOption = option;

    this.key = this.field.key;
    this.isOpen = false;

    this.dataChange.emit(
      // selectOpt: option,
      // key: this.key
      option
    );
  }

  checkSelected(option: any) {
    return option[this.field.filterAttribute] === this.selectedOption[this.field.filterAttribute];
  }
}
