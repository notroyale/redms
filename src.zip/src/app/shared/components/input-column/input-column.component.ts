import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-input-column',
  templateUrl: './input-column.component.html',
  styleUrls: ['./input-column.component.css']
})
export class InputColumnComponent {
  @Input() data: InputElem;
  @Input() value: any;
  @Input() label: any;
  @Input() type: any;
}

export interface InputElem{
  value: any;
  help: string;
  id: string;
  label: string;
}