import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputColumnComponent } from './input-column.component';
import { FormsModule } from '@angular/forms';

describe('InputColumnComponent', () => {
  let component: InputColumnComponent;
  let fixture: ComponentFixture<InputColumnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormsModule],
      declarations: [ InputColumnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InputColumnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
