import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-input-switch',
  templateUrl: './input-switch.component.html',
  styleUrls: ['./input-switch.component.css']
})
export class InputSwitchComponent {
  @Input() label: string;
  @Input() isChecked: boolean;
  
  @Output() isCheckedChange = new EventEmitter<boolean>();
 
  toggleSwitch() {
    this.isChecked = !this.isChecked;
    this.isCheckedChange.emit(this.isChecked);
  }
 }