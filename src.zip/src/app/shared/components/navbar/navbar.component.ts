import { Component, } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/auth/data-access/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {

  isLoggedIn$: Observable<boolean>;
  adminFields: boolean = false;

  constructor(private authService: AuthService) { }

  subOptions: any = [
    {
      name: "Business Units",
      reference: "./bu-dashboard"
    },
    {
      name: "Business Areas",
      reference: "./ba-dashboard"
    },
    {
      name: "Legal Entities",
      reference: "./le-dashboard"
    }
  ];

  menuOptions: typeof MenuOptions = MenuOptions;
}

enum MenuOptions {
  Home = "Home",
  Observations = "Observations",
  Help = "Help",
  Admin = "Admin"
}
