import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-button-column',
  templateUrl: './button-column.component.html',
  styleUrls: ['./button-column.component.css']
})
export class ButtonColumnComponent {
  @Input() label: any;
  @Input() url: any;

}
