import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/auth/data-access/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {

  constructor(private authService: AuthService) { }


  onLogout() {
    this.authService.logout();
  }

  color: string = "white";
  size: number = 32;
  options = [
    { label: 'Observations', route: '/home', showIcon: false },
    { label: 'About', route: '/about', showIcon: false },
    {
      label: 'Admin',
      route: '/admin',
      showIcon: true,
      subOptions: [
        { label: 'Business units', route: '/contact/suboption1' },
        { label: 'Business areas', route: '/contact/suboption2' },
        { label: 'Legal entities', route: '/contact/suboption3' }
      ]
    }
  ];

  menuOpen = false;

  toggleMenu(): void {
    this.menuOpen = !this.menuOpen;
  }
}
