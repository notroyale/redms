import { Component, Input } from '@angular/core';
import { BadgeColumn } from '../../models/table/badge-column';

@Component({
  selector: 'app-badge-column',
  templateUrl: './badge-column.component.html',
  styleUrls: ['./badge-column.component.css']
})
export class BadgeColumnComponent {
  @Input() status: any;
  @Input() column: BadgeColumn;

  // statuss: any = "OnTrack";

}
