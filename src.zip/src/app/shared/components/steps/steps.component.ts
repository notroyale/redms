import { Component, Input } from '@angular/core';
import { Step } from '../../models/step';

@Component({
  selector: 'app-steps',
  templateUrl: './steps.component.html',
  styleUrls: ['./steps.component.css'],
})
export class StepsComponent {
  @Input() fields: any;
  @Input() data: any;
  isStepActive: boolean;

  setActive($event: any) {
    console.log($event.target);
  }

  steps: Step[] = [
    {
      index: 1,
      title: 'General',
      subtitle: 'Add basic information',
      status: 'completed',
      route: 'details',
    },
    {
      index: 2,
      title: 'Responsibility Centre',
      subtitle: 'Add ownership related information',
      status: 'current',
      route: 'responsibility-centre',
    },
    {
      index: 3,
      title: 'Risk Categorization',
      subtitle: 'Add Risk Categorization related information',
      status: 'upcoming',
      route: 'risk-categorization',
    },
    {
      index: 4,
      title: 'Collaboration Fields',
      subtitle: 'Collaboration Fields details & information',
      status: 'upcoming',
      route: 'collab-fields',
    },
    {
      index: 5,
      title: 'Action Plan',
      subtitle: 'Action plans for risk mitigation',
      status: 'upcoming',
      route: 'action-plan',
    },
    {
      index: 6,
      title: 'Supporting Documents',
      subtitle: 'Attachments & Supporting Documents',
      status: 'upcoming',
      route: 'additional-details',
    },

  ];
}
