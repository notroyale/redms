import { Component, Input, ViewEncapsulation } from '@angular/core';
import { ChipColumn } from '../../models/table/chip-column';

@Component({
    selector: 'app-chip-column',
    templateUrl: './chip-column.component.html',
    styleUrls: ['./chip-column.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class ChipColumnComponent {
    @Input() status: any;
    @Input() column: ChipColumn;
    x = '#07223b';
    // getSeverity(status: any) {
    //     switch (status) {
    //         case 1:
    //             return 'bg-[#8acebf]';

    //         case 2:
    //           return 'bg-rose-700';

    //         case 3:
    //             return 'bg-blue-600';

    //         case 4:
    //             return 'bg-yellow-400';

    //         case 5:
    //             return 'bg-yellow-400';
    //         default: return 'bg-neutral-600';
    //     }
    // }
}
