import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputTextareaComponent } from './input-textarea.component';
import { FieldType } from '../../models/field-type';
import { FormsModule } from '@angular/forms';

describe('InputTextareaComponent', () => {
  let component: InputTextareaComponent;
  let fixture: ComponentFixture<InputTextareaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormsModule],
      declarations: [ InputTextareaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InputTextareaComponent);
    component = fixture.componentInstance;
    component.field = {
      type: FieldType.TextArea,
      for: '',
      display: '',
      styleClass: ''
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
