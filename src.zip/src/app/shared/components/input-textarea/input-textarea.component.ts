import { Component, EventEmitter, Input, Output } from '@angular/core';
import { TextareaField } from '../../models/textarea-field';

@Component({
  selector: 'app-input-textarea',
  templateUrl: './input-textarea.component.html',
  styleUrls: ['./input-textarea.component.css']
})
export class InputTextareaComponent {
  @Input() field: TextareaField;
  @Input() data: any = {};
  labelClass: string = "label-custom";

  @Output() dataChange = new EventEmitter<any>();

  onChange() {
    this.dataChange.emit(this.data);
  }
}
