import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditableTableComponent } from './editable-table.component';
import { TableModule } from 'primeng/table';

describe('EditableTableComponent', () => {
  let component: EditableTableComponent;
  let fixture: ComponentFixture<EditableTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[TableModule],
      declarations: [ EditableTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditableTableComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
