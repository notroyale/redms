import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Result } from 'src/app/domain/result';
import { UserInfo } from 'src/app/domain/user';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class UserinfoService {
  constructor(private http: HttpClient) { }

  public get(id: any): Observable<Result<UserInfo>> {
    const url = `${settings.apibaseUrl}/api/Users/get?bnum=${id}`;
    return this.http.get<Result<UserInfo>>(url);
  }
}