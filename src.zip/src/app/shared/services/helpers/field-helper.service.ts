import { Injectable } from '@angular/core';
import { Field } from '../../models/field';
import { DropdownField } from '../../models/dropdown-field';
import { TextareaField } from '../../models/textarea-field';

@Injectable({
  providedIn: 'root'
})
export class FieldHelperService {
  isCommon(obj: Field): obj is Field {
    return obj && obj.for !== undefined && obj.display !== undefined && obj.type !== undefined;
  }

  isDropdownField(obj: DropdownField): obj is DropdownField {
    return obj && this.isCommon(obj) && obj.display !== undefined;
  }

  // isTextareaField(obj: TextareaField): obj is TextareaField {
  //   return obj && this.isCommon(obj) && obj.rows !== undefined && obj.cols !== undefined && obj.autoResize !== undefined;
  // }

  asDropdownField(obj: DropdownField): DropdownField {
    return obj as DropdownField;
  }

  asTextareaField(obj: TextareaField): TextareaField {
    return obj as TextareaField;
  }
}