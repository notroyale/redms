import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { AdfsService } from './auth/adfs/adfs.service';
import { AuthenticatedResult, LoginResponse, OidcSecurityService } from 'angular-auth-oidc-client';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  isAuthenticated$: Observable<AuthenticatedResult>;
  constructor(private oidcSecurityService: OidcSecurityService) {}
  isAuth: boolean;

  ngOnInit() {
    this.oidcSecurityService
    .checkAuth()
    .subscribe(({ isAuthenticated, userData, accessToken }) => {
      console.log('app authenticated', isAuthenticated);
      console.log('app user data', userData);
      console.log(`Current access token is '${accessToken}'`);
    });
    // this.oidcSecurityService
    //   .checkAuth()
    //   .subscribe((loginResponse: LoginResponse) => {
    //     const { isAuthenticated, userData, accessToken, idToken, configId } =
    //       loginResponse;

    //     /*...*/
    //   });
    // this.isAuthenticated$ = this.oidcSecurityService.isAuthenticated$;
    //  this.oidcSecurityService.isAuthenticated$.subscribe(x=> {
    //   console.log(x);
    //   this.isAuth = x.isAuthenticated;
    // });
  }

  login() {
    this.oidcSecurityService.authorize();
  }

  logout() {
    this.oidcSecurityService
      .logoff()
      .subscribe((result) => console.log(result));
  }

  getToken(){
    const token = this.oidcSecurityService.getAccessToken().subscribe(x =>{
      console.log(x);

    });
    console.log(token);
  }
}
