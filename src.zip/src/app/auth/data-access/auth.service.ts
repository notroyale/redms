import { Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { User } from 'src/app/domain/user';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  get isLoggedIn() {
    return this.loggedIn.asObservable();
  }

  constructor(
    private router: Router
  ) {
    if( window.sessionStorage.getItem("auth-user"))
    { this.loggedIn.next(true);
    }

  }

  login(user: User) {
    if (user.userName !== '' && user.password !== '' ) {

      this.loggedIn.next(true);
      window.sessionStorage.setItem("auth-user", "true");
      this.router.navigate(['']);
    }
  }

  logout() {
    this.loggedIn.next(false);
    this.router.navigate(['/unauthorized']);
  }

  public routeToLogin(): void {
    this.router.navigate(['./unauthorized']);

  }
}
