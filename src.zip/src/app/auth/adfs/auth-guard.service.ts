import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { map, take } from 'rxjs';

export const isAuthenticated = () => {
  const oidcSecurityService = inject(OidcSecurityService);
  const router = inject(Router);
  return oidcSecurityService.isAuthenticated$.pipe(
    take(1),
    map(({ isAuthenticated }) => {

      if (!isAuthenticated) {
        // oidcSecurityService
        // .checkAuth()
        // .subscribe(({ isAuthenticated, userData, accessToken }) => {
        //   console.log('app authenticated', isAuthenticated);
        //   console.log('app user data', userData);
        //   console.log(`Current access token is '${accessToken}'`);
        // });
        // oidcSecurityService.authorize();
        // router.navigate(['login']);
        // oidcSecurityService.authorize();

        return false;
      }
      return true;
    })
  );
};
