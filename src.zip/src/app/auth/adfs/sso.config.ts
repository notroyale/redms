import { AuthWellKnownEndpoints, LogLevel, PassedInitialConfig } from "angular-auth-oidc-client";

const authWellKnownEndpoints: AuthWellKnownEndpoints = {
    issuer: 'https://syst-fs1.danskebank.com/adfs',
    authorizationEndpoint: 'https://syst-fs1.danskebank.com/adfs/oauth2/authorize/',
    tokenEndpoint: 'https://syst-fs1.danskebank.com/adfs/oauth2/token/',
    jwksUri: "https://art-adfsproxy-syst.danskenet.net/adfs/discovery/keys",
    userInfoEndpoint: 'https://art-adfsproxy-syst.danskenet.net/adfs/userinfo'
};

export const openIDConfig: PassedInitialConfig = {
    config: {
        authority: 'https://art-adfsproxy-syst.danskenet.net/adfs',
        authWellknownEndpoints: authWellKnownEndpoints,
        redirectUrl: `${window.location.origin}/callback`,
        // window.location.origin,
        postLogoutRedirectUri: window.location.origin,
        clientId: '099435c6-43e7-43a9-bd27-3d6787eb9b98',
        scope: 'openid profile',
        responseType: 'id_token token',
        logLevel: LogLevel.None,
        silentRenew: true,
        useRefreshToken: true,
        autoUserInfo: false,
        disablePkce: false,
        startCheckSession: true,
        customParamsAuthRequest: {
            resource: 'RAMS.Authorization',
        },
        customParamsRefreshTokenRequest: {
          scope: 'openid profile',
        },
        secureRoutes: ['https://localhost:5001/' ],

    }
};
