import { APP_INITIALIZER, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NavbarComponent } from './shared/components/navbar/navbar.component';

import { TableModule } from 'primeng/table';
import { MultiSelectModule } from 'primeng/multiselect';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TagModule } from 'primeng/tag';
import { CalendarModule } from 'primeng/calendar';
import { ToastModule } from 'primeng/toast';
import { DropdownModule } from 'primeng/dropdown';
import { MessageService } from 'primeng/api';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ToolbarModule } from 'primeng/toolbar';
import { BadgeModule } from 'primeng/badge';
import { PanelModule } from 'primeng/panel';
import { StyleClassModule } from 'primeng/styleclass';
import { SplitButtonModule } from 'primeng/splitbutton';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { InputTextModule } from 'primeng/inputtext';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { CarouselModule } from 'primeng/carousel';

import { DropdownComponent } from './shared/components/dropdown/dropdown.component';
import { TableComponent } from './shared/components/table/table.component';
import { InputComponent } from './shared/components/input/input.component';
import { ButtonColumnComponent } from './shared/components/button-column/button-column.component';
import { ChipColumnComponent } from './shared/components/chip-column/chip-column.component';
import { BadgeColumnComponent } from './shared/components/badge-column/badge-column.component';
import { ActionButtonColumnComponent } from './shared/components/action-button-column/action-button-column.component';
import { EditableTableComponent } from './shared/components/editable-table/editable-table.component';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { StepsComponent } from './shared/components/steps/steps.component';
import { StepsModule } from 'primeng/steps';
import { CardModule } from 'primeng/card';
import { InputColumnComponent } from './shared/components/input-column/input-column.component';
import { InputTextareaComponent } from './shared/components/input-textarea/input-textarea.component';

import { NgxHideOnScrollModule } from 'ngx-hide-on-scroll';
import { HeaderComponent } from './shared/components/header/header.component';
import { FooterComponent } from './shared/components/footer/footer.component';
import { AccordionModule } from 'primeng/accordion';
import { LandingPageComponent } from './home/ui/landing-page/landing-page.component';
import { NewsListComponent } from './home/feature/news-list/news-list.component';
import { NewsItemComponent } from './home/feature/news-item/news-item.component';
import { SideBySideComponent } from './shared/components/side-by-side/side-by-side.component';
import { FormComponent } from './shared/components/form/form.component';
import { LoginScreenComponent } from './auth/login-screen/login-screen.component';
import { BusinessUnitDashboardComponent } from './admin-pages/business-units/ui/business-unit-dashboard/business-unit-dashboard.component';
import { BusinessAreaDashboardComponent } from './admin-pages/business-areas/ui/business-area-dashboard/business-area-dashboard.component';
import { TaxonomyDashboardComponent } from './admin-pages/taxonomies/ui/taxonomy-dashboard/taxonomy-dashboard.component';
import { LegalEntityDashboardComponent } from './admin-pages/legal-entities/ui/legal-entity-dashboard/legal-entity-dashboard.component';
import { ObservationDashboardComponent } from './observations-home-page/ui/observation-dashboard/observation-dashboard.component';
import { StepActionPlanComponent } from './observation-edit-page/feature/step-action-plan/step-action-plan.component';
import { StepAdditionalDetailsComponent } from './observation-edit-page/feature/step-additional-details/step-additional-details.component';
import { ObservationEditComponent } from './observation-edit-page/ui/observation-edit/observation-edit.component';
import { GradesDashboardComponent } from './admin-pages/grades/ui/grades-dashboard/grades-dashboard.component';
import { ObservationStatusCardComponent } from './observation-edit-page/feature/observation-status-card/observation-status-card.component';
import { ObservationService } from './observation-edit-page/data-access/observation.service';
import { ButtonComponent } from './shared/components/button/button.component';
import { AuthorizedComponent } from './shared/layouts/authorized/authorized.component';
import { UnauthorizedComponent } from './shared/layouts/unauthorized/unauthorized.component';
import { FiltersComponent } from './shared/components/filters/filters.component';
import { BadgeListColumnComponent } from './shared/components/badge-list-column/badge-list-column.component';
import { SearchBoxComponent } from './shared/components/search-box/search-box.component';
import { FilteredTableComponent } from './shared/components/filtered-table/filtered-table.component';
import { DropdownFilterComponent } from './shared/components/dropdown-filter/dropdown-filter.component';
import { MultiselectComponent } from './shared/components/multiselect/multiselect.component';
import { InputSwitchComponent } from './shared/components/input-switch/input-switch.component';
import { StepDetailsComponent } from './observation-edit-page/feature/step-details/step-details.component';
import { StepResponsibilityCentreComponent } from './observation-edit-page/feature/step-responsibility-centre/step-responsibility-centre.component';
import { StepRiskCategorizationComponent } from './observation-edit-page/feature/step-risk-categorization/step-risk-categorization.component';
import { DatepickerComponent } from './shared/components/datepicker/datepicker.component';
import { DynamicTableComponent } from './shared/components/dynamic-table/dynamic-table.component';
import { StepCollaborationFieldsComponent } from './observation-edit-page/feature/step-collaboration-fields/step-collaboration-fields.component';
import { AutosizeModule } from 'ngx-autosize';
import { InputMultiselectLevelsComponent } from './shared/components/input-multiselect-levels/input-multiselect-levels.component';
import { ModalComponent } from './shared/components/modal/modal.component';
import { ActionButtonObsComponent } from './shared/components/action-button-obs/action-button-obs.component';
import { UserInfoComponent } from './shared/components/user-info/user-info.component';
import { AppSettingsService, initializeAppFactory } from 'src/utils/appsettings.service';
import { BaCountryFormComponent } from './observation-edit-page/feature/ba-country-form/ba-country-form.component';
import { AdfsService } from './auth/adfs/adfs.service';
import { AuthInterceptor, AuthModule, LogLevel } from 'angular-auth-oidc-client';
import { openIDConfig } from './auth/adfs/sso.config';
import { CallbackComponent } from './auth/adfs/callback/callback.component';

@NgModule({
  declarations: [
    AppComponent,
    BusinessUnitDashboardComponent,
    BusinessAreaDashboardComponent,
    NavbarComponent,
    TaxonomyDashboardComponent,
    LegalEntityDashboardComponent,
    ObservationDashboardComponent,
    DropdownComponent,
    TableComponent,
    InputComponent,
    InputColumnComponent,
    ButtonColumnComponent,
    ChipColumnComponent,
    BadgeColumnComponent,
    ActionButtonColumnComponent,
    EditableTableComponent,
    StepsComponent,
    StepActionPlanComponent,
    StepAdditionalDetailsComponent,
    ObservationEditComponent,
    GradesDashboardComponent,
    InputTextareaComponent,
    HeaderComponent,
    FooterComponent,
    LandingPageComponent,
    NewsListComponent,
    NewsItemComponent,
    SideBySideComponent,
    FormComponent,
    ObservationStatusCardComponent,
    LoginScreenComponent,
    ButtonComponent,
    AuthorizedComponent,
    UnauthorizedComponent,
    FiltersComponent,
    BadgeListColumnComponent,
    SearchBoxComponent,
    FilteredTableComponent,
    DropdownFilterComponent,
    MultiselectComponent,
    InputSwitchComponent,
    StepDetailsComponent,
    StepResponsibilityCentreComponent,
    StepRiskCategorizationComponent,
    DatepickerComponent,
    DynamicTableComponent,
    StepCollaborationFieldsComponent,
    InputMultiselectLevelsComponent,
    ModalComponent,
    ActionButtonObsComponent,
    UserInfoComponent,
    BaCountryFormComponent,
    CallbackComponent

    ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ButtonModule,
    TableModule,
    MultiSelectModule,
    FormsModule,
    CalendarModule,
    ToastModule,
    DropdownModule,
    InputSwitchModule,
    ToolbarModule,
    BadgeModule,
    PanelModule,
    TagModule,
    StyleClassModule,
    SplitButtonModule,
    MenuModule,
    RippleModule,
    OverlayPanelModule,
    StepsModule,
    CardModule,
    InputTextModule,
    InputTextareaModule,
    NgxHideOnScrollModule,
    AccordionModule,
    CarouselModule,
    ReactiveFormsModule,
    AutosizeModule,
    //OAuthModule.forRoot(),
    AuthModule.forRoot(openIDConfig)
  ],
  providers: [MessageService, ObservationService, HttpClientModule,
    {
    provide: APP_INITIALIZER,
    useFactory: initializeAppFactory,
    multi: true,
    deps: [ AppSettingsService ]
  },
  { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },

],
  bootstrap: [AppComponent],

})
export class AppModule { }
