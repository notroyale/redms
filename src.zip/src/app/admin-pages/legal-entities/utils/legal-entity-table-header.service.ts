import { Injectable } from '@angular/core';
import { FieldType } from 'src/app/shared/models/field-type';
import { Form } from 'src/app/shared/models/form';
import { InputType } from 'src/app/shared/models/input-type';
import { Table } from 'src/app/shared/models/table';
import { ColumnStyleType, ColumnType } from 'src/app/shared/models/table/column-type';

@Injectable({
  providedIn: 'root'
})
export class LegalEntityTableHeaderService {
  getTable(): Table {
    return {
        columns: [
        {
          headerStyle:'common-header', for: 'id', header: 'Id',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column'
        },
        {
          headerStyle:'common-header', for: 'name', header: 'Name',
          columnStyle: ColumnStyleType.CommonColumn,
          type: ColumnType.TextColumn, styleClass: 'bold-column'
        },
        {
          headerStyle:'common-header', for: 'businessUnits', header: 'Business Units',
          columnStyle: ColumnStyleType.DropdownInfoColumn,
          type: ColumnType.BadgeListColumn, styleClass: 'common-column', displayAttribute: 'name'
        },
        {
          headerStyle:'common-header', for: 'isActive', header: 'Active',
          columnStyle: ColumnStyleType.CommonColumn,
          type: ColumnType.InputSwitchColumn, styleClass: 'bold-column'
        },
        {
          headerStyle:'actions-header', for: 'actions', header: 'Actions',
          type: ColumnType.ActionButtonColumn, columnStyle:
          ColumnStyleType.Frozen, alignFrozen: 'right', styleClass: 'actions-column'
        }
      ],
      totalCount: 0,
      page: 1,
      rows: 5,
      first: 0
    }
  }

  getForm(): Form {
    return {
      title: 'Edit Legal Entity',
      subtitle: '',
      fields: [
        {
          for: "id", display: "Id", type: FieldType.Input, inputType: InputType.Text, styleClass: "input-custom"
        },
        {
          for: "name", display: "Name", type: FieldType.Input, inputType: InputType.Text, styleClass: "input-custom"
        },
        {
          key: "businessUnits", displayAttribute: 'name', for: "businessUnits", display: "Business Unit", type: FieldType.Multiselect, styleClass: "", filterAttribute: 'id'
        },
        {
          for: "isActive", display: "Active", type: FieldType.InputSwitch, styleClass: ""
        }
      ],
      btnLabel: 'Save'
    }
  }
}
