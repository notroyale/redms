import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { LegalEntityService } from './legal-entity.service';

describe('LegalEntityService', () => {
  let service: LegalEntityService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(LegalEntityService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
