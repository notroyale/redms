import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { Taxonomy } from 'src/app/domain/taxonomy';
import { TaxonomyLevel } from 'src/app/domain/taxonomy-level';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class TaxonomyService {
  constructor(private http: HttpClient) {}

  public getAll(): Observable<Taxonomy[]> {
    return this.http.get<Taxonomy[]>(`${settings.apibaseUrl}/api/Taxonomy/all`);
  }
  public getTaxonomyLevels(): Observable<TaxonomyLevel[]> {
    return this.http.get<TaxonomyLevel[]>(`${settings.apibaseUrl}/api/TaxonomyLevels/all`);
  }

  public getAllWithFilters(skip: number, rows: number): Observable<DataTableRequest> {
    return this.http.get<DataTableRequest>(`${settings.apibaseUrl}/api/Taxonomy/allBase/options?page=${skip}&pageSize=${rows}`);
  }

  public getAllBySearch(searchTerm: string): Observable<DataTableRequest> {
    return this.http.get<DataTableRequest>(`${settings.apibaseUrl}/api/Taxonomy/allBase/options?searchTerm=${searchTerm}`);
  }

  public getChildrenByIds(ids: number[]): Observable<DataTableRequest> {
    let params = new  HttpParams();
    ids.forEach(id => {
      params = params.append('Ids', id.toString())
    });
    return this.http.get<DataTableRequest>(`${settings.apibaseUrl}/api/Taxonomy/getChildrenByIds?`, {params});
  }

  public getAllByLevel(level: number): Observable<Taxonomy[]> {
    return this.http.get<Taxonomy[]>(`${settings.apibaseUrl}/api/Taxonomy/getByLevel?level=${level}`);
  }

  public add(taxonomy : Taxonomy): Observable<any>{
    return this.http.post<any>(`${settings.apibaseUrl}/api/Taxonomy/add`, taxonomy);
  }

  public delete(taxonomyId : number): Observable<any>{
    return this.http.delete<any>(`${settings.apibaseUrl}/api/Taxonomy/delete?Id=`+taxonomyId);
  }

  public update(taxonomy : Taxonomy): Observable<any>{
    return this.http.put<any>(`${settings.apibaseUrl}/api/Taxonomy/update`, taxonomy);
  }
}
