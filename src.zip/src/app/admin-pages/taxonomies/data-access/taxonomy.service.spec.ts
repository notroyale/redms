import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { TaxonomyService } from './taxonomy.service';

describe('TaxonomyService', () => {
  let service: TaxonomyService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(TaxonomyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
