import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { TaxonomyTableHeaderService } from './taxonomy-table-header.service';

describe('TaxonomyTableHeaderService', () => {
  let service: TaxonomyTableHeaderService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(TaxonomyTableHeaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
