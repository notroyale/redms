import { Injectable } from '@angular/core';
import { FieldType } from 'src/app/shared/models/field-type';
import { Form } from 'src/app/shared/models/form';
import { InputType } from 'src/app/shared/models/input-type';
import { Table } from 'src/app/shared/models/table';
import { ColumnStyleType, ColumnType } from 'src/app/shared/models/table/column-type';

@Injectable({
  providedIn: 'root'
})
export class TaxonomyTableHeaderService {
  getTable(): Table {
    return {
      columns: [
        { headerStyle:'common-header', for: 'id', header: 'Id',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column' },
        { headerStyle:'common-header', for: 'name', header: 'Name',
          columnStyle: ColumnStyleType.CommonColumn,
          type: ColumnType.TextColumn, styleClass: 'bold-column min-w-small' },
        { headerStyle:'common-header', for: 'levelID', header: 'Level',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.TextColumn, styleClass: 'common-column' },

        // { headerStyle:'common-header', for: 'description', header: 'Description', isFrozen: false, alignFrozen: 'left', type: ColumnType.TextColumn, styleClass: 'common-column' },
        { headerStyle:'common-header', for: 'subTaxonomies', header: 'Related Taxonomies',
          columnStyle: ColumnStyleType.DropdownInfoColumn,
          type: ColumnType.BadgeListColumn, styleClass: 'common-column max-w-large', displayAttribute:'name' },
        { headerStyle:'common-header', for: 'isActive', header: 'Active',
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'left',
          type: ColumnType.InputSwitchColumn, styleClass: 'common-column' },
        { headerStyle:'actions-header', for: 'actions', header: 'Actions', type: ColumnType.ActionButtonColumn,
          columnStyle: ColumnStyleType.Frozen, alignFrozen: 'right', styleClass: 'actions-column' }
      ],
      totalCount: 0,
      page: 1,
      rows: 5,
      first: 0
    };
  }

  getForm(): Form {
    return {
      title: 'Edit Taxonomy',
      subtitle: '',
      fields: [
        {
          for: "levelID", display: "Level", type: FieldType.Input, inputType: InputType.Text, styleClass: "input-custom"
        },
        {
          for: "name", display: "Name", type: FieldType.Input, inputType: InputType.Text, styleClass: "input-custom"
        },
        {
          for: "description", display: "Description", type: FieldType.Input, inputType: InputType.Text, styleClass: "input-custom"
        },
        {
          key: "subTaxonomies", displayAttribute: 'name', for: "subTaxonomies", display: "Related Taxonomies", type: FieldType.Multiselect, styleClass: "", filterAttribute: 'id'
        },
        {
          for: "isActive", display: "Active", type: FieldType.InputSwitch, styleClass: ""
        }
      ],
      btnLabel: 'Save'
    }
  }
}
