import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { LazyLoadEvent } from 'primeng/api';
import { TaxonomyService } from '../../data-access/taxonomy.service';
import { Taxonomy } from 'src/app/domain/taxonomy';
import { Subject, combineLatest, finalize, map, of } from 'rxjs';
import { TaxonomyTableHeaderService } from '../../utils/taxonomy-table-header.service';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { Form } from 'src/app/shared/models/form';
import { DataForm } from 'src/app/shared/models/data-form';
import { SideBySide } from 'src/app/shared/models/side-by-side';
import { Table } from 'src/app/shared/models/table';
import { DataTable } from 'src/app/shared/models/data-table';
import { FieldType } from 'src/app/shared/models/field-type';
import { TableType } from 'src/app/shared/models/table-type';

@Component({
  selector: 'app-taxonomy-dashboard',
  templateUrl: './taxonomy-dashboard.component.html',
  styleUrls: ['./taxonomy-dashboard.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TaxonomyDashboardComponent implements OnInit {
  addRowEnabled: boolean = true;

  sideBySide$ = new Subject<SideBySide>();
  table: Table;
  form: Form;

  onInit = true; // Flag to prevent onInit lazy load
  loading = true; // Flag to prevent multiple requests

  constructor(
    private taxonomyTableHeaderService: TaxonomyTableHeaderService,
    private taxonomyService: TaxonomyService) { }

  ngOnInit(): void {
    this.table = this.taxonomyTableHeaderService.getTable();
    this.form = this.taxonomyTableHeaderService.getForm();
    this.fetchData(this.table.first, this.table.rows);
  }

  lazyLoad($event: LazyLoadEvent) {
    if (this.onInit) {
      this.onInit = false;
      return;
    }

    const first = $event.first || this.table.first;
    const rows = $event.rows || this.table.rows;

    this.fetchData(first, rows);
  }

  fetchData(first: number, rows: number) {
    this.loading = true;

    combineLatest([
      this.taxonomyService.getAllWithFilters(first + 1, rows),
      this.taxonomyService.getAll()
    ])
    .pipe(
      finalize(() => {
        this.loading = false;
      }),
      map(([data, dropdownData]) => ({
        dataTable: this.mapTableData(this.table, data, dropdownData),
        dataForm: this.mapFormData(this.form, dropdownData),
        type: TableType.filtered
      }))
    )
    .subscribe((response) => {
      console.log(response);

      this.sideBySide$.next(response);
    });
  }

  setAddRowEnabled(enabled: boolean) {
    this.addRowEnabled = enabled;
  }

  onRowSave(selectedOption: Taxonomy) {
    if (selectedOption.id >= 0) {
      if (!this.addRowEnabled) {
        this.addTaxonomy(selectedOption);
        this.setAddRowEnabled(true);
        return;
      }

      this.updateTaxonomy(selectedOption);
      return;
    }
  }

  addTaxonomy(Taxonomy: Taxonomy) {
    this.taxonomyService.add(Taxonomy).subscribe((data: any) => {
    });
  }

  deleteTaxonomy(TaxonomyID: number) {
    this.taxonomyService.delete(TaxonomyID).subscribe((data: any) => {
    });
  }

  updateTaxonomy(Taxonomy: Taxonomy) {
    this.taxonomyService.update(Taxonomy).subscribe((data: any) => {
    });
  }

  mapTableData(table: Table, request: DataTableRequest, dropd: any[]) : DataTable{
    return {
      data: request.values,
      filters: [
        {
          field: {
            key: 'bus',
            display: 'Name',
            for: 'name',
            type: FieldType.Dropdown,
            styleClass: '',
            filterAttribute: 'id',
            displayAttribute: 'name'
          },
          data: dropd
        }
      ],
      table: {
        totalCount: request.totalCount,
        page: request.page,
        columns: table.columns,
        rows: table.rows,
        first: table.first
      }
    }
  }

  mapFormData(form: Form, dropdownsData: any[]) : DataForm{
    return {
      form: form,
      data: {},
      dropdownsData: {
        subTaxonomies: dropdownsData
      }
    }
  }
}
