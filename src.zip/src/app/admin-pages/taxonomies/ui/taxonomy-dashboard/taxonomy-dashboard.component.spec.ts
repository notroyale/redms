import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxonomyDashboardComponent } from './taxonomy-dashboard.component';
import { HttpClientModule } from '@angular/common/http';

describe('TaxonomyDashboardComponent', () => {
  let component: TaxonomyDashboardComponent;
  let fixture: ComponentFixture<TaxonomyDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [ TaxonomyDashboardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TaxonomyDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
