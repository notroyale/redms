import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessAreaDashboardComponent } from './business-area-dashboard.component';
import { HttpClientModule } from '@angular/common/http';

describe('BusinessAreaDashboardComponent', () => {
  let component: BusinessAreaDashboardComponent;
  let fixture: ComponentFixture<BusinessAreaDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [ BusinessAreaDashboardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BusinessAreaDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
