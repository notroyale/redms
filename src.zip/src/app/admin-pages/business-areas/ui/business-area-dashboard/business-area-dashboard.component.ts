import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { LazyLoadEvent } from 'primeng/api';
import { Subject, combineLatest, finalize, map } from 'rxjs';
import { BusinessAreaTableHeaderService } from '../../utils/business-area-table-header.service';
import { BusinessUnitService } from 'src/app/admin-pages/business-units/data-access/business-unit.service';
import { BusinessAreaService } from '../../data-access/business-area.service';
import { SideBySide } from 'src/app/shared/models/side-by-side';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { Form } from 'src/app/shared/models/form';
import { DataForm } from 'src/app/shared/models/data-form';
import { Table } from 'src/app/shared/models/table';
import { FieldType } from 'src/app/shared/models/field-type';
import { DataTable } from 'src/app/shared/models/data-table';
import { TableType } from 'src/app/shared/models/table-type';

@Component({
  selector: 'app-business-area-dashboard',
  templateUrl: './business-area-dashboard.component.html',
  styleUrls: ['./business-area-dashboard.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BusinessAreaDashboardComponent implements OnInit {
  sideBySide$ = new Subject<SideBySide>();
  table: Table;
  form: Form;

  onInit = true; // Flag to prevent onInit lazy load
  loading = true; // Flag to prevent multiple requests

  constructor(
    private businessUnitService: BusinessUnitService,
    private businessAreaService: BusinessAreaService,
    private businessAreaTableHeaderService: BusinessAreaTableHeaderService) {}

  ngOnInit(): void {
    this.table = this.businessAreaTableHeaderService.getTable();
    this.form = this.businessAreaTableHeaderService.getForm();
    this.fetchData(this.table.first, this.table.rows);
  }

  lazyObservationsLoad($event: LazyLoadEvent) {
    if (this.onInit) {
      this.onInit = false;
      return;
    }

    const first = $event.first || this.table.first;
    const rows = $event.rows || this.table.rows;

    this.fetchData(first, rows);
  }

  fetchData(first: number, rows: number) {
    this.loading = true;

    combineLatest([
      this.businessAreaService.getAllWithFilters(first + 1, rows),
      this.businessUnitService.getAll()
    ])
    .pipe(
      finalize(() => {
        this.loading = false;
      }),
      map(([data, dropdownData]) => ({
        dataTable: this.mapTableData(this.table, data, dropdownData),
        dataForm: this.mapFormData(this.form, dropdownData),
        type: TableType.filtered
      }))
    )
    .subscribe((response) => {
      console.log(response);

      this.sideBySide$.next(response);
    });
  }

  mapTableData(table: Table, request: DataTableRequest, dropd: any[]):DataTable{
    return {
      data: request.values,
      filters: [
        {
          field: {
            key: 'bus',
            display: 'Name',
            for: 'name',
            type: FieldType.Dropdown,
            styleClass: '',
            filterAttribute: 'id',
            displayAttribute: 'name'
          },
          data: dropd
        }
      ],
      table: {
        totalCount: request.totalCount,
        page: request.page,
        columns: table.columns,
        rows: table.rows,
        first: table.first
      }
    }
  }

  mapFormData(form: Form, dropdownsData: any[]) : DataForm{
    return {
      form: form,
      data: {},
      dropdownsData: {
        businessUnits: dropdownsData
      }
    }
  }
  
  editEntry(data:any){
    this.businessAreaService.update(data).subscribe(data=>console.log(data));
  }
}
