import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BusinessArea } from 'src/app/domain/business-area';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { HttpClient } from '@angular/common/http';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class BusinessAreaService {
  constructor(private http: HttpClient) { }

  public update(businessArea: BusinessArea): Observable<any> {
    return this.http.put<any>(`${settings.apibaseUrl}/api/BusinessArea/update`, businessArea);
  }

  public getAll(): Observable<BusinessArea[]> {
    return this.http.get<BusinessArea[]>(`${settings.apibaseUrl}/api/BusinessArea/all`);
  }

  public getAllWithFilters(skip: number, rows: number): Observable<DataTableRequest> {
    return this.http.get<DataTableRequest>(`${settings.apibaseUrl}/api/BusinessArea/allBase/options?page=${skip}&pageSize=${rows}`);
  }

  public add(businessArea: BusinessArea): Observable<any> {
    return this.http.post<any>(`${settings.apibaseUrl}/api/BusinessArea/add`, businessArea);
  }

  public delete(businessAreaId: number): Observable<any> {
    return this.http.delete<any>(`${settings.apibaseUrl}/api/BusinessArea/delete?Id=`+businessAreaId);
  }
}
