import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Grade } from 'src/app/domain/grade';
import { settings } from 'src/utils/appsettings.service';

@Injectable({
  providedIn: 'root'
})
export class GradeService {
  constructor(private http: HttpClient) { }

  public getAll(): Observable<Grade[]> {
    const url = `${settings.apibaseUrl}/api/Grade/all`;
    return this.http.get<Grade[]>(url);
  }
}