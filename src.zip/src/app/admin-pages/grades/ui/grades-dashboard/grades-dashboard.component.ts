import { Component } from '@angular/core';

@Component({
  selector: 'app-grades-dashboard',
  templateUrl: './grades-dashboard.component.html',
  styleUrls: ['./grades-dashboard.component.css']
})
export class GradesDashboardComponent {

}
