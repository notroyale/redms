import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { RagStatusService } from './rag-status.service';

describe('RagStatusService', () => {
  let service: RagStatusService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(RagStatusService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
