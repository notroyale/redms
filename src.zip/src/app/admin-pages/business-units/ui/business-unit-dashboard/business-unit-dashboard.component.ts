import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { LazyLoadEvent } from 'primeng/api';
import { Subject, combineLatest, finalize, map, of, switchMap } from 'rxjs';
import { BusinessUnitTableHeaderService } from '../../utils/business-unit-table-header.service';
import { BusinessUnitService } from '../../data-access/business-unit.service';
import { DataTableRequest } from 'src/app/domain/data-table-request';
import { SideBySide } from 'src/app/shared/models/side-by-side';
import { Filter } from 'src/app/shared/models/filter';
import { DataForm } from 'src/app/shared/models/data-form';
import { Form } from 'src/app/shared/models/form';
import { DropdownField } from 'src/app/shared/models/dropdown-field';
import { DataTable } from 'src/app/shared/models/data-table';
import { Table } from 'src/app/shared/models/table';
import { FieldType } from 'src/app/shared/models/field-type';
import { TableType } from 'src/app/shared/models/table-type';

@Component({
  selector: 'app-business-unit-dashboard',
  templateUrl: './business-unit-dashboard.component.html',
  styleUrls: ['./business-unit-dashboard.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BusinessUnitDashboardComponent implements OnInit{
  sideBySide$ = new Subject<SideBySide>();
  table: Table;
  form: Form;

  onInit = true; // Flag to prevent onInit lazy load
  loading = true; // Flag to prevent multiple requests

  constructor(
    private businessUnitService: BusinessUnitService,
    private businessUnitTableHeaderService: BusinessUnitTableHeaderService) {
  }

  lazyObservationsLoad($event: LazyLoadEvent) {
    if (this.onInit) {
      this.onInit = false;
      return;
    }

    const first = $event.first || this.table.first;
    const rows = $event.rows || this.table.rows;

    this.fetchData(first, rows);
  }

  ngOnInit(): void {
    this.table = this.businessUnitTableHeaderService.getTable();
    this.form = this.businessUnitTableHeaderService.getForm();
    this.fetchData(this.table.first, this.table.rows);
  }

  fetchData(first: number, rows: number) {
    this.loading = true;

    combineLatest([
      this.businessUnitService.getAllWithFilters(first + 1, rows),
      this.businessUnitService.getAll()
    ])
    .pipe(
      finalize(() => {
        this.loading = false;
      }),
      map(([data, dropdownData]) => ({
        dataTable: this.mapTableData(this.table, data, dropdownData),
        dataForm: this.mapFormData(this.form),
        type: TableType.filtered
      }))
    )
    .subscribe((response) => {
      console.log(response);

      this.sideBySide$.next(response);
    });
  }

  mapTableData(table: Table, request: DataTableRequest, dropd: any[]) : DataTable{
    return {
      data: request.values,
      filters: [
        {
          field: {
            key: 'bus',
            display: 'Name',
            for: 'name',
            type: FieldType.Dropdown,
            styleClass: '',
            filterAttribute: 'id',
            displayAttribute: 'name'
          },
          data: dropd
        }
      ],
      table: {
        totalCount: request.totalCount,
        page: request.page,
        columns: table.columns,
        rows: table.rows,
        first: table.first
      }
    }
  }

  mapFormData(form: Form) : DataForm{
    return {
      form: form,
      data: {},
      dropdownsData: {}
    }
  }

  mapFilters(field: DropdownField, data: any[]) : Filter{
    return {
      field: field,
      data: data
    }
  }

  editEntry(data:any){
    this.businessUnitService.update(data).subscribe(data=>console.log(data));
  }
}
