import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { BusinessUnitService } from './business-unit.service';

describe('BusinessUnitService', () => {
  let service: BusinessUnitService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });
      service = TestBed.inject(BusinessUnitService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
