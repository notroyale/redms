import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';

import { BusinessUnitTableHeaderService } from './business-unit-table-header.service';

describe('BusinessUnitTableHeaderService', () => {
  let service: BusinessUnitTableHeaderService;

  beforeEach(() => {
     TestBed.configureTestingModule({
      imports: [HttpClientModule],
     });;
    service = TestBed.inject(BusinessUnitTableHeaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
