

// @Injectable({
//   providedIn: 'root'
// })
// export class AuditService {

//   constructor(private http: HttpClient) {

//   }

//   public getAuditLog(): Observable<AuditEntry[]> {
//     return this.http.get<AuditEntry[]>(`${settings.apibaseUrl}/api/Audit/getAuditLog`);
//   }
// }
