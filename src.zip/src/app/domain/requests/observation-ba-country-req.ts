export interface ObservationBaCountryReq {
  observationID: number
  businessAreaID: number
  countryID: number
}
