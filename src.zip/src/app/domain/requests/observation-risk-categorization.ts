import { ObservationLegalEntity } from "../observation-legal-entity";

export interface ObservationRiskCategorizationReq {
  directive: string
  businessLine: string
  taxonomyLevel1: number,
  taxonomiesLevel2: number[],
  taxonomiesLevel3: number[],
}
