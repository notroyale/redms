import { ObservationLegalEntity } from "../observation-legal-entity";

export interface ObservationResponsibilityCenterReq {
  activityOwner: string
  riskOwner: string
  assignee: string
  businessUnitID: number
  legalEntities: ObservationLegalEntity[];
}
