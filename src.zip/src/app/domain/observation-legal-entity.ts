export interface ObservationLegalEntity {
    id: number;
    name: string;
    isActive: boolean;
  }