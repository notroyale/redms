export interface Category {
  id: number
  description:string
  isActive: boolean
}
