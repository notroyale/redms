export interface BusinessUnit {
    id: number
    code:string
    name:string
    isActive: boolean
}