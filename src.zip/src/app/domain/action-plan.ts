export interface ActionPlan{
id: number
actionTitle: string
actionSummary: string
businessAreaID: number
observationID: number
assignee: string
deadline: Date
actionStatus: string
creationDate: Date
// closureDate: Date
// closureUser: string
taxonomyLevel3ID: number
actionComment1LoD: string
actionComment1LODUser: string
activityOwner: string
}
