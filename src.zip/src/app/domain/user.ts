export interface User {
  password: string;
  userName: string;

}
export interface UserInfo {
  name: string;
  lastname: string;
  active: number;
}
