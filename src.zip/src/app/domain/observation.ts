import { ActionPlan } from "./action-plan";
import { BusinessUnit } from "./business-unit";
import { Category } from "./category";
import { Grade } from "./grade";
import { ObservationBusinessAreaCountry } from "./observation-business-area-country";
import { ObservationLegalEntity } from "./observation-legal-entity";
import { Taxonomy } from "./taxonomy";

export interface Observation {
  id: number;
  detailsStep: DetailsStep;
  responsibleCentreStep: ResponsibilityCentreStep;
  riskCategorizationStep: RiskCategorizationStep;
  recommendation: string | null;
  proposedPlan: string | null;
  registrationNumber: string | null;
  directive: string;
  submitted: boolean;
  deleted: boolean;
  mitigationActionComment: string | null;
  riskAssessmentId: number | null;
  ragStatusID: number;
}

export interface DetailsStep {
  [key: string]: any;
  title: string;
  categoryId: number;
  category: Category;
  dateIdentified: Date | null;
  creationDate: Date;
  deadline: Date | null;
  revisedDeadline: Date | null;
  grade: Grade;
  description: string | null;
}

export interface DetailsStepResponse {
  title: string;
  dateIdentified: Date | null;
  deadline: Date | null;
  categoryId: number;
  revisedDeadline: Date | null;
  gradeID: number;
  description: string | null;
}

export interface ResponsibilityCentreStep {
  [key: string]: any;
  businessUnit: BusinessUnit;
  businessAreasCountries: ObservationBusinessAreaCountry[];
  legalEntities: ObservationLegalEntity[];
  activityOwner: string;
  riskOwner: string;
  assignee: string;
}

export interface RelationshipStep {
  [key: string]: any;
  businessUnitId: number;
  categoryId: number;
  businessAreas: any;
  legalEntities:any;
  regulations:any;
  regulatoryCategories:any;
  taxonomies: any;
  countries: any;
}

export interface RiskCategorizationStep {
  [key: string]: any;
  taxonomies: { [key: number] : Taxonomy[] };
  businessLine: string;
  directive: string;
}

export interface CollabFieldsStep {
  [key: string]: any;
  ragStatusID: number;
  comment: string;
  comment1LoD: number;

}

export interface ActionPlanStep {
  [key: string]: any;
  actionPlans: ActionPlan[];

}
