export interface NewsEntry {
    id: number
    title:string
    description:string
    shortDescription:string
    date: Date
    author: string
}