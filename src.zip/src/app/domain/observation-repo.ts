import { RagStatus } from "./rag-status";
import { Status } from "./status";

export interface ObservationRepo {
  id:number;
  title : string;
  businessUnit : string;
  categoryId :number;
  level: number;
  riskOwner : string;
  statusID : number;
  ragStatusID : number;
  // creationDate: Date;
  creationUser: string;
  closureDate: string;
  deadline: string;
  ragStatus: RagStatus;
  Status: Status;
}

export interface AuthorisedObservationRepo {
  observation: ObservationRepo
  adminAccess: boolean
  approverAcces: boolean
  commentAccess: boolean
  editAccess: boolean
  viewAccess: boolean

}
