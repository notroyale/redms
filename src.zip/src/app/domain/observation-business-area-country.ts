export interface ObservationBusinessAreaCountry {
    id: number;
    observationID: number;
    businessAreaID: number;
    countryID: number;
}