export interface DataTableRequest {
  values: any[];
  page: number;
  pageSize: number;
  totalCount: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
  loading: boolean;
}