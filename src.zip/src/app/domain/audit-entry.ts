export interface AuditEntry {

}