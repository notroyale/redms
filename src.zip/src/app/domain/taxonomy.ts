export interface Taxonomy {
  id: number
  name: string
  description?: string
  isActive: boolean
  levelID: number
  subTaxonomies: Taxonomy[]
}
