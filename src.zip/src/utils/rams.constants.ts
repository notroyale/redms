import { InjectionToken } from "@angular/core";
import { AppSettings } from "./appsettings.service";

export const APP_CONFIG: InjectionToken<AppSettings> = new InjectionToken<AppSettings>('Application Configuration');