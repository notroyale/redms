import { Inject, Injectable, Injector } from '@angular/core';
import { HttpBackend, HttpClient } from '@angular/common/http';
import { Observable, ReplaySubject, of } from 'rxjs';
import { APP_CONFIG } from './rams.constants';

export interface AppSettings {
  apibaseUrl: string;
  appversion: string;
  defaultLocale: string;
}

export let settings: AppSettings;

export const initializeAppFactory = (
  service: AppSettingsService) => {
    console.log("inside appsettings");
    return () => { return service.initSettings(); }
};

@Injectable({
  providedIn: 'root'
})
export class AppSettingsService {
  private settings!: AppSettings;
  private subject$: ReplaySubject<AppSettings> = new ReplaySubject();
  public settings$: Observable<AppSettings> = this.subject$.asObservable();
  private withoutInterceptor: HttpClient;

  constructor(private httpBackend: HttpBackend,
    private injector: Injector,
    //private store: Store,
    @Inject(APP_CONFIG) private readonly appConfig: AppSettings,
    ) {

    this.withoutInterceptor = new HttpClient(httpBackend);

    this.initSettings();
  }

  initSettings(): Observable<void>{
    settings = this.appConfig as AppSettings;
    this.settings = this.appConfig as AppSettings;
    console.log(settings);
    this.subject$.next(settings);
    this.subject$.complete();

    return of();
  }
}
