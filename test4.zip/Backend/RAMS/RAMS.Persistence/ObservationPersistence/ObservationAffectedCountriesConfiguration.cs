﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Domain;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.ObservationPersistence;

internal class ObservationAffectedCountriesConfiguration : IEntityTypeConfiguration<ObservationAffectedCountries>
{

    public void Configure(EntityTypeBuilder<ObservationAffectedCountries> builder)
    {
        builder
            .ToTable(TablesNames.ObservationAffectedCountries);

        builder.ToTable(tb => tb.HasTrigger("after_observation_affectedCountry_delete"));
        builder.ToTable(tb => tb.HasTrigger("after_observation_affectedCountry_insert"));


        builder
            .HasKey(x => new {x.ObservationID, x.CountryID});

        builder.Property(p => p.Id).UseIdentityColumn();
    }
}