﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Domain;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.ObservationPersistence;

internal class ObservationLegalEntitiesConfiguration : IEntityTypeConfiguration<ObservationLegalEntity>
{

    public void Configure(EntityTypeBuilder<ObservationLegalEntity> builder)
    {
        builder
            .ToTable(TablesNames.ObservationLegalEntities);

        builder.ToTable(tb => tb.HasTrigger("after_observation_legalEntity_insert"));
        builder.ToTable(tb => tb.HasTrigger("after_observation_legalEntity_delete"));


        builder
            .HasKey(x => new {x.ObservationID, x.LegalEntityID});


        //builder
        //    .HasOne(x => x.Observation)
        //    .WithMany(x => x.LegalEntities)
        //    .HasForeignKey(x => x.ObservationID);


        builder
            .HasOne(x => x.LegalEntity)
            .WithMany(x => x.Observations)
            .HasForeignKey(x => x.LegalEntityID);
    }
}