﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RAMS.Domain;

namespace RAMS.Persistence.ObservationPersistence
{
    internal class ObservationGradeConfiguration : IEntityTypeConfiguration<ObservationGrade>
    {
        public void Configure(EntityTypeBuilder<ObservationGrade> builder)
        {
            builder
                .ToTable(TablesNames.ObservationGrade);

            builder.ToTable(tb => tb.HasTrigger("after_observation_grade_update"));
            builder.ToTable(tb => tb.HasTrigger("after_observation_grade_insert"));

            builder
                .HasKey(x => new { x.ObservationID });

            builder.Property(p => p.Id).UseIdentityColumn();

        }
    }
}
