﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Domain;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.ObservationPersistence;

internal class ObservationRegCategoriesConfiguration : IEntityTypeConfiguration<ObservationRegCategories>
{
    public void Configure(EntityTypeBuilder<ObservationRegCategories> builder)
    {
        builder
            .ToTable(TablesNames.ObservationRegulatoryCategory);

        builder
            .HasKey(x => new { x.ObservationID, x.RegulatoryCategoryID });

        builder.ToTable(tb => tb.HasTrigger("after_observation_regCategory_delete"));
        builder.ToTable(tb => tb.HasTrigger("after_observation_regCategory_insert"));

        builder
           .HasOne(x => x.Observation)
           .WithMany(x => x.RegulatoryCategories)
           .HasForeignKey(x => x.ObservationID);
    }
}