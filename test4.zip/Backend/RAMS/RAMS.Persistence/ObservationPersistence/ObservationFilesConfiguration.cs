﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Domain;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.ObservationPersistence;

internal class ObservationFilesConfiguration : IEntityTypeConfiguration<ObservationAttachment>
{

    public void Configure(EntityTypeBuilder<ObservationAttachment> builder)
    {
        builder
            .ToTable(TablesNames.ObservationFiles);

        builder.ToTable(tb => tb.HasTrigger("after_observation_file_delete"));
        builder.ToTable(tb => tb.HasTrigger("after_observation_file_insert"));


        builder
            .HasKey(x => new {x.ObservationID, x.Id});

        builder.Property(p => p.Id).UseIdentityColumn();
    }
}