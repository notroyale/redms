﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Domain;
using RAMS.Persistence.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Persistence.ObservationPersistence
{
    internal class ObservationBinaryFieldsConfiguration : IEntityTypeConfiguration<ObservationBinaryFields>
    {
        public void Configure(EntityTypeBuilder<ObservationBinaryFields> builder)
        {
            builder
                .ToTable(TablesNames.ObservationBinaryFields);

            builder.ToTable(tb => tb.HasTrigger("after_observation_binary_fields_insert"));
            builder.ToTable(tb => tb.HasTrigger("after_observation_binary_fields_update"));

            builder
                .HasKey(x => x.ObservationID);


            builder.Property(p => p.Id).UseIdentityColumn();
        }


    }
}
