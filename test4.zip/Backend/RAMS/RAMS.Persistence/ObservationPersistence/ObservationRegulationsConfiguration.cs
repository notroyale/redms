﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Domain;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.ObservationPersistence;

internal class ObservationRegulationsConfiguration : IEntityTypeConfiguration<ObservationRegulation>
{
    public void Configure(EntityTypeBuilder<ObservationRegulation> builder)
    {
        builder
            .ToTable(TablesNames.ObservationRegulations);

        builder.ToTable(tb => tb.HasTrigger("after_observation_regulation_delete"));
        builder.ToTable(tb => tb.HasTrigger("after_observation_regulation_insert"));

        builder
            .HasKey(x => new { x.ObservationID, x.RegulationID });
    }
}