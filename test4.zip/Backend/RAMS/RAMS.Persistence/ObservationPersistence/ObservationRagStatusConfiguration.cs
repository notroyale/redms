﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Domain;
using RAMS.Persistence.Common;


namespace RAMS.Persistence.ObservationPersistence;

internal class ObservationRagStatusConfiguration : IEntityTypeConfiguration<ObservationRagStatus>
{
    public void Configure(EntityTypeBuilder<ObservationRagStatus> builder)
    {
        builder
            .ToTable(TablesNames.ObservationRagStatus);

        builder.ToTable(tb => tb.HasTrigger("after_observation_ragStatus_insert"));
        builder.ToTable(tb => tb.HasTrigger("after_observation_ragStatus_update"));

        builder
            .HasKey(x => new { x.ObservationID});

        builder.Property(p => p.Id).UseIdentityColumn();

    }

}
