﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Domain;
using RAMS.Persistence.Common;


namespace RAMS.Persistence.ObservationPersistence;

internal class ObservationSelfRaisedIssueConfiguration : IEntityTypeConfiguration<ObservationSelfRaisedIssue>
{
    public void Configure(EntityTypeBuilder<ObservationSelfRaisedIssue> builder)
    {
        builder
            .ToTable(TablesNames.ObservationSelfRaisedIssue);

        builder.ToTable(tb => tb.HasTrigger("after_observation_selfRaisedIssue_update"));
        builder.ToTable(tb => tb.HasTrigger("after_observation_selfRaisedIssue_insert"));


        builder
            .HasKey(x => x.ObservationID);


        builder.Property(p => p.Id).UseIdentityColumn();
    }


}
