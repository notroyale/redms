﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.BusinessUnitPersistence;

internal class ObservationConfiguration : IEntityTypeConfiguration<Observation>
{
    public void Configure(EntityTypeBuilder<Observation> builder)
    {

        builder
            .ToTable(TablesNames.Observations);

        builder.ToTable(tb => tb.HasTrigger("after_observation_insert"));
        builder.ToTable(tb => tb.HasTrigger("after_observation_update"));

        //builder.ToTable(c => c.IsTemporal(tb =>
        //    {
        //        tb.UseHistoryTable("Observation", "History");
        //        tb
        //        .HasPeriodStart("ValidFrom")
        //        .HasColumnName("ValidFrom");
        //        tb.HasPeriodEnd("ValidTo")
        //        .HasColumnName("ValidTo");

        //    }));

        builder
            .HasKey(x => x.Id);

        builder
            .HasMany(x => x.LegalEntities)
            .WithOne(x => x.Observation)
            .HasForeignKey(x => x.ObservationID);


        builder
           .HasOne(x => x.SelfRaisedIssue)
           .WithOne(x => x.Observation)
           .HasForeignKey<ObservationSelfRaisedIssue>(x => x.ObservationID);

        builder
           .HasOne(x => x.BinaryFields)
           .WithOne(x => x.Observation)
           .HasForeignKey<ObservationBinaryFields>(x => x.ObservationID);

        builder
           .HasOne(x => x.ObservationRagStatus)
           .WithOne(x => x.Observation)
           .HasForeignKey<ObservationRagStatus>(x => x.ObservationID);

        builder
           .HasOne(x => x.ObservationGrade)
           .WithOne(x => x.Observation)
           .HasForeignKey<ObservationGrade>(x => x.ObservationID);

        builder
            .HasMany(x => x.Taxonomies)
            .WithOne(x => x.Observation)
            .HasForeignKey(obsTax => obsTax.ObservationID);

        //builder
        //    .HasMany(x => x.BusinessAreas)
        //    .WithMany(x => x.Observations)
        //    .UsingEntity<ObservationBusinessArea>();

        builder
            .HasMany(x => x.Regulations)
            .WithOne(x => x.Observation)
            .HasForeignKey(x=>x.ObservationID);

        builder
            .HasMany(x => x.ActionPlans)
            .WithOne(x => x.Observation)
            .HasForeignKey(x => x.ObservationID);

        builder
            .HasMany(x=>x.RegulatoryCategories)
            .WithOne(x=>x.Observation)
            .HasForeignKey(x => x.ObservationID);

        builder
            .HasMany(x => x.AffectedBusinessUnits)
            .WithOne(x => x.Observation)
            .HasForeignKey(x => x.ObservationID);

        builder
            .HasMany(x => x.AffectedBusinessAreas)
            .WithOne(x => x.Observation)
            .HasForeignKey(x => x.ObservationID);

        builder
            .HasMany(x => x.AffectedLegalEntities)
            .WithOne(x => x.Observation)
            .HasForeignKey(x => x.ObservationID);

        builder
            .HasMany(x => x.AffectedLegalEntities)
            .WithOne(x => x.Observation)
            .HasForeignKey(x => x.ObservationID);

        //builder
        //     .HasMany(x => x.Countries)
        //     .WithMany(x => x.Observations)
        //     .UsingEntity<ObservationBusinessArea>();

        builder
            .HasMany(x => x.BusinessAreasCountry)
            .WithOne(x => x.Observation)
            .HasForeignKey(x => x.ObservationID);

        //builder
        //   .HasOne(x => x.BusinessUnits)
        //   .WithMany(x => x.Observations)
        //   .HasForeignKey(x => x.BusinessUnitId);

        //builder
        //   .HasOne(x => x.Grade)
        //   .WithMany(x => x.Observations)
        //   .HasForeignKey(x => x.GradeID);

        builder
           .HasOne(x => x.RAGStatus)
           .WithMany(x => x.Observations)
           .HasForeignKey(x => x.RAGStatusID);

        builder
           .HasOne(x => x.Category)
           .WithMany(x => x.Observations)
           .HasForeignKey(x => x.CategoryId);

        builder
      .HasMany(x => x.Attachments)
      .WithOne(x => x.Observation)
      .HasForeignKey(x => x.ObservationID);

    }
}