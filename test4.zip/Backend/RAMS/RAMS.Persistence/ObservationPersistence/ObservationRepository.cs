﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using RAMS.Application.Common;
using RAMS.Application.ObservationApp;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Domain.Enumerators;
using RAMS.Domain.User;
using RAMS.Persistence.Common;
using System.Linq.Expressions;
using System.Net.Mail;

namespace RAMS.Persistence.ObservationPersistence;

internal class ObservationRepository : Repository<Observation>, IObservationRepository
{
    private readonly RiskManagementDbContext _context;

    public ObservationRepository(RiskManagementDbContext context) : base(context)
    {
        _context = context;
    }

    public async Task<Observation?> GetFull(Expression<Func<Observation, bool>> expression)
    {
        return await _context.Observations
            .Include(x => x.Taxonomies)
            .ThenInclude(x => x.Taxonomy)
            .Include(x => x.BusinessAreasCountry)
            .ThenInclude(x => x.BusinessArea)
            .Include(x => x.BusinessAreasCountry)
            .ThenInclude(x => x.Country)
            .Include(x => x.LegalEntities)
            .ThenInclude(x => x.LegalEntity)
            .Include(x => x.Attachments)
            .AsSplitQuery()
            .Select(x => new Observation
            {
                Id = x.Id,
                Title = x.Title,
                CategoryId = x.CategoryId,
                //GradeID = x.GradeID,
                //Category = x.Category,
                //Grade = x.Grade,
                RiskOwner = x.RiskOwner,
                StatusID = x.StatusID,
                //Status = x.Status,
                RAGStatusID = x.RAGStatusID,
                //RAGStatus = x.RAGStatus,
                //BusinessUnit = x.BusinessUnit,
                LegalEntities = x.LegalEntities,
                BusinessAreasCountry = x.BusinessAreasCountry.ToList(),
                Summary = x.Summary,
                RegulatoryCategories = x.RegulatoryCategories,
                BusinessLine = x.BusinessLine,
                ActivityOwner = x.ActivityOwner,
                Assignee = x.Assignee,
                BusinessUnitId = x.BusinessUnitId,
                Taxonomies = x.Taxonomies,
                Regulations = x.Regulations,
                ActionPlans = x.ActionPlans.ToList(),
                RiskAssessmentId = x.RiskAssessmentId,
                GroupObservationId = x.GroupObservationId,
                RegistrationNumber = x.RegistrationNumber,
                Recommendation = x.Recommendation,
                Comment = x.Comment,
                Comment1LoD = x.Comment1LoD,
                ProposedPlan = x.ProposedPlan,
                Directive = x.Directive,
                Submitted = x.Submitted,
                Deleted = x.Deleted,
                MitigationActionComment = x.MitigationActionComment,
                CreationDate = x.CreationDate,
                ClosureDate = x.ClosureDate,
                Deadline = x.Deadline,
                DateIdentified = x.Deadline,
                RevisedDeadline = x.RevisedDeadline,
                SelfRaisedIssue = x.SelfRaisedIssue,
                //RelatedToESG = x.RelatedToESG,
                //RelatedToConductRisk = x.RelatedToConductRisk,
                //ESGJustification = x.ESGJustification,
                //ConductRiskJustification = x.ConductRiskJustification,
                CancellationComment = x.CancellationComment,
                CancellationDate = x.CancellationDate,
                RiskAcceptanceDate = x.RiskAcceptanceDate,
                DeadlineExtensionDate = x.DeadlineExtensionDate,
                AffectedBusinessUnits = x.AffectedBusinessUnits,
                AffectedLegalEntities = x.AffectedLegalEntities,
                AffectedBusinessAreas = x.AffectedBusinessAreas,
                AffectedCountries = x.AffectedCountries,
                ObservationRagStatus = x.ObservationRagStatus,
                SubmittedForClosure = x.SubmittedForClosure,
                ClosureJustification = x.ClosureJustification,
                Attachments = x.Attachments.Select(y => new ObservationAttachment() { Id = y.Id, Filename = y.Filename, LoD = y.LoD, GDPR = y.GDPR, Deleted = y.Deleted, ObservationID = y.ObservationID }).ToList(),
                BinaryFields = x.BinaryFields,
                ObservationGrade = x.ObservationGrade
            })
            .FirstOrDefaultAsync(expression);
    }
    public async Task<ObservationAuthorisation?> GetFull(int id, AccessControl accessControl, IEnumerable<FieldHelpText>? helpText)
    {
        IQueryable<Observation> observationsQuery = _context.Observations.Where(obs => obs.Id == id);

        observationsQuery = observationsQuery.Where(obs =>
            (accessControl.BusinessUnitIds.Contains(obs.BusinessUnitId) && obs.LegalEntities.Count() == 0) ||
            (accessControl.BusinessUnitIds.Contains(obs.BusinessUnitId) && obs.LegalEntities.All(le => accessControl.LegalEntityIds.Contains(le.LegalEntityID))));

        return await observationsQuery
            .Include(x => x.Taxonomies)
            .ThenInclude(x => x.Taxonomy)
            .Include(x => x.BusinessAreasCountry)
            .ThenInclude(x => x.BusinessArea)
            .Include(x => x.BusinessAreasCountry)
            .ThenInclude(x => x.Country)
            .Include(x => x.LegalEntities)
            .ThenInclude(x => x.LegalEntity)
            .Include(x => x.Attachments)
            .AsSplitQuery()
            .Select(x => ObservationAuthorisation.Create(new Observation
            {
                Id = x.Id,
                Title = x.Title,
                CategoryId = x.CategoryId,
                //GradeID = x.GradeID,
                //Category = x.Category,
                //Grade = x.Grade,
                RiskOwner = x.RiskOwner,
                StatusID = x.StatusID,
                //Status = x.Status,
                RAGStatusID = x.RAGStatusID,
                //RAGStatus = x.RAGStatus,
                //BusinessUnit = x.BusinessUnit,
                LegalEntities = x.LegalEntities,
                BusinessAreasCountry = x.BusinessAreasCountry.ToList(),
                Summary = x.Summary,
                RegulatoryCategories = x.RegulatoryCategories,
                BusinessLine = x.BusinessLine,
                ActivityOwner = x.ActivityOwner,
                Assignee = x.Assignee,
                BusinessUnitId = x.BusinessUnitId,
                Taxonomies = x.Taxonomies,
                Regulations = x.Regulations,
                ActionPlans = x.ActionPlans.ToList(),
                RiskAssessmentId = x.RiskAssessmentId,
                GroupObservationId = x.GroupObservationId,
                RegistrationNumber = x.RegistrationNumber,
                Recommendation = x.Recommendation,
                Comment = x.Comment,
                Comment1LoD = x.Comment1LoD,
                ProposedPlan = x.ProposedPlan,
                Directive = x.Directive,
                Submitted = x.Submitted,
                Deleted = x.Deleted,
                MitigationActionComment = x.MitigationActionComment,
                CreationDate = x.CreationDate,
                ClosureDate = x.ClosureDate,
                Deadline = x.Deadline,
                DateIdentified = x.DateIdentified,
                RevisedDeadline = x.RevisedDeadline,
                SelfRaisedIssue = x.SelfRaisedIssue,
                //RelatedToESG = x.RelatedToESG,
                //RelatedToConductRisk = x.RelatedToConductRisk,
                //ESGJustification = x.ESGJustification,
                //ConductRiskJustification = x.ConductRiskJustification,
                CancellationComment = x.CancellationComment,
                CancellationDate = x.CancellationDate,
                RiskAcceptanceDate = x.RiskAcceptanceDate,
                DeadlineExtensionDate = x.DeadlineExtensionDate,
                AffectedBusinessUnits = x.AffectedBusinessUnits,
                AffectedLegalEntities = x.AffectedLegalEntities,
                AffectedBusinessAreas = x.AffectedBusinessAreas,
                AffectedCountries = x.AffectedCountries,
                ObservationRagStatus = x.ObservationRagStatus,
                SubmittedForClosure = x.SubmittedForClosure,
                ClosureJustification = x.ClosureJustification,
                Attachments = x.Attachments.Select(y => new ObservationAttachment() { Id = y.Id, Filename = y.Filename, LoD = y.LoD, GDPR = y.GDPR, Deleted = y.Deleted, ObservationID=y.ObservationID }).ToList(),
                ObservationCategoryExplanation = x.ObservationCategoryExplanation,
                DeadlineExtensionJustification = x.DeadlineExtensionJustification,
                BinaryFields = x.BinaryFields,
                ObservationGrade = x.ObservationGrade
            },
            accessControl, helpText))
            .FirstOrDefaultAsync();
    }

    public async Task<ObservationAuthorisation?> GetFull(int id, AccessControl accessControl)
    {
        IQueryable<Observation> observationsQuery = _context.Observations.Where(obs => obs.Id == id);

        observationsQuery = observationsQuery.Where(obs =>
            (accessControl.BusinessUnitIds.Contains(obs.BusinessUnitId) && obs.LegalEntities.Count() == 0) ||
            (accessControl.BusinessUnitIds.Contains(obs.BusinessUnitId) && obs.LegalEntities.All(le => accessControl.LegalEntityIds.Contains(le.LegalEntityID))));

        return await observationsQuery
            .Include(x => x.Taxonomies)
            .ThenInclude(x => x.Taxonomy)
            .Include(x => x.BusinessAreasCountry)
            .ThenInclude(x => x.BusinessArea)
            .Include(x => x.BusinessAreasCountry)
            .ThenInclude(x => x.Country)
            .Include(x => x.LegalEntities)
            .ThenInclude(x => x.LegalEntity)
            .Include(x => x.Attachments)
            .AsSplitQuery()
            .Select(x => ObservationAuthorisation.Create(new Observation
            {
                Id = x.Id,
                Title = x.Title,
                CategoryId = x.CategoryId,
                //GradeID = x.GradeID,
                //Category = x.Category,
                //Grade = x.Grade,
                RiskOwner = x.RiskOwner,
                StatusID = x.StatusID,
                //Status = x.Status,
                RAGStatusID = x.RAGStatusID,
                //RAGStatus = x.RAGStatus,
                //BusinessUnit = x.BusinessUnit,
                LegalEntities = x.LegalEntities,
                BusinessAreasCountry = x.BusinessAreasCountry.ToList(),
                Summary = x.Summary,
                RegulatoryCategories = x.RegulatoryCategories,
                BusinessLine = x.BusinessLine,
                ActivityOwner = x.ActivityOwner,
                Assignee = x.Assignee,
                BusinessUnitId = x.BusinessUnitId,
                Taxonomies = x.Taxonomies,
                Regulations = x.Regulations,
                ActionPlans = x.ActionPlans.ToList(),
                RiskAssessmentId = x.RiskAssessmentId,
                GroupObservationId = x.GroupObservationId,
                RegistrationNumber = x.RegistrationNumber,
                Recommendation = x.Recommendation,
                Comment = x.Comment,
                Comment1LoD = x.Comment1LoD,
                ProposedPlan = x.ProposedPlan,
                Directive = x.Directive,
                Submitted = x.Submitted,
                Deleted = x.Deleted,
                MitigationActionComment = x.MitigationActionComment,
                CreationDate = x.CreationDate,
                ClosureDate = x.ClosureDate,
                ClosureUser = x.ClosureUser,
                Deadline = x.Deadline,
                DateIdentified = x.DateIdentified,
                RevisedDeadline = x.RevisedDeadline,
                SelfRaisedIssue = x.SelfRaisedIssue,
                //RelatedToESG = x.RelatedToESG,
                //RelatedToConductRisk = x.RelatedToConductRisk,
                //ESGJustification = x.ESGJustification,
                //ConductRiskJustification = x.ConductRiskJustification,
                CancellationComment = x.CancellationComment,
                CancellationDate = x.CancellationDate,
                RiskAcceptanceDate = x.RiskAcceptanceDate,
                DeadlineExtensionDate = x.DeadlineExtensionDate,
                AffectedBusinessUnits = x.AffectedBusinessUnits,
                AffectedLegalEntities = x.AffectedLegalEntities,
                AffectedBusinessAreas = x.AffectedBusinessAreas,
                AffectedCountries = x.AffectedCountries,
                ObservationRagStatus = x.ObservationRagStatus,
                SubmittedForClosure = x.SubmittedForClosure,
                ClosureJustification = x.ClosureJustification,
                Attachments = x.Attachments.Select(y => new ObservationAttachment() { Id = y.Id, Filename = y.Filename, LoD = y.LoD, GDPR = y.GDPR, Deleted = y.Deleted, ObservationID = y.ObservationID }).ToList(),
                ObservationCategoryExplanation = x.ObservationCategoryExplanation,
                DeadlineExtensionJustification = x.DeadlineExtensionJustification,
                BinaryFields = x.BinaryFields,
                ObservationGrade = x.ObservationGrade
            },
            accessControl, null))
            .FirstOrDefaultAsync();
    }


    public async Task<PagedList<ObservationAuthorisation>> GetAllBaseAsync(SearchOptions searchOptions, AccessControl accessControl)
    {
        IQueryable<Observation> observationsQuery = _context.Observations.Where(obs => !obs.Deleted && obs.Submitted);

        observationsQuery = observationsQuery.Where(obs =>
            (accessControl.BusinessUnitIds.Contains(obs.BusinessUnitId) && obs.LegalEntities.Count() == 0) ||
            (accessControl.BusinessUnitIds.Contains(obs.BusinessUnitId) && obs.LegalEntities.All(le => accessControl.LegalEntityIds.Contains(le.LegalEntityID))));

        if (searchOptions.SearchTerm != null)
        {
            observationsQuery = SearchingByTerm(searchOptions, observationsQuery, searchOptions.SearchTerm);
        }

        if (searchOptions.LegalEntityIDs != null && searchOptions.LegalEntityIDs.Length > 0)
            observationsQuery = observationsQuery.Where(x => x.LegalEntities.Any(y => searchOptions.LegalEntityIDs.Contains(y.LegalEntityID)));

        if (searchOptions.StatusIDs != null && searchOptions.StatusIDs.Length > 0)
            observationsQuery = observationsQuery.Where(x => searchOptions.StatusIDs.Contains(x.StatusID));

        if (searchOptions.GradeIDs != null && searchOptions.GradeIDs.Length > 0)
            observationsQuery = observationsQuery.Where(x => searchOptions.GradeIDs.Contains(x.ObservationGrade.GradeID));

        if (searchOptions.Countries != null && searchOptions.Countries.Length > 0)
            observationsQuery = observationsQuery.Where(x => x.BusinessAreasCountry.Any(y => searchOptions.Countries.Contains(y.CountryID)));

        if (searchOptions.BusinessUnitIDs != null && searchOptions.BusinessUnitIDs.Length > 0)
            observationsQuery = observationsQuery.Where(x => searchOptions.BusinessUnitIDs.Contains(x.BusinessUnitId));

        if (searchOptions.CategoryIDs != null && searchOptions.CategoryIDs.Length > 0)
            observationsQuery = observationsQuery.Where(x => searchOptions.CategoryIDs.Contains(x.CategoryId));

        if (searchOptions.BusinessAreaIDs != null && searchOptions.BusinessAreaIDs.Length > 0)
            observationsQuery = observationsQuery.Where(x => x.BusinessAreas.Any(y => searchOptions.BusinessAreaIDs.Contains(y.Id)));

        if (searchOptions.LegalEntityIDs != null && searchOptions.LegalEntityIDs.Length > 0)
            observationsQuery = observationsQuery.Where(x => x.LegalEntities.Any(y => searchOptions.LegalEntityIDs.Contains(y.LegalEntityID)));

        if (searchOptions.TaxonomyLevel1IDs != null && searchOptions.TaxonomyLevel1IDs.Length > 0)
           observationsQuery = observationsQuery.Where(x => x.Taxonomies.Any(y => searchOptions.TaxonomyLevel1IDs.Contains(y.TaxonomyID)));
        if (searchOptions.TaxonomyLevel2IDs != null && searchOptions.TaxonomyLevel2IDs.Length > 0)
            observationsQuery = observationsQuery.Where(x => x.Taxonomies.Any(y => searchOptions.TaxonomyLevel2IDs.Contains(y.TaxonomyID)));
        if (searchOptions.TaxonomyLevel3IDs != null && searchOptions.TaxonomyLevel3IDs.Length > 0)
            observationsQuery = observationsQuery.Where(x => x.Taxonomies.Any(y => searchOptions.TaxonomyLevel3IDs.Contains(y.TaxonomyID)));


        Expression<Func<Observation, object>> keyselector  = MapSortColumn(searchOptions);

        if(searchOptions.SortOrder == SortOrder.Desc)
        {
            observationsQuery = observationsQuery.OrderByDescending(keyselector);
        }
        else
        {
            observationsQuery = observationsQuery.OrderBy(keyselector);
        }

        IQueryable<ObservationAuthorisation> authorisedObservationsQuery = observationsQuery
            .Select(obs => ObservationAuthorisation.Create(
                new Observation()
                {
                    Id = obs.Id,
                    Title = obs.Title,
                    CategoryId = obs.CategoryId,
                    Category = obs.Category,
                    CreationDate = obs.CreationDate,
                    //GradeID = obs.GradeID,
                    ObservationGrade = obs.ObservationGrade,
                    RiskOwner = obs.RiskOwner,
                    CreationUser = obs.CreationUser,
                    ClosureDate = obs.ClosureDate,
                    Deadline = obs.Deadline,
                    StatusID = obs.StatusID,
                    RAGStatusID = obs.RAGStatusID,
                    RAGStatus = obs.RAGStatus,
                    Status = obs.Status,
                    DateIdentified = obs.Deadline,
                    RevisedDeadline = obs.RevisedDeadline,
                    BusinessUnitId = obs.BusinessUnitId,
                    BusinessUnit = obs.BusinessUnit,
                    LegalEntities = obs.LegalEntities,
                    Assignee = obs.Assignee,
                    ModifiedUser = obs.ModifiedUser,
                    ModifiedDate = obs.ModifiedDate,
                    Summary = obs.Summary,

                },
                accessControl,null));

        var authorisedObservations = await PagedList<ObservationAuthorisation>.CreateAsync(
            authorisedObservationsQuery,
            searchOptions.Page,
            searchOptions.PageSize);

        return authorisedObservations;
    }

    private static Expression<Func<Observation, object>>  MapSortColumn(SearchOptions searchOptions)
    {
        return searchOptions.SortColumn.ToLower() switch

        {
            "id" => observation => observation.Id,
            "title" => observation => observation.Title,
            "status" => observation => observation.StatusID,
            "businessunit" => observation => observation.BusinessUnitId,
            "category" => observation => observation.CategoryId,
            "level" => observation => observation.ObservationGrade.GradeID,
            "deadline" => observation => observation.Deadline,
            "creationuser" => observation => observation.CreationUser,
            "closuredate" => observation => observation.ClosureDate,
            "ragstatus" => observation => observation.RAGStatusID,
            "creationdate" => observation => observation.CreationDate,
            "riskowner" => observation => observation.ActivityOwner,
            _ => observation => observation.Id
        };

      
    }

    private static IQueryable<Observation> SearchingByTerm(SearchOptions searchOptions, IQueryable<Observation> observationsQuery, string searchTerm)
    {
        bool isNumber = int.TryParse(searchOptions.SearchTerm, out int id);
        if (!isNumber)
        {
            return observationsQuery.Where(x => x.Title.ToLower().Contains(searchTerm.ToLower()));
        }

        return observationsQuery.Where(x => x.Id == id);
    }

    public async Task<IEnumerable<AuthorisationAccessPermission>> GetAllAuthorised()
    {
        return await _context.AuthorizationAccessPermissions
            .Select(x => new AuthorisationAccessPermission()
            {
                AdminAccess = x.AdminAccess,
                ApproverAccess = x.ApproverAccess,
                CommentAccess = x.CommentAccess,
                EditAccess = x.EditAccess,
                ViewAccess = x.ViewAccess,
                AuthorisationID = x.AuthorisationID,
                Authorisation = new Authorisation()
                {
                    Id = x.Authorisation.Id,
                    BusinessUnits = x.Authorisation.BusinessUnits.Select(x => new BusinessUnit()
                    {
                        Id = x.Id
                    }),
                    LegalEntities = x.Authorisation.LegalEntities.Select(x => new LegalEntity()
                    {
                        Id = x.Id
                    }),
                }
            })
            .ToListAsync();
    }



}