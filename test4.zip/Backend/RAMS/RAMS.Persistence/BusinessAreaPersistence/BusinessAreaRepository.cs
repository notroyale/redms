﻿using Microsoft.EntityFrameworkCore;
using RAMS.Application.BusinessAreaApp;
using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.BusinessAreaPersistence;

internal class BusinessAreaRepository : Repository<BusinessArea>, IBusinessAreaRepository
{
    private readonly RiskManagementDbContext _context;

    public BusinessAreaRepository(RiskManagementDbContext context) : base(context)
    {
        _context = context;
    }

    public async Task<IEnumerable<BusinessArea>> GetAllByBusinessUnitId(int[] ids)
    {
        return await _context.BusinessAreas
            .Where(ba => ids.Any(id => id == ba.BusinessUnitID) && !ba.LegalEntity)
            .GroupBy(x => x.Id)
            .Select(x => new BusinessArea{ 
                Id = x.First().Id,
                Name = x.First().Name,
                IsActive = x.First().IsActive && x.First().IsActive,
            })
            .OrderByDescending(x => x.IsActive).ThenBy(x => x.Name)
            .ToListAsync();
    }


    public async Task<IEnumerable<BusinessArea>> GetAllWithBusinessUnits()
    {
        return await _context.BusinessAreas.Where(ba => !ba.LegalEntity)
            .Select(x => new BusinessArea(x.Id, x.Name, x.IsActive, x.IsDefault, x.BusinessUnitID, x.BusinessUnit))
            .ToListAsync();
    }

    public async Task<PagedList<BusinessArea>> GetAllWithOptions(SearchOptions searchOptions)
    {
        IQueryable<BusinessArea> businessAreasQuery = _context.BusinessAreas;

        businessAreasQuery = businessAreasQuery.Where(ba => !ba.LegalEntity)
            .Select(x => new BusinessArea
            {
                Id = x.Id,
                Name = x.Name,
                BusinessUnitID = x.BusinessUnitID,
                IsActive = x.IsActive,
                BusinessUnit = x.BusinessUnit
            });

        var businessAreas = await PagedList<BusinessArea>.CreateAsync(
            businessAreasQuery,
            searchOptions.Page,
            searchOptions.PageSize);

        return businessAreas;
    }
}