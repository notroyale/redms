﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.BusinessUnitPersistence;

internal class BusinessAreaConfiguration : IEntityTypeConfiguration<BusinessArea>
{
    public void Configure(EntityTypeBuilder<BusinessArea> builder)
    {
        builder
            .ToTable(TablesNames.BusinessAreas);

        builder
            .HasKey(x => x.Id);

        builder
            .HasMany(x => x.Observations)
            .WithMany(x => x.BusinessAreas)
            .UsingEntity<ObservationBusinessArea>();

        builder
            .HasOne(x => x.BusinessUnit)
            .WithMany(x => x.BusinessAreas)
            .HasForeignKey(x => x.BusinessUnitID);
            //.UsingEntity<BusinessUnitBusinessArea>();
    }
}