﻿using RAMS.Application.Common;
using RAMS.Application.GradeApp;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.GradePersistence;

internal class GradeRepository : Repository<Grade>, IGradeRepository
{
    private readonly RiskManagementDbContext _context;

    public GradeRepository(RiskManagementDbContext context) : base(context)
    {
        _context = context;
    }

    public async Task<PagedList<Grade>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        IQueryable<Grade> gradesQuery = _context.Grade;

        var gradesResponseQuery = gradesQuery
            .Select(x => new Grade
            {
                Id = x.Id,
                Name = x.Name,
                IsActive = x.IsActive
            });

        var grades = await PagedList<Grade>.CreateAsync(
            gradesResponseQuery,
            searchOptions.Page,
            searchOptions.PageSize);

        return grades;
    }
}