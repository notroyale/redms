﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.AuthorisationPersistence;

internal class AuthorisationConfiguration : IEntityTypeConfiguration<Authorisation>
{
    public void Configure(EntityTypeBuilder<Authorisation> builder)
    {
        builder
            .ToTable(TablesNames.Authorisations);

        builder
            .HasKey(x => x.Id);

        builder
            .HasMany(x => x.BusinessUnits)
            .WithMany(x => x.Authorisations)
            .UsingEntity<AuthorisationBusinessUnit>();

        builder
            .HasMany(x => x.LegalEntities)
            .WithMany(x => x.Authorisations)
            .UsingEntity<AuthorisationLegalEntity>();

        builder
            .HasMany(x => x.Role)
            .WithMany(x => x.Authorisations)
            .UsingEntity<AuthorisationRoles>();
    }
}