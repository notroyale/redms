﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.AuthorisationPersistence;

internal class AuthorisationBusinessUnitConfiguration : IEntityTypeConfiguration<AuthorisationBusinessUnit>
{
    public void Configure(EntityTypeBuilder<AuthorisationBusinessUnit> builder)
    {
        builder
            .ToTable(TablesNames.AuthorisationBusinessUnits);

        builder
            .HasKey(x => new { x.AuthorisationID, x.BusinessUnitID });
    }
}