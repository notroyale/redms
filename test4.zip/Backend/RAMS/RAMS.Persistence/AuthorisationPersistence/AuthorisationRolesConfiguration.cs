﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RAMS.Domain;
using RAMS.Persistence.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Persistence.AuthorisationPersistence;

internal class AuthorisationRoleConfiguration : IEntityTypeConfiguration<AuthorisationRoles>
{
    public void Configure(EntityTypeBuilder<AuthorisationRoles> builder)
    {
        builder
            .ToTable(TablesNames.AuthorisationRoles);

        builder
            .HasKey(x => new { x.AuthorisationID, x.RoleID });

    }
}