﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.AuthorisationPersistence;

internal class AuthorisationAccessPermissionsConfiguration : IEntityTypeConfiguration<AuthorisationAccessPermission>
{
    public void Configure(EntityTypeBuilder<AuthorisationAccessPermission> builder)
    {
        builder
            .ToTable(TablesNames.AuthorisationAccessPermissions);

        builder
            .HasKey(x => x.AuthorisationID);

        builder
            .HasOne(x => x.Authorisation)
            .WithOne(x => x.AccessPermission)
            .HasForeignKey<AuthorisationAccessPermission>(x => x.AuthorisationID);
    }
}