﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.AuthorisationPersistence;

internal class AuthorisationLegalEntityConfiguration : IEntityTypeConfiguration<AuthorisationLegalEntity>
{
    public void Configure(EntityTypeBuilder<AuthorisationLegalEntity> builder)
    {
        builder
            .ToTable(TablesNames.AuthorisationLegalEntities);

        builder
            .HasKey(x => new { x.AuthorisationID, x.LegalEntityID });
    }
}