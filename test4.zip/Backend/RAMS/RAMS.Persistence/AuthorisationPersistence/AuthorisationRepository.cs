﻿using Microsoft.EntityFrameworkCore;
using RAMS.Application.AuthorisationApp;
using RAMS.Domain;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.AuthorisationPersistence;

internal class AuthorisationRepository : Repository<Country>, IAuthorisationRepository
{
    private readonly RiskManagementDbContext _context;

    public AuthorisationRepository(RiskManagementDbContext context) : base(context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Authorisation>> GetUserPermissions(IEnumerable<string> authorisations)
    {
        return await _context.Authorisations
            .Where(a => authorisations.Any(x => x.Equals(a.ShortName)))
            .Select(x => new Authorisation()
            {
                Id = x.Id,
                Name = x.Name,
                ShortName = x.ShortName,
                AccessPermission = new AuthorisationAccessPermission()
                {
                    EditAccess = x.AccessPermission.EditAccess,
                    ViewAccess = x.AccessPermission.ViewAccess,
                    ApproverAccess = x.AccessPermission.ApproverAccess,
                    AdminAccess = x.AccessPermission.AdminAccess,
                    CommentAccess = x.AccessPermission.CommentAccess
                },
                BusinessUnits = x.BusinessUnits.Select(y => new BusinessUnit
                {
                    Id=y.Id,
                }),
                LegalEntities = x.LegalEntities.Select(y => new LegalEntity
                {
                    Id = y.Id,
                }),
            })
            .ToListAsync();
    }

    public async Task<IEnumerable<Authorisation>> GetAllAsync()
    {
        return await _context.Authorisations
            .Include(a => a.BusinessUnits)
            .Include(a => a.LegalEntities)
            .Select(x => new Authorisation()
            {
                Id = x.Id,
                Name = x.Name,
                ShortName = x.ShortName,
                Description = x.Description,
                Role = x.Role.Select(x => new Roles
                {
                    Id = x.Id,
                    Name = x.Name,
                    IsActive = x.IsActive,
                    Description = x.Description,
                }),
                BusinessUnits = x.BusinessUnits.Select(y => new BusinessUnit
                {
                    Id = y.Id,
                    Code = y.Code,
                    Name = y.Name,
                    IsActive = y.IsActive,
                }),
                LegalEntities = x.LegalEntities.Select(y => new LegalEntity
                {
                    Id = y.Id,
                    Name = y.Name,
                    IsActive = y.IsActive,
                }),
                IsActive = x.IsActive,
            })
            .ToListAsync();
    }
}