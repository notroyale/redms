﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.ActionPlanPersistence;

internal class ActionPlanConfiguration : IEntityTypeConfiguration<ActionPlan>
{
    public void Configure(EntityTypeBuilder<ActionPlan> builder)
    {
        builder
            .ToTable(TablesNames.ActionPlan);

        builder.ToTable(tb => tb.HasTrigger("after_observation_action_insert"));
        builder.ToTable(tb => tb.HasTrigger("after_observation_action_update"));
        builder.ToTable(tb => tb.HasTrigger("after_observation_action_delete"));
        builder
            .HasKey(x => x.Id);
    }
}