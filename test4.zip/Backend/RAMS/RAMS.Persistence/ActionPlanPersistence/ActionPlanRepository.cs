﻿using Microsoft.EntityFrameworkCore;
using RAMS.Application.ActionPlanApp;
using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Persistence.Common;
using System.Linq.Expressions;

namespace RAMS.Persistence.ActionPlanPersistence;

internal class ActionPlanRepository : Repository<ActionPlan>, IActionPlanRepository
{
    private readonly RiskManagementDbContext _context;

    public ActionPlanRepository(RiskManagementDbContext context) : base(context)
    {
        _context = context;
    }

    public async Task<ActionPlan?> GetFull(Expression<Func<ActionPlan, bool>> expression)
    {
        return await _context.ActionPlan
            .Select(x => new ActionPlan
            {
                Id = x.Id,
                ActivityOwner = x.ActivityOwner,
                Assignee = x.Assignee,                
                CreationDate = x.CreationDate,
                ClosureDate = x.ClosureDate,
                Deadline = x.Deadline,
                ActionTitle = x.ActionTitle,
                ActionSummary = x.ActionSummary,
                BusinessAreaID = x.BusinessAreaID,
                ObservationID = x.ObservationID,
                CreationUser = x.CreationUser,
                ModifiedUser = x.ModifiedUser,
                ModifiedDate = x.ModifiedDate,
                ActionStatus = x.ActionStatus,
                ClosureUser = x.ClosureUser,
                TaxonomyLevel3ID = x.TaxonomyLevel3ID,
                ActionComment1LoD = x.ActionComment1LoD,
                ActionComment1LoDDate = x.ActionComment1LoDDate,
                ActionComment1LODUser = x.ActionComment1LODUser,
                Observation = x.Observation,
            })
            .FirstOrDefaultAsync(expression);
    }

    public async Task<PagedList<ActionPlan>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        IQueryable<ActionPlan> actionPlansQuery = _context.ActionPlan;

        if (!string.IsNullOrEmpty(searchOptions.SearchTerm))
        {
            actionPlansQuery = actionPlansQuery.Where(x => x.ObservationID.ToString().Equals(searchOptions.SearchTerm));
        }

        var actionPlansResponseQuery = actionPlansQuery
            .Select(x => new ActionPlan
            {
                Id = x.Id,
                ActionTitle = x.ActionTitle,
                ActionSummary = x.ActionSummary,
                BusinessAreaID = x.BusinessAreaID,
                ObservationID = x.ObservationID,
                Assignee = x.Assignee,
                Deadline = x.Deadline,
                CreationUser = x.CreationUser,
                CreationDate = x.CreationDate,
                ModifiedUser = x.ModifiedUser,
                ModifiedDate = x.ModifiedDate,
                ActionStatus = x.ActionStatus,
                ClosureDate = x.ClosureDate,
                ClosureUser = x.ClosureUser,
                TaxonomyLevel3ID = x.TaxonomyLevel3ID,
                ActionComment1LoD = x.ActionComment1LoD,
                ActionComment1LoDDate = x.ActionComment1LoDDate,
                ActionComment1LODUser = x.ActionComment1LODUser,
                ActivityOwner = x.ActivityOwner
            });

        var actionPlans = await PagedList<ActionPlan>.CreateAsync(
            actionPlansResponseQuery,
            searchOptions.Page,
            searchOptions.PageSize);

        return actionPlans;
    }
}