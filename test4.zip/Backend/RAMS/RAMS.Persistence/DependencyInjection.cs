﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RAMS.Application.ActionPlanApp;
using RAMS.Application.AttachmentApp;
using RAMS.Application.AuditApp;
using RAMS.Application.AuthorisationApp;
using RAMS.Application.BusinessAreaApp;
using RAMS.Application.BusinessUnitApp;
using RAMS.Application.CategoryApp;
using RAMS.Application.Contracts;
using RAMS.Application.CountryApp;
using RAMS.Application.FieldHelpTextApp;
using RAMS.Application.GradeApp;
using RAMS.Application.LegalEntityApp;
using RAMS.Application.NewsApp;
using RAMS.Application.ObservationApp;
using RAMS.Application.ObservationBusinessAreaCountryApp;
using RAMS.Application.RAGStatusApp;
using RAMS.Application.RegulationApp;
using RAMS.Application.RegulatoryCategoryApp;
using RAMS.Application.StatusApp;
using RAMS.Application.StatusRequestApp;
using RAMS.Application.TaxonomyApp;
using RAMS.Application.TaxonomyLevelApp;
using RAMS.Persistence.ActionPlanPersistence;
using RAMS.Persistence.AttachmentPersistence;
using RAMS.Persistence.AuditPersistence;
using RAMS.Persistence.AuthorisationPersistence;
using RAMS.Persistence.BusinessAreaPersistence;
using RAMS.Persistence.BusinessUnitPersistence;
using RAMS.Persistence.CategoryPersistence;
using RAMS.Persistence.Common;
using RAMS.Persistence.Common.Interceptors;
using RAMS.Persistence.CountryPersistence;
using RAMS.Persistence.FieldHelpTextPersistence;
using RAMS.Persistence.GradePersistence;
using RAMS.Persistence.LegalEntityPersistence;
using RAMS.Persistence.NewsPersistence;
using RAMS.Persistence.ObservationBusinessAreaCountryPersistence;
using RAMS.Persistence.ObservationPersistence;
using RAMS.Persistence.RAGStatusPersistence;
using RAMS.Persistence.RegulationPersistence;
using RAMS.Persistence.RegulatoryCategoryPersistence;
using RAMS.Persistence.StatusPersistence;
using RAMS.Persistence.StatusRequestPersistence;
using RAMS.Persistence.TaxonomyLevelPersistence;
using RAMS.Persistence.TaxonomyPersistence;

namespace RAMS.Persistence;

public static class DependencyInjection
{
    public static IServiceCollection AddPersistence(
        this IServiceCollection services, IConfiguration configuration)
    {
        string? connection = configuration.GetConnectionString(DatabaseConnectionScheme.SectionName);

        if (connection is null)
        {
            return services;
        }

        services.AddDbContext<RiskManagementDbContext>((sp,options) =>
        {
            UpdateAuditableEntitiesInterceptor? auditableInterceptor = sp.GetService<UpdateAuditableEntitiesInterceptor>();

            if (auditableInterceptor is null)
            {
                return;
            }

            options.UseSqlServer(connection).AddInterceptors(auditableInterceptor);

        });

        AddDependencies(services);

        return services;
    }

    private static void AddDependencies(IServiceCollection services)
    {
        services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
        services.AddScoped<IUnitOfWork, UnitOfWork>();
        services.AddScoped<IObservationRepository, ObservationRepository>();
        services.AddScoped<IObservationBusinessAreaCountryRepository, ObservationBusinessAreaCountryRepository>();
        services.AddScoped<IBusinessUnitRepository, BusinessUnitRepository>();
        services.AddScoped<IBusinessAreaRepository, BusinessAreaRepository>();
        services.AddScoped<ILegalEntityRepository, LegalEntityRepository>();
        services.AddScoped<ITaxonomyRepository, TaxonomyRepository>();
        services.AddScoped<ITaxonomyLevelRepository, TaxonomyLevelRepository>();
        services.AddScoped<IStatusRepository, StatusRepository>();
        services.AddScoped<IRAGStatusRepository, RAGStatusRepository>();
        services.AddScoped<IRegulationRepository, RegulationRepository>();
        services.AddScoped<ICountryRepository, CountryRepository>();
        services.AddScoped<IGradeRepository, GradeRepository>();
        services.AddScoped<IStatusRequestRepository, StatusRequestRepository>();
        services.AddScoped<IRegulatoryCategoryRepository, RegulatoryCategoryRepository>();
        services.AddScoped<INewsRepository, NewsRepository>();
        services.AddScoped<ICategoryRepository, CategoryRepository>();
        services.AddScoped<IActionPlanRepository, ActionPlanRepository>();
        services.AddScoped<IAuthorisationRepository, AuthorisationRepository>();
        services.AddScoped<IAttachmentRepository, AttachmentRepository>();
        services.AddScoped<IFieldHelpTextRepository, FieldHelpTextRepository>();
        services.AddScoped<IAuditRepository, AuditRepository>();

        services.AddScoped<UpdateAuditableEntitiesInterceptor>();
    }
}