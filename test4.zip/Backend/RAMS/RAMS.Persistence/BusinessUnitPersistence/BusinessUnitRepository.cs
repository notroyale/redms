﻿using Microsoft.EntityFrameworkCore;
using RAMS.Application.BusinessUnitApp;
using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.BusinessUnitPersistence;

internal class BusinessUnitRepository : Repository<BusinessUnit>, IBusinessUnitRepository
{
    private readonly RiskManagementDbContext _context;

    public BusinessUnitRepository(RiskManagementDbContext context) : base(context)
    {
        _context = context;
    }

    public async Task<IEnumerable<BusinessUnit>> GetAllSortedByNameAsync()
    {
        return await _context.BusinessUnits
            .OrderByDescending(x => x.IsActive==true ).ThenBy(x => x.Name)
            .ToListAsync();
    }

    public async Task<PagedList<BusinessUnit>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        IQueryable<BusinessUnit> observationsQuery = _context.BusinessUnits;

        var observationsResponseQuery = observationsQuery
            .Select(x => new BusinessUnit
            {
                Id = x.Id,
                Code = x.Code,
                Name = x.Name,
                IsActive = x.IsActive,
            });

        var businessUnits = await PagedList<BusinessUnit>.CreateAsync(
            observationsResponseQuery,
            searchOptions.Page,
            searchOptions.PageSize);

        return businessUnits;
    }
}