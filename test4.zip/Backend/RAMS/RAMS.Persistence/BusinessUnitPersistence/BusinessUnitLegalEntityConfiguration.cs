﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.BusinessUnitPersistence;

internal class BusinessUnitLegalEntityConfiguration : IEntityTypeConfiguration<BusinessUnitLegalEntity>
{
    public void Configure(EntityTypeBuilder<BusinessUnitLegalEntity> builder)
    {
        builder
            .ToTable(TablesNames.BusinessUnitLegalEntity);

        builder
            .HasKey(x => new { x.BusinessUnitID, x.LegalEntityID });

        //builder
        //    .HasMany(x => x.Observations)
        //    .WithOne(x => x.BusinessUnit)
        //    .HasForeignKey(x => x.BusinessUnitId);

    }
}