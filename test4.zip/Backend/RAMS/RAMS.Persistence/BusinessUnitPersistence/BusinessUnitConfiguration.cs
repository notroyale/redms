﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.BusinessUnitPersistence;

internal class BusinessUnitConfiguration : IEntityTypeConfiguration<BusinessUnit>
{
    public void Configure(EntityTypeBuilder<BusinessUnit> builder)
    {
        builder
            .ToTable(TablesNames.BusinessUnits);

        builder
            .HasKey(x => x.Id);

        builder
            .HasMany(x => x.Observations)
            .WithOne(x => x.BusinessUnit)
            .HasForeignKey(x => x.BusinessUnitId);

        builder
            .HasMany(x => x.BusinessAreas)
            .WithOne(x => x.BusinessUnit)
            .HasForeignKey(x => x.BusinessUnitID);

        builder
            .HasMany(x => x.LegalEntities)
            .WithMany(x => x.BusinessUnits)
            .UsingEntity<BusinessUnitLegalEntity>();
    }
}