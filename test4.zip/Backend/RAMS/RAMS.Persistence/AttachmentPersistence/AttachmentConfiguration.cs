﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.AttachmentPersistence;

internal class AttachmentConfiguration : IEntityTypeConfiguration<ObservationAttachment>
{
    public void Configure(EntityTypeBuilder<ObservationAttachment> builder)
    {
        builder
            .ToTable(TablesNames.ObservationFiles);

        builder.ToTable(tb => tb.HasTrigger("after_observation_file_update"));

        builder
            .HasKey(x => x.Id);
    }
}