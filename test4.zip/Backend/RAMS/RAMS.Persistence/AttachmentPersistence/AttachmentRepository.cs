﻿using RAMS.Application.AttachmentApp;
using RAMS.Application.RAGStatusApp;
using RAMS.Domain;
using RAMS.Persistence.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using ObservationAttachment = RAMS.Domain.ObservationAttachment;

namespace RAMS.Persistence.AttachmentPersistence
{
    internal class AttachmentRepository : Repository<ObservationAttachment>, IAttachmentRepository
    {
        private readonly RiskManagementDbContext _context;

        public AttachmentRepository(RiskManagementDbContext context) : base(context)
        {
            _context = context;
        }


    }
}
