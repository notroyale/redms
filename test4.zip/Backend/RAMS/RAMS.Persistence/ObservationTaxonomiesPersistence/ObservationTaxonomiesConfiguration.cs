﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Domain;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.ObservationTaxonomiesPersistence;

internal class ObservationTaxonomiesConfiguration : IEntityTypeConfiguration<ObservationTaxonomy>
{
    public void Configure(EntityTypeBuilder<ObservationTaxonomy> builder)
    {
        builder
            .ToTable(TablesNames.ObservationTaxonomies);

        builder.ToTable(tb => tb.HasTrigger("after_observation_taxonomy_delete"));
        builder.ToTable(tb => tb.HasTrigger("after_observation_taxonomy_insert"));

        builder
            .HasKey(x => new { x.ObservationID, x.TaxonomyID });
    }
}