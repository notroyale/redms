﻿using RAMS.Domain;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.ObservationPersistence;

internal class ObservationTaxonomiesRepository : Repository<ObservationTaxonomy>, IObservationTaxonomyRepository
{
    private readonly RiskManagementDbContext _context;

    public ObservationTaxonomiesRepository(RiskManagementDbContext context) : base(context)
    {
        _context = context;
    }
}