﻿using RAMS.Application.NewsApp;
using RAMS.Domain;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.NewsPersistence;

internal class NewsRepository : Repository<News>, INewsRepository
{
    private readonly RiskManagementDbContext _context;

    public NewsRepository(RiskManagementDbContext context) : base(context)
    {
        _context = context;
    }
}