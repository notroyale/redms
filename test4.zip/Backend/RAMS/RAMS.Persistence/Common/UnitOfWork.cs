﻿using RAMS.Application.Contracts;

namespace RAMS.Persistence.Common;

internal class UnitOfWork : IUnitOfWork
{
    private readonly RiskManagementDbContext _context;

    public UnitOfWork(RiskManagementDbContext context)
    {
        _context = context;
    }

    public bool Commit()
        => _context.SaveChanges() > 0;

    public async Task<bool> CommitAsync()
        => await _context.SaveChangesAsync() > 0;

    public void Rollback()
        => _context.Dispose();

    public async Task RollbackAsync()
        => await _context.DisposeAsync();
}