﻿namespace RAMS.Persistence.Common;

internal static class TablesNames
{
    public const string LegalEntities = "LegalEntity";
    public const string BusinessAreas = "BusinessArea";
    public const string BusinessUnits = "BusinessUnit";
    public const string Status = "ObservationStatus";
    public const string RegulatoryCategory = "RegulatoryCategory";
    public const string StatusRequest = "StatusRequest";
    public const string Regulation = "Regulation";
    public const string RAGStatus = "RAGStatus";
    public const string Country = "Country";
    public const string Grade = "Grades";
    public const string ActionPlan = "ObservationActions";
    public const string Category = "ObservationCategory";
    public const string BusinessUnitLegalEntity = "LegalEntityToBusinessUnit";
    public const string Taxonomies = "Taxonomies";
    public const string TaxonomiesLevels = "TaxonomyLevels";

    public const string TaxonomiesRelations = "TaxonomiesRelations";

    public const string ObservationTaxonomies = "ObservationTaxonomies";
    public const string Observations = "Observation";
    public const string ObservationLegalEntities = "ObservationLegalEntities";
    public const string ObservationBusinessAreas = "ObservationBusinessAreas";
    public const string ObservationRegulatoryCategory = "ObservationRegCategories";
    public const string ObservationRegulations = "ObservationRegulations";
    public const string ObservationSelfRaisedIssue = "ObservationSelfRaisedIssue";
    public const string ObservationBinaryFields = "ObservationBinaryFields";
    
    public const string ObservationAffectedBusinessUnits ="ObservatioNAffectedBusinessUnits";
    public const string ObservationAffectedBusinessAreas ="ObservatioNAffectedBusinessAreas";
    public const string ObservationAffectedLegalEntities ="ObservatioNAffectedLegalEntities";
    public const string ObservationAffectedCountries = "ObservatioNAffectedCountries";
    public const string ObservationRagStatus = "ObservationRagStatus";
    public const string ObservationGrade = "ObservationGrade";

    public const string News = "News";
    public const string AuditLog = "Observation_Changes_Log";
    public const string Authorisations = "Authorisations";
    public const string ObservationFiles = "ObservationFiles";
    public const string FieldHelpText = "FieldHelpText";

    public const string AuthorisationBusinessUnits = "AuthorisationBusinessUnits";
    public const string AuthorisationLegalEntities = "AuthorisationLegalEntities";
    public const string AuthorisationAccessPermissions = "AuthorisationAccessPermissions";

    public static string AuthorisationRoles = "AuthorisationRoles";
    public static string Roles = "Roles";
}