﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using RAMS.Domain;
using RAMS.Persistence.ActionPlanPersistence;
using RAMS.Persistence.AttachmentPersistence;
using RAMS.Persistence.AuthorisationPersistence;
using RAMS.Persistence.BusinessUnitPersistence;
using RAMS.Persistence.CategoryPersistence;
using RAMS.Persistence.CountryPersistence;
using RAMS.Persistence.FieldHelpTextPersistence;
using RAMS.Persistence.GradePersistence;
using RAMS.Persistence.ObservationBusinessAreaCountryPersistence;
using RAMS.Persistence.ObservationPersistence;
using RAMS.Persistence.ObservationTaxonomiesPersistence;
using RAMS.Persistence.RAGStatusPersistence;
using RAMS.Persistence.RegulationPersistence;
using RAMS.Persistence.RegulatoryCategoryPersistence;
using RAMS.Persistence.StatusPersistence;
using RAMS.Persistence.StatusRequestPersistence;
using RAMS.Persistence.TaxonomyLevelPersistence;
using System.Net.Mail;
using ObservationAttachment = RAMS.Domain.ObservationAttachment;

namespace RAMS.Persistence.Common;

internal class RiskManagementDbContext : DbContext
{
    public DbSet<BusinessUnit> BusinessUnits => Set<BusinessUnit>();
    public DbSet<BusinessArea> BusinessAreas => Set<BusinessArea>();
    public DbSet<LegalEntity> LegalEntities => Set<LegalEntity>();
    public DbSet<ObservationBusinessArea> ObservationBusinessAreas => Set<ObservationBusinessArea>();
    public DbSet<ObservationLegalEntity> ObservationLegalEntities => Set<ObservationLegalEntity>();
    public DbSet<ObservationTaxonomy> ObservationTaxonomies => Set<ObservationTaxonomy>();
    public DbSet<BusinessUnitLegalEntity> BusinessUnitLegalEntity => Set<BusinessUnitLegalEntity>();
    public DbSet<Taxonomy> Taxonomies => Set<Taxonomy>();
    public DbSet<TaxonomyRelation> TaxonomiesRelations => Set<TaxonomyRelation>();
    public DbSet<TaxonomyLevel> TaxonomyLevel => Set<TaxonomyLevel>();
    public DbSet<Status> Status => Set<Status>();
    public DbSet<RAGStatus> RAGStatus => Set<RAGStatus>();
    public DbSet<Regulation> Regulation => Set<Regulation>();
    public DbSet<Country> Country => Set<Country>();
    public DbSet<Grade> Grade => Set<Grade>();
    public DbSet<Category> Category => Set<Category>();
    public DbSet<StatusRequest> StatusRequest => Set<StatusRequest>();
    public DbSet<RegulatoryCategory> RegulatoryCategory => Set<RegulatoryCategory>();
    public DbSet<Observation> Observations => Set<Observation>();
    public DbSet<ActionPlan> ActionPlan => Set<ActionPlan>();
    public DbSet<News> News => Set<News>();
    public DbSet<Audit> AuditLog => Set<Audit>();
    public DbSet<Authorisation> Authorisations => Set<Authorisation>();
    public DbSet<AuthorisationAccessPermission> AuthorizationAccessPermissions => Set<AuthorisationAccessPermission>();
    public DbSet<AuthorisationBusinessUnit> AuthorisationBusinessUnits => Set<AuthorisationBusinessUnit>();
    public DbSet<AuthorisationLegalEntity> AuthorisationLegalEntities => Set<AuthorisationLegalEntity>();
    public DbSet<ObservationAffectedBusinessUnits> AuthorisationAffectedBusinessUnits => Set<ObservationAffectedBusinessUnits>();

    public DbSet<ObservationAttachment> ObservationFiles => Set<ObservationAttachment>();
    public DbSet<FieldHelpText> FieldHelpText => Set<FieldHelpText>();


    public RiskManagementDbContext(DbContextOptions<RiskManagementDbContext> options)
        : base(options)
    {}

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfiguration(new ObservationConfiguration());
        modelBuilder.ApplyConfiguration(new BusinessAreaConfiguration());
        modelBuilder.ApplyConfiguration(new LegalEntityConfiguration());
        modelBuilder.ApplyConfiguration(new BusinessUnitConfiguration());
        modelBuilder.ApplyConfiguration(new TaxonomyConfiguration());
        modelBuilder.ApplyConfiguration(new TaxonomyRelationConfiguration());
        modelBuilder.ApplyConfiguration(new TaxonomyLevelConfiguration());
        modelBuilder.ApplyConfiguration(new BusinessUnitLegalEntityConfiguration());
        modelBuilder.ApplyConfiguration(new StatusConfiguration());
        modelBuilder.ApplyConfiguration(new RAGStatusConfiguration());
        modelBuilder.ApplyConfiguration(new RegulationConfiguration());
        modelBuilder.ApplyConfiguration(new CountryConfiguration());
        modelBuilder.ApplyConfiguration(new GradeConfiguration());
        modelBuilder.ApplyConfiguration(new StatusRequestConfiguration());
        modelBuilder.ApplyConfiguration(new RegulatoryCategoryConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationLegalEntitiesConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationTaxonomiesConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationBusinessAreasConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationRegulationsConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationRegCategoriesConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationRagStatusConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationSelfRaisedIssueConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationBinaryFieldsConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationGradeConfiguration());
        modelBuilder.ApplyConfiguration(new CategoryConfiguration());
        modelBuilder.ApplyConfiguration(new ActionPlanConfiguration());
        modelBuilder.ApplyConfiguration(new AuditConfiguration());
        modelBuilder.ApplyConfiguration(new AuthorisationConfiguration());
        modelBuilder.ApplyConfiguration(new AuthorisationAccessPermissionsConfiguration());
        modelBuilder.ApplyConfiguration(new AuthorisationBusinessUnitConfiguration());
        modelBuilder.ApplyConfiguration(new AttachmentConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationAffectedBusinessUnitsConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationAffectedBusinessAreasConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationAffectedCountriesConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationAffectedLegalEntitiesConfiguration());
        modelBuilder.ApplyConfiguration(new ObservationFilesConfiguration());
        modelBuilder.ApplyConfiguration(new FieldHelpTextConfiguration());

    }


    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        int entriesAdded = 0;

        foreach (var entry in ChangeTracker.Entries())
        {
            if (entry.Entity is Observation observation &&
                entry.State == EntityState.Added)
            {
                if (observation.BusinessUnitId == 0)
                {
                    int defaultBusinessUnitId = await GetDefaultBusinessUnitId();

                    if (defaultBusinessUnitId == -1)
                        return -1;

                    observation.BusinessUnitId = defaultBusinessUnitId;
                }

                if (observation.CategoryId == 0)
                {
                    int defaultCategoryId = await GetDefaultCategoryId();

                    if (defaultCategoryId == -1)
                        return -1;

                    observation.CategoryId = defaultCategoryId;
                }

                if (observation.RAGStatusID == 0)
                {
                    int defaultRagStatusId = await GetDefaultRagStatusId();

                    if (defaultRagStatusId == -1)
                        return -1;

                    observation.RAGStatusID = defaultRagStatusId;
                }

                if (observation.StatusID == 0)
                {
                    int defaultStatusId = await GetDefaultStatusId();

                    if (defaultStatusId == -1)
                        return -1;

                    observation.StatusID = defaultStatusId;
                }

                //if (observation.ObservationGrade == null)
                //{
                //    int defaultGradeId = await GetDefaultGradeId();

                //    if (defaultGradeId == -1)
                //        return -1;

                //    observation.ObservationGrade = new ObservationGrade(defaultGradeId,observation.Id,"");

                //}

                break;
            }

            if (entry.Entity is ObservationRegulation observationRegulation &&
                entry.State == EntityState.Modified)
            {
                bool isValid = await GetDefaultRegulation(observationRegulation.RegulationID, observationRegulation.RegulationComment);

                if (!isValid)
                    return -1;
            }

            if (entry.Entity is ObservationBusinessArea observationBusinessArea &&
               entry.State == EntityState.Added)
            {
                entriesAdded = await base.SaveChangesAsync(cancellationToken);

                if (entriesAdded <= 0)
                    return -1;

                var ba = await BusinessAreas
                    .Select(x => new BusinessArea()
                    {
                        Id = x.Id,
                        Name = x.Name
                    })
                    .FirstOrDefaultAsync(ba => ba.Id == observationBusinessArea.BusinessAreaID);

                if (ba is null)
                {
                    return -1;
                }

                observationBusinessArea.UpdateBusinessArea(ba);

                var country = await Country
                    .Select(x => new Country()
                    {
                        Id = x.Id,
                        Name = x.Name
                    })
                    .FirstOrDefaultAsync(ba => ba.Id == observationBusinessArea.CountryID);

                if (country is null)
                {
                    return -1;
                }

                observationBusinessArea.UpdateCountry(country);
            }
        }

        if (entriesAdded > 0)
        {
            return entriesAdded;
        }

        return await base.SaveChangesAsync(cancellationToken);
    }

    private async Task<int> GetDefaultGradeId()
    {
        return await Grade
            .Select(b => b.Id)
            .FirstOrDefaultAsync(id => id == 1);
    }

    private async Task<int> GetDefaultBusinessUnitId()
    {
        return await BusinessUnits
            .Select(b => b.Id)
            .FirstOrDefaultAsync(id => id == 19);
    }

    private async Task<int> GetDefaultStatusId()
    {
        return await Status
            .Select(b => b.Id)
            .FirstOrDefaultAsync(id => id == 2);
    }

    private async Task<int> GetDefaultCategoryId()
    {
        return await Category
            .Select(c => c.Id)
            .FirstOrDefaultAsync(id => id == 12);
    }

    private async Task<int> GetDefaultRagStatusId()
    {
        return await RAGStatus
            .Select(rag => rag.Id)
            .FirstOrDefaultAsync(id => id == 5);
    }

    private async Task<bool> GetDefaultRegulation(int regulationId, string? regulationComment)
    {
        var regHasComment = await Regulation
            .Select(r => new Regulation()
            {
                Id = r.Id,
                HasComment = r.HasComment
            })
            .FirstOrDefaultAsync(x => x.HasComment && x.Id == regulationId);

        bool isRegulationWithComment = regHasComment is not null;
        bool hasComment = !string.IsNullOrEmpty(regulationComment);

        return (!(isRegulationWithComment && hasComment));
    }
}