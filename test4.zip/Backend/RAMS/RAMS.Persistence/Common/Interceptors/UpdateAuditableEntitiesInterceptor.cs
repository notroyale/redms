﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Diagnostics;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Persistence.Common.Interceptors;

public sealed class UpdateAuditableEntitiesInterceptor: SaveChangesInterceptor
{
    private readonly IDateTimeProvider _dateTimeProvider;

    public UpdateAuditableEntitiesInterceptor(IDateTimeProvider dateTimeProvider)
    {
        _dateTimeProvider = dateTimeProvider;
    }

    public override InterceptionResult<int> SavingChanges(DbContextEventData eventData, InterceptionResult<int> result)
    {
        var dbContext = eventData.Context;

        if (dbContext is null)
        {
            return base.SavingChanges(eventData, result);
        }

        var auditableEntries =  dbContext.ChangeTracker.Entries<IAuditableEntity>();
        IList<Audit> auditLogs = new List<Audit>();

        foreach (var auditableEntry in auditableEntries)
        {
            int id = auditableEntry.Property(a => a.Id).CurrentValue;
            if (auditableEntry.State == EntityState.Added)
            {
                CreateAuditLogs(auditLogs, auditableEntry, nameof(EntityState.Added), id);
                //auditableEntry.Property(a => a.ValidFrom).CurrentValue = _dateTimeProvider.UtcNow;
                continue;
            }

            if (auditableEntry.State == EntityState.Modified)
            {
                CreateAuditLogs(auditLogs, auditableEntry, nameof(EntityState.Modified), id);
                //auditableEntry.Property(a => a.ValidFrom).CurrentValue = _dateTimeProvider.UtcNow;

            }
            if (auditableEntry.State == EntityState.Deleted)
            {
                CreateAuditLogs(auditLogs, auditableEntry, nameof(EntityState.Deleted), id);
                //auditableEntry.Property(a => a.ValidFrom).CurrentValue = _dateTimeProvider.UtcNow;

            }
        }

        Console.WriteLine(dbContext.ChangeTracker.DebugView.LongView);

        dbContext.AddRange(auditLogs);

        return result; //base.SavingChanges(eventData, result);
    }

    private void CreateAuditLogs(IList<Audit> auditLogs, EntityEntry<IAuditableEntity> auditableEntry, string action, int id)
    {
        foreach (var property in auditableEntry.Properties)
        {
            if (property.IsModified)
            {
                auditLogs.Add(new Audit(id, "system", _dateTimeProvider.UtcNow, action, property.Metadata.Name, $"{property.OriginalValue}", $"{property.CurrentValue}"));
            }
        }
    }
}