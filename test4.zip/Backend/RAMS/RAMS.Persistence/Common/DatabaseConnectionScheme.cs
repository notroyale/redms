﻿namespace RAMS.Persistence.Common;

internal static class DatabaseConnectionScheme
{
    public const string SectionName = "RiskManagement";
}