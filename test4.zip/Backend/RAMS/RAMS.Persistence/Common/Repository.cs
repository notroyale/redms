﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using RAMS.Application.Contracts;

namespace RAMS.Persistence.Common;

internal class Repository<TEntity> : IRepository<TEntity> where TEntity : class
{
    private readonly RiskManagementDbContext _context;
    public readonly DbSet<TEntity> _dbSet;

    public Repository(RiskManagementDbContext context)
    {
        _context = context;
        _dbSet = context.Set<TEntity>();
    }

    public virtual async Task<TEntity?> GetAsync(Expression<Func<TEntity, bool>> expression)
        => await _dbSet.FirstOrDefaultAsync(expression);

    public virtual async Task<IEnumerable<TEntity>> GetAll()
        => await _dbSet.ToListAsync();

    public virtual async Task<IEnumerable<TEntity>> GetAll(Expression<Func<TEntity, bool>> expression)
        => await _dbSet.Where(expression).ToListAsync();

    public virtual void Insert(TEntity entity)
        => _context.Add(entity);

    public virtual void InsertRange(IEnumerable<TEntity> entities)
        => _context.AddRange(entities);

    public virtual void Delete(TEntity entityToDelete)
        => _context.Remove(entityToDelete);

    public virtual void Update(TEntity entityToUpdate)
        => _context.Attach(entityToUpdate);
}