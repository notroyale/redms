﻿using RAMS.Application.Common;
using RAMS.Application.CountryApp;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.CountryPersistence;

internal class CountryRepository : Repository<Country>, ICountryRepository
{
    private readonly RiskManagementDbContext _context;

    public CountryRepository(RiskManagementDbContext context) : base(context)
    {
        _context = context;
    }

    public async Task<PagedList<Country>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        IQueryable<Country> countriesQuery = _context.Country;

        var countriesResponseQuery = countriesQuery
            .Select(x => new Country
            {
                Id = x.Id,
                Name = x.Name,
                IsActive = x.IsActive
            });

        var countries = await PagedList<Country>.CreateAsync(
            countriesResponseQuery,
            searchOptions.Page,
            searchOptions.PageSize);

        return countries;
    }
}