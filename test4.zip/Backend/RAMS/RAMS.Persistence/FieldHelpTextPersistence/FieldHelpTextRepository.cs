﻿using RAMS.Application.Common;
using RAMS.Application.GradeApp;
using RAMS.Domain.Common;
using RAMS.Domain;
using RAMS.Persistence.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RAMS.Application.FieldHelpTextApp;
using Microsoft.EntityFrameworkCore;

namespace RAMS.Persistence.FieldHelpTextPersistence
{
    internal class FieldHelpTextRepository : Repository<FieldHelpText>, IFieldHelpTextRepository
    {
        private readonly RiskManagementDbContext _context;

        public FieldHelpTextRepository(RiskManagementDbContext context) : base(context)
        {
            _context = context;
        }


        public async Task<IEnumerable<FieldHelpText>> GetAllBaseAsync()
        {
            IQueryable<FieldHelpText> helpTextQuery = _context.FieldHelpText;

            var gradesResponseQuery = await helpTextQuery.ToListAsync();
            return gradesResponseQuery;
        }

    }
}
