﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Domain;
using RAMS.Persistence.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Persistence.FieldHelpTextPersistence
{
    internal class FieldHelpTextConfiguration : IEntityTypeConfiguration<FieldHelpText>
    {
        public void Configure(EntityTypeBuilder<FieldHelpText> builder)
        {
            builder
                .ToTable(TablesNames.FieldHelpText);

            builder
                .HasKey(x => x.Id);
        }
    }
}
