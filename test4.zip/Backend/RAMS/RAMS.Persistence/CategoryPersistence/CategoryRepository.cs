﻿using RAMS.Application.CategoryApp;
using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.CategoryPersistence;

internal class CategoryRepository : Repository<Category>, ICategoryRepository
{
    private readonly RiskManagementDbContext _context;

    public CategoryRepository(RiskManagementDbContext context) : base(context)
    {
        _context = context;
    }

    public async Task<PagedList<Category>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        IQueryable<Category> categoriesQuery = _context.Category;

        var categoriesResponseQuery = categoriesQuery
            .Select(x => new Category
            {
                Id = x.Id,
                Description = x.Description,
                IsActive = x.IsActive
            });

        var categories = await PagedList<Category>.CreateAsync(
            categoriesResponseQuery,
            searchOptions.Page,
            searchOptions.PageSize);

        return categories;
    }
}