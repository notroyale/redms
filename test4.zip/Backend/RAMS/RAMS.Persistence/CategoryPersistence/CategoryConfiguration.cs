﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.CategoryPersistence;

internal class CategoryConfiguration : IEntityTypeConfiguration<Category>
{
    public void Configure(EntityTypeBuilder<Category> builder)
    {
        builder
            .ToTable(TablesNames.Category);

        builder
            .HasKey(x => x.Id);
    }
}