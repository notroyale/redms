﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.BusinessUnitPersistence;

internal class LegalEntityConfiguration : IEntityTypeConfiguration<LegalEntity>
{
    public void Configure(EntityTypeBuilder<LegalEntity> builder)
    {
        builder
            .ToTable(TablesNames.LegalEntities);

        builder
            .HasKey(x => x.Id);

        /*builder
            .HasMany(x => x.Observations)
            .WithMany(x => x.LegalEntities)
            .UsingEntity<ObservationLegalEntity>();*/

        builder
            .HasMany(x => x.BusinessUnits)
            .WithMany(x => x.LegalEntities)
            .UsingEntity<BusinessUnitLegalEntity>();
    }
}