﻿using Microsoft.EntityFrameworkCore;
using RAMS.Application.Common;
using RAMS.Application.LegalEntityApp;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.LegalEntityPersistence;

internal class LegalEntityRepository : Repository<LegalEntity>, ILegalEntityRepository
{
    private readonly RiskManagementDbContext _context;

    public LegalEntityRepository(RiskManagementDbContext context) : base(context)
    {
        _context = context;
    }

    public async Task<IEnumerable<LegalEntity>> GetAllByBusinessUnitId(int[] ids)
    {
        return await _context.BusinessUnitLegalEntity
            .Where(ba => ids.Any(id => id == ba.BusinessUnitID))
            .Include(x => x.LegalEntity)
            .GroupBy(x => x.LegalEntity.Id)
            .Select(x => new LegalEntity()
            {
                Id  = x.First().LegalEntityID,
                Name = x.First().LegalEntity.Name,
                IsActive = x.First().LegalEntity.IsActive && x.First().IsActive
            })
            .OrderByDescending(x => x.IsActive == true).ThenBy(x => x.Name)
            .ToListAsync();
    }

    public async Task<IEnumerable<LegalEntity>> GetAllWithBusinessUnits()
    {
        return await _context.LegalEntities
            .Include(x => x.BusinessUnits)
            .ToListAsync();
    }

    public async Task<PagedList<LegalEntity>> GetAllWithOptions(SearchOptions searchOptions)
    {
        IQueryable<LegalEntity> legalEntitiesQuery = _context.LegalEntities;

        legalEntitiesQuery = legalEntitiesQuery
            .Include(x => x.BusinessUnits);

        var legalEntities = await PagedList<LegalEntity>.CreateAsync(
            legalEntitiesQuery,
            searchOptions.Page,
            searchOptions.PageSize);

        return legalEntities;
    }
}