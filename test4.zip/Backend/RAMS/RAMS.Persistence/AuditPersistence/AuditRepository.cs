﻿using Microsoft.EntityFrameworkCore;
using RAMS.Application.AuditApp;
using RAMS.Application.GradeApp;
using RAMS.Domain;
using RAMS.Persistence.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Persistence.AuditPersistence
{
    internal class AuditRepository : Repository<Audit>, IAuditRepository
    {
        private readonly RiskManagementDbContext _context;

        public AuditRepository(RiskManagementDbContext context) : base(context)
        {
            _context = context;

        }

        public async Task<IEnumerable<Audit>> GetAllLogsAsync(int observationID)
        {
            return await _context.AuditLog.Where(log => log.ObservationID == observationID)
                .ToListAsync();
        }
    }
}
