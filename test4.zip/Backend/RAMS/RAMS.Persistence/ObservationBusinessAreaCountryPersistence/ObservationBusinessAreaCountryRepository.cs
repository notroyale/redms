﻿using Microsoft.EntityFrameworkCore;
using RAMS.Application.ObservationBusinessAreaCountryApp;
using RAMS.Domain;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.ObservationBusinessAreaCountryPersistence;

internal class ObservationBusinessAreaCountryRepository : Repository<ObservationBusinessArea>, IObservationBusinessAreaCountryRepository
{
    private readonly RiskManagementDbContext _context;

    public ObservationBusinessAreaCountryRepository(RiskManagementDbContext context) : base(context)
    {
        _context = context;
    }


    public async Task<ObservationBusinessArea> GetBaCountry(int id)
    {
        return await _context.ObservationBusinessAreas
            .Where(ba => id == ba.ID).Include(b => b.BusinessArea).Include(c => c.Country)
            .FirstOrDefaultAsync();

    }

}