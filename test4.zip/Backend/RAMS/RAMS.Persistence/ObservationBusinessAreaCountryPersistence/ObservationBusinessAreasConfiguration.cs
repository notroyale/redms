﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Domain;
using RAMS.Persistence.Common;

namespace RAMS.Persistence.ObservationBusinessAreaCountryPersistence;

internal class ObservationBusinessAreasConfiguration : IEntityTypeConfiguration<ObservationBusinessArea>
{
    public void Configure(EntityTypeBuilder<ObservationBusinessArea> builder)
    {
        builder
            .ToTable(TablesNames.ObservationBusinessAreas);

        builder.ToTable(tb => tb.HasTrigger("after_observation_businessArea_delete"));
        builder.ToTable(tb => tb.HasTrigger("after_observation_businessArea_insert"));


        builder
            .HasKey(x => new { x.ObservationID, x.BusinessAreaID, x.CountryID });



        builder.Property(p => p.ID).UseIdentityColumn();    

    }
}