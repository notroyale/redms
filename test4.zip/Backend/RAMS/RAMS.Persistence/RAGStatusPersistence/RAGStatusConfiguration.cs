﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RAMS.Persistence.Common;
using RAMS.Domain;

namespace RAMS.Persistence.RAGStatusPersistence;

internal class RAGStatusConfiguration : IEntityTypeConfiguration<RAGStatus>
{
    public void Configure(EntityTypeBuilder<RAGStatus> builder)
    {
        builder
            .ToTable(TablesNames.RAGStatus);

        builder
            .HasKey(x => x.Id);
    }
}