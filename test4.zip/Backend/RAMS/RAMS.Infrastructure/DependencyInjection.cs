﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Application.UserApp;
using RAMS.Infrastructure.AuthInfrastructure.AuthorizationSetup;
using RAMS.Infrastructure.AuthInfrastructure.AuthorizationSetup.Policies;
using RAMS.Infrastructure.AuthInfrastructure.OptionsSetup;
using RAMS.Infrastructure.CachingInfrastructure;
using RAMS.Infrastructure.DateTimeInfrastructure;
using RAMS.Infrastructure.LdapInfrastructure;

namespace RAMS.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services)
    {
        services.AddSingleton<IDateTimeProvider, DateTimeProvider>();
        services.AddTransient<ICacheService, MemoryCacheService>();
        services.AddDistributedMemoryCache();

        AddPolicies(services);
        AddAuthentication(services);
        AddLdap(services);

        return services;
    }

    private static void AddPolicies(IServiceCollection services)
    {
        services.ConfigureOptions<PolicyOptionsSetup>();
        services.ConfigureOptions<AuthorisationOptionsSetup>();
        services.AddOptions<AuthorizationOptions>();

        services.AddScoped<IAuthorizationHandler, IsAllowedToAccessHandler>();
    }

    private static void AddLdap(IServiceCollection services)
    {
        services.ConfigureOptions<LdapOptionsSetup>();
        services.ConfigureOptions<LdapAtributeMappingOptionsSetup>();
        //services.AddTransient<ILdapService, LdapService>(); library was not working in syst
        services.AddTransient<ILdapService, LdapNovellService>();
    }

    private static void AddAuthentication(IServiceCollection services)
    {
        services.ConfigureOptions<AuthenticationOptionsSetup>();
        services.ConfigureOptions<OpenIdConnectOptionsSetup>();
        services.ConfigureOptions<JwtConnectOptionsSetup>();

        services.AddAuthentication(options =>
        {
            options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
        })
        .AddCookie(options =>
        {
            options.Cookie.HttpOnly = true;
            options.Cookie.SameSite = SameSiteMode.None;
            options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
            options.Events = new CookieAuthenticationEvents
            {
                OnValidatePrincipal = async context =>
                {
                    if (context.Properties.ExpiresUtc <= DateTime.UtcNow)
                    {
                        context.RejectPrincipal();
                        await context.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                    }
                },
                OnRedirectToAccessDenied = async context =>
                {
                    context.Response.Redirect("Authorization/AccessDenied");
                    await context.Response.CompleteAsync();
                }
            };
        })
        .AddJwtBearer()
        .AddOpenIdConnect();
    }
}