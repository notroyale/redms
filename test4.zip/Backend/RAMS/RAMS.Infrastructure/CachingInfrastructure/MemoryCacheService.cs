﻿using Microsoft.Extensions.Caching.Memory;
using RAMS.Application.Common;

namespace RAMS.Infrastructure.CachingInfrastructure;

public class MemoryCacheService : ICacheService
{
    private readonly IMemoryCache _memoryCache;

    public MemoryCacheService(IMemoryCache memoryCache)
    {
        _memoryCache = memoryCache;
    }

    public TEntity Get<TEntity>(string cacheKey)
    {
        return _memoryCache.Get<TEntity>(cacheKey);
    }

    public void Set<TEntity>(string cacheKey, TEntity entity, TimeSpan expiration)
    {
        _memoryCache.Set(cacheKey, entity, expiration);
    }
}
