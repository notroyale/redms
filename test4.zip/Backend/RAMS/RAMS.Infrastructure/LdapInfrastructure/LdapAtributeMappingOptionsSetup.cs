﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace RAMS.Infrastructure.LdapInfrastructure;

public class LdapAtributeMappingOptionsSetup : IConfigureOptions<LdapAttributeMappingOptions>
{
    private const string SectionName = "LDAPAtributeMapping";
    private readonly IConfiguration _configuration;

    public LdapAtributeMappingOptionsSetup(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public void Configure(LdapAttributeMappingOptions options)
    {
        _configuration.GetSection(SectionName).Bind(options);
    }
}