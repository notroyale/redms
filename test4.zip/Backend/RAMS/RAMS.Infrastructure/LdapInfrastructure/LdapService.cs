﻿//using Microsoft.Extensions.Options;
//using RAMS.Application.UserApp;
//using RAMS.Domain.User;
//using System.DirectoryServices.Protocols;
//using System.Net;

//namespace RAMS.Infrastructure.LdapInfrastructure;

//internal class LdapService : ILdapService
//{
//    //private LdapConnection _ldapConnection;
//    //private readonly LdapOptions _ldapOptions;
//    //private readonly LdapAttributeMappingOptions _ldapAttributeMapping;

//    //public LdapService(IOptions<LdapOptions> ldapOptions, IOptions<LdapAttributeMappingOptions> ldapAttributeMapping)
//    //{
//    //    _ldapOptions = ldapOptions.Value;
//    //    _ldapAttributeMapping = ldapAttributeMapping.Value;

//    //    Console.WriteLine("connecting to LDAP...");
//    //    Console.WriteLine(_ldapOptions.Domain);
        
//    //    try
//    //    {
//    //        _ldapConnection = new LdapConnection(
//    //          new LdapDirectoryIdentifier(_ldapOptions.Server, _ldapOptions.Port),
//    //          new NetworkCredential(_ldapOptions.Username, _ldapOptions.Password, _ldapOptions.Domain)
//    //        )
//    //        {
//    //            AuthType = AuthType.Basic,
//    //            Timeout = TimeSpan.FromMinutes(1),
//    //            SessionOptions =
//    //            {
//    //                ProtocolVersion = 3
//    //                //enable SecureSocketLayer when supported https://github.com/dotnet/runtime/issues/43890
//    //            }
//    //        };
//    //        _ldapConnection.SessionOptions.ProtocolVersion = 3;
//    //        _ldapConnection.SessionOptions.ReferralChasing = ReferralChasingOptions.None;

//    //        _ldapConnection.Bind();
//    //    }
//    //    catch (Exception e)
//    //    {
//    //        Console.WriteLine("Exception with LDAP!!");
//    //        Console.WriteLine(e.ToString());
//    //        throw e;
//    //    }
//    //}

//    //public LdapUser GetUserByBNumber(string bNumber)
//    //{
//        //try
//        //{
//        //    string filter = _ldapAttributeMapping.GetFilterCriterium(bNumber);
//        //    SearchRequest? searchRequest = new(_ldapOptions.SearchBase, filter, SearchScope.Subtree);
//        //    SearchResponse searchResponse = (SearchResponse) _ldapConnection.SendRequest(searchRequest);

//        //    if (searchResponse is null)
//        //        return new LdapUser();

//        //    foreach (SearchResultEntry entry in searchResponse.Entries)
//        //    {
//        //        return CreateUser(entry);
//        //    }

//        //    return new LdapUser();
//        //}
//        //catch (LdapException ex)
//        //{
//        //    //_logger.LogError($"LDAP search error: {ex.Message}");
//        //    throw;
//        //}
//        //catch (Exception ex)
//        //{
//        //    //_logger.LogError($"Unexpected error during LDAP search: {ex.Message}");
//        //    throw;
//        //}
//    //}

//    //private LdapUser CreateUser(SearchResultEntry entry)
//    //{
//    //    string cn = (string) entry.Attributes[_ldapAttributeMapping.Username][0];
//    //    string displayname = (string) entry.Attributes[_ldapAttributeMapping.DisplayName][0];
//    //    string mail = (string) entry.Attributes[_ldapAttributeMapping.Mail][0];
//    //    bool userenabled = bool.Parse((string) entry.Attributes[_ldapAttributeMapping.IsActive][0]);
//    //    //foreach (DictionaryEntry item in entry.Attributes)
//    //    //{
//    //    //    Console.WriteLine($"{item.Key} - {entry.Attributes[item.Key.ToString()][0]}");
//    //    //}
//    //    if (cn is null || displayname is null || mail is null)
//    //    {
//    //        return new LdapUser();
//    //    }

//    //    return new LdapUser(cn, displayname, mail, userenabled);
//    //}
//}