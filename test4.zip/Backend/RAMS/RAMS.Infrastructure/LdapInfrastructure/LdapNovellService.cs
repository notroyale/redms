﻿using Microsoft.Extensions.Options;
using Novell.Directory.Ldap;
using RAMS.Application.UserApp;
using RAMS.Domain.User;

namespace RAMS.Infrastructure.LdapInfrastructure;

internal class LdapNovellService : ILdapService
{
    private readonly LdapOptions _ldapOptions;
    private readonly LdapAttributeMappingOptions _ldapAttributeMapping;

    public LdapNovellService(IOptions<LdapOptions> ldapOptions, IOptions<LdapAttributeMappingOptions> ldapAttributeMapping)
    {
        _ldapOptions = ldapOptions.Value;
        _ldapAttributeMapping = ldapAttributeMapping.Value;
    }

    public LdapUser GetUserByBNumber(string bNumber)
    {
        try
        {
            LdapEntry? searchResponse;

            using (var ldapConnection = new LdapConnection())
            {
                ldapConnection.SecureSocketLayer = true;

                Console.WriteLine("Trying to connect to LDAP...");
                ldapConnection.Connect(_ldapOptions.Server, LdapConnection.DefaultSslPort);

                Console.WriteLine($"Connected. Trying to bind user...");
                ldapConnection.Bind($"{_ldapOptions.GetUserDomain()}", _ldapOptions.Password);

                Console.WriteLine($"looking for user...");

                string filter = _ldapAttributeMapping.GetFilterCriterium(bNumber);

                searchResponse = ldapConnection.Search(_ldapOptions.SearchBase, LdapConnection.ScopeSub, filter, _ldapAttributeMapping.GetAttrs(), false).SingleOrDefault();

            }

            if (searchResponse is null)
                return new LdapUser();

            Console.WriteLine($"Found user!!!");

            return CreateUser(searchResponse.GetAttributeSet());
        }
        catch (LdapException ex)
        {
            Console.WriteLine(($"LDAP search error: {ex.Message}"));
            throw;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Unexpected error during LDAP search: {ex.Message}");
            throw;
        }
    }

    private LdapUser CreateUser(LdapAttributeSet entry)
    {
        string bNumber = entry.GetAttribute(_ldapAttributeMapping.Username).StringValue;
        string displayname = entry.GetAttribute(_ldapAttributeMapping.DisplayName).StringValue;
        string departament = "NA";
        try
        {
            departament = entry.GetAttribute(_ldapAttributeMapping.Departament).StringValue;
        }
        catch (Exception) { }
        if (entry.Count<5 || (bNumber is null || displayname is null))
        {
            return new LdapUser(bNumber, displayname, true, departament);
        }

        //entry.FirstOrDefault(x => x.Key == "msRTCSIP-UserEnabled", new LdapAttribute { });
        bool userEnabled = bool.Parse(entry.GetAttribute(_ldapAttributeMapping.IsActive).StringValue);


        ////foreach (DictionaryEntry item in entry.Attributes)
        ////{
        ////    Console.WriteLine($"{item.Key} - {entry.Attributes[item.Key.ToString()][0]}");
        ////}

        return new LdapUser(bNumber, displayname, userEnabled, departament);
    }
}