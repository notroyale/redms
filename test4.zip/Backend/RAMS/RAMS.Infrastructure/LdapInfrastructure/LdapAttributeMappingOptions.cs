﻿namespace RAMS.Infrastructure.LdapInfrastructure;

public class LdapAttributeMappingOptions
{
    public string Username { get; init; }
    public string DisplayName { get; init; }
    public string Mail { get; init; }
    public string Departament { get; init; }
    public string IsActive { get; init; }
    public string Filter { get; init; }

    public string GetFilterCriterium(string criterium)
    {
        if (criterium is null)
        {
            return string.Empty;
        }

        const int UserStartIndex = 7;

        if(criterium.Length <= UserStartIndex)
        {
            return $"(&({Filter}={criterium}))";
        }

        return $"(&({Filter}={criterium[UserStartIndex..]}))";
    }

    public string[] GetAttrs()
    {
        return new string[] { DisplayName, Username, Mail, Departament, IsActive };
    }
}