﻿namespace RAMS.Infrastructure.LdapInfrastructure;

public class LdapOptions
{
    public string Server { get; init; }
    public int Port { get; init; }
    public string Domain { get; init; }
    public string Username { get; init; }
    public string Password { get; init; }
    public string SearchBase { get; init; }

    public string GetUserDomain()
    {
        return $"{Domain}\\{Username}";
    }
}