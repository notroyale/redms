﻿namespace RAMS.Infrastructure.AuthInfrastructure.OptionsSetup;

public class AuthenticationOptions
{
    public string Issuer { get; init; }
    public string ClientId { get; init; }
    public string Resource { get; init; }
    public string Audience { get; init; }
    public string ValidIssuer { get; init; }
    public string CallbackPath { get; init; }
}