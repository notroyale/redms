﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Options;

namespace RAMS.Infrastructure.AuthInfrastructure.OptionsSetup;

public class JwtConnectOptionsSetup : IPostConfigureOptions<JwtBearerOptions>
{
    private readonly AuthenticationOptions _authenticationOptions;

    public JwtConnectOptionsSetup(IOptions<AuthenticationOptions> openIdOptions)
    {
        _authenticationOptions = openIdOptions.Value;
    }

    public void PostConfigure(string? name, JwtBearerOptions options)
    {
        Console.WriteLine(name);

        options.Authority = _authenticationOptions.Issuer;
        options.SaveToken = true;
        options.RequireHttpsMetadata = false;
        options.TokenValidationParameters = new()
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = _authenticationOptions.ValidIssuer,
            ValidAudience = _authenticationOptions.Audience            

        };
    }
}