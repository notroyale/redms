﻿using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;

namespace RAMS.Infrastructure.AuthInfrastructure.OptionsSetup;

public class OpenIdConnectOptionsSetup : IPostConfigureOptions<OpenIdConnectOptions>
{
    private readonly AuthenticationOptions _authenticationOptions;

    public OpenIdConnectOptionsSetup(IOptions<AuthenticationOptions> openIdOptions)
    {
        _authenticationOptions = openIdOptions.Value;
    }

    public void PostConfigure(string? name, OpenIdConnectOptions options)
    {
        Console.WriteLine(name);

        options.Authority = _authenticationOptions.Issuer;
        options.Resource = _authenticationOptions.Resource;
        options.ClientId = _authenticationOptions.ClientId;
        options.CallbackPath = _authenticationOptions.CallbackPath;
        options.ResponseType = OpenIdConnectResponseType.IdToken;
        options.SaveTokens = true;
        options.UseTokenLifetime = true;
        options.NonceCookie.SecurePolicy = CookieSecurePolicy.Always;
        options.NonceCookie.SameSite = SameSiteMode.None;
        options.CorrelationCookie.SecurePolicy = CookieSecurePolicy.Always;
        options.CorrelationCookie.SameSite = SameSiteMode.None;
        options.RequireHttpsMetadata = false;
        options.TokenValidationParameters = new()
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = _authenticationOptions.ValidIssuer,
            ValidAudience = _authenticationOptions.ClientId
        };
    }
}