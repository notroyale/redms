﻿using Microsoft.AspNetCore.Authorization;

namespace RAMS.Infrastructure.AuthInfrastructure.AuthorizationSetup;

public sealed class HasPermissionAttribute : AuthorizeAttribute
{
    public HasPermissionAttribute(string policy) : base(policy)
    {
    }
}