﻿namespace RAMS.Infrastructure.AuthInfrastructure.AuthorizationSetup;

public static class Permission
{
    public const string AccessMember = "AccessMember";
}