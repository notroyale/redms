﻿namespace RAMS.Infrastructure.AuthInfrastructure.AuthorizationSetup;

public class PolicyOptions
{
    public string ADGroup { get; set; }
}