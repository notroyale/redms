﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using RAMS.Infrastructure.AuthInfrastructure.AuthorizationSetup.Policies;

namespace RAMS.Infrastructure.AuthInfrastructure.AuthorizationSetup;

public class AuthorisationOptionsSetup : IConfigureOptions<AuthorizationOptions>
{
    private readonly PolicyOptions _policyOptions;

    public AuthorisationOptionsSetup(IOptions<PolicyOptions> policyOptions)
    {
        _policyOptions = policyOptions.Value;
    }

    public void Configure(AuthorizationOptions options)
    {
        options.AddPolicy(Permission.AccessMember, policy =>
        {
            policy.Requirements.Add(new IsAllowedToAccessRequirement(_policyOptions.ADGroup));
        });
    }
}