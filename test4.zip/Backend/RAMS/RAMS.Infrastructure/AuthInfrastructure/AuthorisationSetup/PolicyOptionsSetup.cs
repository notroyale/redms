﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace RAMS.Infrastructure.AuthInfrastructure.AuthorizationSetup;

public class PolicyOptionsSetup : IConfigureOptions<PolicyOptions>
{
    private const string SectionName = "Policy";
    private readonly IConfiguration _configuration;

    public PolicyOptionsSetup(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public void Configure(PolicyOptions options)
    {
        _configuration.GetSection(SectionName).Bind(options);
    }
}