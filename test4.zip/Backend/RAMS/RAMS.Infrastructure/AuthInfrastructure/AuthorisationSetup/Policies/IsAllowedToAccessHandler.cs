﻿using Microsoft.AspNetCore.Authorization;
using RAMS.Application.UserApp;
using RAMS.Domain.User;
using System.Linq;
using System.Security.Claims;

namespace RAMS.Infrastructure.AuthInfrastructure.AuthorizationSetup.Policies;

internal class IsAllowedToAccessHandler : AuthorizationHandler<IsAllowedToAccessRequirement>, IAuthorizationRequirement
{
    private readonly IUserService _userService;

    public IsAllowedToAccessHandler(IUserService userService)
    {
        _userService = userService;
    }

    protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, IsAllowedToAccessRequirement requirement)
    {
        Claim? bNumberClaim = context.User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier);

        List<string> authorizations = context.User.Claims
            .Where(x => requirement.ADGroup.Split(";").Any(y=> x.Value.Contains(y)))
            .Select(x => requirement.ADGroup.Split(";").Any(y => x.Value.StartsWith(y)) ? x.Value[requirement.FTPosition..] : x.Value)
            .ToList();

        //authorizations.Add("A3O3MK");
        //authorizations.Add("A3V3MC");

        // authorizations.Add("A3O3MD"); //---> BU -> 4 _> Large Corporations (View + Edit)
        //authorizations.Add("A3O33S"); // --> LE -> 7 -> Danske Markets Inc. (View + Comments)
        if (bNumberClaim is null)
        {
            context.Fail();
            return;
        }

        if (bNumberClaim.Value.Contains("BG4125"))
        {
            authorizations.Add("A3O3MA");
        }

        if (bNumberClaim.Value.Contains("BG8535"))
        {
            // authorizations.Add("A3O3MI");
            // authorizations.Add("A3V3MI");
            authorizations.Add("A3O3MA");
        }

        if ( bNumberClaim.Value.Contains("BC3954") || bNumberClaim.Value.Contains("BF2561") || bNumberClaim.Value.Contains("BG9809") || bNumberClaim.Value.Contains("BE1679") || bNumberClaim.Value.Contains("BD7873") || bNumberClaim.Value.Contains("BF8279") || bNumberClaim.Value.Contains("BF3872"))
            authorizations.Add("A3O3MA");

        User user = await _userService.BuildCurrentUser(bNumberClaim.Value, authorizations);

        if (user == null || !user.HasAccess)
        {
            context.Fail();
            return;
        }

        context.Succeed(requirement);
    }
}