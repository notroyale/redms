﻿using Microsoft.AspNetCore.Authorization;

namespace RAMS.Infrastructure.AuthInfrastructure.AuthorizationSetup.Policies;

internal class IsAllowedToAccessRequirement : IAuthorizationRequirement
{
    public string ADGroup { get; init; }
    public int FTPosition { get; init; }

    public IsAllowedToAccessRequirement(string adGroup) 
    {     
        ADGroup = adGroup;
        FTPosition = 2;
    }
}