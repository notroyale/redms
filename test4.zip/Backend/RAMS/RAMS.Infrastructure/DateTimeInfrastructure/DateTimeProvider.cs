﻿using RAMS.Application.Contracts;

namespace RAMS.Infrastructure.DateTimeInfrastructure;

public class DateTimeProvider : IDateTimeProvider
{
    public DateTime UtcNow => DateTime.UtcNow;
}