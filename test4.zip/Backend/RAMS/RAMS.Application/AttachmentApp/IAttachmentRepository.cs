﻿using RAMS.Application.Contracts;
using RAMS.Domain;

namespace RAMS.Application.AttachmentApp
{
    public interface IAttachmentRepository : IRepository<ObservationAttachment>
    {
    }
}