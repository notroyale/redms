﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.Application.AttachmentApp
{
    public interface IAttachmentService : IService<ObservationAttachment>
    {
        Task<ObservationAttachment> DownloadAttachment(int attachmentID);
        Task<List<ObservationAttachment>> UploadAttachments(AttachmentMetadata metadata, List<IFormFile> files);
        Task<bool> DeleteAttachment(int attachmentID);
    }
}