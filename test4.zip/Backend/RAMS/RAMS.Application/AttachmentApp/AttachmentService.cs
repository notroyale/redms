﻿using Microsoft.AspNetCore.Http;
using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Application.UserApp;
using RAMS.Domain;


namespace RAMS.Application.AttachmentApp
{
    internal class AttachmentService : Service<ObservationAttachment>, IAttachmentService
    {
        private readonly IAttachmentRepository _attachmentRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUserService _userService;


        public AttachmentService(IAttachmentRepository repository, IUnitOfWork unitOfWork, IUserService userService) : base(repository, unitOfWork)
        {
            _attachmentRepository = repository;
            _unitOfWork = unitOfWork;
            _userService = userService;
        }

        public async Task<ObservationAttachment> DownloadAttachment(int attachmentID)
        {
            return await _attachmentRepository.GetAsync(attachment => attachment.Id == attachmentID);
        }
        public async Task<bool> DeleteAttachment(int attachmentID)
        {
            var file = _attachmentRepository.GetAsync(attachment => attachment.Id == attachmentID).Result;
            if (file != null)
            {
                file.ModifiedUser = _userService.GetCurrentUser().BNumber;
                file.ModifiedDate = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("Central Europe Standard Time"));
                _attachmentRepository.Delete(file);
                return await _unitOfWork.CommitAsync();
            }
            // place for error handling
            return false;
        }


        public async Task<List<ObservationAttachment>> UploadAttachments(AttachmentMetadata meta, List<IFormFile> files)
        {
            List<ObservationAttachment> attachments = new List<ObservationAttachment>();
            foreach (var file in files)
            {
                if (file != null && file.Length > 0)
                {

                    var fileBytes = new byte[file.Length];
                    using (var stream = file.OpenReadStream())
                    {
                        stream.Read(fileBytes, 0, (int)file.Length);
                    }

                    attachments.Add(new ObservationAttachment
                    {
                        Deleted = false,
                        Filename = file.FileName,
                        ObservationID = meta.ObservationID,
                        GDPR = meta.Gdpr,
                        UploadDate = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("Central Europe Standard Time")),
                        ModifiedUser = _userService.GetCurrentUser().BNumber,
                        ModifiedDate = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("Central Europe Standard Time")),
                        UploadUser = _userService.GetCurrentUser().BNumber,
                        Content = fileBytes,
                        RetentionPeriod = 10,
                        LoD = "2LoD" // change when frontend is ready
                    });
                }
            }
            _attachmentRepository.InsertRange(attachments);
            await _unitOfWork.CommitAsync();
            return attachments;
        }

    }
}
