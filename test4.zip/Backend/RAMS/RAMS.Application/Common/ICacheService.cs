﻿namespace RAMS.Application.Common;

public interface ICacheService
{
    TEntity Get<TEntity>(string cacheKey);
    void Set<TEntity>(string cacheKey, TEntity entity, TimeSpan expiration);
}