﻿using Messaging;
using RAMS.Application.Contracts;
using RAMS.Domain.Common;
using System.Linq.Expressions;

namespace RAMS.Application.Common;

internal class Service<TEntity> : IService<TEntity> where TEntity : class, Entity<TEntity>
{
    private readonly IRepository<TEntity> _repository;
    private readonly IUnitOfWork _unitOfWork;

    public Service(IRepository<TEntity> repository, IUnitOfWork unitOfWork)
    {
        _repository = repository;
        _unitOfWork = unitOfWork;
    }

    public virtual async Task<Result<TEntity>> GetAsync(Expression<Func<TEntity, bool>> expression)
    {
        var foundEntity = await _repository.GetAsync(expression);

        if (foundEntity is null)
            return ApplicationErrors.Common.NotFound;

        return foundEntity;
    }

    public virtual async Task<IEnumerable<TEntity>> GetAllAsync()
        => await _repository.GetAll();

    public virtual async Task<IEnumerable<TEntity>> GetAllAsync(Expression<Func<TEntity, bool>> expression)
        => await _repository.GetAll(expression);

    public virtual async Task<Result<TEntity>> Insert(TEntity entity)
    {
        _repository.Insert(entity);

        return await SaveChangesAsync(entity);
    }

    public virtual async Task<Result<TEntity>> Delete(Expression<Func<TEntity, bool>> expression)
    {
        var entity = await _repository.GetAsync(expression);

        if (entity is null)
            return ApplicationErrors.Common.NotFound;

        _repository.Delete(entity);

        return await SaveChangesAsync(entity);
    }

    public virtual async Task<Result<TEntity>> Update(Expression<Func<TEntity, bool>> expression, TEntity entityToUpdate)
    {
        var entity = await _repository.GetAsync(expression);

        if (entity is null)
            return ApplicationErrors.Common.NotFound;

        entity.Update(entityToUpdate);

        _repository.Update(entity);

        return await SaveChangesAsync(entity);
    }

    private async Task<Result<TEntity>> SaveChangesAsync(TEntity entity)
    {
        if (!await _unitOfWork.CommitAsync())
            return ApplicationErrors.Common.NotSaved;

        return entity;
    }
}