﻿using Microsoft.EntityFrameworkCore;
using RAMS.Domain;

namespace RAMS.Application.Common;

public class PagedList<T>
{
    public List<T> Items { get;  }
    public int Page { get;  }
    public int PageSize { get;  }
    public int TotalCount { get;  }
    public bool HasNextPage => Page * PageSize < TotalCount;
    public bool HasPreviousPage => Page > 1;

    private PagedList(List<T> items, int page, int pageSize, int totalCount)
    {
        Items = items;
        Page = page;
        PageSize = pageSize;
        TotalCount = totalCount;
    }

    public static async Task<PagedList<T>> CreateAsync(IQueryable<T> query, int page, int pageSize) 
    {
        var totalCount = await query.CountAsync();

        var items = await query
            .Skip((page - 1) * pageSize)
            .Take(pageSize == 0 ? totalCount : pageSize)
            .ToListAsync();

        return new(items, page, pageSize, totalCount);
    }
}

public class AuthorizedObservation
{
    public bool ViewAccess { get; set; }
    public bool EditAccess { get; set; }
    public bool CommentAccess { get; set; }
    public bool ApproverAccess { get; set; }
    public bool AdminAccess { get; set; }
    public Observation Observation { get; }

    public AuthorizedObservation(bool viewAccess, bool editAccess, bool commentAccess, bool approverAccess, bool adminAccess, Observation observation)
    {
        ViewAccess = viewAccess;
        EditAccess = editAccess;
        CommentAccess = commentAccess;
        ApproverAccess = approverAccess;
        AdminAccess = adminAccess;
        Observation = observation;
    }
}