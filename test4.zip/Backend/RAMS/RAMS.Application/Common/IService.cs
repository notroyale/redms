﻿using Messaging;
using RAMS.Domain.Common;
using System.Linq.Expressions;

namespace RAMS.Application.Common;

public interface IService<TEntity> where TEntity : class, Entity<TEntity>
{
    Task<Result<TEntity>> Delete(Expression<Func<TEntity, bool>> expression);
    Task<Result<TEntity>> GetAsync(Expression<Func<TEntity, bool>> expression);
    Task<IEnumerable<TEntity>> GetAllAsync();
    Task<IEnumerable<TEntity>> GetAllAsync(Expression<Func<TEntity, bool>> expression);
    Task<Result<TEntity>> Insert(TEntity entity);
    Task<Result<TEntity>> Update(Expression<Func<TEntity, bool>> expression, TEntity entityToUpdate);
}