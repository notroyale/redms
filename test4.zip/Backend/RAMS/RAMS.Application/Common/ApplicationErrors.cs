﻿using Messaging;

namespace RAMS.Application.Common;

public static class ApplicationErrors
{
    public static class Common
    {
        public static readonly Error NotFound = new("Common.NotFound", "Error! Entity not found.");
        public static readonly Error NotSaved = new("Common.Commit", "Error! Entity not saved.");
    }
    public static class Ldap
    {
        public static readonly Error UserNotFound = new("Ldap.UserNotFound", "Error! User not found.");
    }

    public static class BusinessUnit
    {
        public static readonly Error GetAllBusinessUnits = new("BusinessUnit.GetAllBusinessUnitsError", "Cannot get the BusinessUnits!");
        public static readonly Error GetBusinessUnit = new("BusinessUnit.GetBusinessUnitError", "Cannot get the BusinessUnit!");
        public static readonly Error CreateBusinessUnit = new("BusinessUnit.CreateError", "Cannot create the BusinessUnit!");
        public static readonly Error RemoveBusinessUnit = new("BusinessUnit.RemoveBusinessUnitError", "Cannot remove the BusinessUnit!");
        public static readonly Error UpdateBusinessUnit = new("BusinessUnit.UpdateBusinessUnitError", "Cannot update the BusinessUnit!");
    }

    public static class BusinessArea
    {
        public static readonly Error GetAllBusinessAreas = new("BusinessArea.GetAllBusinessUnitsError", "Cannot get the BusinessAreas!");
        public static readonly Error GetBusinessArea = new("BusinessArea.GetBusinessUnitError", "Cannot get the BusinessArea!");
        public static readonly Error CreateBusinessArea = new("BusinessArea.CreateBusinessAreaError", "Cannot create the BusinessArea!");
        public static readonly Error RemoveBusinessArea = new("BusinessArea.RemoveBusinessAreaError", "Cannot remove the BusinessArea!");
        public static readonly Error UpdateBusinessArea = new("BusinessArea.UpdateBusinessAreaError", "Cannot update the BusinessArea!");
    }

    public static class LegalEntity
    {
        public static readonly Error GetAllLegalEntitys = new("LegalEntity.GetAllLegalEntitysError", "Cannot get the LegalEntitys!");
        public static readonly Error GetLegalEntity = new("LegalEntity.GetBusinessUnitError", "Cannot get the LegalEntity!");
        public static readonly Error CreateLegalEntity = new("LegalEntity.CreateLegalEntityError", "Cannot create the LegalEntity!");
        public static readonly Error RemoveLegalEntity = new("LegalEntity.RemoveLegalEntityError", "Cannot remove the LegalEntity!");
        public static readonly Error UpdateLegalEntity = new("LegalEntity.UpdateLegalEntityError", "Cannot update the LegalEntity!");
    }
}