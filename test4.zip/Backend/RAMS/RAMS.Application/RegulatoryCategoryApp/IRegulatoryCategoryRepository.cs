﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.RegulatoryCategoryApp;

public interface IRegulatoryCategoryRepository : IRepository<RegulatoryCategory>
{
    Task<PagedList<RegulatoryCategory>> GetAllBaseAsync(SearchOptions searchOptions);
    Task<IEnumerable<RegulatoryCategory>> GetAllSortedByNameAsync();
    Task<IEnumerable<RegulatoryCategory>> GetAllByTaxonomyId(int[] ids);
}