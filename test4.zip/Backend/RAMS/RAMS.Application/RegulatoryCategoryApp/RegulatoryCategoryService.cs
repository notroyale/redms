﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.RegulatoryCategoryApp;

internal class RegulatoryCategoryService : Service<RegulatoryCategory>, IRegulatoryCategoryService
{
    private readonly IRegulatoryCategoryRepository _regulatoryCategoryRepository;

    public RegulatoryCategoryService(IRegulatoryCategoryRepository repository, IUnitOfWork unitOfWork) : base(repository, unitOfWork)
    {
        _regulatoryCategoryRepository = repository;
    }

    public async Task<PagedList<RegulatoryCategory>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        return await _regulatoryCategoryRepository.GetAllBaseAsync(searchOptions);
    }

    public async Task<IEnumerable<RegulatoryCategory>> GetAllSortedByNameAsync()
    {
        return await _regulatoryCategoryRepository.GetAllSortedByNameAsync();
    }

    public async Task<IEnumerable<RegulatoryCategory>> GetAllByTaxonomyId(int[] ids)
    {
        return await _regulatoryCategoryRepository.GetAllByTaxonomyId(ids);
    }
}