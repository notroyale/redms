﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;

namespace RAMS.Application.TaxonomyLevelApp;

public interface ITaxonomyLevelRepository : IRepository<TaxonomyLevel>
{
}