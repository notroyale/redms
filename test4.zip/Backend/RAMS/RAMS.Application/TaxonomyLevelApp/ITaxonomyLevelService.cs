﻿using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.Application.TaxonomyLevelApp;

public interface ITaxonomyLevelService : IService<TaxonomyLevel>
{
}