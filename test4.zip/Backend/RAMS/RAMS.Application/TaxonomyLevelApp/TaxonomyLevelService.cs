﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;

namespace RAMS.Application.TaxonomyLevelApp;

internal class TaxonomyLevelService : Service<TaxonomyLevel>, ITaxonomyLevelService
{
    private readonly ITaxonomyLevelRepository _taxonomyLevelRepository;

    public TaxonomyLevelService(ITaxonomyLevelRepository repository, IUnitOfWork unitOfWork) : base(repository, unitOfWork)
    {
        _taxonomyLevelRepository = repository;
    }
}