﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.CountryApp;

internal class CountryService : Service<Country>, ICountryService
{
    private readonly ICountryRepository _countryRepository;

    public CountryService(ICountryRepository repository, IUnitOfWork unitOfWork) : base(repository, unitOfWork)
    {
        _countryRepository = repository;
    }

    public async Task<PagedList<Country>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        return await _countryRepository.GetAllBaseAsync(searchOptions);
    }
}