﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.CountryApp;

public interface ICountryRepository : IRepository<Country>
{
    Task<PagedList<Country>> GetAllBaseAsync(SearchOptions searchOptions);
}