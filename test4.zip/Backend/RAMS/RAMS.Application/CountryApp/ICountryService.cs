﻿using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.CountryApp;

public interface ICountryService : IService<Country>
{
    Task<PagedList<Country>> GetAllBaseAsync(SearchOptions searchOptions);
}