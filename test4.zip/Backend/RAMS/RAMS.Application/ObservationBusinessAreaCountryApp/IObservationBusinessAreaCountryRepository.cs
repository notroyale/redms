﻿using RAMS.Application.Contracts;
using RAMS.Domain;

namespace RAMS.Application.ObservationBusinessAreaCountryApp;

public interface IObservationBusinessAreaCountryRepository : IRepository<ObservationBusinessArea>
{
    Task<ObservationBusinessArea> GetBaCountry(int id);
}