﻿using Messaging;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.Application.ObservationBusinessAreaCountryApp;

public interface IObservationBusinessAreaCountryService : IService<ObservationBusinessArea>
{
    Task<Result<ObservationBusinessArea>> AddAsync(ObservationBusinessArea observationBusinessArea);
    Task<Result<bool>> DeleteAsync(int id);

}