﻿using Messaging;
using RAMS.Application.AttachmentApp;
using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Application.UserApp;
using RAMS.Domain;
using RAMS.Domain.User;
using System.Net.Mail;

namespace RAMS.Application.ObservationBusinessAreaCountryApp;

internal class ObservationBusinessAreaCountryService : Service<ObservationBusinessArea>, IObservationBusinessAreaCountryService
{
    private readonly IObservationBusinessAreaCountryRepository _observationRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IUserService _userService;


    public ObservationBusinessAreaCountryService(IObservationBusinessAreaCountryRepository repository, IUnitOfWork unitOfWork, IUserService userService) : base(repository, unitOfWork)
    {
        _observationRepository = repository;
        _unitOfWork = unitOfWork;
        _userService = userService;
    }

    public async Task<Result<ObservationBusinessArea>> AddAsync(ObservationBusinessArea observationBusinessArea)
    {
        observationBusinessArea.ModifiedBy = _userService.GetCurrentUser().BNumber;

        _observationRepository.Insert(observationBusinessArea);

        if (!await _unitOfWork.CommitAsync())
        {
            return ApplicationErrors.Common.NotSaved; 
        }

        observationBusinessArea = await _observationRepository.GetBaCountry(observationBusinessArea.ID.Value);

        return observationBusinessArea;
    }

    public async Task<Result<bool>> DeleteAsync(int id)
    {
        _observationRepository.Delete(_observationRepository.GetBaCountry(id).Result);

        return await _unitOfWork.CommitAsync();
    }
}