﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;

namespace RAMS.Application.NewsApp;

internal class NewsService : Service<News>, INewsService
{
    private readonly INewsRepository _newsRepository;

    public NewsService(INewsRepository newsRepository, IUnitOfWork unitOfWork) : base(newsRepository, unitOfWork)
    {
        _newsRepository = newsRepository;
    }
}