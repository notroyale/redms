﻿using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.Application.NewsApp;

public interface INewsService : IService<News>
{
}