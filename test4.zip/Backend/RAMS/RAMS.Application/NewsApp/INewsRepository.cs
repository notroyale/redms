﻿using RAMS.Application.Contracts;
using RAMS.Domain;

namespace RAMS.Application.NewsApp;

public interface INewsRepository : IRepository<News>
{
}