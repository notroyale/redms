﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.StatusApp;

internal class StatusService : Service<Status>, IStatusService
{
    private readonly IStatusRepository _statusRepository;

    public StatusService(IStatusRepository repository, IUnitOfWork unitOfWork) : base(repository, unitOfWork)
    {
        _statusRepository = repository;
    }

    public async Task<PagedList<Status>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        return await _statusRepository.GetAllBaseAsync(searchOptions);
    }
}