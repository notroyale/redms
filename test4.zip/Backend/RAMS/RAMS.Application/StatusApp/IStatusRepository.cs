﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.StatusApp;

public interface IStatusRepository : IRepository<Status>
{
    Task<PagedList<Status>> GetAllBaseAsync(SearchOptions searchOptions);
}