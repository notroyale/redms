﻿using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.StatusApp;

public interface IStatusService : IService<Status>
{
    Task<PagedList<Status>> GetAllBaseAsync(SearchOptions searchOptions);
}