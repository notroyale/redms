﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.BusinessAreaApp;

internal class BusinessAreaService : Service<BusinessArea>, IBusinessAreaService
{
    private readonly IBusinessAreaRepository _businessAreaRepository;

    public BusinessAreaService(IBusinessAreaRepository businessAreaRepository, IUnitOfWork unitOfWork ) : base(businessAreaRepository, unitOfWork)
    {
        _businessAreaRepository = businessAreaRepository;
    }

    public async Task<IEnumerable<BusinessArea>> GetAllByBusinessUnitId(int[] ids)
    {
        return await _businessAreaRepository.GetAllByBusinessUnitId(ids);
    }

    public async Task<IEnumerable<BusinessArea>> GetAllWithBusinessUnits()
    {
        return await _businessAreaRepository.GetAllWithBusinessUnits();
    }

    public async Task<PagedList<BusinessArea>> GetAllWithOptions(SearchOptions searchOptions)
    {
        return await _businessAreaRepository.GetAllWithOptions(searchOptions);
    }
}