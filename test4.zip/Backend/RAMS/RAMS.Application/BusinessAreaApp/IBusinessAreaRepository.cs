﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.BusinessAreaApp;

public interface IBusinessAreaRepository : IRepository<BusinessArea>
{
    Task<IEnumerable<BusinessArea>> GetAllByBusinessUnitId(int[] ids);
    Task<IEnumerable<BusinessArea>> GetAllWithBusinessUnits();
    Task<PagedList<BusinessArea>> GetAllWithOptions(SearchOptions searchOptions);
}