﻿using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.BusinessAreaApp;

public interface IBusinessAreaService : IService<BusinessArea>
{
    Task<IEnumerable<BusinessArea>> GetAllWithBusinessUnits();
    Task<IEnumerable<BusinessArea>> GetAllByBusinessUnitId(int[] ids);
    Task<PagedList<BusinessArea>> GetAllWithOptions(SearchOptions searchOptions);
}