﻿using Messaging;
using RAMS.Application.ActionPlanApp;
using RAMS.Application.AttachmentApp;
using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Application.UserApp;
using RAMS.Domain;
using RAMS.Domain.Enumerators;
using System.ComponentModel;

namespace RAMS.Application.AuditApp;

internal class AuditService : Service<Audit>, IAuditService
{
    private readonly IAuditRepository _auditRepository;
    private readonly IUserService _userService;
    private readonly IDateTimeProvider _dateTimeProvider;
    private readonly IUnitOfWork _unitOfWork;

    public AuditService(IAuditRepository auditRepository, IUnitOfWork unitOfWork, IUserService userService, IDateTimeProvider dateTimeProvider) : base(auditRepository, unitOfWork)
    {
        _auditRepository = auditRepository;
        _unitOfWork = unitOfWork;
        _userService = userService;
        _dateTimeProvider = dateTimeProvider;
    }

    public async Task<Result<bool>> AddAuditLog(int observationID, AuditAction action)
    {
        var currentUser = _userService.GetCurrentUser();

        var currentDate = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("Central Europe Standard Time"));

        if (currentUser == null)
        {
            return ApplicationErrors.Ldap.UserNotFound;
        }

        Audit newAuditLog = new Audit(observationID, currentUser.BNumber, currentDate, action.ToString(), string.Empty, string.Empty, string.Empty);
        _auditRepository.Insert(newAuditLog);

        if (!await _unitOfWork.CommitAsync())
        {
            return ApplicationErrors.Common.NotSaved;
        }

        return true;

    }

    public async Task<Result<bool>> AddFileUploadAuditLog(int observationID, AuditAction action, List<ObservationAttachment> attachments)
    {
        var currentUser = _userService.GetCurrentUser();

        if (currentUser == null)
        {
            return ApplicationErrors.Ldap.UserNotFound;
        }

        if (attachments != null)
        {
            foreach (var item in attachments)
            {
                _auditRepository.Insert(new Audit(observationID, currentUser.BNumber, TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("Central Europe Standard Time")), action.ToString(), "Attachment", string.Empty, item.Filename));
            }
        }

        if (!await _unitOfWork.CommitAsync())
        {
            return ApplicationErrors.Common.NotSaved;
        }

        return true;

    }

    public async Task<Result<bool>> AddFileDownloadAuditLog(int observationID, AuditAction action, ObservationAttachment attachment)
    {
        var currentUser = _userService.GetCurrentUser();

        if (currentUser == null)
        {
            return ApplicationErrors.Ldap.UserNotFound;
        }
        if(attachment != null)
        {
            Audit newAuditLog = new Audit(observationID, currentUser.BNumber, TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("Central Europe Standard Time")), action.ToString(), "Attachment", string.Empty, attachment.Filename);
            _auditRepository.Insert(newAuditLog);

            if (!await _unitOfWork.CommitAsync())
            {
                return ApplicationErrors.Common.NotSaved;
            }
            return true;
        }
        return false;

    }

    public async Task<bool> AddRange(IEnumerable<Audit> auditLogs)
    {
        _auditRepository.InsertRange(auditLogs);
        return await _unitOfWork.CommitAsync();
    }
    public async Task<IEnumerable<Audit>> GetAll(int observationID)
    {
        return await _auditRepository.GetAllLogsAsync(observationID);
    }
}