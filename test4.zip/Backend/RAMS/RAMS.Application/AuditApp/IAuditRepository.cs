﻿using RAMS.Application.Contracts;
using RAMS.Domain;

namespace RAMS.Application.AuditApp;

public interface IAuditRepository : IRepository<Audit>
{
    Task<IEnumerable<Audit>> GetAllLogsAsync(int observationID);
}