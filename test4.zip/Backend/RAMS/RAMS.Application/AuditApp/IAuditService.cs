﻿using Messaging;
using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Enumerators;

namespace RAMS.Application.AuditApp;

public interface IAuditService : IService<Audit>
{
    Task<bool> AddRange(IEnumerable<Audit> auditLogs);
    Task<IEnumerable<Audit>> GetAll(int observationID);
    Task<Result<bool>> AddAuditLog(int observationID, AuditAction action);
    Task<Result<bool>> AddFileUploadAuditLog(int observationID, AuditAction action, List<ObservationAttachment> attachments);
    Task<Result<bool>> AddFileDownloadAuditLog(int observationID, AuditAction action, ObservationAttachment attachment);

}