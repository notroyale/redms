﻿using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.RegulationApp;

public interface IRegulationService : IService<Regulation>
{
    Task<PagedList<Regulation>> GetAllBaseAsync(SearchOptions searchOptions);
}