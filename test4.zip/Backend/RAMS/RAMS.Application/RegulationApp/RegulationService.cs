﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.RegulationApp;

internal class RegulationService : Service<Regulation>, IRegulationService
{
    private readonly IRegulationRepository _regulationRepository;

    public RegulationService(IRegulationRepository repository, IUnitOfWork unitOfWork) : base(repository, unitOfWork)
    {
        _regulationRepository = repository;
    }

    public async Task<PagedList<Regulation>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        return await _regulationRepository.GetAllBaseAsync(searchOptions);
    }
}