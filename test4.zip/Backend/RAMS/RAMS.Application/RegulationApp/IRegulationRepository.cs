﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.RegulationApp;

public interface IRegulationRepository : IRepository<Regulation>
{
    Task<PagedList<Regulation>> GetAllBaseAsync(SearchOptions searchOptions);
}