﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.StatusRequestApp;

public interface IStatusRequestRepository : IRepository<StatusRequest>
{
    Task<PagedList<StatusRequest>> GetAllBaseWithOptions(SearchOptions searchOptions);
}