﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.StatusRequestApp;

internal class StatusRequestService : Service<StatusRequest>, IStatusRequestService
{
    private readonly IStatusRequestRepository _statusRequestRepository;

    public StatusRequestService(IStatusRequestRepository repository, IUnitOfWork unitOfWork) : base(repository, unitOfWork)
    {
        _statusRequestRepository = repository;
    }

    public async Task<PagedList<StatusRequest>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        return await _statusRequestRepository.GetAllBaseWithOptions(searchOptions);
    }
}