﻿using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.StatusRequestApp;

public interface IStatusRequestService : IService<StatusRequest>
{
    Task<PagedList<StatusRequest>> GetAllBaseAsync(SearchOptions searchOptions);
}