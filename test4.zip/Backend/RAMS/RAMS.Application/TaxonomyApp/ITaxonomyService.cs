﻿using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;
using System.Linq.Expressions;

namespace RAMS.Application.TaxonomyApp;

public interface ITaxonomyService : IService<Taxonomy>
{
    Task<IEnumerable<Taxonomy>> GetAllWithRelations();
    Task<PagedList<TaxonomyRelation>> GetAllWithOptions(SearchOptions searchOptions);
    Task<PagedList<TaxonomyRelation>> GetChildrenByIds(int[] ids, string? sortColumn, string? sortOrder, int page, int pageSize);
    Task<Taxonomy?> GetWithRelations(Expression<Func<Taxonomy, bool>> expression);
    Task<IEnumerable<Taxonomy>> GetChildrenByIds(int[] ids);
}