﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;
using System.Linq.Expressions;

namespace RAMS.Application.TaxonomyApp;

internal class TaxonomyService : Service<Taxonomy>, ITaxonomyService
{
    private readonly ITaxonomyRepository _taxonomyRepository;

    public TaxonomyService(ITaxonomyRepository taxonomyRepository, IUnitOfWork unitOfWork) : base(taxonomyRepository, unitOfWork)
    {
        _taxonomyRepository = taxonomyRepository;
    }

    public async Task<IEnumerable<Taxonomy>> GetAllWithRelations()
    {
        return await _taxonomyRepository.GetAllWithRelations();
    }

    public async Task<Taxonomy?> GetWithRelations(Expression<Func<Taxonomy, bool>> expression)
    {
        return await _taxonomyRepository.GetWithRelations(expression);
    }

    public async Task<PagedList<TaxonomyRelation>> GetAllWithOptions(SearchOptions searchOptions)
    {
        return await _taxonomyRepository.GetAllWithOptions(searchOptions);
    }

    public async Task<PagedList<TaxonomyRelation>> GetChildrenByIds(int[] ids, string? sortColumn, string? sortOrder, int page, int pageSize)
    {
        return await _taxonomyRepository.GetChildrenByIds(ids, sortColumn, sortOrder, page, pageSize);
    }

    public async Task<IEnumerable<Taxonomy>> GetChildrenByIds(int[] ids)
    {
        return await _taxonomyRepository.GetChildrenByIds(ids);
    }
}