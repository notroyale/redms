﻿using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.LegalEntityApp;

public interface ILegalEntityService : IService<LegalEntity>
{
    Task<IEnumerable<LegalEntity>> GetAllByBusinessUnitId(int[] ids);
    Task<IEnumerable<LegalEntity>> GetAllWithBusinessUnits();
    Task<PagedList<LegalEntity>> GetAllWithOptions(SearchOptions searchOptions);
}