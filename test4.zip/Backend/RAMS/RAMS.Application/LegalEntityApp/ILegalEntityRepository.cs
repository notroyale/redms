﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.LegalEntityApp;

public interface ILegalEntityRepository : IRepository<LegalEntity>
{
    Task<IEnumerable<LegalEntity>> GetAllByBusinessUnitId(int[] ids);
    Task<IEnumerable<LegalEntity>> GetAllWithBusinessUnits();
    Task<PagedList<LegalEntity>> GetAllWithOptions(SearchOptions searchOptions);
}