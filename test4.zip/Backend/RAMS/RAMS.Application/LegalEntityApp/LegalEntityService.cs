﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.LegalEntityApp;

internal class LegalEntityService : Service<LegalEntity>, ILegalEntityService
{
    private readonly ILegalEntityRepository _legalEntityRepository;

    public LegalEntityService(ILegalEntityRepository legalEntityRepository, IUnitOfWork unitOfWork) : base(legalEntityRepository, unitOfWork)
    {
        _legalEntityRepository = legalEntityRepository;
    }

    public async Task<IEnumerable<LegalEntity>> GetAllByBusinessUnitId(int[] ids)
    {
        return await _legalEntityRepository.GetAllByBusinessUnitId(ids);
    }

    public async Task<IEnumerable<LegalEntity>> GetAllWithBusinessUnits()
    {
        return await _legalEntityRepository.GetAllWithBusinessUnits();
    }

    public async Task<PagedList<LegalEntity>> GetAllWithOptions(SearchOptions searchOptions)
    {
        return await _legalEntityRepository.GetAllWithOptions(searchOptions);
    }
}