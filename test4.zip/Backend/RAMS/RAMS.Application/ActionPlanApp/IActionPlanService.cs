﻿using Messaging;
using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Domain.Observations.Steps;

namespace RAMS.Application.ActionPlanApp;

public interface IActionPlanService : IService<ActionPlan>
{
    Task<PagedList<ActionPlan>> GetAllBaseAsync(SearchOptions searchOptions);
    Task<bool> UpdateActionPlan(int id, ActionPlan request);
    Task<bool> CloseActionPlan(int id);
    Task<Result<ActionPlan>> AddActionPlan(ActionPlan actionPlan);
}