﻿using Messaging;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.DependencyInjection;
using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Application.ObservationApp;
using RAMS.Application.UserApp;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Domain.Observations.Steps;

namespace RAMS.Application.ActionPlanApp;

internal class ActionPlanService : Service<ActionPlan>, IActionPlanService
{
    private readonly IActionPlanRepository _actionPlanRepository;
    private readonly IUserService _userService;
    private readonly IDateTimeProvider _dateTimeProvider;
    private readonly IUnitOfWork _unitOfWork;

    public ActionPlanService(IActionPlanRepository repository, IUnitOfWork unitOfWork, IUserService userService, IDateTimeProvider dateTimeProvider) : base(repository, unitOfWork)
    {
        _actionPlanRepository = repository;
        _unitOfWork = unitOfWork;
        _userService = userService;
        _dateTimeProvider = dateTimeProvider;
    }

    public async Task<PagedList<ActionPlan>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        return await _actionPlanRepository.GetAllBaseAsync(searchOptions);
    }
    public async Task<bool> UpdateActionPlan(int id, ActionPlan request)
    {
        var currentUser = _userService.GetCurrentUser();

        if (currentUser == null)
        {
            return false;
        }

        var existingAction = await _actionPlanRepository.GetFull(obs => obs.Id == id);

        if (existingAction is null)
        {
            return false;
        }

        _actionPlanRepository.Update(existingAction);

        existingAction.SetModifiedValues(currentUser.BNumber, _dateTimeProvider.UtcNow);
        existingAction.Update(request);

        return await _unitOfWork.CommitAsync();
    }
    
    public async Task<bool> CloseActionPlan(int id)
    {
        var currentUser = _userService.GetCurrentUser();

        if (currentUser == null)
        {
            return false;
        }

        var existingAction = await _actionPlanRepository.GetFull(obs => obs.Id == id);

        if (existingAction is null)
        {
            return false;
        }

        _actionPlanRepository.Update(existingAction);

        existingAction.CloseActionPlan(currentUser.BNumber, _dateTimeProvider.UtcNow);

        return await _unitOfWork.CommitAsync();
    }

    public async Task<Result<ActionPlan>> AddActionPlan(ActionPlan actionPlan)
    {
        var currentUser = _userService.GetCurrentUser();

        if (currentUser == null)
        {
            return ApplicationErrors.Ldap.UserNotFound;
        }

        actionPlan.SetCreationValues(currentUser.BNumber, _dateTimeProvider.UtcNow);
        _actionPlanRepository.Insert(actionPlan);

        if (!await _unitOfWork.CommitAsync())
        {
            return ApplicationErrors.Common.NotSaved;
        }


        return actionPlan;
    }

}