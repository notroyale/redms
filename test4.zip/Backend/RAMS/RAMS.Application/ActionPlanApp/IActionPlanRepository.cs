﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;
using System.Linq.Expressions;

namespace RAMS.Application.ActionPlanApp;

public interface IActionPlanRepository : IRepository<ActionPlan>
{
    Task<PagedList<ActionPlan>> GetAllBaseAsync(SearchOptions searchOptions);
    Task<ActionPlan?> GetFull(Expression<Func<ActionPlan, bool>> expression);
}