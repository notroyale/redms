﻿using RAMS.Domain.User;

namespace RAMS.Application.UserApp;

public interface ILdapService
{
    LdapUser GetUserByBNumber(string bNumber);
}