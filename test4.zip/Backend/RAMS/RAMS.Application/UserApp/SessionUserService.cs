﻿using Microsoft.AspNetCore.Http;
using RAMS.Domain.User;

namespace RAMS.Application.UserApp;

internal class SessionUserService : IUserService
{
    private const string SessionKeyUser = "_User";

    private readonly IUserService _userService;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public SessionUserService(IUserService userService, IHttpContextAccessor httpContextAccessor)
    {
        _userService = userService;
        _httpContextAccessor = httpContextAccessor;
    }

    public User FindUser(string bNumber)
    {
        return _userService.FindUser(bNumber);
    }

    public async Task<User> BuildCurrentUser(string bNumber, IEnumerable<string> authorizations)
    {
        HttpContext? context = _httpContextAccessor.HttpContext;

        if (context is null)
        {
            return new User();
        }

        ISession session = context.Session;

        User? foundUser;

        // Requires SessionExtensions.
        if (session.Get<User>(SessionKeyUser) == default)
        {
            foundUser = await _userService.BuildCurrentUser(bNumber, authorizations);
            session.Set(SessionKeyUser, foundUser);
        }

        foundUser = session.Get<User>(SessionKeyUser);

        if (foundUser is null)
        {
            return new User();
        }

        return foundUser;
    }

    public User GetCurrentUser()
    {
        HttpContext? context = _httpContextAccessor.HttpContext;

        if (context is null)
        {
            return new User();
        }

        ISession session = context.Session;
        User? foundUser = session.Get<User>(SessionKeyUser);

        if (foundUser is null)
        {
            return new User();
        }

        return foundUser;
    }
}