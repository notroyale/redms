﻿using RAMS.Application.AuthorisationApp;
using RAMS.Domain;
using RAMS.Domain.User;

namespace RAMS.Application.UserApp;

public class UserService : IUserService
{
    private readonly ILdapService _ldapService;
    private readonly IAuthorisationService _authorisationService;

    public UserService(ILdapService ldapService, IAuthorisationService authorisationService)
    {
        _ldapService = ldapService;
        _authorisationService = authorisationService;
    }

    public User FindUser(string bNumber)
    {
        LdapUser ldapUser = _ldapService.GetUserByBNumber(bNumber);

        if (ldapUser is null)
        {
            return new User();
        }

        return new User(ldapUser.BNumber, ldapUser.Name, ldapUser.Email, ldapUser.Departament, ldapUser.IsActive);
    }

    public async Task<User> BuildCurrentUser(string bNumber, IEnumerable<string> authorizations)
    {
        LdapUser ldapUser = _ldapService.GetUserByBNumber(bNumber);

        if (ldapUser is null)
        {
            return new User();
        }

        IEnumerable<Authorisation> authorisationPermissions = await _authorisationService.FindAllByShortName(authorizations);

        if (authorisationPermissions is null || !authorisationPermissions.Any())
        {
            return new User();
        }

        authorisationPermissions =
            authorisationPermissions.Where(x => authorizations.Any(y => x.ShortName.Equals(y)));

        return new(ldapUser.BNumber, ldapUser.Name, ldapUser.Email, ldapUser.IsActive, AccessControl.Build(authorisationPermissions));
    }

    public User GetCurrentUser()
    {
        return new User();
    }
}