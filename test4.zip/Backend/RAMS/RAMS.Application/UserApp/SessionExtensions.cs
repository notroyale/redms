﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace RAMS.Application.UserApp;

public static class SessionExtensions
{
    public static void Set<T>(this ISession session, string key, T value)
    {
        string serializedJson = JsonConvert.SerializeObject(value);

        session.SetString(key, serializedJson);
    }

    public static T? Get<T>(this ISession session, string key)
    {
        string? value = session.GetString(key);

        return value == null ? default : JsonConvert.DeserializeObject<T>(value);
    }
}