﻿using RAMS.Domain.User;

namespace RAMS.Application.UserApp;

public interface IUserService
{
    User FindUser(string bNumber);
    Task<User> BuildCurrentUser(string bNumber, IEnumerable<string> authorizations);
    User GetCurrentUser();

}