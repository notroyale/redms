﻿using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.BusinessUnitApp;

public interface IBusinessUnitService : IService<BusinessUnit>
{
    Task<IEnumerable<BusinessUnit>> GetAllSortedByNameAsync();
    Task<PagedList<BusinessUnit>> GetAllBaseAsync(SearchOptions searchOptions);
}