﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.BusinessUnitApp;

internal class BusinessUnitService : Service<BusinessUnit>, IBusinessUnitService
{
    private readonly IBusinessUnitRepository _businessUnitRepository;

    public BusinessUnitService(IBusinessUnitRepository repository, IUnitOfWork unitOfWork) : base(repository, unitOfWork)
    {
        _businessUnitRepository = repository;
    }

    public async Task<IEnumerable<BusinessUnit>> GetAllSortedByNameAsync()
    {
        return await _businessUnitRepository.GetAllSortedByNameAsync();
    }

    public async Task<PagedList<BusinessUnit>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        return await _businessUnitRepository.GetAllBaseAsync(searchOptions);
    }
}