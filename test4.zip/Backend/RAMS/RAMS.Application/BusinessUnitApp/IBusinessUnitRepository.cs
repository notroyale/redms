﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.BusinessUnitApp;

public interface IBusinessUnitRepository : IRepository<BusinessUnit>
{
    Task<IEnumerable<BusinessUnit>> GetAllSortedByNameAsync();
    Task<PagedList<BusinessUnit>> GetAllBaseAsync(SearchOptions searchOptions);
}