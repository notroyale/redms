﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain.Common;
using RAMS.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Application.FieldHelpTextApp
{
    public interface IFieldHelpTextRepository : IRepository<FieldHelpText>
    {
        Task<IEnumerable<FieldHelpText>> GetAllBaseAsync();
    }
}
