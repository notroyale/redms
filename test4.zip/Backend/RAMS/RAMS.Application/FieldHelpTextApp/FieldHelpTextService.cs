﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Application.CountryApp;
using RAMS.Domain.Common;
using RAMS.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Application.FieldHelpTextApp
{
    internal class FieldHelpTextService : Service<FieldHelpText>, IFieldHelpTextService
    {
        private readonly IFieldHelpTextRepository _fieldHelpTextRepository;

        public FieldHelpTextService(IFieldHelpTextRepository repository, IUnitOfWork unitOfWork) : base(repository, unitOfWork)
        {
            _fieldHelpTextRepository = repository;
        }

        public async Task<IEnumerable<FieldHelpText>> GetAllBaseAsync()
        {
            return await _fieldHelpTextRepository.GetAllBaseAsync();
        }
    }
}
