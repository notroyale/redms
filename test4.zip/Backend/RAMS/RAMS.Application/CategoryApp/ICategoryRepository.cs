﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.CategoryApp;

public interface ICategoryRepository : IRepository<Category>
{
    Task<PagedList<Category>> GetAllBaseAsync(SearchOptions searchOptions);
}