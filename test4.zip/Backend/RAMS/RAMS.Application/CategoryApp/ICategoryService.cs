﻿using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.CategoryApp;

public interface ICategoryService : IService<Category>
{
    Task<PagedList<Category>> GetAllBaseAsync(SearchOptions searchOptions);
}