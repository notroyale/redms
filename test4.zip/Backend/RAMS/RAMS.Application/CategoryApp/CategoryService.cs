﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.CategoryApp;

internal class CategoryService : Service<Category>, ICategoryService
{
    private readonly ICategoryRepository _categoryRepository;

    public CategoryService(ICategoryRepository repository, IUnitOfWork unitOfWork) : base(repository, unitOfWork)
    {
        _categoryRepository = repository;
    }

    public async Task<PagedList<Category>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        return await _categoryRepository.GetAllBaseAsync(searchOptions);
    }
}