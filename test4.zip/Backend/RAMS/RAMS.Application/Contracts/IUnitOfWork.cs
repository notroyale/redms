﻿namespace RAMS.Application.Contracts;

public interface IUnitOfWork
{
    bool Commit();
    void Rollback();
    Task<bool> CommitAsync();
    Task RollbackAsync();
}