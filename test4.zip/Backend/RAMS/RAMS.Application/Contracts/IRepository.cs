﻿using System.Linq.Expressions;

namespace RAMS.Application.Contracts;

public interface IRepository<TEntity> where TEntity : class
{
    void Delete(TEntity entityToDelete);
    Task<TEntity?> GetAsync(Expression<Func<TEntity, bool>> expression);
    Task<IEnumerable<TEntity>> GetAll();
    Task<IEnumerable<TEntity>> GetAll(Expression<Func<TEntity, bool>> expression);
    void Insert(TEntity entity);
    void InsertRange(IEnumerable<TEntity> entities);
    void Update(TEntity entityToUpdate);

}