﻿namespace RAMS.Application.Contracts;

public interface IDateTimeProvider
{
    DateTime UtcNow { get; }
}