﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.GradeApp;

public interface IGradeRepository : IRepository<Grade>
{
    Task<PagedList<Grade>> GetAllBaseAsync(SearchOptions searchOptions);
}