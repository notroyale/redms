﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.GradeApp;

internal class GradeService : Service<Grade>, IGradeService
{
    private readonly IGradeRepository _gradeRepository;

    public GradeService(IGradeRepository repository, IUnitOfWork unitOfWork) : base(repository, unitOfWork)
    {
        _gradeRepository = repository;
    }

    public async Task<PagedList<Grade>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        return await _gradeRepository.GetAllBaseAsync(searchOptions);
    }
}