﻿using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.GradeApp;

public interface IGradeService : IService<Grade>
{
    Task<PagedList<Grade>> GetAllBaseAsync(SearchOptions searchOptions);
}