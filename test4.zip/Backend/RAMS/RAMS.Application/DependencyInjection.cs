﻿using Microsoft.Extensions.DependencyInjection;
using RAMS.Application.Common;
using RAMS.Application.TaxonomyApp;
using RAMS.Application.ObservationApp;
using RAMS.Application.BusinessAreaApp;
using RAMS.Application.BusinessUnitApp;
using RAMS.Application.LegalEntityApp;
using RAMS.Application.StatusApp;
using RAMS.Application.RAGStatusApp;
using RAMS.Application.RegulationApp;
using RAMS.Application.CountryApp;
using RAMS.Application.StatusRequestApp;
using RAMS.Application.RegulatoryCategoryApp;
using RAMS.Application.GradeApp;
using RAMS.Application.NewsApp;
using RAMS.Application.CategoryApp;
using RAMS.Application.ActionPlanApp;
using RAMS.Application.ObservationBusinessAreaCountryApp;
using RAMS.Application.TaxonomyLevelApp;
using RAMS.Application.UserApp;
using RAMS.Application.AuthorisationApp;
using Microsoft.AspNetCore.Http;
using RAMS.Application.AttachmentApp;
using RAMS.Application.FieldHelpTextApp;
using RAMS.Application.AuditApp;

namespace RAMS.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddScoped(typeof(IService<>), typeof(Service<>));
        services.AddScoped<ITaxonomyService, TaxonomyService>();
        services.AddScoped<ITaxonomyLevelService, TaxonomyLevelService>();
        services.AddScoped<IObservationService, ObservationService>();
        services.AddScoped<IBusinessAreaService, BusinessAreaService>();
        services.AddScoped<IBusinessUnitService, BusinessUnitService>();
        services.AddScoped<ILegalEntityService, LegalEntityService>();
        services.AddScoped<IStatusService, StatusService>();
        services.AddScoped<IRAGStatusService, RAGStatusService>();
        services.AddScoped<IRegulationService, RegulationService>();
        services.AddScoped<ICountryService, CountryService>();
        services.AddScoped<IGradeService, GradeService>();
        services.AddScoped<IStatusRequestService, StatusRequestService>();
        services.AddScoped<IRegulatoryCategoryService, RegulatoryCategoryService>();
        services.AddScoped<INewsService, NewsService>();
        services.AddScoped<ICategoryService, CategoryService>();
        services.AddScoped<IActionPlanService, ActionPlanService>();
        services.AddScoped<IObservationBusinessAreaCountryService, ObservationBusinessAreaCountryService>();
        services.AddScoped<IAuthorisationService, AuthorisationService>();
        services.AddScoped<IAttachmentService, AttachmentService>();
        services.AddScoped<IFieldHelpTextService, FieldHelpTextService>();
        services.AddScoped<IAuditService, AuditService>();

        AddUserSession(services);

        return services;
    }

    private static void AddUserSession(IServiceCollection services)
    {
        //services.AddScoped<IUserService, UserService>();
        services.AddScoped<UserService>();

        services.AddSession(options =>
        {
            options.IdleTimeout = TimeSpan.FromDays(1);
            options.Cookie.HttpOnly = true;
            options.Cookie.IsEssential = true;
        });

        services.AddTransient<IHttpContextAccessor, HttpContextAccessor>();
        services.AddScoped<IUserService>(provider =>//move session to application layer
        {
            var userContext = provider.GetRequiredService<IHttpContextAccessor>();
            var userService = provider.GetRequiredService<UserService>();

            return new SessionUserService(userService, userContext);
        });
    }
}