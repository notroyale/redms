﻿using RAMS.Application.Contracts;
using RAMS.Domain;

namespace RAMS.Persistence.ObservationPersistence;

public interface IObservationTaxonomyRepository : IRepository<ObservationTaxonomy>
{
}