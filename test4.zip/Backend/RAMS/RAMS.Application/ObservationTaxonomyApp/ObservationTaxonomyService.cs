﻿using RAMS.Application.Contracts;
using RAMS.Domain;

namespace RAMS.Application.ObservationTaxonomyApp;

internal class ObservationTaxonomyService : IObservationTaxonomyService
{
    private readonly IRepository<ObservationTaxonomy> _repository;
    private readonly IUnitOfWork _unitOfWork;

    public ObservationTaxonomyService(IRepository<ObservationTaxonomy> repository, IUnitOfWork unitOfWork)
    {
        _repository = repository;
        _unitOfWork = unitOfWork;
    }

    public async Task<bool> Add(ObservationTaxonomy observationTaxonomy)
    {
        _repository.Insert(observationTaxonomy);
        return await _unitOfWork.CommitAsync();
    }

    public async Task<bool> Delete(ObservationTaxonomy observationTaxonomy)
    {
        _repository.Delete(observationTaxonomy);
        return await _unitOfWork.CommitAsync();
    }

    public async Task<IEnumerable<ObservationTaxonomy>> GetAllByObservationID(int observationID)
    {
        return await _repository.GetAll(obsTax => obsTax.ObservationID == observationID);
    }
}