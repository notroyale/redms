﻿using RAMS.Domain;

namespace RAMS.Application.ObservationTaxonomyApp;

internal interface IObservationTaxonomyService
{
    Task<IEnumerable<ObservationTaxonomy>> GetAllByObservationID(int observationID);
    Task<bool> Add(ObservationTaxonomy observationTaxonomy);
    Task<bool> Delete(ObservationTaxonomy observationTaxonomy);
}