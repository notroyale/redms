﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Domain.User;
using System.Linq.Expressions;

namespace RAMS.Application.ObservationApp;

public interface IObservationRepository : IRepository<Observation>
{
    Task<IEnumerable<AuthorisationAccessPermission>> GetAllAuthorised();
    Task<PagedList<ObservationAuthorisation>> GetAllBaseAsync(SearchOptions searchOptions, AccessControl accessControl);
    Task<Observation?> GetFull(Expression<Func<Observation, bool>> expression);
    Task<ObservationAuthorisation?> GetFull(int id, AccessControl accessControl);
    Task<ObservationAuthorisation?> GetFull(int id, AccessControl accessControl, IEnumerable<FieldHelpText>? helpText);

}