﻿using Messaging;
using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Domain.Observations.Steps;
using System.Linq.Expressions;

namespace RAMS.Application.ObservationApp;

public interface IObservationService : IService<Observation>
{
    Task<PagedList<ObservationAuthorisation>> GetAllBaseAsync(SearchOptions searchOptions);
    //Task<ObservationAuthorisation?> GetFull(Expression<Func<Observation, bool>> expression);
    Task<ObservationAuthorisation?> GetFull(int id);
    Task<bool> UpdateDetailsStep(int id,ObservationDetailsStep request);
    Task<bool> UpdateResposibilityCentreStep(int id, ObservationResposibilityCentreStep request);
    Task<bool> UpdateCollaborationFieldsStep(int id, ObservationCollaborationFieldsStep request);
    Task<bool> UpdateRiskCategorizationStep(int id, ObservationRiskCategorizationStep request);
    Task<bool> UpdateActionPlanStep(int id, ObservationActionPlanStep request);
    Task<bool> UpdateAffectedFieldsStep(int id, ObservationAffectedFieldsStep request);
    Task<bool> UpdateClosureFieldsStep(int id, ObservationClosureFieldsStep request);
    Task<bool> ObservationClosure(int id, ObservationClosureStep request);
    Task<IEnumerable<AuthorisationAccessPermission>> GetAllAuthorised();
    Task<ObservationAuthorisation> Create();
    Task<Result<bool>> Submit(int id);
    Task<bool> UpdateAllSteps(int id, ObservationDetailsStep detailsStep, ObservationResposibilityCentreStep resposibilityCentreStep, ObservationRiskCategorizationStep riskCategorizationStep, ObservationCollaborationFieldsStep collaborationFieldsStep, ObservationAffectedFieldsStep affectedFieldsStep, ObservationStatusStep statusStep, ObservationActionPlanStep actionPlanStep);
}