﻿using Messaging;
using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Application.FieldHelpTextApp;
using RAMS.Application.TaxonomyApp;
using RAMS.Application.UserApp;
using RAMS.Domain;
using RAMS.Domain.Common;
using RAMS.Domain.Observations.Steps;
using RAMS.Domain.User;
using System.Linq.Expressions;

namespace RAMS.Application.ObservationApp;

internal class ObservationService : Service<Observation>, IObservationService
{
    private readonly IObservationRepository _observationRepository;
    private readonly IFieldHelpTextService _fieldHelpTextService;
    private readonly ITaxonomyService _taxonomyService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IUserService _userService;
    private readonly IDateTimeProvider _dateTimeProvider;

    public ObservationService(
        IObservationRepository observationRepository,
        IFieldHelpTextService fieldHelpTextService,
        IUnitOfWork unitOfWork, 
        ITaxonomyService taxonomyService, 
        IUserService userService, 
        IDateTimeProvider dateTimeProvider)
        : base(observationRepository, unitOfWork)
    {
        _observationRepository = observationRepository;
        _unitOfWork = unitOfWork;
        _taxonomyService = taxonomyService;
        _userService = userService;
        _dateTimeProvider = dateTimeProvider;
        _fieldHelpTextService = fieldHelpTextService;
    }

    public async Task<PagedList<ObservationAuthorisation>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        User currentUser = _userService.GetCurrentUser();

        return await _observationRepository.GetAllBaseAsync(searchOptions, currentUser.AccessControl);
    }

    public async Task<ObservationAuthorisation?> GetFull(int id)
    {
        User currentUser = _userService.GetCurrentUser();
        var helpTexts = await _fieldHelpTextService.GetAllBaseAsync();

        return await _observationRepository.GetFull(id, currentUser.AccessControl, helpTexts);
    }

    public async Task<bool> UpdateAllSteps(int id,
    ObservationDetailsStep detailsStep,
    ObservationResposibilityCentreStep resposibilityCentreStep,
    ObservationRiskCategorizationStep riskCategorizationStep,
    ObservationCollaborationFieldsStep collaborationFieldsStep,
    ObservationAffectedFieldsStep affectedFieldsStep,
    ObservationStatusStep statusStep, ObservationActionPlanStep actionPlanStep)
    {
        var existingObs = await _observationRepository.GetFull(obs => obs.Id == id);
        var currentUser = _userService.GetCurrentUser().BNumber;
        if (existingObs is null)
        {
            return false;
        }

        _observationRepository.Update(existingObs);
        existingObs.SetSubmissionState();
        existingObs.UpdateDetailsStep(detailsStep, currentUser,id);
        existingObs.UpdateResposibilityCentreStep(resposibilityCentreStep, currentUser);

        var foundTax = await _taxonomyService.GetWithRelations(x => x.Id == riskCategorizationStep.TaxLevel1);

        if (foundTax is null)
        {
            return false;
        }

        existingObs.UpdateRiskCategorizationeStep(riskCategorizationStep, foundTax, currentUser);
        existingObs.UpdateCollaborationFieldsStep(collaborationFieldsStep, currentUser, id);
        existingObs.UpdateAffectedFieldsStep(affectedFieldsStep, currentUser);
        existingObs.UpdateStatusStep(statusStep);
        existingObs.UpdateActionPlanStep(actionPlanStep);
        existingObs.UpdateBinaryFields(detailsStep, riskCategorizationStep, id, currentUser);
        existingObs.ModifiedDate = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("Central Europe Standard Time"));
        existingObs.ModifiedUser = currentUser;


        SetModifiedByForBa(existingObs.BusinessAreasCountry,currentUser);

  
       

        //existingObs.ObservarionClosureStep(closureFieldsStep, _dateTimeProvider.UtcNow);

        return await _unitOfWork.CommitAsync();
    }

    void SetModifiedByForBa(IEnumerable<ObservationBusinessArea> BusinessAreasCountries, string currentUser)
    {
        if (BusinessAreasCountries == null || string.IsNullOrEmpty(currentUser))
        {
            return;
        }
        if (BusinessAreasCountries != null)
        {
            foreach (var item in BusinessAreasCountries)
            {
                item.ModifiedBy = currentUser;
            }
        }
    }


    public async Task<bool> UpdateDetailsStep(int id, ObservationDetailsStep request)
    {
        var existingObs = await _observationRepository.GetFull(obs => obs.Id == id);
        var currentUser = _userService.GetCurrentUser().BNumber;

        if (existingObs is null)
        {
            return false;
        }

        _observationRepository.Update(existingObs);
        existingObs.UpdateDetailsStep(request, currentUser,id);

        return await _unitOfWork.CommitAsync();    
    }

    public async Task<bool> UpdateResposibilityCentreStep(int id, ObservationResposibilityCentreStep request)
    {
        var existingObs = await _observationRepository.GetFull(obs => obs.Id == id);
        var currentUser = _userService.GetCurrentUser().BNumber;

        if (existingObs is null)
        {
            return false;
        }

        _observationRepository.Update(existingObs);
        existingObs.UpdateResposibilityCentreStep(request, currentUser);

        return await _unitOfWork.CommitAsync();
    }

    public async Task<bool> UpdateRiskCategorizationStep(int id, ObservationRiskCategorizationStep request)
    {
        var existingObs = await _observationRepository.GetFull(obs => obs.Id == id);
        var currentUser = _userService.GetCurrentUser().BNumber;

        if (existingObs is null)
        {
            return false;
        }

        var foundTax = await _taxonomyService.GetWithRelations(x => x.Id == request.TaxLevel1);

        if (foundTax is null)
        { 
            return false; 
        }

        _observationRepository.Update(existingObs);
        existingObs.UpdateRiskCategorizationeStep(request, foundTax, currentUser);
    
        return await _unitOfWork.CommitAsync();
    }

    public async Task<bool> UpdateCollaborationFieldsStep(int id, ObservationCollaborationFieldsStep request)
    {
        var existingObs = await _observationRepository.GetFull(obs => obs.Id == id);
        var currentUser = _userService.GetCurrentUser().BNumber;

        if (existingObs is null)
        {
            return false;
        }

        _observationRepository.Update(existingObs);
        existingObs.UpdateCollaborationFieldsStep(request, currentUser, id);

        return await _unitOfWork.CommitAsync();
    }

    public async Task<IEnumerable<AuthorisationAccessPermission>> GetAllAuthorised()
    {
        return await _observationRepository.GetAllAuthorised();
    }

    public async Task<bool> UpdateAffectedFieldsStep(int id, ObservationAffectedFieldsStep request)
    {
        var existingObs = await  _observationRepository.GetFull(obs => obs.Id == id);
        var currentUser = _userService.GetCurrentUser().BNumber;

        if (existingObs is null)
        {
            return false;
        }

        _observationRepository.Update(existingObs);
        existingObs.UpdateAffectedFieldsStep(request, currentUser);

        return await _unitOfWork.CommitAsync();
    }

    public async Task<bool> UpdateClosureFieldsStep(int id, ObservationClosureFieldsStep request)
    {
        var existingObs = await _observationRepository.GetFull(obs => obs.Id == id);

        if (existingObs is null)
        {
            return false;
        }

        _observationRepository.Update(existingObs);
        existingObs.UpdateClosurFeldsStep(request);

        return await _unitOfWork.CommitAsync();
    }

    public async Task<bool> ObservationClosure(int id, ObservationClosureStep request)
    {

        var currentUser = _userService.GetCurrentUser();

        if (currentUser == null)
        {
            return false;
        }

        var existingObs = await _observationRepository.GetFull(obs => obs.Id == id);

        if (existingObs is null)
        {
            return false;
        }

        _observationRepository.Update(existingObs);
        existingObs.ObservarionClosureStep(request, currentUser.BNumber, _dateTimeProvider.UtcNow);

        return await _unitOfWork.CommitAsync();
    }

    public async Task<ObservationAuthorisation> Create()
    {
        Observation observation = new();
        observation.SetCreation(_dateTimeProvider.UtcNow, _userService.GetCurrentUser().BNumber);

        _observationRepository.Insert(observation);

        if(!await _unitOfWork.CommitAsync())
        {
            return ObservationAuthorisation.Create(observation);
        }

        return ObservationAuthorisation.Create(observation);
    }

    public async Task<bool> UpdateActionPlanStep(int id, ObservationActionPlanStep request)
    {
        var existingObs = await _observationRepository.GetFull(obs => obs.Id == id);

        if (existingObs is null)
        {
            return false;
        }

        _observationRepository.Update(existingObs);
        existingObs.UpdateActionPlanStep(request);

        return await _unitOfWork.CommitAsync();
    }

    public async Task<Result<bool>> Submit(int id)
    {
        var existingObs = await _observationRepository.GetFull(obs => obs.Id == id);

        if (existingObs is null)
        {
            return false;
        }

        _observationRepository.Update(existingObs);
        existingObs.SetSubmissionState();

        return await _unitOfWork.CommitAsync();
    }
}