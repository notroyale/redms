﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.RAGStatusApp;

public interface IRAGStatusRepository : IRepository<RAGStatus>
{
    Task<PagedList<RAGStatus>> GetAllBaseAsync(SearchOptions searchOptions);
}