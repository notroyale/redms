﻿using RAMS.Application.Common;
using RAMS.Application.Contracts;
using RAMS.Domain;
using RAMS.Domain.Common;

namespace RAMS.Application.RAGStatusApp;

internal class RAGStatusService : Service<RAGStatus>, IRAGStatusService
{
    private readonly IRAGStatusRepository _ragStatusRepository;

    public RAGStatusService(IRAGStatusRepository repository, IUnitOfWork unitOfWork) : base(repository, unitOfWork)
    {
        _ragStatusRepository = repository;
    }

    public async Task<PagedList<RAGStatus>> GetAllBaseAsync(SearchOptions searchOptions)
    {
        return await _ragStatusRepository.GetAllBaseAsync(searchOptions);
    }
}