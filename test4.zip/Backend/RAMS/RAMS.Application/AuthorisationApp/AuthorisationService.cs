﻿using RAMS.Domain;

namespace RAMS.Application.AuthorisationApp;

internal class AuthorisationService : IAuthorisationService
{
    private readonly IAuthorisationRepository _repository;

    public AuthorisationService(IAuthorisationRepository repository)
    {
        _repository = repository;
    }

    public async Task<IEnumerable<Authorisation>> FindAllByShortName(IEnumerable<string> authorisations)
    {
        return await _repository.GetUserPermissions(authorisations);
    }

    public async Task<IEnumerable<Authorisation>> GetAllAsync()
    {
        return await _repository.GetAllAsync();
    }
}