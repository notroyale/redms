﻿using RAMS.Domain;

namespace RAMS.Application.AuthorisationApp;

public interface IAuthorisationRepository
{
    Task<IEnumerable<Authorisation>> GetUserPermissions(IEnumerable<string> authorisations);

    Task<IEnumerable<Authorisation>> GetAllAsync();

}