﻿using RAMS.Domain;

namespace RAMS.Application.AuthorisationApp;

public interface IAuthorisationService
{
    Task<IEnumerable<Authorisation>> FindAllByShortName(IEnumerable<string> authorisations);
    
    Task<IEnumerable<Authorisation>> GetAllAsync();
}