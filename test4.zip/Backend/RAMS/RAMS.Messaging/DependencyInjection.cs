﻿namespace RAMS.Messaging;

public class DependencyInjection
{

}