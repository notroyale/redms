﻿using RAMS.API.CommonAPI;
using RAMS.API.StatusRequestAPI.ContractResponses;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.API.StatusRequestAPI.ContractMapping;

public static class StatusRequestDomainToDto
{
    public static GetAllResponseStatusRequestDto ToGetAllResponseDto(this IEnumerable<StatusRequest> entities)
    {
        ICollection<GetResponseStatusRequestDto> dtos = new List<GetResponseStatusRequestDto>();

        foreach (StatusRequest entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllResponseStatusRequestDto.Create(dtos);
    }

    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseStatusRequestDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<StatusRequest>? entities)
    {
        ICollection<GetResponseBaseStatusRequestDto> dtos = new List<GetResponseBaseStatusRequestDto>();

        foreach (StatusRequest entity in entities.Items)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseStatusRequestDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetResponseBaseStatusRequestDto ToGetBaseResponseDto(this StatusRequest entity)
    {
        return GetResponseBaseStatusRequestDto.Create(entity.Id, entity.Name, entity.TemplateName, entity.TemplateLocation, entity.IsActive);
    }

    public static GetResponseStatusRequestDto ToGetResponseDto(this StatusRequest entity)
    {
        return GetResponseStatusRequestDto.Create(entity.Id, entity.Name, entity.TemplateName, entity.TemplateLocation, entity.IsActive);
    }

    public static UpdateResponseStatusRequestDto ToUpdateResponseDto(this StatusRequest entity)
    {
        return UpdateResponseStatusRequestDto.Create(entity.Id, entity.Name);
    }

    public static AddResponseStatusRequestDto ToAddResponseDto(this StatusRequest entity)
    {
        return AddResponseStatusRequestDto.Create(entity.Id, entity.Name);
    }

    public static DeleteResponseStatusRequestDto ToDeleteResponseDto(this StatusRequest entity)
    {
        return DeleteResponseStatusRequestDto.Create(entity.Id, entity.Name);
    }
}