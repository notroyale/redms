﻿using RAMS.API.StatusRequestAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.StatusRequestAPI.ContractMapping;

public static class StatusRequestDtoToDomain
{
    public static StatusRequest ToDomain(this AddRequestStatusRequestDto requestDto)
    {
        return new StatusRequest()
        {
            Name = requestDto.Name,
            TemplateName = requestDto.TemplateName,
            TemplateLocation = requestDto.TemplateLocation,
            IsActive = requestDto.IsActive
        };
    }

    public static StatusRequest ToDomain(this UpdateRequestStatusRequestDto requestDto)
    {
        return new StatusRequest()
        {
            Id = requestDto.Id,
            Name = requestDto.Name,
            TemplateName = requestDto.TemplateName,
            TemplateLocation = requestDto.TemplateLocation,
            IsActive = requestDto.IsActive
        };
    }
}