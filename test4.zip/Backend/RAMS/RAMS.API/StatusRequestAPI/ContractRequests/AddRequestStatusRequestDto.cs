﻿namespace RAMS.API.StatusRequestAPI.ContractRequests;

public record AddRequestStatusRequestDto(string Name, string TemplateName, string TemplateLocation, bool IsActive);