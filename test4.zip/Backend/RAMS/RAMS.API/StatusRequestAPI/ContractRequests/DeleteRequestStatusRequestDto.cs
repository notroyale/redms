﻿namespace RAMS.API.StatusRequestAPI.ContractRequests;

public record DeleteRequestStatusRequestDto(int Id);