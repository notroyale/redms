﻿namespace RAMS.API.StatusRequestAPI.ContractRequests;

public record GetRequestStatusRequestDto(int Id);