﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.StatusRequestAPI.ContractMapping;
using RAMS.API.StatusRequestAPI.ContractRequests;
using RAMS.API.CommonAPI;
using RAMS.Application.StatusRequestApp;
using RAMS.Application.Common;
using RAMS.Domain.Common;

namespace RAMS.API.StatusRequestAPI;

public class StatusRequestController : APIController
{
    private readonly IStatusRequestService _statusRequestService;
    private readonly ICacheService _cache;


    public StatusRequestController(IStatusRequestService statusRequestService, ICacheService memoryCache) : base(memoryCache)
    {
        _statusRequestService = statusRequestService;
        _cache = memoryCache;
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var result = await _statusRequestService.GetAllAsync();

        return Ok(result.ToGetAllResponseDto().Values);
    }

    [HttpGet("allBase/options")]
    public async Task<IActionResult> GetBaseRepositoryDataAsync([FromQuery] SearchOptions searchOptions)
    {
        var statusRequests = await _statusRequestService.GetAllBaseAsync(searchOptions);

        if (statusRequests is null)
            return NotFound();

        return Ok(statusRequests.ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get(GetRequestStatusRequestDto requestDto)
    {
        var result = await _statusRequestService.GetAsync(ba => ba.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestStatusRequestDto requestDto)
    {
        var result = await _statusRequestService.Insert(requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestStatusRequestDto requestDto)
    {
        var result = await _statusRequestService.Update(ba => ba.Id == requestDto.Id, requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public IActionResult Delete(DeleteRequestStatusRequestDto requestDto)
    {
        return Ok("Delete status Request reached!");
    }
}