﻿namespace RAMS.API.StatusRequestAPI.ContractResponses;

public record DeleteResponseStatusRequestDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected DeleteResponseStatusRequestDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static DeleteResponseStatusRequestDto Create(int id, string name)
    {
        return new(id, name);
    }
}