﻿namespace RAMS.API.StatusRequestAPI.ContractResponses;

public record GetResponseBaseStatusRequestDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public string TemplateName { get; init; }
    public string TemplateLocation { get; init; }
    public bool IsActive { get; init; }

    protected GetResponseBaseStatusRequestDto(int id, string name, string templateName, string templateLocation, bool isActive)
    {
        Id = id;
        Name = name;
        TemplateName = templateName;
        TemplateLocation = templateLocation;
        IsActive = isActive;
    }

    public static GetResponseBaseStatusRequestDto Create(int id, string name, string templateName, string templateLocation, bool isActive)
    {
        return new(id, name, templateName, templateLocation, isActive);
    }
}