﻿namespace RAMS.API.StatusRequestAPI.ContractResponses;

public record UpdateResponseStatusRequestDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected UpdateResponseStatusRequestDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static UpdateResponseStatusRequestDto Create(int id, string name)
    {
        return new(id, name);
    }
}