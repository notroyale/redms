﻿namespace RAMS.API.StatusRequestAPI.ContractResponses;

public record AddResponseStatusRequestDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected AddResponseStatusRequestDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static AddResponseStatusRequestDto Create(int id, string name)
    {
        return new(id, name);
    }
}