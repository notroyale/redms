﻿namespace RAMS.API.StatusRequestAPI.ContractResponses;

public record GetAllResponseStatusRequestDto
{
    public IEnumerable<GetResponseStatusRequestDto> Values { get; init; }

    protected GetAllResponseStatusRequestDto(IEnumerable<GetResponseStatusRequestDto> values)
    {
        Values = values;
    }

    public static GetAllResponseStatusRequestDto Create(IEnumerable<GetResponseStatusRequestDto> values)
    {
        return new(values);
    }
}