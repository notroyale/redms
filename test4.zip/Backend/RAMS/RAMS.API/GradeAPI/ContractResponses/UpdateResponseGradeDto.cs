﻿namespace RAMS.API.GradeAPI.ContractResponses;

public record UpdateResponseGradeDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected UpdateResponseGradeDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static UpdateResponseGradeDto Create(int id, string name)
    {
        return new(id, name);
    }
}