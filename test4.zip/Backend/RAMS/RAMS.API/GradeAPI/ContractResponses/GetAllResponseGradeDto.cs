﻿namespace RAMS.API.GradeAPI.ContractResponses;

public record GetAllResponseGradeDto
{
    public IEnumerable<GetResponseGradeDto> Values { get; init; }

    protected GetAllResponseGradeDto(IEnumerable<GetResponseGradeDto> values)
    {
        Values = values;
    }

    public static GetAllResponseGradeDto Create(IEnumerable<GetResponseGradeDto> values)
    {
        return new(values);
    }
}