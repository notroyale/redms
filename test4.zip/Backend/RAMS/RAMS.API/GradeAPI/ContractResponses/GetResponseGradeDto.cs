﻿namespace RAMS.API.GradeAPI.ContractResponses;

public record GetResponseGradeDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public bool IsActive { get; init; }

    protected GetResponseGradeDto(int id, string name, bool isActive)
    {
        Id = id;
        Name = name;
        IsActive = isActive;
    }
    public GetResponseGradeDto()
    {
        Name = string.Empty;
    }

    public static GetResponseGradeDto Create(int id, string name, bool isActive)
    {
        return new(id, name, isActive);
    }
    public static GetResponseGradeDto Empty()
    {
        return new();
    }
}