﻿namespace RAMS.API.GradeAPI.ContractResponses;

public record DeleteResponseGradeDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected DeleteResponseGradeDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static DeleteResponseGradeDto Create(int id, string name)
    {
        return new(id, name);
    }
}