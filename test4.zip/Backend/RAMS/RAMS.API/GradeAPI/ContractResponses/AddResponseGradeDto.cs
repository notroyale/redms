﻿namespace RAMS.API.GradeAPI.ContractResponses;

public record AddResponseGradeDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected AddResponseGradeDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static AddResponseGradeDto Create(int id, string name)
    {
        return new(id, name);
    }
}