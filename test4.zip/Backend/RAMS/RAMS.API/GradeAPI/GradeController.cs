﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.GradeAPI.ContractMapping;
using RAMS.API.GradeAPI.ContractRequests;
using RAMS.API.CommonAPI;
using RAMS.Application.GradeApp;
using RAMS.Application.Common;
using RAMS.Domain.Common;

namespace RAMS.API.GradeAPI;

public class GradeController : APIController
{
    private readonly IGradeService _gradeService;
    private readonly ICacheService _cache;

    public GradeController(IGradeService gradeService, ICacheService memoryCache) : base(memoryCache)
    {
        _gradeService = gradeService;
        _cache = memoryCache;   
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var result = await _gradeService.GetAllAsync();

        return Ok(result.ToGetAllResponseDto().Values);
    }

    [HttpGet("allBase/options")]
    public async Task<IActionResult> GetBaseRepositoryDataAsync([FromQuery] SearchOptions searchOptions)
    {
        var grades = await _gradeService.GetAllBaseAsync(searchOptions);

        if (grades is null)
            return NotFound();

        return Ok(grades.ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get(GetRequestGradeDto requestDto)
    {
        var result = await _gradeService.GetAsync(ba => ba.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestGradeDto requestDto)
    {
        var result = await _gradeService.Insert(requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestGradeDto requestDto)
    {
        var result = await _gradeService.Update(ba => ba.Id == requestDto.Id, requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public IActionResult Delete(DeleteRequestGradeDto requestDto)
    {
        return Ok("Delete grade reached!");
    }
}