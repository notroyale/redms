﻿namespace RAMS.API.GradeAPI.ContractRequests;

public record DeleteRequestGradeDto(int Id);