﻿namespace RAMS.API.GradeAPI.ContractRequests;

public record GetRequestGradeDto(int Id);