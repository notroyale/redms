﻿namespace RAMS.API.GradeAPI.ContractRequests;

public record UpdateRequestGradeDto(int Id, string Name, bool IsActive);