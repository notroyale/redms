﻿namespace RAMS.API.GradeAPI.ContractRequests;

public record AddRequestGradeDto(string Name, bool IsActive);