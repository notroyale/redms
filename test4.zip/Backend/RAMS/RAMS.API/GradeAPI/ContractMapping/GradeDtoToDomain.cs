﻿using RAMS.API.GradeAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.GradeAPI.ContractMapping;

public static class GradeDtoToDomain
{
    public static Grade ToDomain(this AddRequestGradeDto requestDto)
    {
        return new Grade()
        {
            Name = requestDto.Name,
            IsActive = requestDto.IsActive
        };
    }

    public static Grade ToDomain(this UpdateRequestGradeDto requestDto)
    {
        return new Grade()
        {
            Id = requestDto.Id,
            Name = requestDto.Name,
            IsActive = requestDto.IsActive
        };
    }
}