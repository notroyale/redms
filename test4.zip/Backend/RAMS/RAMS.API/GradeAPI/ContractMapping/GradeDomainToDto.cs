﻿using RAMS.API.CommonAPI;
using RAMS.API.GradeAPI.ContractResponses;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.API.GradeAPI.ContractMapping;

public static class GradeDomainToDto
{
    public static GetAllResponseGradeDto ToGetAllResponseDto(this IEnumerable<Grade> entities)
    {
        ICollection<GetResponseGradeDto> dtos = new List<GetResponseGradeDto>();

        foreach (Grade entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllResponseGradeDto.Create(dtos);
    }

    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseGradeDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<Grade>? entities)
    {
        ICollection<GetResponseBaseGradeDto> dtos = new List<GetResponseBaseGradeDto>();

        foreach (Grade entity in entities.Items)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseGradeDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetResponseBaseGradeDto ToGetBaseResponseDto(this Grade entity)
    {
        return GetResponseBaseGradeDto.Create(entity.Id, entity.Name, entity.IsActive);
    }

    public static GetResponseGradeDto ToGetResponseDto(this Grade entity)
    {
        if(entity is null)
        {
            return GetResponseGradeDto.Empty();
        }

        return GetResponseGradeDto.Create(entity.Id, entity.Name, entity.IsActive);
    }

    public static UpdateResponseGradeDto ToUpdateResponseDto(this Grade entity)
    {
        return UpdateResponseGradeDto.Create(entity.Id, entity.Name);
    }

    public static AddResponseGradeDto ToAddResponseDto(this Grade entity)
    {
        return AddResponseGradeDto.Create(entity.Id, entity.Name);
    }

    public static DeleteResponseGradeDto ToDeleteResponseDto(this Grade entity)
    {
        return DeleteResponseGradeDto.Create(entity.Id, entity.Name);
    }
}