﻿namespace RAMS.API.StatusAPI.ContractResponses;

public record AddResponseStatusDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected AddResponseStatusDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static AddResponseStatusDto Create(int id, string name)
    {
        return new(id, name);
    }
}