﻿namespace RAMS.API.StatusAPI.ContractResponses;

public record GetAllResponseStatusDto
{
    public IEnumerable<GetResponseStatusDto> Values { get; init; }

    protected GetAllResponseStatusDto(IEnumerable<GetResponseStatusDto> values)
    {
        Values = values;
    }

    public static GetAllResponseStatusDto Create(IEnumerable<GetResponseStatusDto> values)
    {
        return new(values);
    }
}