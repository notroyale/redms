﻿namespace RAMS.API.StatusAPI.ContractResponses;

public record UpdateResponseStatusDto
{
    public int Id { get; init; }
    public string Description { get; init; }
    public bool IsActive { get; set; }

    protected UpdateResponseStatusDto(int id, string description, bool isActive)
    {
        Id = id;
        Description = description;
        IsActive = isActive;
    }

    public static UpdateResponseStatusDto Create(int id, string description, bool isActive)
    {
        return new(id, description, isActive);
    }
}