﻿namespace RAMS.API.StatusAPI.ContractResponses;

public record DeleteResponseStatusDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected DeleteResponseStatusDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static DeleteResponseStatusDto Create(int id, string name)
    {
        return new(id, name);
    }
}