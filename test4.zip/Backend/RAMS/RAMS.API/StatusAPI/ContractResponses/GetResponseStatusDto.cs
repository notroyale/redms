﻿namespace RAMS.API.StatusAPI.ContractResponses;

public record GetResponseStatusDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public string Color { get; init; }
    public bool IsActive { get; init; }

    protected GetResponseStatusDto(int id, string name, string color, bool isActive)
    {
        Id = id;
        Name = name;
        Color = color;
        IsActive = isActive;
    }

    protected GetResponseStatusDto()
    {
        Name = string.Empty;
        Color = string.Empty;
    }

    public static GetResponseStatusDto Empty()
    {
        return new();
    }

    public static GetResponseStatusDto Create(int id, string name, string color, bool isActive)
    {
        return new(id, name, color, isActive);
    }
}