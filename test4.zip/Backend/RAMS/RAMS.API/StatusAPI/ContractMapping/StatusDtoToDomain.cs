﻿using RAMS.API.StatusAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.StatusAPI.ContractMapping;

public static class StatusDtoToDomain
{
    public static Status ToDomain(this AddRequestStatusDto requestDto)
    {
        return new Status()
        {
            Name = requestDto.Name,
            Color = requestDto.Color,
            IsActive = requestDto.IsActive
        };
    }

    public static Status ToDomain(this UpdateRequestStatusDto requestDto)
    {
        return new Status()
        {
            Id = requestDto.Id,
            Name = requestDto.Name,
            Color = requestDto.Color,
            IsActive = requestDto.IsActive
        };
    }
}