﻿using RAMS.API.CommonAPI;
using RAMS.API.StatusAPI.ContractResponses;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.API.StatusAPI.ContractMapping;

public static class StatusDomainToDto
{
    public static GetAllResponseStatusDto ToGetAllResponseDto(this IEnumerable<Status> entities)
    {
        ICollection<GetResponseStatusDto> dtos = new List<GetResponseStatusDto>();
        foreach (Status entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllResponseStatusDto.Create(dtos);
    }

    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseStatusDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<Status>? entities)
    {
        if (entities == null)
            return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseStatusDto>.Empty();

        ICollection<GetResponseBaseStatusDto> dtos = new List<GetResponseBaseStatusDto>();

        foreach (Status entity in entities.Items)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseStatusDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetResponseBaseStatusDto ToGetBaseResponseDto(this Status entity)
    {
        return GetResponseBaseStatusDto.Create(entity.Id, entity.Name, entity.Color, entity.IsActive);
    }

    public static GetResponseStatusDto ToGetResponseDto(this Status entity)
    {
        if (entity is null)
            return GetResponseStatusDto.Empty();

        return GetResponseStatusDto.Create(entity.Id, entity.Name, entity.Color, entity.IsActive);
    }

    public static UpdateResponseStatusDto ToUpdateResponseDto(this Status entity)
    {
        return UpdateResponseStatusDto.Create(entity.Id, entity.Name, entity.IsActive);
    }

    public static AddResponseStatusDto ToAddResponseDto(this Status entity)
    {
        return AddResponseStatusDto.Create(entity.Id, entity.Name);
    }

    public static DeleteResponseStatusDto ToDeleteResponseDto(this Status entity)
    {
        return DeleteResponseStatusDto.Create(entity.Id, entity.Name);
    }
}