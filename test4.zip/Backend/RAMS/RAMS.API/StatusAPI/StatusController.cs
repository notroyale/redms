﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.StatusAPI.ContractMapping;
using RAMS.API.StatusAPI.ContractRequests;
using RAMS.API.CommonAPI;
using RAMS.Application.StatusApp;
using RAMS.Application.Common;
using RAMS.Domain.Common;

namespace RAMS.API.StatusAPI;

public class StatusController : APIController
{
    private readonly IStatusService _statusService;
    private readonly ICacheService _cache;

    public StatusController(IStatusService statusService, ICacheService memoryCache) : base(memoryCache)
    {
        _statusService = statusService;
        _cache = memoryCache;
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var result = await _statusService.GetAllAsync();

        return Ok(result.OrderBy(x => x.Name).ToGetAllResponseDto().Values);
    }

    [HttpGet("allBase/options")]
    public async Task<IActionResult> GetBaseRepositoryDataAsync([FromQuery] SearchOptions searchOptions)
    {
        var statuses = await _statusService.GetAllBaseAsync(searchOptions);

        if (statuses is null)
            return NotFound();

        return Ok(statuses.ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get(GetRequestStatusDto requestDto)
    {
        var result = await _statusService.GetAsync(ba => ba.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestStatusDto requestDto)
    {
        var result = await _statusService.Insert(requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestStatusDto requestDto)
    {
        var result = await _statusService.Update(ba => ba.Id == requestDto.Id, requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public IActionResult Delete(DeleteRequestStatusDto requestDto)
    {
        return Ok("Delete status reached!");
    }
}