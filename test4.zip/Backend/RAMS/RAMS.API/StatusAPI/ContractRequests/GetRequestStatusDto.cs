﻿namespace RAMS.API.StatusAPI.ContractRequests;

public record GetRequestStatusDto(int Id);