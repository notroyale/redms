﻿namespace RAMS.API.StatusAPI.ContractRequests;

public record DeleteRequestStatusDto(int Id);