﻿namespace RAMS.API.StatusAPI.ContractRequests;

public record UpdateRequestStatusDto(int Id, string Name, string Color, bool IsActive);