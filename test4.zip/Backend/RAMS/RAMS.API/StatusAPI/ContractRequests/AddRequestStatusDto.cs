﻿namespace RAMS.API.StatusAPI.ContractRequests;

public record AddRequestStatusDto(string Name, string Color, bool IsActive);