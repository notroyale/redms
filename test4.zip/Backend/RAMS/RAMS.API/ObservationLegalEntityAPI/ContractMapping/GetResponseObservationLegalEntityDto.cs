﻿namespace RAMS.API.ObservationLegalEntityAPI.ContractMapping;

public record GetResponseObservationLegalEntityDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected GetResponseObservationLegalEntityDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    protected GetResponseObservationLegalEntityDto()
    {
        Name = string.Empty;
    }

    public static GetResponseObservationLegalEntityDto Empty()
    {
        return new();
    }

    public static GetResponseObservationLegalEntityDto Create(int id, string name)
    {
        return new(id, name);
    }
}