﻿using RAMS.API.ObservationLegalEntityAPI.ContractMapping;
using RAMS.Domain;

namespace RAMS.API.ObservationLegalEntityAPI.ContractResponses;

public static class ObservationLegalEntityDomainToDto
{
    public static IReadOnlyList<int> ToGetAllResponseDto(this ICollection<ObservationLegalEntity> entities)
    {
        List<int> dtos = new();
        if (entities == null) return dtos;
        foreach (ObservationLegalEntity entity in entities)
        {
            dtos.Add(entity.LegalEntityID);
        }

        return dtos;
    }

    public static GetResponseObservationLegalEntityDto ToGetResponseDto(this ObservationLegalEntity entity)
    {
        if (entity is null || entity.LegalEntity is null)
            return GetResponseObservationLegalEntityDto.Empty();

        return GetResponseObservationLegalEntityDto.Create(entity.LegalEntityID, entity.LegalEntity.Name);
    }
}