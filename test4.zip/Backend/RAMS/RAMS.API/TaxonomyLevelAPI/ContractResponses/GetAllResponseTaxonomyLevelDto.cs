﻿namespace RAMS.API.TaxonomyLevelAPI.ContractResponses;

public record GetAllResponseTaxonomyLevelDto
{
    public IEnumerable<GetResponseTaxonomyLevelDto> Values { get; init; }

    protected GetAllResponseTaxonomyLevelDto(IEnumerable<GetResponseTaxonomyLevelDto> values)
    {
        Values = values;
    }

    public static GetAllResponseTaxonomyLevelDto Create(IEnumerable<GetResponseTaxonomyLevelDto> values)
    {
        return new(values);
    }
}