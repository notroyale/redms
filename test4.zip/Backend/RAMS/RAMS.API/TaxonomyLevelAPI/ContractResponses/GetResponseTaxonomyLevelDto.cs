﻿namespace RAMS.API.TaxonomyLevelAPI.ContractResponses;

public record GetResponseTaxonomyLevelDto
{
    public int Id { get; init; }
    public int Level { get; init; }
    public string Name { get; init; }
    public bool IsMandatory { get; init; }
    public bool IsActive { get; init; }

    protected GetResponseTaxonomyLevelDto(int id, int level, string name, bool isMandatory, bool isActive)
    {
        Id = id;
        Level = level;
        Name = name;
        IsMandatory = isMandatory;
        IsActive = isActive;
    }

    public static GetResponseTaxonomyLevelDto Create(int id, int level, string name, bool isMandatory, bool isActive)
    {
        return new(id, level, name, isMandatory, isActive);
    }
}