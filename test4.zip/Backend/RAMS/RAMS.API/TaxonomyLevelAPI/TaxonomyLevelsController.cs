﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.CommonAPI;
using RAMS.API.TaxonomyLevelAPI.ContractMapping;
using RAMS.Application.Common;
using RAMS.Application.TaxonomyLevelApp;

namespace RAMS.API.TaxonomyLevelAPI;

public class TaxonomyLevelsController : APIController
{
    private readonly ITaxonomyLevelService _taxonomyLevelService;
    private readonly ICacheService _cache;

    public TaxonomyLevelsController(ITaxonomyLevelService taxonomyLevelService, ICacheService memoryCache) : base(memoryCache)
    {
        _taxonomyLevelService = taxonomyLevelService;
        _cache = memoryCache;
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var result = await _taxonomyLevelService.GetAllAsync();
        return Ok(result
            .ToGetAllResponseDto());
    }
}