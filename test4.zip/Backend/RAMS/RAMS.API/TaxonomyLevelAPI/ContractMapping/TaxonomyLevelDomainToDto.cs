﻿using RAMS.API.TaxonomyLevelAPI.ContractResponses;
using RAMS.Domain;

namespace RAMS.API.TaxonomyLevelAPI.ContractMapping;

public static class TaxonomyLevelDomainToDto
{
    public static IEnumerable<GetResponseTaxonomyLevelDto> ToGetAllResponseDto(this IEnumerable<TaxonomyLevel> entities)
    {
        ICollection<GetResponseTaxonomyLevelDto> dtos = new List<GetResponseTaxonomyLevelDto>();

        foreach (TaxonomyLevel entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return dtos;
    }

    public static GetResponseTaxonomyLevelDto ToGetResponseDto(this TaxonomyLevel entity)
    {
        return GetResponseTaxonomyLevelDto.Create(entity.Id, entity.Level, entity.Name, entity.IsMandatory, entity.IsActive);
    }
}