﻿using RAMS.API.BusinessUnitAPI.ContractResponses;
using RAMS.API.LegalEntityAPI.ContractResponses;
using RAMS.Domain;

namespace RAMS.API.NewsAPI.ContractResponses
{
    public class GetResponseNewsDto
    {
        public int Id { get; init; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string ShortDescription { get; set; }
        public DateTime Date { get; set; }
        public string Author { get; set; }

        public GetResponseNewsDto(int id, string title, string description, string shortDescription, DateTime date, string author)
        {
            Id = id;
            Title = title;
            Description = description;
            ShortDescription = shortDescription;
            Date= date;
            Author = author;
        }
        public static GetResponseNewsDto Create(int id, string title, string description, string shortDescription, DateTime date, string author)
        {
            return new(id, title, description, shortDescription, date, author);
        }
    }
}
