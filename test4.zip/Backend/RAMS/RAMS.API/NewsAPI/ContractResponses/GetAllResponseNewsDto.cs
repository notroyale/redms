﻿
namespace RAMS.API.NewsAPI.ContractResponses;

public class GetAllResponseNewsDto
{
    public IEnumerable<GetResponseNewsDto> Values { get; init; }

    protected GetAllResponseNewsDto(IEnumerable<GetResponseNewsDto> values)
    {
        Values = values;
    }

    public static GetAllResponseNewsDto Create(IEnumerable<GetResponseNewsDto> values)
    {
        return new(values);
    }
}
