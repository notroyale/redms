﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.CommonAPI;
using RAMS.API.NewsAPI.ContractMapping;
using RAMS.Application.Common;
using RAMS.Application.NewsApp;

namespace RAMS.API.LegalEntityAPI;

public class NewsController : APIController
{
    private readonly INewsService _newsService;
    private readonly ICacheService _cache;

    public NewsController(INewsService newsService, ICacheService memoryCache) : base(memoryCache)
    {
        _newsService = newsService;
        _cache = memoryCache;
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var result = await _newsService.GetAllAsync();

        return Ok(result.ToGetAllResponseDto());
    }
}