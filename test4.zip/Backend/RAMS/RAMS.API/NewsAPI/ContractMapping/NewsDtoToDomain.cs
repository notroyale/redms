﻿namespace RAMS.API.NewsAPI.ContractMapping
{
    public class NewsDtoToDomain
    {
    }
}
