﻿using RAMS.API.NewsAPI.ContractResponses;
using RAMS.Domain;

namespace RAMS.API.NewsAPI.ContractMapping;

public static class NewsDomainToDto
{
    public static IEnumerable<GetResponseNewsDto> ToGetAllResponseDto(this IEnumerable<News> entities)
    {
        ICollection<GetResponseNewsDto> dtos = new List<GetResponseNewsDto>();

        foreach (News entity in entities)
        {
            dtos.Add(entity.ToGetResponseNewsDto());
        }

        return dtos;
    }
    
    public static GetResponseNewsDto ToGetResponseNewsDto(this News entity)
    {
        return GetResponseNewsDto.Create(entity.Id, entity.Title, entity.Description, entity.ShortDescription, entity.Date, entity.Author);
    }
}