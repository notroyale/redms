﻿using Microsoft.AspNetCore.Mvc;

namespace RAMS.API.AuthAPI;

[Route("api/[controller]")]
public class AuthController : Controller
{
    private readonly IHttpClientFactory _clientFactory;
    private readonly IConfiguration _configuration;


    public AuthController(IHttpClientFactory clientFactory, IConfiguration configuration)
    {
        _clientFactory = clientFactory;
        _configuration = configuration;
    }

    [HttpGet("openid-configuration")]
    public async Task<IActionResult> GetOpenIdConfiguration()
    {
        var url = _configuration.GetSection("PROXY_ADFS_OPENID_CONFIG");
        if (url == null || url.Value == null)
        {
            return BadRequest();
        }
        return await GetContent(url.Value);

    }

    [HttpGet("openid-keys")]
    public async Task<IActionResult> GetOpenIdKeys()
    {
        var url = _configuration.GetSection("PROXY_ADFS_KEYS");
        if(url == null || url.Value == null)
        {
            return BadRequest();
        }

        return await GetContent(url.Value);
    }

    private async Task<IActionResult> GetContent(string url)
    {
        try
        {
            HttpClient client = _clientFactory.CreateClient();
            HttpResponseMessage? response = await client.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                string content = await response.Content.ReadAsStringAsync();

                return Content(content, "application/json");
            }

            return StatusCode((int)response.StatusCode);
        }
        catch (HttpRequestException)
        {
            return BadRequest("Proxy request failed");
        }
    }
}