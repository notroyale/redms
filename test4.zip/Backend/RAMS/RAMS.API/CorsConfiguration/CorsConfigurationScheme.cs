﻿namespace RAMS.API.CorsConfiguration;

public class CorsConfigurationScheme
{
    public const string SectionName = "Cors";
    public string[] Origins { get; init; } = Array.Empty<string>();
}