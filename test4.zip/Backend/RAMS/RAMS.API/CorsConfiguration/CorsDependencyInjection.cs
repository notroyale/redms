﻿using RAMS.API.CorsConfiguration;

namespace RAMS.API.CorsConfiguration;

public static class CorsDependencyInjection
{
    public static IServiceCollection AddCors(this IServiceCollection services, ConfigurationManager configuration)
    {
        CorsConfigurationScheme corsConfiguration = new();

        configuration.Bind(CorsConfigurationScheme.SectionName, corsConfiguration);

        services.AddCors(options =>
        {
            options.AddDefaultPolicy(policy =>
            {
                policy.WithOrigins(corsConfiguration.Origins)
                    .AllowCredentials()
                    .AllowAnyHeader()
                    .AllowAnyMethod();
            });
        });

        return services;
    }

    public static void AddCors(this IApplicationBuilder app)
    {
        app.UseCors();
    }
}