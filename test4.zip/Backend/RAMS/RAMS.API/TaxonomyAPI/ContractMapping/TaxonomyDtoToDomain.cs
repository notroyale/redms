﻿using RAMS.API.TaxonomyAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.TaxonomyAPI.ContractMapping;

public static class TaxonomyDtoToDomain
{
    public static Taxonomy ToDomain(this AddRequestTaxonomyDto requestDto)
    {
        return new Taxonomy()
        {
            Name = requestDto.Name,
            Description = requestDto.Description,
            IsActive = requestDto.IsActive,
            LevelID = requestDto.LevelID
        };
    }

    public static Taxonomy ToDomain(this UpdateRequestTaxonomyDto requestDto)
    {
        return new Taxonomy()
        {
            Id = requestDto.Id,
            Name = requestDto.Name,
            Description = requestDto.Description,
            IsActive = requestDto.IsActive,
            LevelID = requestDto.LevelID
        };
    }
}