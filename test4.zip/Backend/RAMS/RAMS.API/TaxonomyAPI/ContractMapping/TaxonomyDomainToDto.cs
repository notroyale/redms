﻿using RAMS.API.CommonAPI;
using RAMS.API.TaxonomyAPI.ContractResponses;
using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Common;
using System.Collections.Generic;

namespace RAMS.API.TaxonomyAPI.ContractMapping;

public static class TaxonomyDomainToDto
{
    public static GetAllResponseTaxonomyDto ToGetAllResponseDto(this IEnumerable<Taxonomy> entities)
    {
        ICollection<GetResponseTaxonomyDto> dtos = new List<GetResponseTaxonomyDto>();

        foreach (Taxonomy entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllResponseTaxonomyDto.Create(dtos);
    }
    public static IReadOnlyDictionary<int, List<int>> ToGetAllByLevelResponseDto(this ICollection<ObservationTaxonomy> entities)
    {
        Dictionary<int, List<int>> dtos = new();

        if(entities is null) 
            return dtos;

        foreach (ObservationTaxonomy entity in entities)
        {
            if (entity.Taxonomy is null)
                continue;

            if (!dtos.ContainsKey(entity.Taxonomy.LevelID))
            {
                List<int> list = new()
                {
                    entity.TaxonomyID
                };

                dtos.Add(entity.Taxonomy.LevelID, list);
                continue;
            }

            dtos[entity.Taxonomy.LevelID].Add(entity.TaxonomyID);
        }

        if (!dtos.ContainsKey(3))
        {
            dtos.Add(3, new List<int>());
        }

        return dtos;
    }
 
    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseTaxonomyDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<TaxonomyRelation>? entities)
    {
        ICollection<GetResponseBaseTaxonomyDto> dtos = new List<GetResponseBaseTaxonomyDto>();

        foreach (TaxonomyRelation entity in entities.Items)
        {
            dtos.Add(entity.TaxonomySubLevel.ToGetBaseResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseTaxonomyDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetResponseBaseTaxonomyDto ToGetBaseResponseDto(this Taxonomy entity)
    {
        if (entity is null)
            return null;

        return GetResponseBaseTaxonomyDto.Create(entity.Id, entity.Name, entity.Description, entity.IsActive, entity.LevelID);
    }

    public static GetResponseTaxonomyDto ToGetResponseDto(this Taxonomy entity)
    {
        return GetResponseTaxonomyDto.Create(entity.Id, entity.Name, entity.Description, entity.IsActive, entity.LevelID);
    }

    public static UpdateResponseTaxonomyDto ToUpdateResponseDto(this Taxonomy entity)
    {
        return UpdateResponseTaxonomyDto.Create(entity.Id, entity.Name);
    }

    public static AddResponseTaxonomyDto ToAddResponseDto(this Taxonomy entity)
    {
        return AddResponseTaxonomyDto.Create(entity.Id, entity.Name, entity.Description, entity.IsActive, entity.LevelID);
    }

    public static DeleteResponseTaxonomyDto ToDeleteResponseDto(this Taxonomy entity)
    {
        return DeleteResponseTaxonomyDto.Create(entity.Id, entity.Name);
    }
}