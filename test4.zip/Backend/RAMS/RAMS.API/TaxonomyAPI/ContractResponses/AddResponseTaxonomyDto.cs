﻿namespace RAMS.API.TaxonomyAPI.ContractResponses;

public record AddResponseTaxonomyDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public string Description { get; init; }
    public bool IsActive { get; init; }
    public int LevelID { get; init; }

    protected AddResponseTaxonomyDto(int id, string name, string description, bool isActive, int levelID)
    {
        Id = id;
        Name = name;
        Description = description;
        IsActive = isActive;
        LevelID = levelID;
    }

    public static AddResponseTaxonomyDto Create(int id, string name, string? description, bool isActive, int levelID)
    {
        if (description is null)
            description = string.Empty;

        return new(id, name, description, isActive, levelID);
    }
}