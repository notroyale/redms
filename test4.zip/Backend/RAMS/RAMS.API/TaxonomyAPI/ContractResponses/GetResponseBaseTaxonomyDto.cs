﻿namespace RAMS.API.TaxonomyAPI.ContractResponses;

public record GetResponseBaseTaxonomyDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public string Description { get; init; }
    public bool IsActive { get; init; }
    public int LevelID { get; init; }

    protected GetResponseBaseTaxonomyDto(int id, string name, string description, bool isActive, int levelID)
    {
        Id = id;
        Description = description;
        Name = name;
        IsActive = isActive;
        LevelID = levelID;
    }

    public static GetResponseBaseTaxonomyDto Create(int id, string name, string? description, bool isActive, int levelID)
    {
        if (description is null)
            description = string.Empty;

        return new (id, name, description, isActive, levelID);
    }
}