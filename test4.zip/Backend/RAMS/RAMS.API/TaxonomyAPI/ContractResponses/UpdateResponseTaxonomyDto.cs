﻿namespace RAMS.API.TaxonomyAPI.ContractResponses;

public record UpdateResponseTaxonomyDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected UpdateResponseTaxonomyDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static UpdateResponseTaxonomyDto Create(int id, string name)
    {
        return new(id, name);
    }
}