﻿namespace RAMS.API.TaxonomyAPI.ContractResponses;

public record GetAllResponseTaxonomyDto
{
    public IEnumerable<GetResponseTaxonomyDto> Values { get; init; }

    protected GetAllResponseTaxonomyDto(IEnumerable<GetResponseTaxonomyDto> values)
    {
        Values = values;
    }

    public static GetAllResponseTaxonomyDto Create(IEnumerable<GetResponseTaxonomyDto> values)
    {
        return new(values);
    }
}