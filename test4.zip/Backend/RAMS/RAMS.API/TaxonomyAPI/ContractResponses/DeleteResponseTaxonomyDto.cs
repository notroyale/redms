﻿namespace RAMS.API.TaxonomyAPI.ContractResponses;

public record DeleteResponseTaxonomyDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected DeleteResponseTaxonomyDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static DeleteResponseTaxonomyDto Create(int id, string name)
    {
        return new(id, name);
    }
}