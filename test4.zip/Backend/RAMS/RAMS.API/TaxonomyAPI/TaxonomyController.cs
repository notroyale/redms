﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.CommonAPI;
using RAMS.API.TaxonomyAPI.ContractMapping;
using RAMS.API.TaxonomyAPI.ContractRequests;
using RAMS.Application.Common;
using RAMS.Application.TaxonomyApp;
using RAMS.Domain.Common;

namespace RAMS.API.TaxonomyAPI;

public class TaxonomyController : APIController
{
    private readonly ITaxonomyService _taxonomyService;
    private readonly ICacheService _cache;

    public TaxonomyController(ITaxonomyService taxonomyService, ICacheService memoryCache) : base(memoryCache)
    {
        _taxonomyService = taxonomyService;
        _cache = memoryCache;   
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var tax = await _taxonomyService.GetAllWithRelations();

        return Ok(tax.ToGetAllResponseDto().Values);
    }

    [HttpGet("GetAllChildren")]
    public async Task<IActionResult> GetAllChildren([FromQuery] int[] ids)
    {
        var tax = await _taxonomyService.GetChildrenByIds(ids);

        return Ok(tax.ToGetAllResponseDto().Values);
    }


    [HttpGet("allBase/options")]
    public async Task<IActionResult> GeAllWithOptions([FromQuery] SearchOptions searchOptions)
    {
        var taxonomies = await _taxonomyService.GetAllWithOptions(searchOptions);

        if (taxonomies is null)
            return NotFound();

        return Ok(taxonomies.ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("getByLevel")]
    public async Task<IActionResult> GetByLevel(int level)
    {
        var taxonomies = await _taxonomyService.GetAllAsync(x => x.LevelID == level);

        return Ok(taxonomies.ToGetAllResponseDto().Values.OrderByDescending(x => x.IsActive).ThenBy(x => x.Name));
    }

    [HttpGet("getChildrenByIds")]
    public async Task<IActionResult> GetChildrenByIds([FromQuery] MultipleSearchOptions multipleSearchOptions)
    {
        var taxonomies = await _taxonomyService.GetChildrenByIds(multipleSearchOptions.Ids, 
            multipleSearchOptions.SortColumn, 
            multipleSearchOptions.SortOrder, 
            multipleSearchOptions.Page, 
            multipleSearchOptions.PageSize);

        if (taxonomies is null)
            return NotFound();

        return Ok(taxonomies.ToGetAllBaseWithSearchOptionsResponseDto());
    }


    [HttpGet("get")]
    public async Task<IActionResult> Get(GetRequestTaxonomyDto requestDto)
    {
        var result = await _taxonomyService.GetAsync(ba => ba.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestTaxonomyDto requestDto)
    {
        var result = await _taxonomyService.Insert(requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestTaxonomyDto requestDto)
    {
        var result = await _taxonomyService.Update(ba => ba.Id == requestDto.Id, requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public IActionResult Delete()
    {
        return Ok("Delete taxonomy reached!");
    }
}