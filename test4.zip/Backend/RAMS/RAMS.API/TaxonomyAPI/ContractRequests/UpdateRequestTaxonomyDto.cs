﻿namespace RAMS.API.TaxonomyAPI.ContractRequests;

public record UpdateRequestTaxonomyDto(int Id, string Name, string Description, bool IsActive, int LevelID);