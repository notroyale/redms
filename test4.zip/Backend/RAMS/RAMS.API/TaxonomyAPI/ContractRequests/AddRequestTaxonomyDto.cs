﻿namespace RAMS.API.TaxonomyAPI.ContractRequests;

public record AddRequestTaxonomyDto(string Name, string Description, bool IsActive, int LevelID);