﻿namespace RAMS.API.TaxonomyAPI.ContractRequests;

public record DeleteRequestTaxonomyDto(int Id);