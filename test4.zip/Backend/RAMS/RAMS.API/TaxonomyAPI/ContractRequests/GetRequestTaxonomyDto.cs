﻿namespace RAMS.API.TaxonomyAPI.ContractRequests;

public record GetRequestTaxonomyDto(int Id);