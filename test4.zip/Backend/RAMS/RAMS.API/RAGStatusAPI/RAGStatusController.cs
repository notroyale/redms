﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.RAGStatusAPI.ContractMapping;
using RAMS.API.RAGStatusAPI.ContractRequests;
using RAMS.API.CommonAPI;
using RAMS.Application.RAGStatusApp;
using RAMS.Application.Common;
using RAMS.Domain.Common;

namespace RAMS.API.RAGStatusAPI;

public class RAGStatusController : APIController
{
    private readonly IRAGStatusService _ragStatusService;
    private readonly ICacheService _cache;


    public RAGStatusController(IRAGStatusService ragStatusService, ICacheService memoryCache) : base(memoryCache)
    {
        _ragStatusService = ragStatusService;
        _cache = memoryCache;
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var result = await _ragStatusService.GetAllAsync();

        return Ok(result.ToGetAllResponseDto().Values);
    }

    [HttpGet("allBase/options")]
    public async Task<IActionResult> GetBaseRepositoryDataAsync([FromQuery] SearchOptions searchOptions)
    {
        var ragStatuses = await _ragStatusService.GetAllBaseAsync(searchOptions);

        if (ragStatuses is null)
            return NotFound();

        return Ok(ragStatuses.ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get(GetRequestRAGStatusDto requestDto)
    {
        var result = await _ragStatusService.GetAsync(ba => ba.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestRAGStatusDto requestDto)
    {
        var result = await _ragStatusService.Insert(requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestRAGStatusDto requestDto)
    {
        var result = await _ragStatusService.Update(le => le.Id == requestDto.Id, requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public async Task<IActionResult> Delete(DeleteRequestRAGStatusDto requestDto)
    {
        return Ok("Delete RAG status reached!");
    }
}