﻿namespace RAMS.API.RAGStatusAPI.ContractRequests;

public record DeleteRequestRAGStatusDto(int Id);