﻿namespace RAMS.API.RAGStatusAPI.ContractRequests;

public record UpdateRequestRAGStatusDto(int Id, string Name, string Color, bool IsActive);