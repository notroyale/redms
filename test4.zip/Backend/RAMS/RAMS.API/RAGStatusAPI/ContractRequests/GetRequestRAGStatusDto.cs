﻿namespace RAMS.API.RAGStatusAPI.ContractRequests;

public record GetRequestRAGStatusDto(int Id);