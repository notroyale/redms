﻿namespace RAMS.API.RAGStatusAPI.ContractRequests;

public record AddRequestRAGStatusDto(string Name, string Color, bool IsActive);