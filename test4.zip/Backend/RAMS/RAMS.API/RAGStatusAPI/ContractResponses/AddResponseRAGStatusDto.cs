﻿namespace RAMS.API.RAGStatusAPI.ContractResponses;

public record AddResponseRAGStatusDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected AddResponseRAGStatusDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static AddResponseRAGStatusDto Create(int id, string name)
    {
        return new(id, name);
    }
}