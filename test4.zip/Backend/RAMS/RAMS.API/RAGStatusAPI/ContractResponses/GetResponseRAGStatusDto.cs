﻿namespace RAMS.API.RAGStatusAPI.ContractResponses;

public record GetResponseRAGStatusDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public string Color { get; init; }
    public bool IsActive { get; init; }

    protected GetResponseRAGStatusDto(int id, string name, string color, bool isActive)
    {
        Id = id;
        Name = name;
        Color = color;
        IsActive = isActive;
    }

    protected GetResponseRAGStatusDto()
    {
        Name = string.Empty; 
        Color = string.Empty;
    }

    public static GetResponseRAGStatusDto Empty()
    {
        return new();
    }

    public static GetResponseRAGStatusDto Create(int id, string name, string color, bool isActive)
    {
        return new(id, name, color, isActive);
    }
}