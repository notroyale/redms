﻿namespace RAMS.API.RAGStatusAPI.ContractResponses;

public record UpdateResponseRAGStatusDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected UpdateResponseRAGStatusDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static UpdateResponseRAGStatusDto Create(int id, string name)
    {
        return new(id, name);
    }
}