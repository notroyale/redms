﻿namespace RAMS.API.RAGStatusAPI.ContractResponses;

public record DeleteResponseRAGStatusDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected DeleteResponseRAGStatusDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static DeleteResponseRAGStatusDto Create(int id, string name)
    {
        return new(id, name);
    }
}