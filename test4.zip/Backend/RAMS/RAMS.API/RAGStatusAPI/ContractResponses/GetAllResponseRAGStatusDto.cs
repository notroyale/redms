﻿namespace RAMS.API.RAGStatusAPI.ContractResponses;

public record GetAllResponseRAGStatusDto
{
    public IEnumerable<GetResponseRAGStatusDto> Values { get; init; }

    protected GetAllResponseRAGStatusDto(IEnumerable<GetResponseRAGStatusDto> values)
    {
        Values = values;
    }

    public static GetAllResponseRAGStatusDto Create(IEnumerable<GetResponseRAGStatusDto> values)
    {
        return new(values);
    }
}