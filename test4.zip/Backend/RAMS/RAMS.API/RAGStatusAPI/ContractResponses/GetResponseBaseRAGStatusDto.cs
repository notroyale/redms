﻿namespace RAMS.API.RAGStatusAPI.ContractResponses;

public record GetResponseBaseRAGStatusDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public string Color { get; init; }
    public bool IsActive { get; init; }

    protected GetResponseBaseRAGStatusDto(int id, string name, string color, bool isActive)
    {
        Id = id;
        Name = name;
        Color = color;
        IsActive = isActive;
    }

    public static GetResponseBaseRAGStatusDto Create(int id, string name, string color, bool isActive)
    {
        return new(id, name, color, isActive);
    }
}