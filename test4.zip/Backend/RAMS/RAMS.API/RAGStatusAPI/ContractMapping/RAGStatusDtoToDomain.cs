﻿using RAMS.API.RAGStatusAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.RAGStatusAPI.ContractMapping;

public static class RAGStatusDtoToDomain
{
    public static RAGStatus ToDomain(this AddRequestRAGStatusDto requestDto)
    {
        return new RAGStatus()
        {
            Name = requestDto.Name,
            Color = requestDto.Color,
            IsActive = requestDto.IsActive
        };
    }

    public static RAGStatus ToDomain(this UpdateRequestRAGStatusDto requestDto)
    {
        return new RAGStatus()
        {
            Id = requestDto.Id,
            Name = requestDto.Name,
            Color = requestDto.Color,
            IsActive = requestDto.IsActive
        };
    }
}