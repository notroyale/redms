﻿using RAMS.API.RAGStatusAPI.ContractResponses;
using RAMS.API.CommonAPI;
using RAMS.API.RAGStatusAPI.ContractResponses;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.API.RAGStatusAPI.ContractMapping;

public static class RAGStatusDomainToDto
{
    public static GetAllResponseRAGStatusDto ToGetAllResponseDto(this IEnumerable<RAGStatus> entities)
    {
        ICollection<GetResponseRAGStatusDto> dtos = new List<GetResponseRAGStatusDto>();

        foreach (RAGStatus entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllResponseRAGStatusDto.Create(dtos);
    }

    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseRAGStatusDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<RAGStatus>? entities)
    {
        ICollection<GetResponseBaseRAGStatusDto> dtos = new List<GetResponseBaseRAGStatusDto>();

        foreach (RAGStatus entity in entities.Items)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseRAGStatusDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetResponseBaseRAGStatusDto ToGetBaseResponseDto(this RAGStatus entity)
    {
        return GetResponseBaseRAGStatusDto.Create(entity.Id, entity.Name, entity.Color, entity.IsActive);
    }

    public static GetResponseRAGStatusDto ToGetResponseDto(this RAGStatus entity)
    {
        if (entity is null)
            return GetResponseRAGStatusDto.Empty();

        return GetResponseRAGStatusDto.Create(entity.Id, entity.Name, entity.Color, entity.IsActive);
    }

    public static UpdateResponseRAGStatusDto ToUpdateResponseDto(this RAGStatus entity)
    {
        return UpdateResponseRAGStatusDto.Create(entity.Id, entity.Name);
    }

    public static AddResponseRAGStatusDto ToAddResponseDto(this RAGStatus entity)
    {
        return AddResponseRAGStatusDto.Create(entity.Id, entity.Name);
    }

    public static DeleteResponseRAGStatusDto ToDeleteResponseDto(this RAGStatus entity)
    {
        return DeleteResponseRAGStatusDto.Create(entity.Id, entity.Name);
    }
}