﻿using RAMS.API.TaxonomyAPI.ContractResponses;

namespace RAMS.API.AuditAPI.ContractResponses
{
    public record GetAllAuditResponseDto
    {
        public IEnumerable<GetAuditResponseDto> Values { get; init; }

        protected GetAllAuditResponseDto(IEnumerable<GetAuditResponseDto> values)
        {
            Values = values;
        }

        public static GetAllAuditResponseDto Create(IEnumerable<GetAuditResponseDto> values)
        {
            return new(values);
        }
    }
}
