﻿using RAMS.API.TaxonomyAPI.ContractResponses;
using System.Globalization;

namespace RAMS.API.AuditAPI.ContractResponses
{
    public record GetAuditResponseDto
    {
        public int LogID { get; set; }
        public int ObservationID { get; set; }
        public string ModifiedUser { get; set; }
        public string ModifiedDate { get; set; }
        public string Action { get; set; }
        public string Field { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }

        public GetAuditResponseDto(int logID, int observationID, string modifiedUser, string modifiedDate, string action, string field, string oldValue, string newValue)
        {
            LogID = logID;
            ObservationID = observationID;
            ModifiedUser = modifiedUser;
            ModifiedDate = modifiedDate;
            Action = action;
            Field = field;
            OldValue = oldValue;
            NewValue = newValue;
        }

        public static GetAuditResponseDto Create(int logID, int observationID, string modifiedUser, DateTime? modifiedDate, string action, string field, string oldValue, string newValue)
        {
            return new(logID,observationID,modifiedUser,modifiedDate.Value.ToString("G",
                  DateTimeFormatInfo.InvariantInfo), action,field,oldValue,newValue);
        }
    }
}
