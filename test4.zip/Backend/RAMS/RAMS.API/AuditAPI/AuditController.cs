﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.AuditAPI.ContractMapping;
using RAMS.API.CommonAPI;
using RAMS.Application.AuditApp;
using RAMS.Application.Common;
using RAMS.Application.ObservationApp;
using RAMS.Application.TaxonomyApp;
using RAMS.Domain;

namespace RAMS.API.AuditAPI
{
    public class AuditController : APIController
    {
        private readonly IAuditService _auditService;

        public AuditController(ICacheService cache, IAuditService auditService) : base(cache)
        {
            _auditService = auditService;
        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAll(int observationID)
        {
            IEnumerable<Audit> auditLog = await _auditService.GetAll(observationID);

            return Ok(auditLog.ToGetAllResponseDto().Values);
        }

    }
}
