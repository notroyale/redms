﻿using RAMS.API.AuditAPI.ContractResponses;
using RAMS.API.TaxonomyAPI.ContractResponses;
using RAMS.Domain;

namespace RAMS.API.AuditAPI.ContractMapping
{
    public static class AuditDomainToDto
    {

        public static GetAllAuditResponseDto ToGetAllResponseDto(this IEnumerable<Audit> entities)
        {
            ICollection<GetAuditResponseDto> dtos = new List<GetAuditResponseDto>();

            foreach (Audit entity in entities)
            {
                dtos.Add(entity.ToGetResponseDto());
            }

            return GetAllAuditResponseDto.Create(dtos.OrderByDescending(x => x.ModifiedDate));
        }

        public static GetAuditResponseDto ToGetResponseDto(this Audit entity)
        {
            return GetAuditResponseDto.Create(entity.LogID, entity.ObservationID, entity.ModifiedUser, entity.ModifiedDate, entity.Action, entity.Field, entity.OldValue, entity.NewValue);
        }

    }
}
