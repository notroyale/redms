﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.CommonAPI;
using RAMS.API.ObservationAPI.ContractMapping;
using RAMS.API.ObservationBusinessAreaCountryAPI.ContractMapping;
using RAMS.API.ObservationBusinessAreaCountryAPI.ContractRequests;
using RAMS.Application.Common;
using RAMS.Application.ObservationBusinessAreaCountryApp;

namespace RAMS.API.ObservationBusinessAreaCountryAPI;

public class ObservationBusinessAreaCountryController : APIController
{
    private readonly IObservationBusinessAreaCountryService _service;
    public ObservationBusinessAreaCountryController(ICacheService cache, IObservationBusinessAreaCountryService service) : base(cache)
    {
        _service = service;
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestObservationBusinessAreaCountryDto requestDto)
    {
        var result = await _service.AddAsync(requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpDelete("delete")]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _service.DeleteAsync(id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value);
    }


}