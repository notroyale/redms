﻿namespace RAMS.API.ObservationBusinessAreaCountryAPI.ContractRequests;

public record AddRequestObservationBusinessAreaCountryDto
(
    int ObservationID,
    int BusinessAreaID,
    int CountryID
);
