﻿namespace RAMS.API.ObservationBusinessAreaCountryAPI.ContractRequests;

public record DeleteRequestObservationBusinessAreaCountryDto
(
    int ID,
    int ObservationID,
    int BusinessAreaID,
    int CountryID
);
