﻿namespace RAMS.API.ObservationBusinessAreaCountryAPI.ContractResponses;

public record AddResponseObservationBusinessAreaCountryDto
{
    public bool IsSuccess { get; init; }

    protected AddResponseObservationBusinessAreaCountryDto(bool isSuccess)
    {
        IsSuccess = isSuccess;
    }

    public static AddResponseObservationBusinessAreaCountryDto Create(bool isSuccess)
    {
        return new(isSuccess);
    }
}