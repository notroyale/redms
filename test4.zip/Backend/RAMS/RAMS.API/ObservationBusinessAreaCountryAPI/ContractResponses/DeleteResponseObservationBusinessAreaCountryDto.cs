﻿namespace RAMS.API.ObservationBusinessAreaCountryAPI.ContractResponses;

public record DeleteResponseObservationBusinessAreaCountryDto
{
    public bool IsSuccess { get; init; }

    protected DeleteResponseObservationBusinessAreaCountryDto(bool isSuccess)
    {
        IsSuccess = isSuccess;
    }
    public static DeleteResponseObservationBusinessAreaCountryDto Create(bool isSuccess)
    {
        return new(isSuccess);
    }
}
