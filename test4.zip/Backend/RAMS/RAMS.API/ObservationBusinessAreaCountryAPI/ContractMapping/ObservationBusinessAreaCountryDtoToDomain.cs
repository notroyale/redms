﻿using RAMS.API.ObservationBusinessAreaCountryAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.ObservationBusinessAreaCountryAPI.ContractMapping;

public static class ObservationBusinessAreaCountryDtoToDomain
{
    public static ObservationBusinessArea ToDomain(this AddRequestObservationBusinessAreaCountryDto dto)
    {
        return new ObservationBusinessArea(dto.ObservationID, dto.BusinessAreaID , dto.CountryID);
    }
    public static ObservationBusinessArea ToDomain(this DeleteRequestObservationBusinessAreaCountryDto dto)
    {
        return new ObservationBusinessArea(dto.ID, dto.ObservationID, dto.BusinessAreaID, dto.CountryID);
    }
}
