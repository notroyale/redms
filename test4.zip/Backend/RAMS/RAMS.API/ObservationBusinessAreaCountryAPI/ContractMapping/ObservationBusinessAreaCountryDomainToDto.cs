﻿using RAMS.API.GradeAPI.ContractResponses;
using RAMS.Domain;

namespace RAMS.API.ObservationBusinessAreaCountryAPI.ContractMapping;

public static class ObservationBusinessAreaCountryDomainToDto
{
    public static GetResponseGradeDto ToGetResponseDto(this Grade entity)
    {
        if (entity is null)
        {
            return GetResponseGradeDto.Empty();
        }

        return GetResponseGradeDto.Create(entity.Id, entity.Name, entity.IsActive);
    }
}