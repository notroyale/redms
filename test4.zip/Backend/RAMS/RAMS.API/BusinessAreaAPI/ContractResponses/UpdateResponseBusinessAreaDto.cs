﻿namespace RAMS.API.BusinessAreaAPI.ContractResponses;

public record UpdateResponseBusinessAreaDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected UpdateResponseBusinessAreaDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static UpdateResponseBusinessAreaDto Create(int id, string name)
    {
        return new(id, name);
    }
}