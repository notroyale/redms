﻿namespace RAMS.API.BusinessAreaAPI;

public record AddResponseBusinessAreaDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected AddResponseBusinessAreaDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static AddResponseBusinessAreaDto Create(int id, string name)
    {
        return new(id, name);
    }
}