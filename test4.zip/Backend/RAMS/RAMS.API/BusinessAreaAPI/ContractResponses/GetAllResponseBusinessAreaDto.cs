﻿using RAMS.API.BusinessUnitAPI.ContractResponses;

namespace RAMS.API.BusinessAreaAPI.ContractResponses;

public record GetAllResponseBusinessAreaDto
{
    public IEnumerable<GetResponseBusinessAreaDto> Values { get; init; }

    protected GetAllResponseBusinessAreaDto(IEnumerable<GetResponseBusinessAreaDto> values)
    {
        Values = values;
    }

    public static GetAllResponseBusinessAreaDto Create(IEnumerable<GetResponseBusinessAreaDto> values)
    {
        return new(values);
    }
}