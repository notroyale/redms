﻿using RAMS.API.BusinessUnitAPI.ContractResponses;

namespace RAMS.API.BusinessAreaAPI.ContractResponses;

public record GetResponseBaseBusinessAreaDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public bool IsActive { get; init; }
    public int BusinessUnitID { get; init; }
    public GetResponseBusinessUnitDto BusinessUnit { get; init; }

    protected GetResponseBaseBusinessAreaDto(int id, string name, bool isActive, int businessUnitID, GetResponseBusinessUnitDto businessUnit)
    {
        Id = id;
        Name = name;
        IsActive = isActive;
        BusinessUnitID = businessUnitID;
        BusinessUnit = businessUnit;
    }

    public static GetResponseBaseBusinessAreaDto Create(int id, string name, bool isActive, int businessUnitID, GetResponseBusinessUnitDto businessUnit)
    {
        return new(id, name, isActive, businessUnitID, businessUnit);
    }
}