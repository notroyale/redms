﻿namespace RAMS.API.BusinessAreaAPI.ContractResponses;

public record DeleteResponseBusinessAreaDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected DeleteResponseBusinessAreaDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static DeleteResponseBusinessAreaDto Create(int id, string name)
    {
        return new(id, name);
    }
}