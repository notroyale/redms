﻿namespace RAMS.API.BusinessAreaAPI.ContractResponses;

public record GetBaseResponseBusinessAreaDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public bool IsActive { get; init; }
    public int BusinessUnitID { get; init; }

    protected GetBaseResponseBusinessAreaDto(int id, string name, bool isActive, int businessUnitID)
    {
        Id = id;
        Name = name;
        IsActive = isActive;
        BusinessUnitID = businessUnitID;
    }

    public static GetBaseResponseBusinessAreaDto Create(int id, string name, bool isActive, int businessUnitID)
    {
        return new(id, name, isActive, businessUnitID);
    }
}