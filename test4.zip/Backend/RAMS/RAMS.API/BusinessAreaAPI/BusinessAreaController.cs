﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.BusinessAreaAPI.ContractMapping;
using RAMS.API.BusinessAreaAPI.ContractRequests;
using RAMS.API.CommonAPI;
using RAMS.Application.BusinessAreaApp;
using RAMS.Application.Common;
using RAMS.Application.LegalEntityApp;
using RAMS.Domain.Common;

namespace RAMS.API.BusinessAreaAPI;

public class BusinessAreaController : APIController
{
    private readonly IBusinessAreaService _businessAreaService;
    private readonly ICacheService _cache;

    public BusinessAreaController(IBusinessAreaService businessAreaService, ICacheService memoryCache) : base(memoryCache)
    {
        _businessAreaService = businessAreaService;
        _cache = memoryCache;
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var bas = await _businessAreaService
            .GetAllWithBusinessUnits();

        return Ok(bas.ToGetAllResponseDto());
    }

    [HttpGet("allByBusinessUnit")]
    public async Task<IActionResult> GetAllByBusinessUnitId([FromQuery] int[] ids)
    {
        var bas = await _businessAreaService
            .GetAllByBusinessUnitId(ids);

        return Ok(bas.ToGetAllBaseResponseDto());
    }

    [HttpGet("default")]
    public async Task<IActionResult> GetDefaultBusinessArea()
    {

        var result = await _businessAreaService.GetAsync(ba => ba.IsDefault);

        return Ok(result.Value.ToGetBaseResponseDto());
    }

    [HttpGet("allBase/options")]
    public async Task<IActionResult> GeAllWithOptions([FromQuery] SearchOptions searchOptions)
    {
        var businessAreas = await _businessAreaService.GetAllWithOptions(searchOptions);

        if (businessAreas is null)
            return NotFound();

        return Ok(businessAreas.ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get(GetRequestBusinessAreaDto requestDto)
    {
        var result = await _businessAreaService.GetAsync(ba => ba.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestBusinessAreaDto requestDto)
    {
        var result = await _businessAreaService.Insert(requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestBusinessAreaDto requestDto)
    {
        var result = await _businessAreaService.Update(ba => ba.Id == requestDto.Id, requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public IActionResult Delete(DeleteRequestBusinessAreaDto requestDto)
    {
        return Ok("Delete business area reached!");
    }
}