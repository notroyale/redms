﻿namespace RAMS.API.BusinessAreaAPI.ContractRequests;

public record AddRequestBusinessAreaDto(string Name, bool IsActive, int BusinessUnitID, AddRequestBusinessAreaBusinessUnitDto BusinessUnit);
public record AddRequestBusinessAreaBusinessUnitDto(int Id, string Name);