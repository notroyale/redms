﻿namespace RAMS.API.BusinessAreaAPI.ContractRequests;

public record UpdateRequestBusinessAreaDto(int Id, string Name, bool IsActive, int BusinessUnitID, UpdateRequestBusinessAreaBusinessUnitDto BusinessUnit);
public record UpdateRequestBusinessAreaBusinessUnitDto(int Id, string Name);