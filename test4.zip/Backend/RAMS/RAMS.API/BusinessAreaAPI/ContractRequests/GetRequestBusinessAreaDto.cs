﻿namespace RAMS.API.BusinessAreaAPI.ContractRequests;

public record GetRequestBusinessAreaDto(int Id);