﻿namespace RAMS.API.BusinessAreaAPI.ContractRequests;

public record DeleteRequestBusinessAreaDto(int Id);