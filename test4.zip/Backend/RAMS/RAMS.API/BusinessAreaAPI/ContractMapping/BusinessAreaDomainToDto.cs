﻿using RAMS.API.BusinessAreaAPI.ContractMapping;
using RAMS.API.BusinessAreaAPI.ContractResponses;
using RAMS.API.BusinessUnitAPI.ContractMapping;
using RAMS.API.CommonAPI;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.API.BusinessAreaAPI.ContractMapping;

public static class BusinessAreaDomainToDto
{
    public static IEnumerable<GetBaseResponseBusinessAreaDto> ToGetAllBaseResponseDto(this IEnumerable<BusinessArea> entities)
    {
        ICollection<GetBaseResponseBusinessAreaDto> dtos = new List<GetBaseResponseBusinessAreaDto>();

        foreach (BusinessArea entity in entities)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return dtos;
    }

    public static IEnumerable<GetResponseBusinessAreaDto> ToGetAllResponseDto(this IEnumerable<BusinessArea> entities)
    {
        ICollection<GetResponseBusinessAreaDto> dtos = new List<GetResponseBusinessAreaDto>();

        foreach (BusinessArea entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return dtos;
    }

    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBusinessAreaDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<BusinessArea>? entities)
    {
        ICollection<GetResponseBusinessAreaDto> dtos = new List<GetResponseBusinessAreaDto>();

        foreach (BusinessArea entity in entities.Items)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBusinessAreaDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetBaseResponseBusinessAreaDto ToGetBaseResponseDto(this BusinessArea entity)
    {
        return GetBaseResponseBusinessAreaDto.Create(entity.Id, entity.Name, entity.IsActive, entity.BusinessUnitID);
    }

    public static GetResponseBusinessAreaDto ToGetResponseDto(this BusinessArea entity)
    {
        return GetResponseBusinessAreaDto.Create(entity.Id, entity.Name, entity.IsActive, entity.BusinessUnitID, entity.BusinessUnit.ToGetResponseDto());
    }

    public static UpdateResponseBusinessAreaDto ToUpdateResponseDto(this BusinessArea entity)
    {
        return UpdateResponseBusinessAreaDto.Create(entity.Id, entity.Name);
    }

    public static AddResponseBusinessAreaDto ToAddResponseDto(this BusinessArea entity)
    {
        return AddResponseBusinessAreaDto.Create(entity.Id, entity.Name);
    }

    public static DeleteResponseBusinessAreaDto ToDeleteResponseDto(this BusinessArea entity)
    {
        return DeleteResponseBusinessAreaDto.Create(entity.Id, entity.Name);
    }
}