﻿using RAMS.API.BusinessAreaAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.BusinessAreaAPI.ContractMapping;

public static class BusinessAreaDtoToDomain
{
    public static BusinessArea ToDomain(this AddRequestBusinessAreaDto requestDto)
    {
        return new BusinessArea()
        {
            Name = requestDto.Name,
            BusinessUnitID = requestDto.BusinessUnitID,
            IsActive = requestDto.IsActive,
        };
    }

    public static BusinessArea ToDomain(this UpdateRequestBusinessAreaDto requestDto)
    {
        return new BusinessArea()
        {
            Id = requestDto.Id,
            Name = requestDto.Name,
            BusinessUnitID = requestDto.BusinessUnitID,
            IsActive = requestDto.IsActive,
        };
    }
}