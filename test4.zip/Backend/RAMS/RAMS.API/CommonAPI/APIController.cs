﻿using Microsoft.AspNetCore.Mvc;
using RAMS.Application.Common;
using RAMS.Infrastructure.AuthInfrastructure.AuthorizationSetup;

namespace RAMS.API.CommonAPI;

[ApiController]
[HasPermission(Permission.AccessMember)]
[Route("api/[controller]")]
public class APIController : ControllerBase
{
    private readonly ICacheService _cache;

    public APIController(ICacheService cache)
    {
        _cache = cache;
    }
    public APIController()
    {
    }


    public void SetCache<TEntity>(string cacheKey, TEntity entity, TimeSpan expiration) 
    {
        _cache.Set<TEntity>(cacheKey, entity, expiration);
    }
}