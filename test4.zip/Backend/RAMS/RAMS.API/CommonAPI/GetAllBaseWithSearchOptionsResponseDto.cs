﻿namespace RAMS.API.CommonAPI;

public record GetAllBaseWithSearchOptionsResponseDto<TDto>
{
    public IEnumerable<TDto> Values { get; init; }
    public int Page { get; }
    public int PageSize { get; }
    public int TotalCount { get; }
    public bool HasNextPage => Page * PageSize < TotalCount;
    public bool HasPreviousPage => PageSize > 1;

    protected GetAllBaseWithSearchOptionsResponseDto(IEnumerable<TDto> values, int page, int pageSize, int totalCount)
    {
        Values = values;
        Page = page;
        PageSize = pageSize;
        TotalCount = totalCount;
    }

    public static GetAllBaseWithSearchOptionsResponseDto<TDto> Empty()
    {
        IEnumerable<TDto> values = Enumerable.Empty<TDto>();

        return new(values, 0, 0, values.Count());
    }

    public static GetAllBaseWithSearchOptionsResponseDto<TDto> Create(IEnumerable<TDto> values, int page, int pageSize, int totalCount)
    {
        return new(values, page, pageSize, totalCount);
    }
}