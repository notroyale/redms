﻿namespace RAMS.API.BusinessUnitAPI.ContractRequests;

public record DeleteRequestBusinessUnitDto(int Id);