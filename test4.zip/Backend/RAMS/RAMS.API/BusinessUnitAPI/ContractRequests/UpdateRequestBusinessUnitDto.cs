﻿namespace RAMS.API.BusinessUnitAPI.ContractRequests;

public record UpdateRequestBusinessUnitDto(int Id, string Code, string Name, bool IsActive);