﻿namespace RAMS.API.BusinessUnitAPI.ContractRequests;

public record AddRequestBusinessUnitDto(string Code, string Name, bool IsActive);