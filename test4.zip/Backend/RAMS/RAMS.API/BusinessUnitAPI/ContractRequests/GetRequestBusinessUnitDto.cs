﻿namespace RAMS.API.BusinessUnitAPI.ContractRequests;

public record GetRequestBusinessUnitDto(int Id);