﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.BusinessUnitAPI.ContractMapping;
using RAMS.API.BusinessUnitAPI.ContractRequests;
using RAMS.API.BusinessUnitAPI.ContractResponses;
using RAMS.API.CommonAPI;
using RAMS.Application.BusinessUnitApp;
using RAMS.Application.Common;
using RAMS.Domain.Common;

namespace RAMS.API.BusinessUnitAPI;

public class BusinessUnitController : APIController
{
    private readonly IBusinessUnitService _businessUnitService;
    private readonly ICacheService _cache;


    public BusinessUnitController(IBusinessUnitService businessUnitService, ICacheService memoryCache): base(memoryCache)    
    {
        _businessUnitService = businessUnitService;
        _cache = memoryCache;
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var result = _cache.Get<GetAllResponseBusinessUnitDto>(nameof(GetAllResponseBusinessUnitDto));

        if (result != null)
        {
            return Ok(result.Values);
        }

        var bus = await _businessUnitService.GetAllSortedByNameAsync();

        var response = bus.ToGetAllResponseDto();
        SetCache(nameof(GetAllResponseBusinessUnitDto), response, TimeSpan.FromDays(3));

        return Ok(response);
    }

    [HttpGet("allBase/options")]
    public async Task<IActionResult> GetBaseRepositoryDataAsync([FromQuery] SearchOptions searchOptions)
    {
        var businessUnits = await _businessUnitService.GetAllBaseAsync(searchOptions);

        if (businessUnits is null)
            return NotFound();

        return Ok(businessUnits
            .ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get([FromQuery] GetRequestBusinessUnitDto requestDto)
    {
        var result = await _businessUnitService.GetAsync(bu => bu.Id == requestDto.Id);

        if (result.IsFailure)
            NotFound(result);

        return Ok(result);
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestBusinessUnitDto requestDto)
    {
        var result = await _businessUnitService.Insert(requestDto.ToDomain());
        
        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestBusinessUnitDto requestDto)
    {
        var result = await _businessUnitService.Update(bu => bu.Id == requestDto.Id, requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public async Task<IActionResult> Delete([FromQuery] DeleteRequestBusinessUnitDto requestDto)
    {
        var result = await _businessUnitService.Delete(bu => bu.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }
}