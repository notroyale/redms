﻿using RAMS.API.BusinessUnitAPI.ContractResponses;
using RAMS.API.CommonAPI;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.API.BusinessUnitAPI.ContractMapping;

public static class BusinessUnitDomainToDto
{
    public static GetAllResponseBusinessUnitDto ToGetAllResponseDto(this IEnumerable<BusinessUnit> entities)
    {
        ICollection<GetResponseBusinessUnitDto> dtos = new List<GetResponseBusinessUnitDto>();

        if (entities is null)
            return GetAllResponseBusinessUnitDto.Empty();

        foreach (BusinessUnit entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllResponseBusinessUnitDto.Create(dtos);
    }

    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseBusinessUnitDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<BusinessUnit>? entities)
    {
        ICollection<GetResponseBaseBusinessUnitDto> dtos = new List<GetResponseBaseBusinessUnitDto>();

        foreach (BusinessUnit entity in entities.Items)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseBusinessUnitDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetResponseBaseBusinessUnitDto ToGetBaseResponseDto(this BusinessUnit entity)
    {
        return GetResponseBaseBusinessUnitDto.Create(
            entity.Id,
            entity.Code,
            entity.Name,
            entity.IsActive);
    }

    public static GetResponseBusinessUnitDto ToGetResponseDto(this BusinessUnit entity)
    {
        return GetResponseBusinessUnitDto.Create(entity.Id, entity.Code, entity.Name, entity.IsActive);
    }

    public static UpdateResponseBusinessUnitDto ToUpdateResponseDto(this BusinessUnit entity)
    {
        return UpdateResponseBusinessUnitDto.Create(entity.Id, entity.Name);
    }

    public static AddResponseBusinessUnitDto ToAddResponseDto(this BusinessUnit entity)
    {
        return AddResponseBusinessUnitDto.Create(entity.Id, entity.Name);
    }

    public static DeleteResponseBusinessUnitDto ToDeleteResponseDto(this BusinessUnit entity)
    {
        return DeleteResponseBusinessUnitDto.Create(entity.Id, entity.Name);
    }
}