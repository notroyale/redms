﻿using RAMS.API.BusinessUnitAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.BusinessUnitAPI.ContractMapping;

public static class BusinessUnitDtoToDomain
{
    public static BusinessUnit ToDomain(this AddRequestBusinessUnitDto requestDto)
    {
        return new BusinessUnit()
        {
            Code = requestDto.Code,
            Name = requestDto.Name,
            IsActive = requestDto.IsActive,
        };
    }

    public static BusinessUnit ToDomain(this UpdateRequestBusinessUnitDto requestDto)
    {
        return new BusinessUnit()
        {
            Id = requestDto.Id,
            Code = requestDto.Code,
            Name = requestDto.Name,
            IsActive = requestDto.IsActive,
        };
    }
}