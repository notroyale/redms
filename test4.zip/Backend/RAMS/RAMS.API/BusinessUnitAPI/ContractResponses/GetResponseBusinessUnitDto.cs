﻿namespace RAMS.API.BusinessUnitAPI.ContractResponses;

public record GetResponseBusinessUnitDto
{
    public int Id { get; init; }
    public string Code { get; init; }
    public string Name { get; init; }
    public bool IsActive { get; init; }

    public GetResponseBusinessUnitDto(int id, string code, string name, bool isActive)
    {
        Id = id;
        Code = code;
        Name = name;
        IsActive = isActive;
    }

    public static GetResponseBusinessUnitDto Create(int id, string code, string name, bool isActive)
    {
        return new(id, code, name, isActive);
    }
}