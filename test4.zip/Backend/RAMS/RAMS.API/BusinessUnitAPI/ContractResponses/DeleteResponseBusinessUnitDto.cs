﻿namespace RAMS.API.BusinessUnitAPI.ContractResponses;

public record DeleteResponseBusinessUnitDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected DeleteResponseBusinessUnitDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static DeleteResponseBusinessUnitDto Create(int id, string name)
    {
        return new(id, name);
    }
}