﻿namespace RAMS.API.BusinessUnitAPI.ContractResponses;

public record AddResponseBusinessUnitDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected AddResponseBusinessUnitDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static AddResponseBusinessUnitDto Create(int id, string name)
    {
        return new(id, name);
    }
}