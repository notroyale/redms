﻿namespace RAMS.API.BusinessUnitAPI.ContractResponses;

public record GetAllResponseBusinessUnitDto
{
    public IEnumerable<GetResponseBusinessUnitDto> Values { get; init; }

    protected GetAllResponseBusinessUnitDto(IEnumerable<GetResponseBusinessUnitDto> values)
    {
        Values = values;
    }

    protected GetAllResponseBusinessUnitDto()
    {
        Values = new List<GetResponseBusinessUnitDto>();
    }

    public static GetAllResponseBusinessUnitDto Empty()
    {
        return new();
    }

    public static GetAllResponseBusinessUnitDto Create(IEnumerable<GetResponseBusinessUnitDto> values)
    {
        return new(values);
    }
}