﻿namespace RAMS.API.BusinessUnitAPI.ContractResponses;

public record UpdateResponseBusinessUnitDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected UpdateResponseBusinessUnitDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static UpdateResponseBusinessUnitDto Create(int id, string name)
    {
        return new(id, name);
    }
}