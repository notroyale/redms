﻿using RAMS.API.CountryAPI.ContractResponses;

namespace RAMS.API.FieldHelpTextAPI.ContractResponses
{
    public record GetAllResponseFieldHelpTextDto
    {
        public IEnumerable<GetResponseFieldHelpTextDto> Values { get; init; }

        protected GetAllResponseFieldHelpTextDto(IEnumerable<GetResponseFieldHelpTextDto> values)
        {
            Values = values;
        }

        public static GetAllResponseFieldHelpTextDto Create(IEnumerable<GetResponseFieldHelpTextDto> values)
        {
            return new(values);
        }
    }

}
