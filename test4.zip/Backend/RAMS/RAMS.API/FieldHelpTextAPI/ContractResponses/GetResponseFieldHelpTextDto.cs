﻿using RAMS.API.CountryAPI.ContractResponses;

namespace RAMS.API.FieldHelpTextAPI.ContractResponses
{
    public record GetResponseFieldHelpTextDto
    {
        public string FieldName { get; init; }
        public string? HelpTextValue { get; init; }
        public string? ForNames { get; init; }

        protected GetResponseFieldHelpTextDto(string fieldName,string? helpTextValue,string? forName)
        {
            FieldName = fieldName;
            HelpTextValue = helpTextValue;
            ForNames = forName;
        }

        protected GetResponseFieldHelpTextDto()
        {
            FieldName = string.Empty;
        }

        public static GetResponseFieldHelpTextDto Empty()
        {
            return new();
        }

        public static GetResponseFieldHelpTextDto Create(string fieldName, string? helpTextValue, string? forName)
        {
            return new(fieldName, helpTextValue, forName);
        }
    }
}
