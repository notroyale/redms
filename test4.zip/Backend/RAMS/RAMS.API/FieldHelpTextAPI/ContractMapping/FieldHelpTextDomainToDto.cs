﻿using RAMS.API.CountryAPI.ContractResponses;
using RAMS.API.FieldHelpTextAPI.ContractResponses;
using RAMS.Domain;

namespace RAMS.API.FieldHelpTextAPI.ContractMapping
{
    public static class FieldHelpTextDomainToDto
    {
        public static GetAllResponseFieldHelpTextDto ToGetAllResponseDto(this IEnumerable<FieldHelpText> entities)
        {
            ICollection<GetResponseFieldHelpTextDto> dtos = new List<GetResponseFieldHelpTextDto>();

            foreach (FieldHelpText entity in entities)
            {
                dtos.Add(entity.ToGetResponseDto());
            }

            return GetAllResponseFieldHelpTextDto.Create(dtos);
        }

        public static GetResponseFieldHelpTextDto ToGetResponseDto(this FieldHelpText entity) 
        {
            return GetResponseFieldHelpTextDto.Create(entity.FieldName, entity.HelpTextValue, entity.ForNames);
        }
    }
}