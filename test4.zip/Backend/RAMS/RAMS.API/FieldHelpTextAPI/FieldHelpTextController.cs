﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.CommonAPI;
using RAMS.API.FieldHelpTextAPI.ContractMapping;
using RAMS.Application.Common;
using RAMS.Application.CountryApp;
using RAMS.Application.FieldHelpTextApp;

namespace RAMS.API.FieldHelpTextAPI
{
    public class FieldHelpTextController : APIController
    {
        private readonly IFieldHelpTextService _fieldHelpTextService;
        private readonly ICacheService _cache;


        public FieldHelpTextController(IFieldHelpTextService fieldHelpTextService, ICacheService memoryCache) : base(memoryCache)
        {
            _fieldHelpTextService = fieldHelpTextService;
            _cache = memoryCache;
        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAll()
        {
            var result = await _fieldHelpTextService.GetAllAsync();
            return Ok(result.ToGetAllResponseDto().Values);
        }
    }
}
