﻿using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace RAMS.API.SwaggerAPI;

public class SwaggerOAuthOpenApiConnectOptionsSetup : IPostConfigureOptions<SwaggerGenOptions>
{
    private readonly SwaggerScheme _swaggerScheme;

    public SwaggerOAuthOpenApiConnectOptionsSetup(IOptions<SwaggerScheme> swaggerScheme)
    {
        _swaggerScheme = swaggerScheme.Value;
    }

    public void PostConfigure(string? name, SwaggerGenOptions options)
    {
        Console.WriteLine(name);

        options.SwaggerDoc(_swaggerScheme.Version, new OpenApiInfo
        {
            Title = _swaggerScheme.Title,
            Version = _swaggerScheme.Version
        });

        OAuthOpenApiSecurityScheme oAuthOpenApiSecurityScheme = _swaggerScheme.OAuthOpenApiSecurityScheme;
        JwtSecurityScheme jwtSecurityScheme = _swaggerScheme.JwtSecurityScheme;

        AddOAuthSecurityDefinition(options, oAuthOpenApiSecurityScheme);
        AddJwtSecurityDefinition(options, jwtSecurityScheme);

        AddSecurityRequirements(options, oAuthOpenApiSecurityScheme, jwtSecurityScheme);
    }

    private static void AddJwtSecurityDefinition(SwaggerGenOptions options, JwtSecurityScheme jwtSecurityScheme)
    {
        options.AddSecurityDefinition(jwtSecurityScheme.Scheme, new OpenApiSecurityScheme
        {
            Description = jwtSecurityScheme.Description,
            Name = jwtSecurityScheme.Name,
            In = ParameterLocation.Header,
            Type = SecuritySchemeType.ApiKey,
        });
    }

    private static void AddOAuthSecurityDefinition(SwaggerGenOptions options, OAuthOpenApiSecurityScheme oAuthOpenApiSecurityScheme)
    {
        options.AddSecurityDefinition(oAuthOpenApiSecurityScheme.Scheme, new OpenApiSecurityScheme
        {
            Type = SecuritySchemeType.OAuth2,
            Flows = new OpenApiOAuthFlows
            {
                Implicit = new OpenApiOAuthFlow
                {
                    AuthorizationUrl = new Uri(oAuthOpenApiSecurityScheme.AuthorizationUrl)
                }
            }
        });
    }

    private static void AddSecurityRequirements(SwaggerGenOptions options, OAuthOpenApiSecurityScheme oAuthOpenApiSecurityScheme, JwtSecurityScheme jwtSecurityScheme)
    {
        options.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
            {
                new OpenApiSecurityScheme
                {
                    In = ParameterLocation.Header,
                    Scheme = oAuthOpenApiSecurityScheme.Scheme,
                    Reference = new OpenApiReference
                    {
                        Id = oAuthOpenApiSecurityScheme.Scheme,
                        Type = ReferenceType.SecurityScheme
                    },
                    Name = oAuthOpenApiSecurityScheme.Name,
                    Description = oAuthOpenApiSecurityScheme.Description
                },
                new List<string>()
            },
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = jwtSecurityScheme.Scheme
                    },
                },
                Array.Empty<string>()
            }
        });
    }
}