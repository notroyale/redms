﻿using Microsoft.Extensions.Options;
using Swashbuckle.AspNetCore.SwaggerUI;

namespace RAMS.API.SwaggerAPI;

public class SwaggerOAuthOpenApiConnectUIOptionsSetup : IPostConfigureOptions<SwaggerUIOptions>
{
    private readonly SwaggerScheme _swaggerScheme;

    public SwaggerOAuthOpenApiConnectUIOptionsSetup(IOptions<SwaggerScheme> swaggerScheme)
    {
        _swaggerScheme = swaggerScheme.Value;
    }

    public void PostConfigure(string? name, SwaggerUIOptions options)
    {
        OAuthOpenApiSecurityScheme oAuthOpenApiSecurityScheme = _swaggerScheme.OAuthOpenApiSecurityScheme;

        options.SwaggerEndpoint("/swagger/v1/swagger.json", _swaggerScheme.Version);
        options.RoutePrefix = string.Empty;
        options.OAuthClientId(oAuthOpenApiSecurityScheme.ClientId);
        options.OAuthAdditionalQueryStringParams(new Dictionary<string, string>
        {
            { "resource", oAuthOpenApiSecurityScheme.Resource },
        });
    }
}