﻿namespace RAMS.API.SwaggerAPI;

public class SwaggerScheme
{
    public string Version { get; init; } = string.Empty;
    public string Title { get; init; } = string.Empty;
    public OAuthOpenApiSecurityScheme OAuthOpenApiSecurityScheme { get; init; } = null!;
    public JwtSecurityScheme JwtSecurityScheme { get; init; } = null!;
}