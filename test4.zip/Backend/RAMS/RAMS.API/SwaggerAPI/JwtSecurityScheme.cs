﻿namespace RAMS.API.SwaggerAPI;

public class JwtSecurityScheme
{
    public string Scheme { get; init; } = string.Empty;
    public string Name { get; init; } = string.Empty;
    public string Description { get; init; } = string.Empty;
}
