﻿namespace RAMS.API.SwaggerAPI;

public class OAuthOpenApiSecurityScheme
{
    public string Scheme { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string AuthorizationUrl { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string Resource { get; set; } = string.Empty;
}