﻿namespace RAMS.API.SwaggerAPI;

public static class SwaggerDependencyInjection
{
    public static void AddSwagger(this IServiceCollection services)
    {
        services.ConfigureOptions<SwaggerOAuthOpenApiSecuritySchemeSetup>();
        services.ConfigureOptions<SwaggerOAuthOpenApiConnectOptionsSetup>();
        services.ConfigureOptions<SwaggerOAuthOpenApiConnectUIOptionsSetup>();

        services.AddSwaggerGen();
    }

    public static void AddSwagger(this IApplicationBuilder app)
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }
}