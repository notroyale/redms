﻿using Microsoft.Extensions.Options;

namespace RAMS.API.SwaggerAPI;

public class SwaggerOAuthOpenApiSecuritySchemeSetup : IConfigureOptions<SwaggerScheme>
{
    private const string SectionName = "Swagger";
    private readonly IConfiguration _configuration;

    public SwaggerOAuthOpenApiSecuritySchemeSetup(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public void Configure(SwaggerScheme options)
    {
        _configuration.GetSection(SectionName).Bind(options);
    }
}