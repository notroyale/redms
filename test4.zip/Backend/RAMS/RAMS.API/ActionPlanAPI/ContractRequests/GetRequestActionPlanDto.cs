﻿namespace RAMS.API.ActionPlanAPI.ContractRequests;

public record GetRequestActionPlanDto(int Id);