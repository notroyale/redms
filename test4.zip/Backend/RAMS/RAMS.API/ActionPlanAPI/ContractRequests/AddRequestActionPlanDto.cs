﻿namespace RAMS.API.ActionPlanAPI.ContractRequests;

public record AddRequestActionPlanDto(
    string? ActionTitle,
    string? ActionSummary,
    int? BusinessAreaID,
    int ObservationID,
    string? Assignee,
    DateTime Deadline,
    int? TaxonomyLevel3ID,
    string? ActivityOwner)
{

};