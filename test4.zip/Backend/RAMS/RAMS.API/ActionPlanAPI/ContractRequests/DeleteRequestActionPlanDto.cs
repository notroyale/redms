﻿namespace RAMS.API.ActionPlanAPI.ContractRequests;

public record DeleteRequestActionPlanDto(int Id);