﻿namespace RAMS.API.ActionPlanAPI.ContractRequests;

public record UpdateRequestActionPlanDto(
    int Id,
    string? ActionTitle,
    string? ActionSummary,
    int? BusinessAreaID,
    string? Assignee,
    DateTime Deadline,
    int? TaxonomyLevel3ID,
    string? ActivityOwner,
    string? ActionComment
    ){};