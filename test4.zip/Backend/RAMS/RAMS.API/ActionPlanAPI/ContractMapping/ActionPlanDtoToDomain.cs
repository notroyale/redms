﻿using RAMS.API.ActionPlanAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.ActionPlanAPI.ContractMapping;

public static class ActionPlanDtoToDomain
{
    public static ActionPlan ToDomain(this AddRequestActionPlanDto requestDto)
    {
        return new ActionPlan()
        {
            ActionTitle = requestDto.ActionTitle,
            ActionSummary = requestDto.ActionSummary,
            BusinessAreaID = requestDto.BusinessAreaID,
            ObservationID = requestDto.ObservationID,
            Assignee = requestDto.Assignee,
            Deadline = requestDto.Deadline,
            TaxonomyLevel3ID = requestDto.TaxonomyLevel3ID,
            ActivityOwner = requestDto.ActivityOwner
        };
    }

    public static ActionPlan ToDomain(this UpdateRequestActionPlanDto requestDto)
    {
        return new ActionPlan()
        {
            Id = requestDto.Id,
            ActionTitle = requestDto.ActionTitle,
            ActionSummary = requestDto.ActionSummary,
            BusinessAreaID = requestDto.BusinessAreaID,
            Assignee = requestDto.Assignee,
            Deadline = requestDto.Deadline,
            TaxonomyLevel3ID = requestDto.TaxonomyLevel3ID,
            ActivityOwner = requestDto.ActivityOwner,
            ActionComment1LoD = requestDto.ActionComment
        };
    }
}