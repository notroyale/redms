﻿using RAMS.API.ActionPlanAPI.ContractResponses;
using RAMS.API.CommonAPI;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.API.ActionPlanAPI.ContractMapping;

public static class ActionPlanDomainToDto
{
    public static IEnumerable<GetResponseActionPlanDto> ToGetAllResponseDto(this IEnumerable<ActionPlan> entities)
    {
        ICollection<GetResponseActionPlanDto> dtos = new List<GetResponseActionPlanDto>();

        foreach (ActionPlan entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return dtos;
    }

    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseActionPlanDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<ActionPlan>? entities)
    {
        ICollection<GetResponseBaseActionPlanDto> dtos = new List<GetResponseBaseActionPlanDto>();

        foreach (ActionPlan entity in entities.Items)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseActionPlanDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetResponseBaseActionPlanDto ToGetBaseResponseDto(this ActionPlan entity)
    {
        return GetResponseBaseActionPlanDto.Create(
            entity.Id,
            entity.ActionTitle,
            entity.BusinessAreaID,
            entity.Assignee,
            entity.Deadline,
            entity.ActionStatus,
            entity.TaxonomyLevel3ID,
            entity.ActivityOwner, 
            entity.ActionSummary,
            entity.ActionComment1LoD,
            entity.ClosureDate,
            entity.ClosureUser);
    }

    public static GetResponseActionPlanDto ToGetResponseDto(this ActionPlan entity)
    {
        return GetResponseActionPlanDto.Create(
            entity.Id, 
            entity.ActionTitle,
            entity.ActionSummary, 
            entity.BusinessAreaID,
            entity.ObservationID,
            entity.Assignee,
            entity.Deadline,
            entity.CreationUser,
            entity.CreationDate,
            entity.ModifiedUser,
            entity.ModifiedDate,
            entity.ActionStatus,
            entity.ClosureDate,
            entity.ClosureUser,
            entity.TaxonomyLevel3ID,
            entity.ActionComment1LoD,
            entity.ActionComment1LoDDate,
            entity.ActionComment1LODUser,
            entity.ActivityOwner);
    }

    public static UpdateResponseActionPlanDto ToUpdateResponseDto(this ActionPlan entity)
    {
        return UpdateResponseActionPlanDto.Create(
            entity.Id,
            entity.ActionTitle,
            entity.ActionSummary,
            entity.BusinessAreaID,
            entity.ObservationID,
            entity.Assignee,
            entity.Deadline,
            entity.CreationUser,
            entity.CreationDate,
            entity.ModifiedUser,
            entity.ModifiedDate,
            entity.ActionStatus,
            entity.ClosureDate,
            entity.ClosureUser,
            entity.TaxonomyLevel3ID,
            entity.ActionComment1LoD,
            entity.ActionComment1LoDDate,
            entity.ActionComment1LODUser,
            entity.ActivityOwner);
    }

    public static AddResponseActionPlanDto ToAddResponseDto(this ActionPlan entity)
    {
        return AddResponseActionPlanDto.Create(
            entity.Id,
            entity.ActionTitle,
            entity.ActionSummary,
            entity.BusinessAreaID,
            entity.ObservationID,
            entity.Assignee,
            entity.Deadline,
            entity.CreationUser,
            entity.CreationDate,
            entity.ModifiedUser,
            entity.ModifiedDate,
            entity.ActionStatus,
            entity.ClosureDate,
            entity.ClosureUser,
            entity.TaxonomyLevel3ID,
            entity.ActionComment1LoD,
            entity.ActionComment1LoDDate,
            entity.ActionComment1LODUser,
            entity.ActivityOwner);
    }

    public static DeleteResponseActionPlanDto ToDeleteResponseDto(this ActionPlan entity)
    {
        return DeleteResponseActionPlanDto.Create(entity.Id);
    }
}