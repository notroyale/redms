﻿namespace RAMS.API.ActionPlanAPI.ContractResponses;

public record AddResponseActionPlanDto
{
    public int Id { get; init; }
    public string? ActionTitle { get; init; }
    public string? ActionSummary { get; init; }
    public int? BusinessAreaID { get; init; }
    public int ObservationID { get; init; }
    public string? Assignee { get; init; }
    public DateTime Deadline { get; init; }
    public string? CreationUser { get; init; }
    public DateTime CreationDate { get; init; }
    public string? ModifiedUser { get; init; }
    public DateTime ModifiedDate { get; init; }
    public int ActionStatus { get; init; }
    public DateTime? ClosureDate { get; init; }
    public string? ClosureUser { get; init; }
    public int? TaxonomyLevel3ID { get; init; }
    public string? ActionComment1LoD { get; init; }
    public DateTime? ActionComment1LoDDate { get; init; }
    public string? ActionComment1LODUser { get; init; }
    public string? ActivityOwner { get; init; }

    protected AddResponseActionPlanDto(int id, string? actionTitle, string? actionSummary,
        int? businessAreaID, int observationID, string? assignee, DateTime deadline,
        string? creationUser, DateTime creationDate, string? modifiedUser, DateTime modifiedDate,
        int actionStatus, DateTime? closureDate, string? closureUser, int? taxonomyLevel3ID,
        string? actionComment1LoD, DateTime? actionComment1LoDDate, string? actionComment1LODUser, string? activityOwner)
    {
        Id = id;
        ActionTitle = actionTitle;
        ActionSummary = actionSummary;
        BusinessAreaID = businessAreaID;
        ObservationID = observationID;
        Assignee = assignee;
        Deadline = deadline;
        CreationUser = creationUser;
        CreationDate = creationDate;
        ModifiedUser = modifiedUser;
        ModifiedDate = modifiedDate;
        ActionStatus = actionStatus;
        ClosureDate = closureDate;
        ClosureUser = closureUser;
        TaxonomyLevel3ID = taxonomyLevel3ID;
        ActionComment1LoD = actionComment1LoD;
        ActionComment1LoDDate = actionComment1LoDDate;
        ActionComment1LODUser = actionComment1LODUser;
        ActivityOwner = activityOwner;
    }

    public static AddResponseActionPlanDto Create(int id, string? actionTitle, string? actionSummary,
        int? businessAreaID, int observationID, string? assignee, DateTime deadline,
        string? creationUser, DateTime creationDate, string? modifiedUser, DateTime modifiedDate,
        int actionStatus, DateTime? closureDate, string? closureUser, int? taxonomyLevel3ID,
        string? actionComment1LoD, DateTime? actionComment1LoDDate, string? actionComment1LODUser, string? activityOwner)
    {
        return new(id, actionTitle, actionSummary, businessAreaID, observationID, assignee, deadline,
            creationUser, creationDate, modifiedUser, modifiedDate, actionStatus, closureDate, closureUser,
            taxonomyLevel3ID, actionComment1LoD, actionComment1LoDDate, actionComment1LODUser, activityOwner);
    }
}