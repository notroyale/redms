﻿using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace RAMS.API.ActionPlanAPI.ContractResponses;

public record GetResponseBaseActionPlanDto
{
    public int Id { get; init; }
    public string? ActionTitle { get; init; }
    public string? ActionSummary { get; init; }
    public int? BusinessAreaID { get; init; }
    public string? Assignee { get; init; }
    public DateTime ActionDeadline { get; init; }
    public string? ActionClosureUser { get; init; }
    public DateTime? ActionClosureDate { get; init; }
    public int ActionStatus { get; init; }
    public int? TaxonomyLevel3ID { get; init; }
    public string? ActionActivityOwner { get; init; }
    public string? ActionComment1LoD { get; init; }

    protected GetResponseBaseActionPlanDto(int id, string? actionTitle, int? businessAreaID, string? assignee, DateTime deadline, int actionStatus, int? taxonomyLevel3ID, string? activityOwner, string? actionSummary, string? actionComment1LoD, DateTime? closure, string? closureUser)
    {
        Id = id;
        ActionTitle = actionTitle;
        BusinessAreaID = businessAreaID;
        Assignee = assignee;
        ActionDeadline = deadline;
        ActionStatus = actionStatus;
        TaxonomyLevel3ID = taxonomyLevel3ID;
        ActionActivityOwner = activityOwner;
        ActionSummary = actionSummary;
        ActionComment1LoD = actionComment1LoD;
        ActionClosureDate= closure;
        ActionClosureUser = closureUser;
    }

    public static GetResponseBaseActionPlanDto Create(int id, string? actionTitle, int? businessAreaID, string? assignee, DateTime deadline, int actionStatus, int? taxonomyLevel3ID, string? activityOwner, string actionSummary, string? actionComment1LoD, DateTime? closure, string? closureUser)
    {
        return new(id, actionTitle, businessAreaID, assignee, deadline, actionStatus, taxonomyLevel3ID, activityOwner, actionSummary, actionComment1LoD, closure, closureUser);
    }
}