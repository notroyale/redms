﻿namespace RAMS.API.ActionPlanAPI.ContractResponses;

public record DeleteResponseActionPlanDto
{
    public int Id { get; init; }

    protected DeleteResponseActionPlanDto(int id)
    {
        Id = id;
    }

    public static DeleteResponseActionPlanDto Create(int id)
    {
        return new(id);
    }
}