﻿namespace RAMS.API.ActionPlanAPI.ContractResponses;

public record GetAllResponseActionPlanDto
{
    public IEnumerable<GetResponseActionPlanDto> Values { get; init; }

    protected GetAllResponseActionPlanDto(IEnumerable<GetResponseActionPlanDto> values)
    {
        Values = values;
    }

    public static GetAllResponseActionPlanDto Create(IEnumerable<GetResponseActionPlanDto> values)
    {
        return new(values);
    }
}