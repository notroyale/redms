﻿using Messaging;
using Microsoft.AspNetCore.Mvc;
using RAMS.API.ActionPlanAPI.ContractMapping;
using RAMS.API.ActionPlanAPI.ContractRequests;
using RAMS.API.CommonAPI;
using RAMS.Application.ActionPlanApp;
using RAMS.Application.BusinessUnitApp;
using RAMS.Application.Common;
using RAMS.Application.ObservationApp;
using RAMS.Domain.Common;

namespace RAMS.API.ActionPlanAPI;

public class ActionPlanController : APIController
{
    private readonly IActionPlanService _actionPlanService;
    private readonly ICacheService _cache;


    public ActionPlanController(IActionPlanService ActionPlanService, ICacheService memoryCache) : base(memoryCache)
    {
        _actionPlanService = ActionPlanService;
        _cache = memoryCache;   
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var actionPlans = await _actionPlanService.GetAllAsync();

        return Ok(actionPlans.ToGetAllResponseDto());
    }

    [HttpGet("allBase/options")]
    public async Task<IActionResult> GetBaseRepositoryDataAsync([FromQuery] SearchOptions searchOptions)
    {
        var actionPlans = await _actionPlanService.GetAllBaseAsync(searchOptions);

        if (actionPlans is null)
            return BadRequest();

        return Ok(actionPlans.ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get([FromQuery] GetRequestActionPlanDto requestDto)
    {
        var result = await _actionPlanService.GetAsync(ap => ap.Id == requestDto.Id);

        if (result.IsFailure)
            return BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPost("close")]
    public async Task<IActionResult> Close([FromQuery] GetRequestActionPlanDto requestDto)
    {
        var result = await _actionPlanService.CloseActionPlan(requestDto.Id);

        return Ok(result);
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestActionPlanDto requestDto)
    {
        var result = await _actionPlanService.AddActionPlan(requestDto.ToDomain());

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestActionPlanDto requestDto)
    {
        var result = await _actionPlanService.UpdateActionPlan(requestDto.Id, requestDto.ToDomain());

        return Ok(result);
    }

    [HttpDelete("delete")]
    public async Task<IActionResult> DeleteAsync([FromQuery] DeleteRequestActionPlanDto requestDto)
    {
        var result = await _actionPlanService.Delete(ap => ap.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result); 
    }
}