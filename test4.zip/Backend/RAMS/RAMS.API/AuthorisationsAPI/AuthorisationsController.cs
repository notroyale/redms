﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using RAMS.API.AuthorisationsAPI.ContractMapping;
using RAMS.API.CommonAPI;
using RAMS.Application.AuthorisationApp;
using RAMS.Application.Common;
using RAMS.Domain;
using RAMS.Domain.Enumerators;

namespace RAMS.API.AuthorisationsAPI
{
    public class AuthorisationsController : APIController
    {
        private readonly IAuthorisationService _authorisationService;
        private readonly ICacheService _cache;

        public AuthorisationsController(IAuthorisationService authorisationService, ICacheService cache) : base(cache)
        {
            _authorisationService = authorisationService;
            _cache = cache;
        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAll()
        {
            var authorisations = await _authorisationService.GetAllAsync();

            return Ok(authorisations.ToGetAllResponseDto());
        }

        [HttpGet("allFts")]
        public async Task<IActionResult> GetAllFts()
        {
            var authorisations = await _authorisationService.GetAllAsync();
            var results = authorisations.ToGetFtAccessResponseDto();
            return Ok(results);
        }



    }
}
