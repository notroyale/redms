﻿namespace RAMS.API.AuthorisationsAPI.ContractResponses
{
    public record GetResponseLineOfDefenseDto
    {
       public IEnumerable<GetResponseAuthorisationsDto> EditBU { get; init; }
       public IEnumerable<GetResponseAuthorisationsDto> ViewBU { get; init; }
       public IEnumerable<GetResponseAuthorisationsDto> EditLE { get; init; }
       public IEnumerable<GetResponseAuthorisationsDto> ViewLE { get; init; }
       public IEnumerable<GetResponseAuthorisationsDto> GroupWide { get; init; }


        protected GetResponseLineOfDefenseDto(IEnumerable<GetResponseAuthorisationsDto> editBU, IEnumerable<GetResponseAuthorisationsDto> viewBU, IEnumerable<GetResponseAuthorisationsDto> editLE, IEnumerable<GetResponseAuthorisationsDto> viewLE, IEnumerable<GetResponseAuthorisationsDto> groupWide)
        {
            this.EditBU = editBU;
            this.ViewBU = viewBU;
            this.EditLE = editLE;
            this.ViewLE = viewLE;
            this.GroupWide = groupWide;
        }

        public static GetResponseLineOfDefenseDto Create(IEnumerable<GetResponseAuthorisationsDto> editBU, IEnumerable<GetResponseAuthorisationsDto> viewBU, IEnumerable<GetResponseAuthorisationsDto> editLE, IEnumerable<GetResponseAuthorisationsDto> viewLE, IEnumerable<GetResponseAuthorisationsDto> groupWide)
        {
            return new(editBU, viewBU, editLE, viewLE, groupWide);
        }
    }
}
