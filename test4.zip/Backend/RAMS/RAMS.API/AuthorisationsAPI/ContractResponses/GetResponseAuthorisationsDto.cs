﻿using RAMS.API.BusinessUnitAPI.ContractResponses;
using RAMS.API.LegalEntityAPI.ContractResponses;
using RAMS.Domain;

namespace RAMS.API.AuthorisationsAPI.ContractResponses
{
    public record GetResponseAuthorisationsDto
    {
        public string Name { get; init; }
        public bool IsActive { get; init; }
        public string ShortName { get; init; }
        public string Description { get; init; }
        public string? BusinessUnits { get; init; }
        public string? LegalEntities { get; init; }
        public string Role { get; init; }

        protected GetResponseAuthorisationsDto(string name, bool isActive, string shortName, string description, string? businessUnits, string? legalEntities, Roles role)
        {
            Name = name;
            IsActive = isActive;
            ShortName = shortName;
            Description = description;
            BusinessUnits = businessUnits;
            LegalEntities = legalEntities;
            Role = role.Name;
        }

        public static GetResponseAuthorisationsDto Create(string name, bool isActive, string shortName, string description, string? businessUnits, string? legalEntities, Roles role)
        {
            return new(name, isActive, shortName, description, businessUnits, legalEntities, role);
        }
    }
}
