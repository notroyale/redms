﻿namespace RAMS.API.AuthorisationsAPI.ContractResponses
{
    public record GetResponseFTsDto
    {
        public GetResponseLineOfDefenseDto FirstLoD { get; init; }
        public GetResponseLineOfDefenseDto SecondLoD { get; init; }
        public IEnumerable<GetResponseAuthorisationsDto> ThirdLoD { get; init; }
        public IEnumerable<GetResponseAuthorisationsDto> GRMAccess { get; init; }

        protected GetResponseFTsDto(GetResponseLineOfDefenseDto firstLod, GetResponseLineOfDefenseDto secondLod, IEnumerable<GetResponseAuthorisationsDto> thirdLod, IEnumerable<GetResponseAuthorisationsDto> gRMAccess)
        {
            FirstLoD = firstLod;
            SecondLoD = secondLod;
            ThirdLoD = thirdLod;
            GRMAccess = gRMAccess;
        }

        public static GetResponseFTsDto Create(GetResponseLineOfDefenseDto firstLod, GetResponseLineOfDefenseDto secondLod, IEnumerable<GetResponseAuthorisationsDto> thirdLod, IEnumerable<GetResponseAuthorisationsDto> gRMAccess)
        {
            return new(firstLod, secondLod, thirdLod, gRMAccess);
        }
    }
}
