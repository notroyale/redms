﻿using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using RAMS.API.ActionPlanAPI.ContractResponses;
using RAMS.API.AuthorisationsAPI.ContractResponses;
using RAMS.API.BusinessUnitAPI.ContractMapping;
using RAMS.API.LegalEntityAPI.ContractMapping;
using RAMS.Domain;
using RAMS.Domain.Enumerators;

namespace RAMS.API.AuthorisationsAPI.ContractMapping
{
    public static class AuthorisationsDomainToDto
    {
        public static GetResponseFTsDto ToGetFtAccessResponseDto(this IEnumerable<Authorisation> entities)
        {
            var thirdLod = entities.Where(x => x.BusinessUnits.Count() < 3 && x.BusinessUnits.Any(x => x.Id == (int)BusinessUnits.GroupInternalAudit)).ToList();
            var grmAutorisations = entities.Where(x => x.BusinessUnits.Count() < 3 && x.BusinessUnits.Any(x => x.Id == (int)BusinessUnits.GroupRiskManagement)).ToList();
            var firstLodView = entities.Where(x => x.Role.Any(x => x.Id == (int)AuthRoles.ViewOnlyTableau)).ToList();
            var firstLodEdit = entities.Where(x => x.Role.Any(x => x.Id == (int)AuthRoles.ViewComments)).ToList();
            var secondLodEdit = entities.Where(x => x.Role.Any(x => x.Id == (int)AuthRoles.ViewEdit)).ToList();
            var secondLodView = entities.Where(x => x.Role.Any(x => x.Id == (int)AuthRoles.ViewOnly)).ToList();


            GetResponseLineOfDefenseDto firstLodFts = GetLineOfDefenseDto(firstLodEdit, firstLodView);
            GetResponseLineOfDefenseDto secondLodFts = GetLineOfDefenseDto(secondLodEdit, secondLodView);
            //foreach (Authorisation entity in entities)
            //{
            //    dtos.Add(entity.ToGetResponseDto());
            //}

            //GetResponseFTsDto dto = new GetResponseFTsDto(null, null, null, null);
            return GetResponseFTsDto.Create(firstLodFts, secondLodFts, thirdLod.ToGetAllResponseDto(), grmAutorisations.ToGetAllResponseDto()) ;
        }

        private static GetResponseLineOfDefenseDto GetLineOfDefenseDto(IEnumerable<Authorisation> editEntities, IEnumerable<Authorisation> viewEntities) //fix database fts and lookup legal entity count to replace hardcoded values
        {
            int majorityOfFts = 15;

            var viewLE = viewEntities.Where(x => x.LegalEntities.Count() > 0 && x.LegalEntities.Count() < majorityOfFts).ToGetListResponseDto();
            var viewBU = viewEntities.Where(x => x.LegalEntities.Count() == 0 && x.BusinessUnits.Count() < majorityOfFts).ToGetListResponseDto();
            var editLE = editEntities.Where(x => x.LegalEntities.Count() > 0 && x.LegalEntities.Count() < majorityOfFts).ToGetListResponseDto();
            var editBU = editEntities.Where(x => x.LegalEntities.Count() == 0 && x.BusinessUnits.Count() < majorityOfFts).ToGetListResponseDto();
            var groupwide = editEntities.Concat(viewEntities).Where(x => x.BusinessUnits.Count() > majorityOfFts || x.LegalEntities.Count() > majorityOfFts).ToGetListResponseDto();

            return GetResponseLineOfDefenseDto.Create(editBU, viewBU, editLE, viewLE, groupwide);
        }

        public static IEnumerable<GetResponseAuthorisationsDto> ToGetAllResponseDto(this IEnumerable<Authorisation> entities)
        {
            ICollection<GetResponseAuthorisationsDto> dtos = new List<GetResponseAuthorisationsDto>();

            foreach (Authorisation entity in entities)
            {
                dtos.Add(entity.ToGetResponseDto());
            }

            return dtos;
        }
        
        public static IEnumerable<GetResponseAuthorisationsDto> ToGetListResponseDto(this IEnumerable<Authorisation> entities)
        {
            ICollection<GetResponseAuthorisationsDto> dtos = new List<GetResponseAuthorisationsDto>();

            foreach (Authorisation entity in entities)
            {
                dtos.Add(entity.ToGetResponseDto());
            }

            return dtos;
        }

        public static GetResponseAuthorisationsDto ToGetResponseDto(this Authorisation entity)
        {
            return GetResponseAuthorisationsDto.Create(
                entity.Name,
                entity.IsActive,
                entity.ShortName,
                entity.Description,
                entity.BusinessUnits.Where(x => x.Id != (int)BusinessUnits.GroupWide).FirstOrDefault(new BusinessUnit { Id =0, Code="", Name="", IsActive=false}).Name,
                entity.LegalEntities.FirstOrDefault(new LegalEntity { Id=0, Name="", IsActive=false}).ToGetBaseResponseDto().Name,
                entity.Role.FirstOrDefault(new Roles { Id=0})
            );
        }
    }
}
