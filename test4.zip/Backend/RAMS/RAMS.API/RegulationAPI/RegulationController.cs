﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.RegulationAPI.ContractMapping;
using RAMS.API.RegulationAPI.ContractRequests;
using RAMS.API.CommonAPI;
using RAMS.Application.RegulationApp;
using RAMS.Application.Common;
using RAMS.Domain.Common;

namespace RAMS.API.RegulationAPI;

public class RegulationController : APIController
{
    private readonly IRegulationService _regulationService;
    private readonly ICacheService _cache;


    public RegulationController(IRegulationService regulationService, ICacheService memoryCache) : base(memoryCache)
    {
        _regulationService = regulationService;
        _cache = memoryCache;
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var result = await _regulationService.GetAllAsync();

        return Ok(result.ToGetAllResponseDto().Values);
    }

    [HttpGet("allBase/options")]
    public async Task<IActionResult> GetBaseRepositoryDataAsync([FromQuery] SearchOptions searchOptions)
    {
        var regulations = await _regulationService.GetAllBaseAsync(searchOptions);

        if (regulations is null)
            return NotFound();

        return Ok(regulations.ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get(GetRequestRegulationDto requestDto)
    {
        var result = await _regulationService.GetAsync(ba => ba.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestRegulationDto requestDto)
    {
        var result = await _regulationService.Insert(requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestRegulationDto requestDto)
    {
        var result = await _regulationService.Update(ba => ba.Id == requestDto.Id, requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public async Task<IActionResult> Delete(DeleteRequestRegulationDto requestDto)
    {
        return Ok("Delete regulation reached!");
    }
}