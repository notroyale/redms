﻿namespace RAMS.API.RegulationAPI.ContractResponses;

public record GetResponseRegulationDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public bool IsActive { get; init; }
    public bool HasComment { get; init; }

    protected GetResponseRegulationDto(int id, string name, bool isActive, bool hasComment)
    {
        Id = id;
        Name = name;
        IsActive = isActive;
        HasComment = hasComment;
    }

    public static GetResponseRegulationDto Create(int id, string name, bool isActive, bool hasComment)
    {
        return new(id, name, isActive, hasComment);
    }
}