﻿namespace RAMS.API.RegulationAPI.ContractResponses;

public record DeleteResponseRegulationDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected DeleteResponseRegulationDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static DeleteResponseRegulationDto Create(int id, string name)
    {
        return new(id, name);
    }
}