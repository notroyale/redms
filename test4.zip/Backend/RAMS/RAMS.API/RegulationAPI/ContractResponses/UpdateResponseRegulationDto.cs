﻿namespace RAMS.API.RegulationAPI.ContractResponses;

public record UpdateResponseRegulationDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected UpdateResponseRegulationDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static UpdateResponseRegulationDto Create(int id, string name)
    {
        return new(id, name);
    }
}