﻿namespace RAMS.API.RegulationAPI.ContractResponses;

public record GetAllResponseRegulationDto
{
    public IEnumerable<GetResponseRegulationDto> Values { get; init; }

    protected GetAllResponseRegulationDto(IEnumerable<GetResponseRegulationDto> values)
    {
        Values = values;
    }

    public static GetAllResponseRegulationDto Create(IEnumerable<GetResponseRegulationDto> values)
    {
        return new(values);
    }
}