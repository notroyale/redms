﻿using RAMS.API.RegulationAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.RegulationAPI.ContractMapping;

public static class RegulationDtoToDomain
{
    public static Regulation ToDomain(this AddRequestRegulationDto requestDto)
    {
        return new Regulation()
        {
            Name = requestDto.Name,
            IsActive = requestDto.IsActive,
            HasComment = requestDto.HasComment
        };
    }

    public static Regulation ToDomain(this UpdateRequestRegulationDto requestDto)
    {
        return new Regulation()
        {
            Id = requestDto.Id,
            Name = requestDto.Name,
            IsActive = requestDto.IsActive,
            HasComment = requestDto.HasComment
        };
    }
}