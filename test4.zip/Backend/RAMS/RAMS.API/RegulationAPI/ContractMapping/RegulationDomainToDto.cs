﻿using RAMS.API.CommonAPI;
using RAMS.API.RegulationAPI.ContractResponses;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.API.RegulationAPI.ContractMapping;

public static class RegulationDomainToDto
{
    public static GetAllResponseRegulationDto ToGetAllResponseDto(this IEnumerable<Regulation> entities)
    {
        ICollection<GetResponseRegulationDto> dtos = new List<GetResponseRegulationDto>();

        foreach (Regulation entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllResponseRegulationDto.Create(dtos);
    }

    public static IReadOnlyList<int> ToGetAllResponseDto(this ICollection<ObservationRegulation> entities)
    {
        List<int> dtos = new();

        if (entities is null) 
            return dtos;

        foreach (ObservationRegulation entity in entities)
        {
            dtos.Add(entity.RegulationID);
        }

        return dtos;
    }

    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseRegulationDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<Regulation>? entities)
    {
        ICollection<GetResponseBaseRegulationDto> dtos = new List<GetResponseBaseRegulationDto>();

        foreach (Regulation entity in entities.Items)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseRegulationDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetResponseBaseRegulationDto ToGetBaseResponseDto(this Regulation entity)
    {
        return GetResponseBaseRegulationDto.Create(entity.Id, entity.Name, entity.IsActive, entity.HasComment);
    }

    public static GetResponseRegulationDto ToGetResponseDto(this Regulation entity)
    {
        return GetResponseRegulationDto.Create(entity.Id, entity.Name, entity.IsActive, entity.HasComment);
    }
    public static GetResponseRegulationDto ToGetResponseDtoWithComment(this Regulation entity)
    {
        return GetResponseRegulationDto.Create(entity.Id, entity.Name, entity.IsActive, entity.HasComment);
    }

    public static UpdateResponseRegulationDto ToUpdateResponseDto(this Regulation entity)
    {
        return UpdateResponseRegulationDto.Create(entity.Id, entity.Name);
    }

    public static AddResponseRegulationDto ToAddResponseDto(this Regulation entity)
    {
        return AddResponseRegulationDto.Create(entity.Id, entity.Name);
    }

    public static DeleteResponseRegulationDto ToDeleteResponseDto(this Regulation entity)
    {
        return DeleteResponseRegulationDto.Create(entity.Id, entity.Name);
    }
}