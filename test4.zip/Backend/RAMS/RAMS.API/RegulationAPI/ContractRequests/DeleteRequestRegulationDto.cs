﻿namespace RAMS.API.RegulationAPI.ContractRequests;

public record DeleteRequestRegulationDto(int Id);