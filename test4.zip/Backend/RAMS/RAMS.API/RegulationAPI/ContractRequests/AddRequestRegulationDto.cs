﻿namespace RAMS.API.RegulationAPI.ContractRequests;

public record AddRequestRegulationDto(string Name, bool IsActive, bool HasComment);