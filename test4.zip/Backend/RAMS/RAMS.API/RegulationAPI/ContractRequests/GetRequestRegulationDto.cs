﻿namespace RAMS.API.RegulationAPI.ContractRequests;

public record GetRequestRegulationDto(int Id);