﻿namespace RAMS.API.RegulationAPI.ContractRequests;

public record UpdateRequestRegulationDto(int Id, string Name, bool IsActive, bool HasComment);