﻿namespace RAMS.API.CountryAPI.ContractRequests;

public record GetRequestCountryDto(int Id);