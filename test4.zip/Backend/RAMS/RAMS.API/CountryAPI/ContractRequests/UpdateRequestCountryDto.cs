﻿namespace RAMS.API.CountryAPI.ContractRequests;

public record UpdateRequestCountryDto(int Id, string Name, bool IsActive);