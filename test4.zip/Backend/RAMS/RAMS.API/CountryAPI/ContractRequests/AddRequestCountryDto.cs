﻿namespace RAMS.API.CountryAPI.ContractRequests;

public record AddRequestCountryDto(string Name, bool IsActive);