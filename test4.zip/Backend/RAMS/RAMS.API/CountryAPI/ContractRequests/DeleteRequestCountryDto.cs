﻿namespace RAMS.API.CountryAPI.ContractRequests;

public record DeleteRequestCountryDto(int Id);