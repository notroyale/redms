﻿using RAMS.API.CountryAPI.ContractResponses;
using RAMS.API.CommonAPI;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.API.CountryAPI.ContractMapping;

public static class CountryDomainToDto
{
    public static GetAllResponseCountryDto ToGetAllResponseDto(this IEnumerable<Country> entities)
    {
        ICollection<GetResponseCountryDto> dtos = new List<GetResponseCountryDto>();

        foreach (Country entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllResponseCountryDto.Create(dtos);
    }

    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseCountryDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<Country>? entities)
    {
        ICollection<GetResponseBaseCountryDto> dtos = new List<GetResponseBaseCountryDto>();

        foreach (Country entity in entities.Items)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseCountryDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetResponseBaseCountryDto ToGetBaseResponseDto(this Country entity)
    {
        return GetResponseBaseCountryDto.Create(entity.Id, entity.Name, entity.IsActive);
    }

    public static GetResponseCountryDto ToGetResponseDto(this Country entity)
    {
        return GetResponseCountryDto.Create(entity.Id, entity.Name, entity.IsActive);
    }

    public static UpdateResponseCountryDto ToUpdateResponseDto(this Country entity)
    {
        return UpdateResponseCountryDto.Create(entity.Id, entity.Name);
    }

    public static AddResponseCountryDto ToAddResponseDto(this Country entity)
    {
        return AddResponseCountryDto.Create(entity.Id, entity.Name);
    }

    public static DeleteResponseCountryDto ToDeleteResponseDto(this Country entity)
    {
        return DeleteResponseCountryDto.Create(entity.Id, entity.Name);
    }
}