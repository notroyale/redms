﻿using RAMS.API.CountryAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.CountryAPI.ContractMapping;

public static class CountryDtoToDomain
{
    public static Country ToDomain(this AddRequestCountryDto requestDto)
    {
        return new Country()
        {
            Name = requestDto.Name,
            IsActive = requestDto.IsActive
        };
    }

    public static Country ToDomain(this UpdateRequestCountryDto requestDto)
    {
        return new Country()
        {
            Id = requestDto.Id,
            Name = requestDto.Name,
            IsActive = requestDto.IsActive
        };
    }
}