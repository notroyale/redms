﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.CountryAPI.ContractMapping;
using RAMS.API.CountryAPI.ContractRequests;
using RAMS.API.CommonAPI;
using RAMS.Application.CountryApp;
using RAMS.Application.Common;
using RAMS.Domain.Common;

namespace RAMS.API.CountryAPI;

public class CountryController : APIController
{
    private readonly ICountryService _countryService;
    private readonly ICacheService _cache;


    public CountryController(ICountryService countryService, ICacheService memoryCache) : base(memoryCache)
    {
        _countryService = countryService;
        _cache = memoryCache;
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var result = await _countryService.GetAllAsync();
        return Ok(result
            .ToGetAllResponseDto().Values.OrderByDescending(x => x.IsActive).ThenBy(x=>x.Name));
    }

    [HttpGet("allBase/options")]
    public async Task<IActionResult> GetBaseRepositoryDataAsync([FromQuery] SearchOptions searchOptions)
    {
        var countries = await _countryService.GetAllBaseAsync(searchOptions);

        if (countries is null)
            return NotFound();

        return Ok(countries
            .ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get(GetRequestCountryDto requestDto)
    {
        var result = await _countryService.GetAsync(ba => ba.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestCountryDto requestDto)
    {
        var result = await _countryService.Insert(requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestCountryDto requestDto)
    {
        var result = await _countryService.Update(ba => ba.Id == requestDto.Id, requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public IActionResult Delete(DeleteRequestCountryDto requestDto)
    {
        return Ok("Delete country reached!");
    }
}