﻿namespace RAMS.API.CountryAPI.ContractResponses;

public record UpdateResponseCountryDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected UpdateResponseCountryDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static UpdateResponseCountryDto Create(int id, string name)
    {
        return new(id, name);
    }
}