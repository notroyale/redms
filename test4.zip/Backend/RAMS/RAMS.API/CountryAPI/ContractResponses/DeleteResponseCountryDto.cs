﻿namespace RAMS.API.CountryAPI.ContractResponses;

public record DeleteResponseCountryDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected DeleteResponseCountryDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static DeleteResponseCountryDto Create(int id, string name)
    {
        return new(id, name);
    }
}