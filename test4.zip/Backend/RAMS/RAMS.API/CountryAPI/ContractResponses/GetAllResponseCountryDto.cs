﻿namespace RAMS.API.CountryAPI.ContractResponses;

public record GetAllResponseCountryDto
{
    public IEnumerable<GetResponseCountryDto> Values { get; init; }

    protected GetAllResponseCountryDto(IEnumerable<GetResponseCountryDto> values)
    {
        Values = values;
    }

    public static GetAllResponseCountryDto Create(IEnumerable<GetResponseCountryDto> values)
    {
        return new(values);
    }
}