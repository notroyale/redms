﻿namespace RAMS.API.CountryAPI.ContractResponses;

public record GetResponseBaseCountryDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public bool IsActive { get; init; }

    public GetResponseBaseCountryDto(int id, string name, bool isActive)
    {
        Id = id;
        Name = name;
        IsActive = isActive;
    }

    public static GetResponseBaseCountryDto Create(int id, string name, bool isActive)
    {
        return new(id, name, isActive);
    }
}