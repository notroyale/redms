﻿namespace RAMS.API.CountryAPI.ContractResponses;

public record GetResponseCountryDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public bool IsActive { get; init; }

    protected GetResponseCountryDto(int id, string name, bool isActive)
    {
        Id = id;
        Name = name;
        IsActive = isActive;
    }

    protected GetResponseCountryDto()
    {
        Name = string.Empty;
    }

    public static GetResponseCountryDto Empty()
    {
        return new();
    }

    public static GetResponseCountryDto Create(int id, string name, bool isActive)
    {
        return new(id, name, isActive);
    }
}