﻿using RAMS.API.LegalEntityAPI.ContractMapping;
using RAMS.API.LegalEntityAPI.ContractResponses;
using RAMS.API.BusinessUnitAPI.ContractMapping;
using RAMS.Domain;
using RAMS.API.BusinessUnitAPI.ContractResponses;
using RAMS.API.CommonAPI;
using RAMS.Application.Common;

namespace RAMS.API.LegalEntityAPI.ContractMapping;

public static class LegalEntityDomainToDto
{
    public static GetAllResponseLegalEntityDto ToGetAllResponseDto(this IEnumerable<LegalEntity> entities)
    {
        ICollection<GetResponseLegalEntityDto> dtos = new List<GetResponseLegalEntityDto>();

        foreach (LegalEntity entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllResponseLegalEntityDto.Create(dtos);
    }

    public static IEnumerable<GetResponseBaseLegalEntityDto> ToGetAllBaseResponseDto(this IEnumerable<LegalEntity> entities)
    {
        ICollection<GetResponseBaseLegalEntityDto> dtos = new List<GetResponseBaseLegalEntityDto>();

        foreach (LegalEntity entity in entities)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return dtos;
    }

    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseLegalEntityDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<LegalEntity>? entities)
    {
        ICollection<GetResponseLegalEntityDto> dtos = new List<GetResponseLegalEntityDto>();

        foreach (LegalEntity entity in entities.Items)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseLegalEntityDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }


    public static IEnumerable<GetResponseBusinessUnitDto> ToGetAllWithLegalEntityResponseDto(this IEnumerable<BusinessUnit> entities)
    {
        ICollection<GetResponseBusinessUnitDto> dtos = new List<GetResponseBusinessUnitDto>();

        foreach (BusinessUnit entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return dtos;
    }

    public static GetResponseBaseLegalEntityDto ToGetBaseResponseDto(this LegalEntity entity)
    {
        return GetResponseBaseLegalEntityDto.Create(entity.Id, entity.Name, entity.IsActive);
    }

    public static GetResponseLegalEntityDto ToGetResponseDto(this LegalEntity entity)
    {
        return GetResponseLegalEntityDto.Create(entity.Id, entity.Name, entity.IsActive, entity.BusinessUnits.ToGetAllWithLegalEntityResponseDto());
    }

    public static UpdateResponseLegalEntityDto ToUpdateResponseDto(this LegalEntity entity)
    {
        return UpdateResponseLegalEntityDto.Create(entity.Id, entity.Name);
    }

    public static AddResponseLegalEntityDto ToAddResponseDto(this LegalEntity entity)
    {
        return AddResponseLegalEntityDto.Create(entity.Id, entity.Name);
    }

    public static DeleteResponseLegalEntityDto ToDeleteResponseDto(this LegalEntity entity)
    {
        return DeleteResponseLegalEntityDto.Create(entity.Id, entity.Name);
    }
}