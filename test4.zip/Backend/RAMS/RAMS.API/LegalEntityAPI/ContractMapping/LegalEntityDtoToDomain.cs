﻿using RAMS.API.LegalEntityAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.LegalEntityAPI.ContractMapping;

public static class LegalEntityDtoToDomain
{
    public static LegalEntity ToDomain(this AddRequestLegalEntityDto requestDto)
    {
        return new LegalEntity()
        {
            Name = requestDto.Name,
            //BusinessUnits = requestDto.BusinessUnits.ToDomain(),
            IsActive = requestDto.IsActive,
        };
    }

    public static LegalEntity ToDomain(this UpdateRequestLegalEntityDto requestDto)
    {
        return new LegalEntity()
        {
            Id = requestDto.Id,
            Name = requestDto.Name,
            //BusinessUnits = requestDto.BusinessUnits.ToDomain(),
            IsActive = requestDto.IsActive,
        };
    }

    public static BusinessUnit ToDomain(this AddRequestLegalEntityBusinessUnitDto requestDto)
    {
        return new BusinessUnit()
        {
            Id = requestDto.Id,
            Name = requestDto.Name
        };
    }

    public static IEnumerable<BusinessUnit> ToDomain(this IEnumerable<AddRequestLegalEntityBusinessUnitDto> requestDto)
    {
        ICollection<BusinessUnit> list = new List<BusinessUnit>();

        foreach (AddRequestLegalEntityBusinessUnitDto item in requestDto)
            list.Add(item.ToDomain());

        return list;
    }

    public static BusinessUnit ToDomain(this UpdateRequestLegalEntityBusinessUnitDto requestDto)
    {
        return new BusinessUnit()
        {
            Id = requestDto.Id,
            Name = requestDto.Name
        };
    }

    public static IEnumerable<BusinessUnit> ToDomain(this IEnumerable<UpdateRequestLegalEntityBusinessUnitDto> requestDto)
    {
        ICollection<BusinessUnit> list = new List<BusinessUnit>();

        foreach (UpdateRequestLegalEntityBusinessUnitDto item in requestDto)
            list.Add(item.ToDomain());

        return list;
    }
}