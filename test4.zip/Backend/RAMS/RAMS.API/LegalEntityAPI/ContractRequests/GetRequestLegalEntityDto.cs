﻿using RAMS.API.BusinessUnitAPI.ContractRequests;

namespace RAMS.API.LegalEntityAPI.ContractRequests;

public record GetRequestLegalEntityDto(int Id);