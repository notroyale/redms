﻿namespace RAMS.API.LegalEntityAPI.ContractRequests;

public record UpdateRequestLegalEntityDto(int Id, string Name, bool IsActive, IEnumerable<UpdateRequestLegalEntityBusinessUnitDto> BusinessUnits);
public record UpdateRequestLegalEntityBusinessUnitDto(int Id, string Name);