﻿namespace RAMS.API.LegalEntityAPI.ContractRequests;

public record DeleteRequesLegalEntityDto(int Id);