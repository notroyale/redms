﻿namespace RAMS.API.LegalEntityAPI.ContractRequests;

public record AddRequestLegalEntityDto(string Name, bool IsActive, IEnumerable<AddRequestLegalEntityBusinessUnitDto> BusinessUnits);
public record AddRequestLegalEntityBusinessUnitDto(int Id, string Name);