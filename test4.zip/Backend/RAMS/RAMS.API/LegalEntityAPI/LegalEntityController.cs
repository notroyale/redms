﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.CommonAPI;
using RAMS.API.LegalEntityAPI.ContractMapping;
using RAMS.API.LegalEntityAPI.ContractRequests;
using RAMS.Application.Common;
using RAMS.Application.LegalEntityApp;
using RAMS.Domain.Common;

namespace RAMS.API.LegalEntityAPI;

public class LegalEntityController : APIController
{
    private readonly ILegalEntityService _legalEntityService;
    private readonly ICacheService _cache;


    public LegalEntityController(ILegalEntityService legalEntityService, ICacheService memoryCache) : base(memoryCache)
    {
        _legalEntityService = legalEntityService;
        _cache = memoryCache;   
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var bus = await _legalEntityService.GetAllWithBusinessUnits();

        return Ok(bus.ToGetAllResponseDto().Values);
    }

    [HttpGet("allByBusinessUnit")]
    public async Task<IActionResult> GetAllByBusinessUnitId([FromQuery] int[] ids)
    {
        var bus = await _legalEntityService.GetAllByBusinessUnitId(ids);

        return Ok(bus.ToGetAllBaseResponseDto());
    }

    [HttpGet("allBase/options")]
    public async Task<IActionResult> GeAllWithOptions([FromQuery] SearchOptions searchOptions)
    {
        var legalEntities = await _legalEntityService.GetAllWithOptions(searchOptions);

        if (legalEntities is null)
            return NotFound();

        return Ok(legalEntities
            .ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get(GetRequestLegalEntityDto requestDto)
    {
        var result = await _legalEntityService.GetAsync(ba => ba.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestLegalEntityDto requestDto)
    {
        var result = await _legalEntityService.Insert(requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestLegalEntityDto requestDto)
    {
        var result = await _legalEntityService.Update(le => le.Id == requestDto.Id, requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public IActionResult Delete()
    {
        return Ok("Delete legal entity reached!");
    }
}