﻿namespace RAMS.API.LegalEntityAPI.ContractResponses;

public record UpdateResponseLegalEntityDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected UpdateResponseLegalEntityDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static UpdateResponseLegalEntityDto Create(int id, string name)
    {
        return new(id, name);
    }
}