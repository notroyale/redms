﻿using RAMS.API.BusinessUnitAPI.ContractResponses;

namespace RAMS.API.LegalEntityAPI.ContractResponses;

public record GetResponseLegalEntityDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public bool IsActive { get; init; }
    public IEnumerable<GetResponseBusinessUnitDto> BusinessUnits { get; init; }

    protected GetResponseLegalEntityDto(int id, string name, bool isActive, IEnumerable<GetResponseBusinessUnitDto> businessUnits)
    {
        Id = id;
        Name = name;
        IsActive = isActive;
        BusinessUnits = businessUnits;
    }

    public static GetResponseLegalEntityDto Create(int id, string name, bool isActive, IEnumerable<GetResponseBusinessUnitDto> businessUnits)
    {
        return new(id, name, isActive, businessUnits);
    }
}