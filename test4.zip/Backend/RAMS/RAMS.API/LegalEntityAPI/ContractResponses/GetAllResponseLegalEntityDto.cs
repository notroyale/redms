﻿namespace RAMS.API.LegalEntityAPI.ContractResponses;

public record GetAllResponseLegalEntityDto
{
    public IEnumerable<GetResponseLegalEntityDto> Values { get; init; }

    protected GetAllResponseLegalEntityDto(IEnumerable<GetResponseLegalEntityDto> values)
    {
        Values = values;
    }

    public static GetAllResponseLegalEntityDto Create(IEnumerable<GetResponseLegalEntityDto> values)
    {
        return new(values);
    }
}