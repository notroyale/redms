﻿namespace RAMS.API.LegalEntityAPI.ContractResponses;

public record GetResponseBaseLegalEntityDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public bool IsActive { get; init; }

    protected GetResponseBaseLegalEntityDto(int id, string name, bool isActive)
    {
        Id = id;
        Name = name;
        IsActive = isActive;
    }

    public static GetResponseBaseLegalEntityDto Create(int id, string name, bool isActive)
    {
        return new(id, name, isActive);
    }
}