﻿namespace RAMS.API.LegalEntityAPI.ContractResponses;

public record DeleteResponseLegalEntityDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected DeleteResponseLegalEntityDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static DeleteResponseLegalEntityDto Create(int id, string name)
    {
        return new(id, name);
    }
}