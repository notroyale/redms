﻿using RAMS.API.RegulatoryCategoryAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.RegulatoryCategoryAPI.ContractMapping;

public static class RegulatoryCategoryDtoToDomain
{
    public static RegulatoryCategory ToDomain(this AddRequestRegulatoryCategoryDto requestDto)
    {
        return new RegulatoryCategory()
        {
            Name = requestDto.Name,
            TaxonomyLevel3ID = requestDto.TaxonomyLevel3ID,
            IsActive = requestDto.IsActive,
            AppliedRegulation = requestDto.AppliedRegulation
        };
    }

    public static RegulatoryCategory ToDomain(this UpdateRequestRegulatoryCategoryDto requestDto)
    {
        return new RegulatoryCategory()
        {
            Id = requestDto.Id,
            Name = requestDto.Name,
            TaxonomyLevel3ID = requestDto.TaxonomyLevel3ID,
            IsActive = requestDto.IsActive,
            AppliedRegulation = requestDto.AppliedRegulation
        };
    }
}