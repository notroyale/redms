﻿using RAMS.API.CommonAPI;
using RAMS.API.ObservationAPI.ContractMapping;
using RAMS.API.ObservationAPI.ContractResponses;
using RAMS.API.RegulatoryCategoryAPI.ContractResponses;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.API.RegulatoryCategoryAPI.ContractMapping;

public static class RegulatoryCategoryDomainToDto
{
    public static GetAllResponseRegulatoryCategoryDto ToGetAllResponseDto(this IEnumerable<RegulatoryCategory> entities)
    {
        ICollection<GetResponseRegulatoryCategoryDto> dtos = new List<GetResponseRegulatoryCategoryDto>();

        foreach (RegulatoryCategory entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllResponseRegulatoryCategoryDto.Create(dtos);
    }

    public static IReadOnlyList<int> ToGetAllResponseDto(this ICollection<ObservationRegCategories> entities)
    {
        List<int> dtos = new();

        if (entities is null) 
            return dtos;

        foreach (ObservationRegCategories entity in entities)
        {
            dtos.Add(entity.RegulatoryCategoryID);
        }

        return dtos;
    }

    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseRegulatoryCategoryDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<RegulatoryCategory>? entities)
    {
        ICollection<GetResponseBaseRegulatoryCategoryDto> dtos = new List<GetResponseBaseRegulatoryCategoryDto>();

        foreach (RegulatoryCategory entity in entities.Items)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseRegulatoryCategoryDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetResponseBaseRegulatoryCategoryDto ToGetBaseResponseDto(this RegulatoryCategory entity)
    {
        return GetResponseBaseRegulatoryCategoryDto.Create(entity.Id, entity.Name, entity.TaxonomyLevel3ID, entity.IsActive, entity.AppliedRegulation);
    }

    public static GetResponseRegulatoryCategoryDto ToGetResponseDto(this RegulatoryCategory entity)
    {
        return GetResponseRegulatoryCategoryDto.Create(entity.Id, entity.Name, entity.TaxonomyLevel3ID, entity.IsActive, entity.AppliedRegulation);
    }

    public static UpdateResponseRegulatoryCategoryDto ToUpdateResponseDto(this RegulatoryCategory entity)
    {
        return UpdateResponseRegulatoryCategoryDto.Create(entity.Id, entity.Name);
    }

    public static AddResponseRegulatoryCategoryDto ToAddResponseDto(this RegulatoryCategory entity)
    {
        return AddResponseRegulatoryCategoryDto.Create(entity.Id, entity.Name);
    }

    public static DeleteResponseRegulatoryCategoryDto ToDeleteResponseDto(this RegulatoryCategory entity)
    {
        return DeleteResponseRegulatoryCategoryDto.Create(entity.Id, entity.Name);
    }
}