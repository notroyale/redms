﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.RegulatoryCategoryAPI.ContractMapping;
using RAMS.API.RegulatoryCategoryAPI.ContractRequests;
using RAMS.API.CommonAPI;
using RAMS.Application.RegulatoryCategoryApp;
using RAMS.Application.Common;
using RAMS.Domain.Common;
using RAMS.Application.LegalEntityApp;

namespace RAMS.API.RegulatoryCategoryAPI;

public class RegulatoryCategoryController : APIController
{
    private readonly IRegulatoryCategoryService _regulatoryCategoryService;
    private readonly ICacheService _cache;

    public RegulatoryCategoryController(IRegulatoryCategoryService regulatoryCategoryService, ICacheService memoryCache) : base(memoryCache)
    {
        _regulatoryCategoryService = regulatoryCategoryService;
        _cache = memoryCache;
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var result = await _regulatoryCategoryService.GetAllSortedByNameAsync();

        return Ok(result.ToGetAllResponseDto().Values);
    }

    [HttpGet("allBase/options")]
    public async Task<IActionResult> GetBaseRepositoryDataAsync([FromQuery] SearchOptions searchOptions)
    {
        var regulatoryCategories = await _regulatoryCategoryService.GetAllBaseAsync(searchOptions);

        if (regulatoryCategories is null)
            return NotFound();

        return Ok(regulatoryCategories.ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get(GetRequestRegulatoryCategoryDto requestDto)
    {
        var result = await _regulatoryCategoryService.GetAsync(ba => ba.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpGet("allByTaxonomy")]
    public async Task<IActionResult> GetAllByTaxonomyId([FromQuery] int[] ids)
    {
        var result = await _regulatoryCategoryService.GetAllByTaxonomyId(ids);

        return Ok(result.ToGetAllResponseDto().Values);
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestRegulatoryCategoryDto requestDto)
    {
        var result = await _regulatoryCategoryService.Insert(requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestRegulatoryCategoryDto requestDto)
    {
        var result = await _regulatoryCategoryService.Update(ba => ba.Id == requestDto.Id, requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public IActionResult Delete(DeleteRequestRegulatoryCategoryDto requestDto)
    {
        return Ok("Delete regulatory category reached!");
    }
}