﻿namespace RAMS.API.RegulatoryCategoryAPI.ContractRequests;

public record AddRequestRegulatoryCategoryDto(string Name, int TaxonomyLevel3ID, bool IsActive, string AppliedRegulation);