﻿namespace RAMS.API.RegulatoryCategoryAPI.ContractRequests;

public record UpdateRequestRegulatoryCategoryDto(int Id, string Name, int TaxonomyLevel3ID, bool IsActive, string AppliedRegulation);