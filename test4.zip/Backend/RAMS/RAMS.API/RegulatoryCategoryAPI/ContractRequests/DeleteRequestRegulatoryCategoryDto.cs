﻿namespace RAMS.API.RegulatoryCategoryAPI.ContractRequests;

public record DeleteRequestRegulatoryCategoryDto(int Id);