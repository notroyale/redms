﻿namespace RAMS.API.RegulatoryCategoryAPI.ContractResponses;

public record DeleteResponseRegulatoryCategoryDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected DeleteResponseRegulatoryCategoryDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static DeleteResponseRegulatoryCategoryDto Create(int id, string name)
    {
        return new(id, name);
    }
}