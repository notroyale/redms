﻿namespace RAMS.API.RegulatoryCategoryAPI.ContractResponses;

public record AddResponseRegulatoryCategoryDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected AddResponseRegulatoryCategoryDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static AddResponseRegulatoryCategoryDto Create(int id, string name)
    {
        return new(id, name);
    }
}