﻿namespace RAMS.API.RegulatoryCategoryAPI.ContractResponses;

public record GetAllResponseRegulatoryCategoryDto
{
    public IEnumerable<GetResponseRegulatoryCategoryDto> Values { get; init; }

    protected GetAllResponseRegulatoryCategoryDto(IEnumerable<GetResponseRegulatoryCategoryDto> values)
    {
        Values = values;
    }

    public static GetAllResponseRegulatoryCategoryDto Create(IEnumerable<GetResponseRegulatoryCategoryDto> values)
    {
        return new(values);
    }
}