﻿namespace RAMS.API.RegulatoryCategoryAPI.ContractResponses;

public record GetResponseBaseRegulatoryCategoryDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public int? TaxonomyLevel3ID { get; init; }
    public bool IsActive { get; init; }
    public string AppliedRegulation { get; init; }

    protected GetResponseBaseRegulatoryCategoryDto(int id, string name, int? taxonomyLevel3ID, bool isActive, string appliedRegulation)
    {
        Id = id;
        Name = name;
        TaxonomyLevel3ID = taxonomyLevel3ID;
        IsActive = isActive;
        AppliedRegulation = appliedRegulation;
    }

    public static GetResponseBaseRegulatoryCategoryDto Create(int id, string name, int? taxonomyLevel3ID, bool isActive, string appliedRegulation)
    {
        return new(id, name, taxonomyLevel3ID, isActive, appliedRegulation);
    }
}