﻿namespace RAMS.API.RegulatoryCategoryAPI.ContractResponses;

public record UpdateResponseRegulatoryCategoryDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected UpdateResponseRegulatoryCategoryDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static UpdateResponseRegulatoryCategoryDto Create(int id, string name)
    {
        return new(id, name);
    }
}