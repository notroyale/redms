﻿using RAMS.API.CategoryAPI.ContractResponses;
using RAMS.API.CommonAPI;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.API.CategoryAPI.ContractMapping;

public static class CategoryDomainToDto
{
    public static GetAllResponseCategoryDto ToGetAllResponseDto(this IEnumerable<Category> entities)
    {
        ICollection<GetResponseCategoryDto> dtos = new List<GetResponseCategoryDto>();

        foreach (Category entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return GetAllResponseCategoryDto.Create(dtos);
    }

    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseCategoryDto> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<Category>? entities)
    {
        ICollection<GetResponseBaseCategoryDto> dtos = new List<GetResponseBaseCategoryDto>();

        foreach (Category entity in entities.Items)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseCategoryDto>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetResponseBaseCategoryDto ToGetBaseResponseDto(this Category entity)
    {
        return GetResponseBaseCategoryDto.Create(entity.Id, entity.Description, entity.IsActive);
    }

    public static GetResponseCategoryDto ToGetResponseDto(this Category entity)
    {
        if (entity is null)
            return GetResponseCategoryDto.Empty();

        return GetResponseCategoryDto.Create(entity.Id, entity.Description, entity.IsActive);
    }

    public static UpdateResponseCategoryDto ToUpdateResponseDto(this Category entity)
    {
        return UpdateResponseCategoryDto.Create(entity.Id, entity.Description, entity.IsActive);
    }

    public static AddResponseCategoryDto ToAddResponseDto(this Category entity)
    {
        return AddResponseCategoryDto.Create(entity.Id, entity.Description, entity.IsActive);
    }

    public static DeleteResponseCategoryDto ToDeleteResponseDto(this Category entity)
    {
        return DeleteResponseCategoryDto.Create(entity.Id);
    }
}