﻿using RAMS.API.CategoryAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.CategoryAPI.ContractMapping;

public static class CategoryDtoToDomain
{
    public static Category ToDomain(this AddRequestCategoryDto requestDto)
    {
        return new Category()
        {
            Description = requestDto.Description,
            IsActive = requestDto.IsActive
        };
    }

    public static Category ToDomain(this UpdateRequestCategoryDto requestDto)
    {
        return new Category()
        {
            Id = requestDto.Id,
            Description = requestDto.Description,
            IsActive = requestDto.IsActive
        };
    }
}