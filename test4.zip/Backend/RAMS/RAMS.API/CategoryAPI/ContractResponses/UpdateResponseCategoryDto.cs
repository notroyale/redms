﻿namespace RAMS.API.CategoryAPI.ContractResponses;

public record UpdateResponseCategoryDto
{
    public int Id { get; init; }
    public string Description { get; init; }
    public bool IsActive { get; set; }

    protected UpdateResponseCategoryDto(int id, string description, bool isActive)
    {
        Id = id;
        Description = description;
        IsActive = isActive;
    }

    public static UpdateResponseCategoryDto Create(int id, string description, bool isActive)
    {
        return new(id, description, isActive);
    }
}