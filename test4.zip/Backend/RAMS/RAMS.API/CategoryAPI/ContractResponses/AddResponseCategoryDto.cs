﻿namespace RAMS.API.CategoryAPI.ContractResponses;

public record AddResponseCategoryDto
{
    public int Id { get; init; }
    public string Description { get; init; }
    public bool IsActive { get; set; }

    protected AddResponseCategoryDto(int id, string description, bool isActive)
    {
        Id = id;
        Description = description;
        IsActive = isActive;
    }

    public static AddResponseCategoryDto Create(int id, string description, bool isActive)
    {
        return new(id, description, isActive);
    }
}