﻿namespace RAMS.API.CategoryAPI.ContractResponses;

public record GetResponseCategoryDto
{
    public int Id { get; init; }
    public string Description { get; init; }
    public bool IsActive { get; init; }

    protected GetResponseCategoryDto(int id, string description, bool isActive)
    {
        Id = id;
        Description = description;
        IsActive = isActive;
    }
    public GetResponseCategoryDto()
    {
        Description = string.Empty;
    }

    public static GetResponseCategoryDto Create(int id, string description, bool isActive)
    {
        return new(id, description, isActive);
    }

    public static GetResponseCategoryDto Empty()
    {
        return new();
    }
}