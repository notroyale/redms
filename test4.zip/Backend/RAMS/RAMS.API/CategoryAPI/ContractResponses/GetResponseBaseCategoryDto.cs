﻿namespace RAMS.API.CategoryAPI.ContractResponses;

public record GetResponseBaseCategoryDto
{
    public int Id { get; init; }
    public string Description { get; init; }
    public bool IsActive { get; init; }

    public GetResponseBaseCategoryDto(int id, string description, bool isActive)
    {
        Id = id;
        Description = description;
        IsActive = isActive;
    }

    public static GetResponseBaseCategoryDto Create(int id, string description, bool isActive)
    {
        return new(id, description, isActive);
    }
}