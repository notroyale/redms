﻿namespace RAMS.API.CategoryAPI.ContractResponses;

public record DeleteResponseCategoryDto
{
    public int Id { get; init; }

    protected DeleteResponseCategoryDto(int id)
    {
        Id = id;
    }

    public static DeleteResponseCategoryDto Create(int id)
    {
        return new(id);
    }
}