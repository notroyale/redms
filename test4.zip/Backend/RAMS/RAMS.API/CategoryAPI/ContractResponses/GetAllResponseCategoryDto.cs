﻿namespace RAMS.API.CategoryAPI.ContractResponses;

public record GetAllResponseCategoryDto
{
    public IEnumerable<GetResponseCategoryDto> Values { get; init; }

    protected GetAllResponseCategoryDto(IEnumerable<GetResponseCategoryDto> values)
    {
        Values = values;
    }

    public static GetAllResponseCategoryDto Create(IEnumerable<GetResponseCategoryDto> values)
    {
        return new(values);
    }
}