﻿namespace RAMS.API.CategoryAPI.ContractRequests;

public record DeleteRequestCategoryDto(int Id);