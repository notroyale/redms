﻿namespace RAMS.API.CategoryAPI.ContractRequests;

public record GetRequestCategoryDto(int Id);