﻿namespace RAMS.API.CategoryAPI.ContractRequests;

public record UpdateRequestCategoryDto(int Id, string Description, bool IsActive);