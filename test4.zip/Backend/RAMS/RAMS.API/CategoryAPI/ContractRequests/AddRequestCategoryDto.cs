﻿namespace RAMS.API.CategoryAPI.ContractRequests;

public record AddRequestCategoryDto(string Description, bool IsActive);
