﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.CategoryAPI.ContractMapping;
using RAMS.API.CategoryAPI.ContractRequests;
using RAMS.API.CommonAPI;
using RAMS.Application.CategoryApp;
using RAMS.Application.Common;
using RAMS.Domain.Common;

namespace RAMS.API.CategoryAPI;

public class CategoryController : APIController
{
    private readonly ICategoryService _categoryService;
    private readonly ICacheService _cache;


    public CategoryController(ICategoryService CategoryService, ICacheService memoryCache) : base(memoryCache)
    {
        _categoryService = CategoryService;
        _cache = memoryCache;   
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var result = await _categoryService.GetAllAsync();
        return Ok(result.OrderBy(x=>x.Description)
            .ToGetAllResponseDto().Values);
    }

    [HttpGet("allBase/options")]
    public async Task<IActionResult> GetBaseRepositoryDataAsync([FromQuery] SearchOptions searchOptions)
    {
        var categories = await _categoryService.GetAllBaseAsync(searchOptions);

        if (categories is null)
            return NotFound();

        return Ok(categories
            .ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get(GetRequestCategoryDto requestDto)
    {
        var result = await _categoryService.GetAsync(ba => ba.Id == requestDto.Id);

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add(AddRequestCategoryDto requestDto)
    {
        var result = await _categoryService.Insert(requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result.Value.ToGetResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UpdateRequestCategoryDto requestDto)
    {
        var result = await _categoryService.Update(ba => ba.Id == requestDto.Id, requestDto.ToDomain());

        if (result.IsFailure)
            BadRequest(result);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public IActionResult Delete(DeleteRequestCategoryDto requestDto)
    {
        return Ok("Delete Category reached!");
    }
}