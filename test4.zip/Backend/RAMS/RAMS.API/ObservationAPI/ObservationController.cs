﻿using Azure.Core;
using Microsoft.AspNetCore.Mvc;
using RAMS.API.CommonAPI;
using RAMS.API.ObservationAPI.ContractMapping;
using RAMS.API.ObservationAPI.ContractRequests;
using RAMS.Application.AuditApp;
using RAMS.Application.Common;
using RAMS.Application.ObservationApp;
using RAMS.Domain.Common;
using RAMS.Domain.Enumerators;

namespace RAMS.API.ObservationAPI;

public class ObservationController : APIController
{
    private readonly IObservationService _observationService;
    private readonly ICacheService _cache;
    private readonly IAuditService _auditService;

    public ObservationController(IObservationService observationService, ICacheService memoryCache, IAuditService auditService) : base(memoryCache)
    {
        _observationService = observationService;
        _cache = memoryCache;   
        _auditService = auditService;
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var result = await _observationService.GetAllAsync();

        return Ok(result.ToGetAllResponseDto().Values);
    }

    [HttpPost("allBase/options")]
    public async Task<IActionResult> GetBaseRepositoryDataAsync([FromBody] SearchOptions searchOptions) 
    {
        var observations = await _observationService.GetAllBaseAsync(searchOptions);

        if (observations is null)
            return NotFound();

        return Ok(observations.ToGetAllBaseWithSearchOptionsResponseDto());
    }

    [HttpGet("get")]
    public async Task<IActionResult> Get([FromQuery] GetRequestObservationDto request)
    {
        var observationAuthorization = await _observationService.GetFull(request.Id);

        if (observationAuthorization is null)
            return NotFound(observationAuthorization);

        _auditService.AddAuditLog(request.Id, AuditAction.View);
        return Ok(observationAuthorization.ToGetFullResponseDto());
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add()
    {
        var observation = await _observationService.Create();

        if (observation is null)
        {
            return BadRequest();
        }

        return Ok(observation.ToGetFullResponseDto());
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(int id, UpdateRequestObservationDto request)
    {
        var result = await _observationService.UpdateAllSteps(id, 
            request.DetailsStep.DetailsStepDtoToDomain(),
            request.ResponsibleCentreStep.ResposibilityCentreStepToDomain(),
            request.RiskCategorizationStep.RiskCategorizationStepDtoToDomain(),
            request.CollabFieldsStep.CollaborationFieldsStepDtoToDomain(),
            request.AffectedFieldsStep.AffectedFieldsDtoToDomain(),
            request.StatusStep.StatusStepDtoToDomain(),
            request.ActionPlanStep.ActionPlanStepDtoToDomain());

        return Ok(result);
    }

    [HttpPut("update-details")]
    public async Task<IActionResult> UpdateDetails(int id, UpdateRequestDetailsDto request)
    {
       var result = await _observationService.UpdateDetailsStep(id, request.DetailsStepDtoToDomain());

        return Ok(result);
    }

    [HttpPut("update-responsibility-center")]
    public async Task<IActionResult> UpdateResposibilityCenter(int id, UpdateRequestResposibilityCentreDto request)
    {
        if(request is null) 
            return BadRequest();

        var result = await _observationService.UpdateResposibilityCentreStep(id, request.ResposibilityCentreStepToDomain());

        return Ok(result);
    }

    [HttpPut("update-collaboration-fields")]
    public async Task<IActionResult> UpdateCollaborationFields(int id, UpdateRequestCollaborationFieldsDto request)
    {
        if (request is null)
            return NotFound();

        var result = await _observationService.UpdateCollaborationFieldsStep(id, request.CollaborationFieldsStepDtoToDomain());

        return Ok(result);
    }


    [HttpPut("update-action-plan-step")]
    public async Task<IActionResult> UpdateActionPlan(int id, UpdateRequestActionPlanStepDto request)
    {
        if (request is null)
            return NotFound();

        var result = await _observationService.UpdateActionPlanStep(id, request.ActionPlanStepDtoToDomain());
        return Ok(result);
    }

    [HttpPut("update-risk-categorization")]
    public async Task<IActionResult> UpdateRiskCategorization(int id, UpdateRequestRiskCategorizationDto request)
    {
        if (request is null)
            return NotFound();

        var result = await _observationService.UpdateRiskCategorizationStep(id, request.RiskCategorizationStepDtoToDomain());

        return Ok(result);
    }

    [HttpPut("update-affected-fields")]
    public async Task<IActionResult> UpdateAffectedFields(int id, UpdateRequestAffectedFieldsDto request)
    {
        if (request is null)
            return NotFound();

        var result = await _observationService.UpdateAffectedFieldsStep(id, request.AffectedFieldsDtoToDomain());

        return Ok(result);
    }
    
    [HttpPut("update-closure-fields")]
    public async Task<IActionResult> UpdateAdminFields(int id, UpdateRequestClosureFieldsDto request)
    {
        if (request is null)
            return NotFound();

        var result = await _observationService.UpdateClosureFieldsStep(id, request.ClosureFieldsDtoToDomain());

        return Ok(result);
    }

    [HttpPut("observation-closure")]
    public async Task<IActionResult> ObservationClosure(int id, UpdateRequestClosureDto request)
    {
        if (request is null)
            return NotFound();

        var result = await _observationService.ObservationClosure(id, request.ClosureDtoToDomain());

        return Ok(result);
    }

    [HttpPut("submit")]
    public async Task<IActionResult> ObservationSubmission(int id)
    {
        if (id == 0)
            return BadRequest();

        var result = await _observationService.Submit(id);

        return Ok(result);
    }

    [HttpDelete("delete")]
    public IActionResult Delete()
    {
        return Ok("Delete observation reached!");
    }

    [HttpGet("getAllAuthorised")]
    public IActionResult GetAllAuthorised()
    {
        var observation = _observationService.GetAllAuthorised();

        if (observation is null)
            return NotFound(observation);

        return Ok(observation);
    }
}