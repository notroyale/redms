﻿namespace RAMS.API.ObservationAPI.ContractRequests;

public record UpdateRequestCollaborationFieldsDto(
    string? Comment,
    string? Comment1LoD,
    int RagStatusID,
    string? RagJustification,
    bool ClosureSubmitted
);