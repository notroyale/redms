﻿namespace RAMS.API.ObservationAPI.ContractRequests
{
    public record GetRequestFilteresDto(
        int[]? Status,
        int[]? BusinessUnits,
        int[]? BusinessAreas,
        int[]? LegalEntities,
        int[]? Category,
        int[]? Taxonomy);
}
