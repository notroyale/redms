﻿namespace RAMS.API.ObservationAPI.ContractRequests;

public record UpdateRequestClosureDto(string ClosureJustification);