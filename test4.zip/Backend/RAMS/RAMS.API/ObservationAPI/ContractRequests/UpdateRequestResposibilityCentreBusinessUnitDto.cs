﻿namespace RAMS.API.ObservationAPI.ContractRequests;

public record UpdateRequestResposibilityCentreBusinessUnitDto(
    int Id,
    string Name,
    string Code
);