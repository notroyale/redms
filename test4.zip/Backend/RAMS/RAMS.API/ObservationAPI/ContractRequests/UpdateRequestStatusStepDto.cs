﻿namespace RAMS.API.ObservationAPI.ContractRequests
{
    public record UpdateRequestStatusStepDto(
        int status,
        DateTime? cancellationDate,
        string? cancellationJustification,
        DateTime? closureDate,
        string? closureJustification,
        DateTime? deadlineExtensionRegistrationDate,
        string? deadlineExtensionJustification,
        DateTime? riskAcceptanceDate,
        string? riskAcceptanceJustification
    );
}
