﻿namespace RAMS.API.ObservationAPI.ContractRequests;

public record UpdateRequestAffectedFieldsDto(
    IEnumerable<int> AffectedBusinessUnits,
    IEnumerable<int>? AffectedBusinessAreas,
    IEnumerable<int> AffectedLegalEntities,
    IEnumerable<int> AffectedCountries
);