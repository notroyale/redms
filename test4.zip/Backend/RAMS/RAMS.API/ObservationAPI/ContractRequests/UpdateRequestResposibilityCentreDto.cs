﻿namespace RAMS.API.ObservationAPI.ContractRequests;

public record UpdateRequestResposibilityCentreDto(
    string ActivityOwner,
    string Assignee,
    string RiskOwner,
    int BusinessUnit,
    IEnumerable<int> LegalEntities
);