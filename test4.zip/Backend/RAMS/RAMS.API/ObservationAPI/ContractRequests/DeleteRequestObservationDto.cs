﻿namespace RAMS.API.ObservationAPI.ContractRequests;

public record DeleteRequesObservationDto(int Id);