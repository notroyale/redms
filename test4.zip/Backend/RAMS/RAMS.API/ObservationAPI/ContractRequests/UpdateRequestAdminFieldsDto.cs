﻿namespace RAMS.API.ObservationAPI.ContractRequests;

public record UpdateRequestClosureFieldsDto(
    int Status,
    DateTime? CancellationDate,
    string? CancellationJustification,
    DateTime? RiskAcceptanceDate,
    string? riskAcceptanceJustification,
    DateTime? DeadlineExtensionRegistrationDate,
    string? DeadlineExtensionJustification,
    DateTime? ClosureDate,
    string? ClosureJustification
);