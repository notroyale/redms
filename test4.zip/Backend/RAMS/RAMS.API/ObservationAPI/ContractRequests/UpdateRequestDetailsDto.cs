﻿using System.ComponentModel.DataAnnotations;

namespace RAMS.API.ObservationAPI.ContractRequests;

public record UpdateRequestDetailsDto(
    int CategoryID,
    DateTime? DateIdentified,
    DateTime Deadline,
    string Description,
    int GradeID,
    DateTime? RevisedDeadline,
    [Required] string Title,
    bool selfRaised,
    string? selfRaisedJustification,
    string? observationCategoryExplanation
);
