﻿namespace RAMS.API.ObservationAPI.ContractRequests;

public record UpdateRequestResposibilityCentreLegalEntitiesDto(
    int Id,
    string Name
);