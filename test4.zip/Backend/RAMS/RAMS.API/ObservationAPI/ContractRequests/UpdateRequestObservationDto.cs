﻿namespace RAMS.API.ObservationAPI.ContractRequests;

public record UpdateRequestObservationDto(
    UpdateRequestDetailsDto DetailsStep,
    UpdateRequestResposibilityCentreDto ResponsibleCentreStep,
    UpdateRequestRiskCategorizationDto RiskCategorizationStep,
    UpdateRequestAffectedFieldsDto AffectedFieldsStep,
    UpdateRequestCollaborationFieldsDto CollabFieldsStep,
    UpdateRequestActionPlanStepDto ActionPlanStep,
    UpdateRequestStatusStepDto StatusStep
);

