﻿namespace RAMS.API.ObservationAPI.ContractRequests;

public record UpdateRequestRiskCategorizationDto(
    string? Directive,
    string? BusinessLine,
    int TaxonomyLevel1,
    ICollection<int> TaxonomiesLevel2,
    ICollection<int> TaxonomiesLevel3,
    bool ConductRisk,
    bool EsgRisk,
    string? ConductJustification,
    string? EsgJustification,
    ICollection<int> Regulations,
    ICollection<int> RegCategories,
    string? RegulationComment
);