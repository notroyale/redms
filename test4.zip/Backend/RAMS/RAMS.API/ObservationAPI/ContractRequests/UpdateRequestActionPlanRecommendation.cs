﻿namespace RAMS.API.ObservationAPI.ContractRequests
{
    public record UpdateRequestActionPlanStepDto(
        string? Recommendation
    );
}
