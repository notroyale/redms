﻿namespace RAMS.API.ObservationAPI.ContractRequests;

public record GetRequestObservationDto(int Id);