﻿using RAMS.API.ObservationAPI.ContractRequests;
using RAMS.Domain;
using RAMS.Domain.Observations.Steps;

namespace RAMS.API.ObservationAPI.ContractMapping;

public static class ObservationStepsDtoToDomain
{
    public static ObservationDetailsStep DetailsStepDtoToDomain(this UpdateRequestDetailsDto requestDto)
    {
        if (requestDto is null)
            return new();

        return new ObservationDetailsStep(
            requestDto.Title,
            requestDto.Description,
            requestDto.GradeID,
            requestDto.CategoryID,
            requestDto.Deadline,
            requestDto.DateIdentified,
            requestDto.RevisedDeadline,
            requestDto.selfRaised,
            requestDto.selfRaisedJustification,
            requestDto.observationCategoryExplanation            
        );
    }

    public static ObservationResposibilityCentreStep ResposibilityCentreStepToDomain(this UpdateRequestResposibilityCentreDto requestDto)
    {
        if (requestDto is null)
            return new();

        return new ObservationResposibilityCentreStep(
            requestDto.ActivityOwner, 
            requestDto.Assignee, 
            requestDto.RiskOwner, 
            requestDto.BusinessUnit,
            requestDto.LegalEntities
        );
    }

    public static ObservationCollaborationFieldsStep CollaborationFieldsStepDtoToDomain(this UpdateRequestCollaborationFieldsDto requestDto)
    {
        if (requestDto is null)
            return new();

        return new ObservationCollaborationFieldsStep(
            requestDto.Comment1LoD,
            requestDto.Comment,
            requestDto.RagStatusID,
            requestDto.RagJustification,
            requestDto.ClosureSubmitted
        );
    }

    public static ObservationActionPlanStep ActionPlanStepDtoToDomain(this UpdateRequestActionPlanStepDto requestDto)
    {
        if (requestDto is null)
            return new();

        return new ObservationActionPlanStep(
            requestDto.Recommendation
        );
    }

    public static ObservationRiskCategorizationStep RiskCategorizationStepDtoToDomain(this UpdateRequestRiskCategorizationDto requestDto)
    {
        if (requestDto is null)
            return new();

        return new ObservationRiskCategorizationStep(
            requestDto.Directive,
            requestDto.BusinessLine,
            requestDto.TaxonomyLevel1,
            requestDto.TaxonomiesLevel2,
            requestDto.TaxonomiesLevel3,
            requestDto.ConductRisk,
            requestDto.EsgRisk,
            requestDto.ConductJustification,
            requestDto.EsgJustification,
            requestDto.Regulations,
            requestDto.RegCategories,
            requestDto.RegulationComment
        );
    }

    public static ObservationAffectedFieldsStep AffectedFieldsDtoToDomain(this UpdateRequestAffectedFieldsDto requestDto)
    {
        if (requestDto is null)
            return new();

        return new ObservationAffectedFieldsStep(
            requestDto.AffectedBusinessUnits,
            requestDto.AffectedBusinessAreas,
            requestDto.AffectedLegalEntities,
            requestDto.AffectedCountries
        );
    }
    public static ObservationStatusStep StatusStepDtoToDomain(this UpdateRequestStatusStepDto requestDto)
    {
        if (requestDto is null)
            return new();

        return new ObservationStatusStep(
            requestDto.status,
            requestDto.cancellationDate,
            requestDto.cancellationJustification,
            requestDto.closureDate, 
            requestDto.closureJustification,
            requestDto.deadlineExtensionRegistrationDate,
            requestDto.deadlineExtensionJustification,
            requestDto.riskAcceptanceDate,
            requestDto.riskAcceptanceJustification);
    }
    
    public static ObservationClosureFieldsStep ClosureFieldsDtoToDomain(this UpdateRequestClosureFieldsDto requestDto)
    {
        if (requestDto is null)
            return new();

        return new ObservationClosureFieldsStep(
            requestDto.Status,
            requestDto.CancellationDate,
            requestDto.RiskAcceptanceDate,
            requestDto.DeadlineExtensionRegistrationDate,
            requestDto.CancellationJustification,
            requestDto.ClosureJustification 
        );
    }
    
    public static ObservationClosureStep ClosureDtoToDomain(this UpdateRequestClosureDto requestDto)
    {
        if (requestDto is null)
            return new();

        return new ObservationClosureStep(
            requestDto.ClosureJustification
        );
    }

    private static BusinessUnit ToDomain(this UpdateRequestResposibilityCentreBusinessUnitDto requestDto)
    {
        if (requestDto is null)
            return new BusinessUnit();


        return new BusinessUnit()
        {
            Id = requestDto.Id,
            Name = requestDto.Name,
            Code = requestDto.Code
        };
    }
    private static ICollection<LegalEntity> ToDomain(this ICollection<UpdateRequestResposibilityCentreLegalEntitiesDto> requestDto)
    {
        if (requestDto is null)
            return new List<LegalEntity>();

        var domainList = new List<LegalEntity>();

        foreach (var dto in requestDto)
        {
            domainList.Add(new LegalEntity()
            {
                Id = dto.Id,
                Name = dto.Name
            });
        }

        return domainList;
    }
}