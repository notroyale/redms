﻿using RAMS.API.ObservationAPI.ContractRequests;
using RAMS.Domain;

namespace RAMS.API.ObservationAPI.ContractMapping;

public static class ObservationDtoToDomain
{
    public static Observation ToDomain(this AddRequestObservationDto requestDto)
    {
        return new Observation()
        {
            Title = requestDto.Title,
            StatusID = requestDto.StatusID,
            BusinessUnitId = requestDto.BusinessUnitId,
            //GradeID = requestDto.Grade,
            Summary = requestDto.Summary,
            Recommendation = requestDto.Recommendation,
            Comment = requestDto.Comment,
            Assignee = requestDto.Assignee,
            ActivityOwner = requestDto.ActivityOwner,
            ProposedPlan = requestDto.ProposedPlan,
            RegistrationNumber = requestDto.RegistrationNumber,
            RiskOwner = requestDto.RiskOwner,
            BusinessLine = requestDto.BusinessLine,
            Directive = requestDto.Directive,
            Submitted = requestDto.Submitted,
            Deleted = requestDto.Deleted,
            MitigationActionComment = requestDto.MitigationActionComment,
            RiskAssessmentId = requestDto.RiskAssessmentId,
            GroupObservationId = requestDto.GroupObservationId,
            CategoryId = requestDto.CategoryId,
            //Comment1LoDId = requestDto.Comment1LoDId,
            RAGStatusID = requestDto.RAGStatusID,
            CreationDate = requestDto.CreationDate,
            ClosureDate = requestDto.ClosureDate,
            Deadline = requestDto.Deadline,
            DateIdentified = requestDto.Deadline,
            RevisedDeadline = requestDto.RevisedDeadline
        };
    }

    //public static Observation ToDomain(this UpdateRequestObservationDto requestDto)
    //{
    //    return new Observation()
    //    {
    //        Id = requestDto.Id,
    //        GradeID = requestDto.Grade,
    //        StatusID = requestDto.StatusID,
    //        Title = requestDto.Title,
    //        BusinessUnitId = requestDto.BusinessUnitId,
    //        Summary = requestDto.Summary,
    //        Recommendation = requestDto.Recommendation,
    //        Comment = requestDto.Comment,
    //        Assignee = requestDto.Assignee,
    //        ActivityOwner = requestDto.ActivityOwner,
    //        ProposedPlan = requestDto.ProposedPlan,
    //        RegistrationNumber = requestDto.RegistrationNumber,
    //        RiskOwner = requestDto.RiskOwner,
    //        BusinessLine = requestDto.BusinessLine,
    //        Directive = requestDto.Directive,
    //        Submitted = requestDto.Submitted,
    //        Deleted = requestDto.Deleted,
    //        MitigationActionComment = requestDto.MitigationActionComment,
    //        RiskAssessmentId = requestDto.RiskAssessmentId,
    //        GroupObservationId = requestDto.GroupObservationId,
    //        CategoryId = requestDto.CategoryId,
    //        //Comment1LoDId = requestDto.Comment1LoDId,
    //        RAGStatusID = requestDto.RAGStatusID,
    //        CreationDate = requestDto.CreationDate,
    //        ClosureDate = requestDto.ClosureDate,
    //        Deadline = requestDto.Deadline,
    //        DateIdentified = requestDto.Deadline,
    //        RevisedDeadline = requestDto.RevisedDeadline
    //    };
    //}
}