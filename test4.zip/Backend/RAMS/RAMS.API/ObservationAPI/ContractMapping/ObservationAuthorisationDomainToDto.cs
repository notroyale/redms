﻿using RAMS.API.CommonAPI;
using RAMS.API.ObservationAPI.ContractResponses;
using RAMS.Application.Common;
using RAMS.Domain;

namespace RAMS.API.ObservationAPI.ContractMapping;

public static class ObservationAuthorisationDomainToDto
{
    public static GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseObservationAuthorisation> ToGetAllBaseWithSearchOptionsResponseDto(this PagedList<ObservationAuthorisation> entities)
    {
        ICollection<GetResponseBaseObservationAuthorisation> dtos = new List<GetResponseBaseObservationAuthorisation>();

        foreach (ObservationAuthorisation entity in entities.Items)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return GetAllBaseWithSearchOptionsResponseDto<GetResponseBaseObservationAuthorisation>.Create(dtos, entities.Page, entities.PageSize, entities.TotalCount);
    }

    public static GetResponseObservationAuthorisation ToGetFullResponseDto(this ObservationAuthorisation entity)
    {
        return GetResponseObservationAuthorisation.Create(
            entity.Observation.ToGetDto(),
            entity.AdminAccess,
            entity.ApproverAccess,
            entity.CommentAccess,
            entity.EditAccess,
            entity.ViewAccess);
    }

    public static GetResponseBaseObservationAuthorisation ToGetBaseResponseDto(this ObservationAuthorisation entity)
    {
        return GetResponseBaseObservationAuthorisation.Create(
            entity.Observation.ToGetBaseResponseDto(),
            entity.AdminAccess,
            entity.ApproverAccess,
            entity.CommentAccess,
            entity.EditAccess,
            entity.ViewAccess);
    }
}