﻿using Messaging;
using RAMS.API.ActionPlanAPI.ContractMapping;
using RAMS.API.ActionPlanAPI.ContractResponses;
using RAMS.API.AttachmentAPI.ContractMapping;
using RAMS.API.BusinessUnitAPI.ContractMapping;
using RAMS.API.CategoryAPI.ContractMapping;
using RAMS.API.CountryAPI.ContractResponses;
using RAMS.API.GradeAPI.ContractMapping;
using RAMS.API.ObservationAPI.ContractResponses;
using RAMS.API.ObservationAPI.ContractResponses.Steps;
using RAMS.API.ObservationLegalEntityAPI.ContractResponses;
using RAMS.API.RAGStatusAPI.ContractMapping;
using RAMS.API.RegulationAPI.ContractMapping;
using RAMS.API.RegulatoryCategoryAPI.ContractMapping;
using RAMS.API.StatusAPI.ContractMapping;
using RAMS.API.TaxonomyAPI.ContractMapping;
using RAMS.Domain;

namespace RAMS.API.ObservationAPI.ContractMapping;

public static class ObservationDomainToDto
{
    public static GetAllResponseObservationDto ToGetAllResponseDto(this IEnumerable<Observation> entities)
    {
        ICollection<GetResponseObservationDto> dtos = new List<GetResponseObservationDto>();

        foreach (Observation entity in entities)
        {
            dtos.Add(entity.ToGetDto());
        }

        return GetAllResponseObservationDto.Create(dtos);
    }

    public static GetResponseBaseObservationDto ToGetBaseResponseDto(this Observation entity)
    {
        return GetResponseBaseObservationDto.Create(
            entity.Id,
            entity.Title,
            entity.Summary,
            entity.Status.ToGetResponseDto(),
            entity.Category.ToGetResponseDto(),
            entity.ObservationGrade == null ? 0: entity.ObservationGrade.GradeID,
            entity.RiskOwner,
            entity.BusinessUnit == null ? "Not Set" : entity.BusinessUnit.Name,
            entity.RAGStatus.ToGetResponseDto(),
            entity.CreationDate,
            entity.ClosureDate,
            entity.Deadline,
            entity.CreationUser,
            entity.Assignee,
            entity.ModifiedUser,
            entity.ModifiedDate);
    }

    public static GetResponseObservationDto ToGetDto(this Observation entity)
    {
        if (entity is null)
            return GetResponseObservationDto.Empty();

        return GetResponseObservationDto.Create(
            entity.Id,
            GetResponseObservatioDetailsStepDto.Create(entity.CategoryId, entity.Title, entity.DateIdentified, entity.CreationDate, entity.Deadline, entity.RevisedDeadline, entity.ClosureDate, entity.ObservationGrade?.GradeID, entity.Summary, entity.IsSelfRaisedIssue(), entity.GetSefRaisedIssueComment(), entity.ObservationCategoryExplanation),
            GetResponseObservationResponsibleCentreStepDto.Create(entity.BusinessUnitId, entity.BusinessAreasCountry.ToGetAllResponseDto(), entity.LegalEntities.ToGetAllResponseDto(), entity.ActivityOwner, entity.RiskOwner, entity.Assignee),
            GetResponseCollabFieldsStepDto.Create(entity.Comment, entity.Comment1LoD, entity.RAGStatusID, entity.GetRAGStatusComment(), entity.SubmittedForClosure),
            GetResponseObservationRiskCatStepDto.Create(entity.Taxonomies.ToGetAllByLevelResponseDto(), entity.GetRegulationComment(), entity.BusinessLine, entity.Directive,entity.IsRelatedToConductRisk(), entity.IsRelatedToESG(),entity.GetConductRiskJustification(), entity.GetRelatedToESGJustification(), entity.RegulatoryCategories.ToGetAllResponseDto(), entity.Regulations.ToGetAllResponseDto()),
            GetResponseObservationActionPlanStepDto.Create(entity.ActionPlans.ToGetAllResponseDto(), entity.Recommendation,entity.ProposedPlan),
            GetResponseObservationAffectedFieldsStepDto.Create(
                entity.AffectedBusinessUnits.ToGetAllResponseDto(), entity.AffectedBusinessAreas.ToGetAllResponseDto(), 
                entity.AffectedLegalEntities.ToGetAllResponseDto(), entity.AffectedCountries.ToGetAllResponseDto()),
            GetResponseSupportingDocumentsStepDto.Create(entity.Attachments.ToGetAllResponseDto()),
            GetResponseObservationStatusFieldStepDto.Create(entity.CancellationDate, entity.RiskAcceptanceDate, entity.DeadlineExtensionDate, entity.ClosureDate,
               "", entity.DeadlineExtensionJustification, entity.CancellationComment, entity.ClosureJustification, entity.StatusID),
            entity.Recommendation,
            entity.Comment,
            entity.RegistrationNumber,
            entity.Submitted,
            entity.Deleted,
            entity.MitigationActionComment,
            entity.RiskAssessmentId);
    }

    public static IReadOnlyList<int> ToGetAllResponseDto(this IEnumerable<ObservationAffectedBusinessUnits> entities)
    {
        List<int> dtos = new();

        if (entities is null) 
            return dtos;

        foreach (ObservationAffectedBusinessUnits entity in entities)
        {
            dtos.Add(entity.BusinessUnitID);
        }

        return dtos;
    }
    public static IReadOnlyList<int> ToGetAllResponseDto(this IEnumerable<ObservationAffectedBusinessAreas> entities)
    {
        List<int> dtos = new();

        if (entities is null) 
            return dtos;

        foreach (ObservationAffectedBusinessAreas entity in entities)
        {
            dtos.Add(entity.BusinessAreaID);
        }

        return dtos;
    }
    public static IReadOnlyList<int> ToGetAllResponseDto(this IEnumerable<ObservationAffectedLegalEntities> entities)
    {
        List<int> dtos = new();

        if (entities is null) 
            return dtos;

        foreach (ObservationAffectedLegalEntities entity in entities)
        {
            dtos.Add(entity.LegalEntityID);
        }

        return dtos;
    }
    public static IReadOnlyList<int> ToGetAllResponseDto(this IEnumerable<ObservationAffectedCountries> entities)
    {
        List<int> dtos = new();

        if (entities is null) 
            return dtos;

        foreach (ObservationAffectedCountries entity in entities)
        {
            dtos.Add(entity.CountryID);
        }

        return dtos;
    }

    public static IReadOnlyList<GetResponseObservationBusinessAreaCountryDto> ToGetAllResponseDto(this IEnumerable<ObservationBusinessArea> entities)
    {
        List<GetResponseObservationBusinessAreaCountryDto> dtos = new();

        if(entities is null) 
            return dtos; 

        foreach (ObservationBusinessArea entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return dtos;
    }

    public static IReadOnlyList<GetResponseBaseActionPlanDto> ToGetAllResponseDto(this IEnumerable<ActionPlan> entities)
    {
        List<GetResponseBaseActionPlanDto> dtos = new();

        if (entities is null) 
            return dtos;

        foreach (ActionPlan entity in entities)
        {
            dtos.Add(entity.ToGetBaseResponseDto());
        }

        return dtos;
    }

    public static IReadOnlyList<GetResponseLegalEntityDto> ToGetAllResponseDto(this IEnumerable<LegalEntity> entities)
    {
        List<GetResponseLegalEntityDto> dtos = new();

        if (entities is null) 
            return dtos;

        foreach (LegalEntity entity in entities)
        {
            dtos.Add(entity.ToGetResponseDto());
        }

        return dtos;
    }

    public static GetResponseObservationBusinessAreaCountryDto ToGetResponseDto(this ObservationBusinessArea entity)
    {
        return GetResponseObservationBusinessAreaCountryDto.Create(entity.ID.Value,entity.BusinessArea.Name, entity.Country.Name);
    }

    public static GetResponseObservationRegulatoryCategoryDto ToGetResponseDto(this ObservationRegCategories entity)
    {
        return GetResponseObservationRegulatoryCategoryDto.Create(entity.RegulatoryCategoryID);
    }

    public static GetResponseObservationRegulationDto ToGetResponseDto(this ObservationRegulation entity)
    {
        return GetResponseObservationRegulationDto.Create(entity.RegulationID);
    }

    public static GetResponseLegalEntityDto ToGetResponseDto(this LegalEntity entity)
    {
        return GetResponseLegalEntityDto.Create(entity.Id, entity.Name, entity.IsActive);
    }

    public static GetResponseObservationBusinessUnitDto ToGetResponseDto(this BusinessUnit entity)
    {
        if (entity is null)
            return GetResponseObservationBusinessUnitDto.Empty();

        return GetResponseObservationBusinessUnitDto.Create(entity.Id, entity.Code, entity.Name, entity.IsActive);
    }
    
    public static GetResponseObservationBusinessUnitDto ToGetResponseDto(this ObservationAffectedBusinessUnits entity)
    {
        if (entity is null)
            return GetResponseObservationBusinessUnitDto.Empty();

        return GetResponseObservationBusinessUnitDto.Create(entity.BusinessUnitID, "", "", false);
    }

    public static GetResponseLegalEntityDto ToGetResponseDto(this ObservationAffectedLegalEntities entity)
    {
        if (entity is null)
            return GetResponseLegalEntityDto.Empty();

        return GetResponseLegalEntityDto.Create(entity.LegalEntityID, "", false);
    }

    public static GetResponseCountryDto ToGetResponseDto(this ObservationAffectedCountries entity)
    {
        if (entity is null)
            return GetResponseCountryDto.Empty();

        return GetResponseCountryDto.Create(entity.CountryID, "", false);
    }
    
    public static GetResponseObservationBusinessAreaDto ToGetResponseDto(this ObservationAffectedBusinessAreas entity)
    {
        if (entity is null)
            return GetResponseObservationBusinessAreaDto.Empty();

        return GetResponseObservationBusinessAreaDto.Create(entity.BusinessAreaID, "", false);
    }

    public static Result<GetResponseObservationDto> ToGetResponseDto(this Observation entity)
    {
        return ToGetDto(entity);
    }

    public static UpdateResponseObservationDto ToUpdateResponseDto(this Observation entity)
    {
        return UpdateResponseObservationDto.Create(entity.Id, entity.Title);
    }

    public static AddResponseObservationDto ToAddResponseDto(this Observation entity)
    {
        return AddResponseObservationDto.Create(entity.Id, entity.Title);
    }

    public static DeleteResponseObservationDto ToDeleteResponseDto(this Observation entity)
    {
        return DeleteResponseObservationDto.Create(entity.Id, entity.Title);
    }
}