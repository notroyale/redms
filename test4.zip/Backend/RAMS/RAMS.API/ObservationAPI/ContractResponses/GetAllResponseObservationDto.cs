﻿namespace RAMS.API.ObservationAPI.ContractResponses;

public record GetAllResponseObservationDto
{
    public IEnumerable<GetResponseObservationDto> Values { get; init; }

    protected GetAllResponseObservationDto(IEnumerable<GetResponseObservationDto> values)
    {
        Values = values;
    }

    public static GetAllResponseObservationDto Create(IEnumerable<GetResponseObservationDto> values)
    {
        return new(values);
    }
}