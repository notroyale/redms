﻿namespace RAMS.API.ObservationAPI.ContractResponses;

public record AddResponseObservationDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected AddResponseObservationDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static AddResponseObservationDto Create(int id, string name)
    {
        return new(id, name);
    }
}