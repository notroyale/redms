﻿namespace RAMS.API.ObservationAPI.ContractResponses;

public record UpdateResponseObservationDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected UpdateResponseObservationDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static UpdateResponseObservationDto Create(int id, string name)
    {
        return new(id, name);
    }
}