﻿using RAMS.API.CategoryAPI.ContractResponses;
using RAMS.API.RAGStatusAPI.ContractResponses;
using RAMS.API.StatusAPI.ContractResponses;

namespace RAMS.API.ObservationAPI.ContractResponses;

public record GetResponseBaseObservationDto
{
    public int Id { get; init; }
    public string Title { get; set; }
    public string? Description { get; set; }
    public GetResponseStatusDto Status { get; set; }
    public int Level { get; set; }
    public string RiskOwner { get; set; }
    public string BusinessUnit { get; set; }
    public GetResponseRAGStatusDto RAGStatus { get; set; }
    public GetResponseCategoryDto Category { get; set; }
    public string CreationDate { get; set; }
    public string ClosureDate { get; set; }
    public string Deadline { get; set; }
    public string CreationUser { get; set; }
    public string Assignee { get; set; }
    public string ModifiedUser { get; set; }
    public string ModifiedDate { get; set; }

    protected GetResponseBaseObservationDto(int id, string title, string description,
        GetResponseStatusDto status, 
        GetResponseCategoryDto category, 
        int level, string riskOwner, string businessUnit, 
        GetResponseRAGStatusDto ragStatus, string creationDate, 
        string closureDate, string deadline, string creationUser,
        string assignee, string modifiedUser, string modifiedDate)
    {
        Id = id;
        Title = title;
        Description = description;
        Status = status;
        Level = level;
        RiskOwner = riskOwner;
        BusinessUnit = businessUnit;
        Category = category;
        RAGStatus = ragStatus;
        CreationDate = creationDate;
        ClosureDate = closureDate;
        Deadline = deadline;
        CreationUser = creationUser;
        Assignee = assignee;
        ModifiedUser = modifiedUser;
        ModifiedDate = modifiedDate;
    }

    public static GetResponseBaseObservationDto Create(int id, string title, string? description,
        GetResponseStatusDto status, 
        GetResponseCategoryDto category, 
        int level, string riskOwner, string businessUnit, 
        GetResponseRAGStatusDto ragStatus, DateTime? creationDate, 
        DateTime? closureDate, DateTime? deadline, string creationUser, string assignee, string modifiedUser, DateTime? modifiedDate)
    {
        return new(id, title, description, status, category, level, riskOwner, businessUnit, ragStatus,
            creationDate.HasValue ? creationDate.Value.ToShortDateString() : "not defined",
            closureDate.HasValue ? closureDate.Value.ToShortDateString() : "not defined",
            deadline.HasValue ? deadline.Value.ToShortDateString() : "not defined", creationUser, assignee,modifiedUser,
            modifiedDate.HasValue ? modifiedDate.Value.ToShortDateString() : "not modified");
    }
}