﻿namespace RAMS.API.ObservationAPI.ContractResponses;

public record GetResponseObservationBusinessAreaDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public bool IsActive { get; init; }

    protected GetResponseObservationBusinessAreaDto(int id, string name, bool isActive)
    {
        Id = id;
        Name = name;
        IsActive = isActive;
    }

    protected GetResponseObservationBusinessAreaDto()
    {
        Name = string.Empty;
    }

    public static GetResponseObservationBusinessAreaDto Empty()
    {
        return new();
    }

    public static GetResponseObservationBusinessAreaDto Create(int id, string name, bool isActive)
    {
        return new(id, name, isActive);
    }
}