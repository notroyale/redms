﻿namespace RAMS.API.ObservationAPI.ContractResponses;

public record GetResponseObservationBusinessAreaCountryDto
{
    public int Id { get; set; }
    public string BusinessArea { get; init; }
    public string Country { get; init; }

    protected GetResponseObservationBusinessAreaCountryDto(int id, string businessArea, string country)
    {
        Id = id;
        BusinessArea = businessArea;
        Country = country;
    }

    public static GetResponseObservationBusinessAreaCountryDto Create(int id, string businessArea, string country)
    {
        return new(id, businessArea, country);
    }
}