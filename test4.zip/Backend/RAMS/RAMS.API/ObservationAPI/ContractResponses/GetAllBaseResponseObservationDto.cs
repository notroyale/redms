﻿namespace RAMS.API.ObservationAPI.ContractResponses;

public record GetAllBaseResponseObservationDto
{
    public IEnumerable<GetResponseBaseObservationDto> Values { get; init; }

    protected GetAllBaseResponseObservationDto(IEnumerable<GetResponseBaseObservationDto> values)
    {
        Values = values;
    }

    public static GetAllBaseResponseObservationDto Create(IEnumerable<GetResponseBaseObservationDto> values)
    {
        return new(values);
    }
}