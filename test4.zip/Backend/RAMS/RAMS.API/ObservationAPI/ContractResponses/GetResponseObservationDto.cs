﻿using RAMS.API.ObservationAPI.ContractResponses.Steps;

namespace RAMS.API.ObservationAPI.ContractResponses;

public record GetResponseObservationDto
{
    public int Id { get; init; }
    public GetResponseObservatioDetailsStepDto DetailsStep { get; init; }
    public GetResponseObservationResponsibleCentreStepDto ResponsibleCentreStep { get; init; }
    public GetResponseCollabFieldsStepDto CollabFieldsStep { get; init; }
    public GetResponseObservationRiskCatStepDto RiskCategorizationStep { get; init; }
    public GetResponseObservationActionPlanStepDto ActionPlanStep { get; init; }
    public GetResponseObservationAffectedFieldsStepDto AffectedFieldsStep { get; init; }
    public GetResponseSupportingDocumentsStepDto SupportingDocumentsStep { get; set; }
    public GetResponseObservationStatusFieldStepDto StatusStep { get; init; }
    public string? Recommendation { get; init; }
    public string? Comment { get; init; }
    public string? RegistrationNumber { get; init; }
    public bool Submitted { get; init; }
    public bool Deleted { get; init; }
    public string? MitigationActionComment { get; init; }
    public int? RiskAssessmentId { get; init; }

    protected GetResponseObservationDto(int id, 
        GetResponseObservatioDetailsStepDto detailsStep, GetResponseObservationResponsibleCentreStepDto responsibleCentreStep, GetResponseCollabFieldsStepDto collabFieldsStep, 
        GetResponseObservationRiskCatStepDto riskCategorizationStep, GetResponseObservationActionPlanStepDto actionPlanStep,GetResponseObservationAffectedFieldsStepDto affectedFieldsStep,
        GetResponseSupportingDocumentsStepDto supportingDocumentsStep,
        GetResponseObservationStatusFieldStepDto statusStep, string? recommendation, string? comment, 
        string? registrationNumber, bool submitted, bool deleted, string? mitigationActionComment, int? riskAssessmentId)
    {
        Id = id;
        DetailsStep = detailsStep;
        ResponsibleCentreStep = responsibleCentreStep;
        CollabFieldsStep = collabFieldsStep;
        RiskCategorizationStep = riskCategorizationStep;
        ActionPlanStep = actionPlanStep;
        AffectedFieldsStep = affectedFieldsStep;
        SupportingDocumentsStep = supportingDocumentsStep;
        StatusStep = statusStep;
        Recommendation = recommendation;
        Comment = comment;
        RegistrationNumber = registrationNumber;
        Submitted = submitted;
        Deleted = deleted;
        MitigationActionComment = mitigationActionComment;
        RiskAssessmentId = riskAssessmentId;
    }

    protected GetResponseObservationDto()
    {
            
    }

    public static GetResponseObservationDto Empty()
    {
        return new();
    }

    public static GetResponseObservationDto Create(int id,
        GetResponseObservatioDetailsStepDto detailsStep, GetResponseObservationResponsibleCentreStepDto responsibleCentreStep, GetResponseCollabFieldsStepDto collabFieldsStep,
        GetResponseObservationRiskCatStepDto riskCategorizationStep, GetResponseObservationActionPlanStepDto actionPlanStep, GetResponseObservationAffectedFieldsStepDto affectedFieldsStep,
        GetResponseSupportingDocumentsStepDto supportingDocumentsStep,
        GetResponseObservationStatusFieldStepDto closureFieldStep, string? recommendation, string? comment,
        string? registrationNumber, bool submitted, bool deleted, string? mitigationActionComment, int? riskAssessmentId)
    {
        return new(id, detailsStep, responsibleCentreStep, collabFieldsStep, riskCategorizationStep, actionPlanStep, affectedFieldsStep, supportingDocumentsStep, closureFieldStep, recommendation, comment, 
           registrationNumber, submitted, deleted, mitigationActionComment, riskAssessmentId);
    }
}