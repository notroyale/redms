﻿namespace RAMS.API.ObservationAPI.ContractResponses;

public record GetResponseObservationRegulationDto
{
    public int Id { get; init; }

    protected GetResponseObservationRegulationDto(int id)
    {
        Id = id;
    }

    public static GetResponseObservationRegulationDto Create(int id)
    {
        return new(id);
    }
}