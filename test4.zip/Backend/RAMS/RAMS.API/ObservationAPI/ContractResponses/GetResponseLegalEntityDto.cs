﻿namespace RAMS.API.ObservationAPI.ContractResponses;

public record GetResponseLegalEntityDto
{
    public int Id { get; init; }
    public string Name { get; init; }
    public bool IsActive { get; init; }

    protected GetResponseLegalEntityDto(int id, string name, bool isActive)
    {
        Id = id;
        Name = name;
        IsActive = isActive;
    }

    protected GetResponseLegalEntityDto()
    {
        Name = string.Empty;
    }

    public static GetResponseLegalEntityDto Empty()
    {
        return new();
    }

    public static GetResponseLegalEntityDto Create(int id, string name, bool isActive)
    {
        return new(id, name, isActive);
    }
}