﻿namespace RAMS.API.ObservationAPI.ContractResponses;

public record DeleteResponseObservationDto
{
    public int Id { get; init; }
    public string Name { get; init; }

    protected DeleteResponseObservationDto(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public static DeleteResponseObservationDto Create(int id, string name)
    {
        return new(id, name);
    }
}