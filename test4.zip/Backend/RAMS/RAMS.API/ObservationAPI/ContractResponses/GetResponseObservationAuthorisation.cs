﻿namespace RAMS.API.ObservationAPI.ContractResponses;

public record GetResponseObservationAuthorisation
{
    public GetResponseObservationDto Observation { get; init; }
    public bool AdminAccess { get; init; }
    public bool ApproverAccess { get; init; }
    public bool CommentAccess { get; init; }
    public bool EditAccess { get; init; }
    public bool ViewAccess { get; init; }

    protected GetResponseObservationAuthorisation(
        GetResponseObservationDto observation,
        bool adminAccess, bool approverAccess, bool commentAccess, bool editAccess, bool viewAccess)
    {
        Observation = observation;
        AdminAccess = adminAccess;
        ApproverAccess = approverAccess;
        CommentAccess = commentAccess;
        EditAccess = editAccess;
        ViewAccess = viewAccess;
    }

    public static GetResponseObservationAuthorisation Create(
        GetResponseObservationDto observation,
        bool adminAccess, bool approverAccess, bool commentAccess, bool editAccess, bool viewAccess)
    {
        return new(observation, adminAccess, approverAccess, commentAccess, editAccess, viewAccess);
    }
}