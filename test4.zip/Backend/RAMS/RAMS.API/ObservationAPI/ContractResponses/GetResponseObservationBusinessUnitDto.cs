﻿namespace RAMS.API.ObservationAPI.ContractResponses;

public record GetResponseObservationBusinessUnitDto
{
    public int Id { get; init; }
    public string Code { get; init; }
    public string Name { get; init; }
    public bool IsActive { get; init; }

    protected GetResponseObservationBusinessUnitDto(int id, string code, string name, bool isActive)
    {
        Id = id;
        Code = code;
        Name = name;
        IsActive = isActive;
    }

    public GetResponseObservationBusinessUnitDto()
    {
        Code = string.Empty; 
        Name = string.Empty;
    }

    public static GetResponseObservationBusinessUnitDto Empty()
    {
        return new();
    }

    public static GetResponseObservationBusinessUnitDto Create(int id, string code, string name, bool isActive)
    {
        return new(id, code, name, isActive);
    }
}