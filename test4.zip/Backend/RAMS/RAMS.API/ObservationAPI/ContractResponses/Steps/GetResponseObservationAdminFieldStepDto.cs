﻿namespace RAMS.API.ObservationAPI.ContractResponses.Steps;

public record GetResponseObservationStatusFieldStepDto
{
    public DateTime? CancellationDate { get; init; }
    public DateTime? RiskAcceptanceDate { get; init; }
    public DateTime? ClosureDate { get; init; }
    public DateTime? DeadlineExtensionRegistrationDate { get; init; }
    public string? CancellationJustification { get; init; }
    public string? ClosureJustification { get; init; }
    public string? RiskAcceptanceJustification { get; init; }
    public string? DeadlineExtensionJustification { get; init; }
    public int Status { get; init; }

    protected GetResponseObservationStatusFieldStepDto(DateTime? cancellationDate, DateTime? riskAcceptanceDate, DateTime? deadlineExtensionRegistrationDate, DateTime? closureDate,
       string? riskAcceptanceJustification, string? deadlineExtensionJustification, string? cancellationJustification, string? closureJustification, int status)
    {
        CancellationDate = cancellationDate;
        RiskAcceptanceDate = riskAcceptanceDate;
        DeadlineExtensionRegistrationDate = deadlineExtensionRegistrationDate;
        CancellationJustification = cancellationJustification;
        ClosureJustification = closureJustification;
        ClosureDate = closureDate;
        RiskAcceptanceJustification = riskAcceptanceJustification;
        DeadlineExtensionJustification = deadlineExtensionJustification; 
        Status = status;
    }

    protected GetResponseObservationStatusFieldStepDto()
    {
    }

    public static GetResponseObservationStatusFieldStepDto Create(DateTime? cancellationDate, DateTime? riskAcceptanceDate, 
        DateTime? deadlineExtentionRegistrationDate, DateTime? closureDate, string? riskAcceptanceJustification, string? deadlineExtensionJustification, string? cancellationJustification, string? closureJustification, int status)
    {
        return new(cancellationDate, riskAcceptanceDate, deadlineExtentionRegistrationDate, closureDate, riskAcceptanceJustification, deadlineExtensionJustification, cancellationJustification, closureJustification, status);
    }
}