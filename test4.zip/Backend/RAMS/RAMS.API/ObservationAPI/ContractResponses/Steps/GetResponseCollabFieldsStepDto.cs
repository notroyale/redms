﻿using RAMS.API.RAGStatusAPI.ContractResponses;

namespace RAMS.API.ObservationAPI.ContractResponses.Steps;

public class GetResponseCollabFieldsStepDto
{
    public string? Comment { get; init; }
    public string? Comment1LoD { get; init; }
    public int RagStatus { get; init; }
    public string? RagJustification { get; init; }
    public bool ClosureSubmitted { get; init; }

    protected GetResponseCollabFieldsStepDto(string? comment, string? comment1LoD, int ragStatus, string? ragJustification, bool closureSubmitted)
    {
        Comment = comment;
        Comment1LoD = comment1LoD;
        RagStatus = ragStatus;
        RagJustification = ragJustification;
        ClosureSubmitted = closureSubmitted;
    }

    protected GetResponseCollabFieldsStepDto()
    {
        Comment1LoD = string.Empty;
    }

    public static GetResponseCollabFieldsStepDto Create(string? comment, string? comment1LoD, int ragStatus, string? ragJustification, bool closureSubmitted)
    {
        return new(comment, comment1LoD, ragStatus, ragJustification, closureSubmitted);
    }
}