﻿using RAMS.API.AttachmentAPI.ContractResponses;

namespace RAMS.API.ObservationAPI.ContractResponses.Steps
{
    public class GetResponseSupportingDocumentsStepDto
    {

        public IEnumerable<GetResponseAttachmentDto> Attachments { get; init; }

        protected GetResponseSupportingDocumentsStepDto(IEnumerable<GetResponseAttachmentDto> attachments)
        {
            Attachments = attachments;
        }

    
        public static GetResponseSupportingDocumentsStepDto Create(IEnumerable<GetResponseAttachmentDto> attachment)
        {
            return new(attachment);
        }
    }
}
