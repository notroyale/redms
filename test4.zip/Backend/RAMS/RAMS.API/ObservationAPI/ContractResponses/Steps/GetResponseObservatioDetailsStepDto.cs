﻿namespace RAMS.API.ObservationAPI.ContractResponses.Steps;

public class GetResponseObservatioDetailsStepDto
{
    public int? CategoryId { get; init; }
    public string Title { get; init; }
    public DateTime? DateIdentified { get; init; }
    public DateTime CreationDate { get; init; }
    public DateTime? Deadline { get; init; }
    public DateTime? ClosureDate { get; init; }
    public DateTime? RevisedDeadline { get; init; }
    public int? GradeID { get; init; }
    public bool? SelfRaised {  get; init; }
    public string? SelfRaisedJustification {  get; init; }
    public string? Description { get; init; }
    public string? ObservationCategoryExplanation { get; init; }

    public GetResponseObservatioDetailsStepDto(int? categoryId, string title, DateTime? dateIdentified, DateTime creationDate, DateTime? deadline, DateTime? closureDate, DateTime? revisedDeadline, int? gradeID,
        string? description, bool? selfRaised, string? selfRaisedJustification, string? observationCategoryExplanation)
    {
        CategoryId = categoryId;
        Title = title;
        DateIdentified = dateIdentified;
        CreationDate = creationDate;
        Deadline = deadline;
        ClosureDate = closureDate;
        RevisedDeadline = revisedDeadline;
        GradeID = gradeID;
        Description = description;
        SelfRaised = selfRaised;
        SelfRaisedJustification = selfRaisedJustification;
        ObservationCategoryExplanation = observationCategoryExplanation;
    }

    protected GetResponseObservatioDetailsStepDto()
    {
        Title = string.Empty;
    }

    public static GetResponseObservatioDetailsStepDto Empty()
    {
        return new();
    }

    public static GetResponseObservatioDetailsStepDto Create(int? categoryId, string title, DateTime? dateIdentified, DateTime creationDate, DateTime? deadline, DateTime? closureDate, DateTime? revisedDeadline, int? gradeID,
        string? description, bool? selfRaised, string? selfRaisedJustification, string? observationCategoryExplanation)
    {
        return new(categoryId, title, dateIdentified, creationDate, deadline, revisedDeadline, closureDate, gradeID, description, selfRaised, selfRaisedJustification, observationCategoryExplanation);
    }
}