﻿namespace RAMS.API.ObservationAPI.ContractResponses.Steps;

public record GetResponseObservationResponsibleCentreStepDto
{
    public int BusinessUnit { get; init; }
    public IReadOnlyList<GetResponseObservationBusinessAreaCountryDto> BusinessAreasCountries { get; init; }
    public IReadOnlyList<int>? LegalEntities { get; init; }
    public string ActivityOwner { get; init; }
    public string RiskOwner { get; init; }
    public string Assignee { get; init; }

    protected GetResponseObservationResponsibleCentreStepDto(
        int businessUnit,
        IReadOnlyList<GetResponseObservationBusinessAreaCountryDto> businessAreasCountries,
        IReadOnlyList<int> legalEntities,
        string activityOwner, string riskOwner, string assignee)
    {
        BusinessUnit = businessUnit;
        LegalEntities = legalEntities;
        BusinessAreasCountries = businessAreasCountries;
        ActivityOwner = activityOwner;
        RiskOwner = riskOwner;
        Assignee = assignee;
    }

    protected GetResponseObservationResponsibleCentreStepDto()
    {
        BusinessAreasCountries = new List<GetResponseObservationBusinessAreaCountryDto>();
        LegalEntities = new List<int>();
        ActivityOwner = string.Empty; 
        RiskOwner = string.Empty; 
        Assignee = string.Empty;
    }

    public static GetResponseObservationResponsibleCentreStepDto Empty()
    {
        return new();
    }

    public static GetResponseObservationResponsibleCentreStepDto Create(
        int businessUnit,
        IReadOnlyList<GetResponseObservationBusinessAreaCountryDto> businessAreasCountries,
        IReadOnlyList<int>? legalEntities,
        string activityOwner, string riskOwner, string assignee)
    {
        return new(businessUnit, businessAreasCountries,(legalEntities == null ? new List<int>(): legalEntities), activityOwner, riskOwner, assignee);
    }
}