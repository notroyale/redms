﻿namespace RAMS.API.ObservationAPI.ContractResponses.Steps;

public record GetResponseObservationAffectedFieldsStepDto
{
    public IReadOnlyList<int> BusinessUnitsAF { get; init; }
    public IReadOnlyList<int> BusinessAreasAF { get; init; }
    public IReadOnlyList<int> LegalEntitiesAF { get; init; }
    public IReadOnlyList<int> CountriesAF { get; init; }

    protected GetResponseObservationAffectedFieldsStepDto(
        IReadOnlyList<int> BusinessUnits,
        IReadOnlyList<int> BusinessAreas,
        IReadOnlyList<int> LegalEntities,
        IReadOnlyList<int> Countries)
    {
        BusinessUnitsAF = BusinessUnits;
        LegalEntitiesAF = LegalEntities;
        BusinessAreasAF = BusinessAreas;
        CountriesAF = Countries;
    }

    protected GetResponseObservationAffectedFieldsStepDto()
    {
        BusinessUnitsAF = new List<int>();
        BusinessAreasAF = new List<int>();
        LegalEntitiesAF = new List<int>();
        CountriesAF = new List<int>();
    }

    public static GetResponseObservationAffectedFieldsStepDto Empty()
    {
        return new();
    }

    public static GetResponseObservationAffectedFieldsStepDto Create(
        IReadOnlyList<int> BusinessUnitsAF,
        IReadOnlyList<int> BusinessAreasAF,
        IReadOnlyList<int> LegalEntitiesAF,
        IReadOnlyList<int> CountriesAF)
    {
        return new(BusinessUnitsAF, BusinessAreasAF, LegalEntitiesAF, CountriesAF);
    }
}