﻿namespace RAMS.API.ObservationAPI.ContractResponses.Steps;

public record GetResponseObservationRiskCatStepDto
{
    public IReadOnlyDictionary<int, List<int>> Taxonomies { get; init; }
    public IReadOnlyList<int> RegulatoryCategories { get; init; }
    public IReadOnlyList<int> Regulations { get; init; }
    public string? RegulationComment { get; init; }
    public string? BusinessLine { get; init; }
    public string? Directive { get; init; }
    public bool? ConductRisk { get; init; }
    public bool? EsgRisk { get; init; }
    public string? ConductJustification {  get; init; }
    public string? EsgJustification {  get; init; }    

    protected GetResponseObservationRiskCatStepDto(IReadOnlyDictionary<int, List<int>> taxonomies, 
        string? regulationComment, string? businessLine, string? directive, bool? conductRisk, bool? esgRisk, string? conductJustification, string? esgJustification,
        IReadOnlyList<int> regulatoryCategories, IReadOnlyList<int> regulations )
    {
        Taxonomies = taxonomies;
        RegulationComment = regulationComment;
        BusinessLine = businessLine;
        Directive = directive;
        ConductRisk = conductRisk;
        EsgRisk = esgRisk;
        ConductJustification = conductJustification;
        EsgJustification = esgJustification;
        RegulatoryCategories = regulatoryCategories;
        Regulations = regulations;
    }

    protected GetResponseObservationRiskCatStepDto()
    {
        Taxonomies = new Dictionary<int, List<int>>();
        RegulatoryCategories = new List<int>();
        Regulations = new List<int>();
    }

    public static GetResponseObservationRiskCatStepDto Empty()
    {
        return new();
    }

    public static GetResponseObservationRiskCatStepDto Create(IReadOnlyDictionary<int, List<int>> taxonomiesByLevel,
        string? regulationComment, string? businessLine, string? directive, bool? conductRisk, bool? esgRisk,
        string? conductJustification, string? esgJustification, 
        IReadOnlyList<int> regulatoryCategories, IReadOnlyList<int> regulations)
    {
        return new(taxonomiesByLevel, regulationComment, businessLine, directive, conductRisk, esgRisk, conductJustification, esgJustification, regulatoryCategories, regulations);
    }
}