﻿using RAMS.API.ActionPlanAPI.ContractResponses;

namespace RAMS.API.ObservationAPI.ContractResponses.Steps;

public record GetResponseObservationActionPlanStepDto
{
    public IReadOnlyCollection<GetResponseBaseActionPlanDto> ActionPlans { get; init; }
    public string? Recommendation { get; set; }
    public string? ProposedPlan { get; set; }

    protected GetResponseObservationActionPlanStepDto(IReadOnlyCollection<GetResponseBaseActionPlanDto> actionPlans, string? recommendation, string? proposedPlan)
    {
        ActionPlans = actionPlans;
        Recommendation = recommendation;
        ProposedPlan = proposedPlan; 
    }

    protected GetResponseObservationActionPlanStepDto()
    {
        ActionPlans = new List<GetResponseBaseActionPlanDto>();
    }

    public static GetResponseObservationActionPlanStepDto Empty()
    {
        return new();
    }

    public static GetResponseObservationActionPlanStepDto Create(IReadOnlyCollection<GetResponseBaseActionPlanDto> actionPlans, string? recommendation, string? proposedPlan)
    {
        return new(actionPlans, recommendation, proposedPlan);
    }
}