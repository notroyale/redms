﻿namespace RAMS.API.ObservationAPI.ContractResponses;

public record GetResponseObservationRegulatoryCategoryDto
{
    public int Id { get; init; }

    protected GetResponseObservationRegulatoryCategoryDto(int id)
    {
        Id = id;
    }

    public static GetResponseObservationRegulatoryCategoryDto Create(int id)
    {
        return new(id);
    }
}