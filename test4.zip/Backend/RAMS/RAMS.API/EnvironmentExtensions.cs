﻿namespace RAMS.API;

public static class EnvironmentExtensions
{
    private static readonly string Syst = "Syst";

    public static bool IsSyst(this IHostEnvironment hostEnvironment)
    {
        if (hostEnvironment == null)
        {
            throw new ArgumentNullException(nameof(hostEnvironment));
        }

        return hostEnvironment.IsEnvironment(Syst);
    }
}