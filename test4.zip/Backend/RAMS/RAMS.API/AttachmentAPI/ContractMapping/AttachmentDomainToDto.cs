﻿using RAMS.API.AttachmentAPI.ContractResponses;
using RAMS.API.BusinessUnitAPI.ContractResponses;
using RAMS.Domain;

namespace RAMS.API.AttachmentAPI.ContractMapping
{
    public static class AttachmentDomainToDto
    {
        public static IEnumerable<GetResponseAttachmentDto> ToGetAllResponseDto(this IEnumerable<ObservationAttachment> entities)
        {
            ICollection<GetResponseAttachmentDto> dtos = new List<GetResponseAttachmentDto>();

            if (entities is null)
                return dtos;

            foreach (ObservationAttachment entity in entities)
            {
                dtos.Add(entity.ToGetResponseDto());
            }

            return dtos;
        }

        public static GetResponseAttachmentDto ToGetResponseDto(this ObservationAttachment entity)
        {
            return GetResponseAttachmentDto.Create(entity.Id, entity.Filename, entity.Deleted, entity.GDPR, entity.ObservationID, entity.LoD);
        }
    }
}
