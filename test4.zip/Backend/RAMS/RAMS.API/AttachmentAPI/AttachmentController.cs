﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RAMS.API.AttachmentAPI.ContractMapping;
using RAMS.API.CommonAPI;
using RAMS.API.ObservationAPI.ContractRequests;
using RAMS.Application.AttachmentApp;
using RAMS.Application.AuditApp;
using RAMS.Application.Common;
using RAMS.Application.ObservationApp;
using RAMS.Application.RAGStatusApp;
using RAMS.Domain;
using RAMS.Domain.Enumerators;
using System.Net.Mail;

namespace RAMS.API.AttachmentAPI
{
    public class AttachmentController : APIController
    {

        private readonly IAttachmentService _attachmentService;
        private readonly ICacheService _cache;
        private readonly IAuditService _auditService;

        public AttachmentController(IAttachmentService attachmentService, ICacheService memoryCache, IAuditService auditService) : base(memoryCache)
        {
            _attachmentService = attachmentService;
            _cache = memoryCache;
            _auditService = auditService;
        }


        [HttpPost("upload-attachments")]
        public async Task<IActionResult> UploadAttachments(int id, string role, bool gdpr, [FromForm] List<IFormFile> files)
        {
            var uploadedAttachments = await _attachmentService.UploadAttachments(new AttachmentMetadata {ObservationID = id, UploaderRole = role, Gdpr = gdpr }, files);

            if (uploadedAttachments is null || uploadedAttachments.Count <= 0)
            {
                return BadRequest(uploadedAttachments);
            }


            _auditService.AddFileUploadAuditLog(id, AuditAction.Upload, uploadedAttachments);
            return Ok(uploadedAttachments.ToGetAllResponseDto()); 
        }

        [HttpGet("download-attachments")]
        public async Task<IActionResult> DownloadAttachment(int attachmentID)
        {
            var attachment = await _attachmentService.DownloadAttachment(attachmentID);

            if (attachment is null || attachment.Content is null)
            {
                return NotFound(attachmentID);
            }

            await _auditService.AddFileDownloadAuditLog(attachment.ObservationID, AuditAction.Download, attachment);
            return File(attachment.Content, "application/octet-stream", attachment.Filename);

        }

        [HttpDelete("delete")]
        public async Task<IActionResult> DeleteAttachment(int id)
        {
            bool attachment = await _attachmentService.DeleteAttachment(id);

            if (!attachment)
            {
                return NotFound(id);
            }

            return Ok(attachment);

        }
    }
}
