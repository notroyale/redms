﻿using RAMS.Domain;

namespace RAMS.API.AttachmentAPI.ContractResponses;

public record GetResponseAttachmentDto
{
    public int Id { get; init; }
    public string Filename { get; init; }
    public bool Deleted { get; init; }
    public bool? GDPR { get; init; }
    public int ObservationID { get; init; }
    public string LoD { get; set; }

    protected GetResponseAttachmentDto(int id, string filename, bool deleted, bool? gDPR, int observationID, string lod)
    {
        Id = id;
        Filename = filename;
        Deleted = deleted;
        GDPR = gDPR;
        ObservationID = observationID;
        LoD = lod;
    }
    public static GetResponseAttachmentDto Create(int id, string filename, bool deleted, bool? gDPR, int observationID, string lod)
    {
        return new(id, filename, deleted, gDPR, observationID, lod);
    }
}
