﻿using Microsoft.AspNetCore.Mvc;
using RAMS.API.CommonAPI;
using RAMS.API.UserApi.ContractMapping;
using RAMS.Application.UserApp;
using RAMS.Domain.User;

namespace RAMS.API.LdapApi;

public class UserController : APIController
{
    private readonly IUserService _userService;

    public UserController(IUserService userService)
    {
        _userService = userService;
    }

    [HttpGet("find")]
    public IActionResult Find(string bNumber)
    {
        User user = _userService.FindUser(bNumber);

        if (user is null)
            return NotFound(user);

        return Ok(user.ToDto());
    }
}