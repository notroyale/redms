﻿using RAMS.API.UserApi.ContractResponses;
using RAMS.Domain.User;

namespace RAMS.API.UserApi.ContractMapping;

public static class UserDomainToDto
{
    public static FindResponseUserDto ToDto(this User user)
    {
        return FindResponseUserDto.Create(user.BNumber, user.Name, user.Departament, user.IsActive);
    }
}