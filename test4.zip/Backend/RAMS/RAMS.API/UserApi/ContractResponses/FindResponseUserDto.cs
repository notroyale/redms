﻿namespace RAMS.API.UserApi.ContractResponses;

public record FindResponseUserDto
{
    public string BNumber { get; init; }
    public string Name { get; init; }
    public string Departament { get; init; }
    public bool IsActive { get; init; }

    protected FindResponseUserDto(string bNumber, string name, string departament, bool isActive)
    {
        BNumber = bNumber;
        Name = name;
        Departament = departament;
        IsActive = isActive;
    }

    public static FindResponseUserDto Create(string bNumber, string name, string departament, bool isActive)
    {
        return new(bNumber, name, departament, isActive);
    }
}
