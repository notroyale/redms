﻿using RAMS.API.CorsConfiguration;
using RAMS.API.SwaggerAPI;
using System.Text.Json.Serialization;

namespace RAMS.API;

public static class DependencyInjection
{
    public static IServiceCollection AddAPI(this IServiceCollection services, ConfigurationManager configuration)
    {
        services
            .AddMemoryCache()
            .AddHealthChecks();

        services.
            AddHttpClient();

        services
            .AddCors(configuration)
            .AddControllers()
            .AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
            });

        services
            .AddEndpointsApiExplorer()
            .AddSwagger();     

        return services;
    }
}