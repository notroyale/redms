using RAMS.API;
using RAMS.API.CorsConfiguration;
using RAMS.API.SwaggerAPI;
using RAMS.Application;
using RAMS.Infrastructure;
using RAMS.Persistence;

var builder = WebApplication.CreateBuilder(args);

var services = builder.Services;
var configuration = builder.Configuration;

builder.Host.ConfigureAppConfiguration((context, config) =>
{
    config.AddJsonFile($"appsettings.{context.HostingEnvironment.EnvironmentName}.json", optional: true, reloadOnChange: true);
    config.AddEnvironmentVariables();

    Console.WriteLine($"Environment: {context.HostingEnvironment.EnvironmentName}");
});

builder.WebHost.ConfigureKestrel(options => options.Limits.MaxRequestBodySize = 100 * 1024 * 1024); //max body file size - 100mb

services
    .AddAPI(configuration)
    .AddApplication()
    .AddInfrastructure()
    .AddPersistence(configuration);

var app = builder.Build();

if (app.Environment.IsDevelopment() || app.Environment.IsSyst())
    app.AddSwagger();

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.AddCors();

app.UseAuthentication();

app.UseSession();
app.UseAuthorization();

app.MapControllers();

app.MapHealthChecks("/health");

app.Run();