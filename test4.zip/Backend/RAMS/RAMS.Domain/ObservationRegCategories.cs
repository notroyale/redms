﻿using RAMS.Domain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain;

public class ObservationRegCategories : Entity<ObservationRegCategories>
{
    //public int Id { get; init; }
    public int ObservationID { get; set; }
    public int RegulatoryCategoryID { get; set; }
    public string ModifiedBy { get; set; }
    public Observation? Observation { get; set; }
    public RegulatoryCategory? RegulatoryCategory { get; set; }

    public ObservationRegCategories(int observationID, int regulatoryCategoryID)
    {
        ObservationID = observationID;
        RegulatoryCategoryID = regulatoryCategoryID;
    }

    public ObservationRegCategories()
    {
       
    }

    public void Update(ObservationRegCategories entity)
    {
        ObservationID = entity.ObservationID;
        RegulatoryCategoryID = entity.RegulatoryCategoryID;
    }
}
