﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class TaxonomyRelation : Entity<TaxonomyRelation>
{
    public int TaxonomyID { get; set; }
    public int TaxonomySubLevelID { get; set; }
    public Taxonomy Taxonomy { get; set; }
    public Taxonomy TaxonomySubLevel { get; set; }

    public TaxonomyRelation(int taxonomyID, int taxonomySubLevelID)
    {
        TaxonomyID = taxonomyID;
        TaxonomySubLevelID = taxonomySubLevelID;
    }

    public void Update(TaxonomyRelation entity)
    {
        TaxonomyID = entity.TaxonomyID;
        TaxonomySubLevelID = entity.TaxonomySubLevelID;
    }
}