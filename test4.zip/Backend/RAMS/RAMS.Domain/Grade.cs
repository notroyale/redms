﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class Grade : IEntity<int>, Entity<Grade>
{
    public int Id { get; init; }
    public string Name { get; set; }
    public bool IsActive { get; set; }
    //public IReadOnlyCollection<Observation> Observations { get; set; }


    public void Update(Grade entity)
    {
        Name = entity.Name;
        IsActive = entity.IsActive;
    }
}