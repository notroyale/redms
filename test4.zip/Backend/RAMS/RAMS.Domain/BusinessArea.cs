﻿using RAMS.Domain.Common;
using System.Text.Json.Serialization;

namespace RAMS.Domain;
public class BusinessArea : IEntity<int>, Entity<BusinessArea>
{
    public int Id { get; init; }
    public string Name { get; set; }
    public bool IsActive { get; set; } 
    public bool LegalEntity { get; set; }
    public bool IsDefault { get; set; }
    public int BusinessUnitID { get; set; }
    public BusinessUnit BusinessUnit { get; set; }
    public IReadOnlyList<Observation> Observations { get; set; }

    public BusinessArea(int id, string name, bool active, bool isDefault, int businessUnitID, BusinessUnit businessUnit)
    {
        Id = id;
        Name = name;
        IsActive = active;
        IsDefault = isDefault;
        BusinessUnitID = businessUnitID;
        BusinessUnit = businessUnit;
    }

    public BusinessArea()
    {

    }

    public void Update(BusinessArea entity)
    {
        Name = entity.Name;
    }
    
}