﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class Category : IEntity<int>, Entity<Category>
{
    public int Id { get; init; }
    public int Value { get; init; }
    public string Description { get; set; }
    public bool IsActive { get; set; }
    public IReadOnlyCollection<Observation> Observations { get; set; }


    public void Update(Category entity)
    {
        Description = entity.Description;
        IsActive = entity.IsActive;
    }
}