﻿using RAMS.Domain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain
{
    public class ObservationAffectedBusinessAreas : Entity<ObservationAffectedBusinessAreas>
    {
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int Id { get; init; }
        public int ObservationID { get; private set; }
        public int BusinessAreaID { get; private set; }
        public string ModifiedBy { get; set; }
        public Observation Observation { get; set; }

        public ObservationAffectedBusinessAreas(int observationID, int businessAreaID, string modifiedBy)
        {
            ObservationID = observationID;
            BusinessAreaID = businessAreaID;
            ModifiedBy = modifiedBy;
        }

        public void Update(ObservationAffectedBusinessAreas entity)
        {
            ObservationID = entity.ObservationID;
            BusinessAreaID = entity.BusinessAreaID;
        }
        public ObservationAffectedBusinessAreas()
        {

        }
    
    }
}
