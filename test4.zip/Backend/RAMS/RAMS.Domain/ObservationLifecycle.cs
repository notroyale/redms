﻿namespace RAMS.Domain;

public class ObservationLifecycle
{
    public int ObservationID { get; set; }
    public DateTime CreationDate { get; set; }
    public TimelineDate Deadline { get; set; }
    public string CreationUser { get; set; }

    public TimelineDate ClosureDate { get; set; }
    public string ClosuredBy { get; set; }
    public string? ClosureJustification { get; set; }

    public TimelineDate RevisedDeadline { get; set; }
    public string RevisedDeadlineBy { get; set; }
    public string? RevisedDeadlineJustification { get; set; }

    public TimelineDate DeadlineExtensionDate { get; set; }
    public string DeadlineExtendedBy { get; set; }
    public string? DeadlineExtensionJustification { get; set; }

    public TimelineDate CancellationDate { get; set; }
    public string CancellationBy { get; set; }
    public string? CancellationJustification { get; set; }

    public TimelineDate RiskAcceptanceDate { get; set; }
    public string RiskAcceptanceBy { get; set; }
    public string? RiskAcceptanceJustification { get; set; }

    public ObservationLifecycle(int observationID, DateTime creationDate, TimelineDate deadline, string creationUser)
    {
        ObservationID = observationID;
        CreationDate = creationDate;
        Deadline = deadline;
        CreationUser = creationUser;
    }
}

public record TimelineDate
{
    public DateTime Value { get; init; }

    protected TimelineDate(DateTime date)
    {
        Value = date;
    }

    public static TimelineDate Create(DateTime date, DateTime creationDate)
    {
        if (DateTime.Compare(date, creationDate) <= 0)
            throw new ArgumentException("Date cannot be in the past or equal to the current date.");

        return new TimelineDate(date);
    }
}

public class ObservationState
{
    public int ObservationID { get; init; }
    public int StatusID { get; init; }
    public TimelineDate DateTime { get; init; }
    public string ChangedBy { get; init; }
    public string Justification { get; init; }

    public ObservationState(int observationID, int statusID, TimelineDate dateTime, string changedBy, string justification)
    {
        ObservationID = observationID;
        StatusID = statusID;
        DateTime = dateTime;
        ChangedBy = changedBy;
        Justification = justification;
    }
}