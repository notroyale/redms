﻿namespace RAMS.Domain.User;

public class User
{
    public string BNumber { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string Departament { get; set; }
    public bool IsActive { get; set; }
    public AccessControl AccessControl { get; set; }
    public bool HasAccess => AccessControl.HasAccess();

    public User(string bNumber, string name, string email, bool isActive, AccessControl accessControl)
    {
        BNumber = bNumber;
        Name = name;
        Email = email;
        IsActive = isActive;
        AccessControl = accessControl;
    }
    public User(string bNumber, string name, string email, string departament, bool isActive)
    {
        BNumber = bNumber;
        Name = name;
        Email = email;
        IsActive = isActive;
        Departament = departament;
    }

    public User(string bNumber, string name, string email, bool isActive)
    {
        BNumber = bNumber;
        Name = name;
        Email = email;
        IsActive = isActive;
    }

    public User()
    {
    }
}