﻿namespace RAMS.Domain.User;

public class AccessPermission 
{
    public bool HasViewAccess { get; set; }
    public bool HasEditAccess { get; set; }
    public bool HasCommentAccess { get; set; }
    public bool HasApproverAccess { get; set; }
    public bool HasAdminAccess { get; set; }

    public AccessPermission(bool hasViewAccess, bool hasEditAccess, bool hasCommentAccess, bool hasApproverAccess, bool hasAdminAccess)
    {
        HasViewAccess = hasViewAccess;
        HasEditAccess = hasEditAccess;
        HasCommentAccess = hasCommentAccess;
        HasApproverAccess = hasApproverAccess;
        HasAdminAccess = hasAdminAccess;
    }

    public AccessPermission()
    {
    }
}