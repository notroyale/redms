﻿namespace RAMS.Domain.User;

public class AccessControl
{
    public Dictionary<int, AccessPermission> AuthorisedBusinessUnits { get; }
    public Dictionary<int, AccessPermission> AuthorisedLegalEntities { get; }
    public IEnumerable<int> BusinessUnitIds => AuthorisedBusinessUnits.Keys;
    public IEnumerable<int> LegalEntityIds => AuthorisedLegalEntities.Keys;

    protected AccessControl()
    {
        AuthorisedBusinessUnits = new Dictionary<int, AccessPermission>();
        AuthorisedLegalEntities = new Dictionary<int, AccessPermission>();
    }

    public bool HasAccess()
    {
        return AuthorisedBusinessUnits is not null && AuthorisedBusinessUnits.Any() ||
               AuthorisedLegalEntities is not null && AuthorisedLegalEntities.Any();
    }

    private void AddAuthorisedBusinessUnit(int id, AuthorisationAccessPermission authorisationAccessPermission)
    {
        AuthorisedBusinessUnits.Add(id, new AccessPermission(
            authorisationAccessPermission.ViewAccess,
            authorisationAccessPermission.EditAccess,
            authorisationAccessPermission.CommentAccess,
            authorisationAccessPermission.ApproverAccess,
            authorisationAccessPermission.AdminAccess)
        );
    }

    private void AddAuthoriseLegalEntity(int id, AuthorisationAccessPermission authorisationAccessPermission)
    {
        AuthorisedLegalEntities.Add(id, new AccessPermission(
            authorisationAccessPermission.ViewAccess,
            authorisationAccessPermission.EditAccess,
            authorisationAccessPermission.CommentAccess,
            authorisationAccessPermission.ApproverAccess,
            authorisationAccessPermission.AdminAccess)
        );
    }

    private void SetAccess(int id, AuthorisationAccessPermission authorisationAccessPermission)
    {
        AuthorisedBusinessUnits[id].HasViewAccess |= authorisationAccessPermission.ViewAccess;
        AuthorisedBusinessUnits[id].HasEditAccess |= authorisationAccessPermission.EditAccess;
        AuthorisedBusinessUnits[id].HasCommentAccess |= authorisationAccessPermission.CommentAccess;
        AuthorisedBusinessUnits[id].HasApproverAccess |= authorisationAccessPermission.ApproverAccess;
        AuthorisedBusinessUnits[id].HasAdminAccess |= authorisationAccessPermission.AdminAccess;
    }

    public static AccessControl Build(IEnumerable<Authorisation> authorisations)
    {
        AccessControl accessControl = new();

        foreach (Authorisation authorisation in authorisations)
        {
            foreach (BusinessUnit businessUnit in authorisation.BusinessUnits)
            {
                if (!accessControl.AuthorisedBusinessUnits.ContainsKey(businessUnit.Id))
                {
                    accessControl.AddAuthorisedBusinessUnit(businessUnit.Id, authorisation.AccessPermission);

                    continue;
                }

                accessControl.SetAccess(businessUnit.Id, authorisation.AccessPermission);
            }

            foreach (LegalEntity legalEntity in authorisation.LegalEntities)
            {
                if (!accessControl.AuthorisedLegalEntities.ContainsKey(legalEntity.Id))
                {
                    accessControl.AddAuthoriseLegalEntity(legalEntity.Id, authorisation.AccessPermission);

                    continue;
                }

                accessControl.SetAccess(legalEntity.Id, authorisation.AccessPermission);
            }
        }

        return accessControl;
    }
}