﻿namespace RAMS.Domain.User;

public class LdapUser
{
    public string BNumber { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string Departament { get; set; }
    public bool IsActive { get; set; }

    public LdapUser(string bNumber, string name, string email, bool isActive)
    {
        BNumber = bNumber;
        Name = name;
        Email = email;
        IsActive = isActive;
    }
    public LdapUser(string bNumber, string name, bool isActive, string departament)
    {
        BNumber = bNumber;
        Name = name;
        Departament = departament;
        IsActive = isActive;
    }

    public LdapUser()
    {

    }
}