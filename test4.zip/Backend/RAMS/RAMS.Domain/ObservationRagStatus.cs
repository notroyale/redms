﻿using RAMS.Domain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain
{
    public class ObservationRagStatus : IEntity<int>, Entity<ObservationRagStatus>
    {
        public int Id { get; init; }
        public int ObservationID { get; set; }
        public int CurrentRAGStatusID { get; set; }
        public string? Comment { get; set; }
        public string ModifiedBy { get; set; }

        public Observation Observation { get; set; }

        public void Update(ObservationRagStatus entity)
        {
            ObservationID = entity.ObservationID;
            CurrentRAGStatusID = entity.CurrentRAGStatusID;
            Comment = entity.Comment;
            //ModifiedBy = entity.ModifiedBy;
        }
        public void Update(int observationID, int currentRagStatusID, string ragJustification, string modifiedBy)
        {
            ObservationID = observationID;
            CurrentRAGStatusID = currentRagStatusID;
            Comment = ragJustification;
            ModifiedBy = modifiedBy;
        }
    }
}
