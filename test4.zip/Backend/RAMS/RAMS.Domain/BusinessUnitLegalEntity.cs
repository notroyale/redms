﻿namespace RAMS.Domain;

public class BusinessUnitLegalEntity
{
    public int BusinessUnitID { get; init; }
    public int LegalEntityID { get; init; }
    public bool IsActive { get; init; }
    public LegalEntity LegalEntity { get; set; }

    public BusinessUnitLegalEntity(int businessUnitID, int legalEntityID, bool isActive)
    {
        BusinessUnitID = businessUnitID;
        LegalEntityID = legalEntityID;
        IsActive = isActive;
    }

    public BusinessUnitLegalEntity()
    {
    }
}