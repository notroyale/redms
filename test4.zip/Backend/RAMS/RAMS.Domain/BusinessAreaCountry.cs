﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class BusinessAreaCountry : IEntity<int>, Entity<BusinessAreaCountry>
{
    public int Id { get; init; }
    public BusinessArea BusinessArea { get;  set; }
    public Country Country { get;  set; }
    public IEnumerable<Observation> Observation { get;  set; }

    public BusinessAreaCountry(int id, BusinessArea businessArea, Country country)
    {
        Id = id;
        Country = country;
        BusinessArea = businessArea;
    }

    public BusinessAreaCountry()
    {

    }

    public void Update(BusinessAreaCountry entity)
    {
        BusinessArea = entity.BusinessArea;
        Country = entity.Country;
    }
}