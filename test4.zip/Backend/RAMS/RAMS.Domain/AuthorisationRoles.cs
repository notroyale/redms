﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain
{
    public class AuthorisationRoles
    {
        public int ID { get; set; }
        public int AuthorisationID { get; set; }
        public int RoleID { get; set; }
    }
}
