﻿using RAMS.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain
{
    public class ObservationAttachment : IEntity<int>, Entity<ObservationAttachment>
    {
        public int Id { get; init; }
        public string Filename { get; set; }
        public bool Deleted { get; set; }
        public bool? GDPR { get; set; }
        public string? UploadUser { get; set; }
        public DateTime? UploadDate { get; set; }
        public int RetentionPeriod { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string? LoD { get; set; }
        public byte[]? Content { get; set; }
        public int ObservationID { get; set; }
        public Observation Observation { get; set; }

        public void Update(ObservationAttachment entity)
        {
            throw new NotImplementedException();
        }
    }
}
