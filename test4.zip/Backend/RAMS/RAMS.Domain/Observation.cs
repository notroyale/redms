﻿using RAMS.Domain.Common;
using RAMS.Domain.Observations.Steps;

namespace RAMS.Domain;

public class Observation : IEntity<int>, Entity<Observation>, IAuditableEntity
{
    public int Id { get; init; }
    public string Title { get; set; } = string.Empty;
    public int StatusID { get; set; }
    //public int GradeID { get; set; }
    //public Grade Grade { get; set; }
    public string Summary { get; set; } = string.Empty;
    public string? Recommendation { get; set; }
    public string? Comment { get; set; }
    public string Assignee { get; set; } = string.Empty;
    public string ActivityOwner { get; set; } = string.Empty;
    public string? ProposedPlan { get; set; }
    public string? RegistrationNumber { get; set; }
    public string RiskOwner { get; set; } = string.Empty;
    public string? BusinessLine { get; set; }
    public string? Directive { get; set; }
    public bool Submitted { get; set; }
    public bool Deleted { get; set; }
    public string? MitigationActionComment { get; set; }
    public int? RiskAssessmentId { get; set; }
    public int BusinessUnitId { get; set; }
    public int? GroupObservationId { get; set; }
    public int CategoryId { get; set; }
    //public int Comment1LoDId { get; set; }
    public int RAGStatusID { get; set; }
    public string? Comment1LoD { get; set; }
    //public bool RelatedToConductRisk { get; set; }
    //public bool RelatedToESG {  get; set; }
    public string? ObservationCategoryExplanation { get; set; }
    //public string? ConductRiskJustification { get; set; }
    //public string? ESGJustification { get; set; }
    public string? CancellationComment { get; set; }
    public bool SubmittedForClosure { get; set; }
    public string? ClosureJustification {  get; set; }
    public string? DeadlineExtensionJustification {  get; set; }
    public RAGStatus RAGStatus { get; set; }
    public ObservationRagStatus ObservationRagStatus { get; set; }
    public BusinessUnit BusinessUnit { get; set; }
    public ObservationSelfRaisedIssue SelfRaisedIssue { get; set; }
    public ObservationBinaryFields BinaryFields { get; set; }
    public ObservationGrade ObservationGrade { get; set; }
    public ICollection<ObservationAffectedBusinessUnits> AffectedBusinessUnits { get; set; }
    public ICollection<ObservationAffectedBusinessAreas> AffectedBusinessAreas { get; set; }
    public ICollection<ObservationAffectedLegalEntities> AffectedLegalEntities { get; set; }
    public ICollection<ObservationAffectedCountries> AffectedCountries { get; set; }
    public ICollection<ObservationLegalEntity> LegalEntities { get; set; }
    public ICollection<ObservationTaxonomy> Taxonomies { get; set; }
    public IReadOnlyList<BusinessArea> BusinessAreas { get; set; }
    public ICollection<ObservationRegulation> Regulations { get; set; }
    public ICollection<ObservationRegCategories> RegulatoryCategories { get; set; }
    public IReadOnlyList<Country> Countries { get; set; }
    public IEnumerable<ObservationBusinessArea> BusinessAreasCountry { get; set; }
    public IReadOnlyList<ActionPlan> ActionPlans { get; set; }
    public IReadOnlyList<ObservationAttachment> Attachments { get; set; }
    public string CreationUser { get; set; } = string.Empty;
    public DateTime CreationDate { get; set; }
    public DateTime? ClosureDate { get; set; }
    public string? ClosureUser { get; set; }
    public DateTime? Deadline { get; set; }
    public DateTime? DateIdentified { get; set; }
    public DateTime? RevisedDeadline { get; set; }
    public DateTime? DeadlineExtensionDate { get; set; }
    public DateTime? RiskAcceptanceDate { get; set; }   
    public DateTime? CancellationDate { get; set; }   
    public DateTime ModifiedDate { get; set; }
    public string? ModifiedUser { get; set; }
    public Category Category { get; set; }

    public Status Status { get; set; }
    //public DateTime PeriodStart { get; set; }
    //public DateTime PeriodEnd { get; set; }

    //public Status Status { get; set; }
    //public ObservationLifecycle Lifecycle { get; set; }


    public Observation()
    {

        ObservationGrade = new ObservationGrade(1, Id, "");
    }

    public Observation(int id, string title, int categoryId, int grade, string riskOwner, int statusID, int rAGStatusID, int businessUnitId, DateTime creationDate, string creationUser, DateTime? closureDate, DateTime deadline , ICollection<ObservationLegalEntity> legalEntities, Status status)
    {
        Id = id;
        Title = title;
        CategoryId = categoryId;
        //GradeID = grade;
        RiskOwner = riskOwner;
        StatusID = statusID;
        RAGStatusID = rAGStatusID;
        BusinessUnitId = businessUnitId;
        CreationDate = creationDate;
        CreationUser = creationUser;
        ClosureDate = closureDate;
        Deadline = deadline;
        LegalEntities = legalEntities;
        Status = status;
    }

    public string? GetRegulationComment()
    {
        if (Regulations is null || Regulations.Count == 0)
            return null;

        string? regulationComment = null;

        foreach (ObservationRegulation regulation in Regulations)
        {
            if (!string.IsNullOrEmpty(regulation.RegulationComment))
            {
                regulationComment = regulation.RegulationComment;
            }
        }

        return regulationComment;
    }

    public string? GetRAGStatusComment()
    {
        if (ObservationRagStatus is null)
            return string.Empty;

        return ObservationRagStatus.Comment;
    }

    public string? GetSefRaisedIssueComment()
    {
        if (BinaryFields is null)
            return string.Empty;

        return BinaryFields.IsSelfRaisedJustification;
    }

    public bool? IsSelfRaisedIssue()
    {
        if (BinaryFields is null)
            return null;

        return BinaryFields.IsSelfRaised;
    }

    public string? GetRelatedToESGJustification()
    {
        if (BinaryFields is null)
            return string.Empty;

        return BinaryFields.ESGJustification;
    }

    public bool? IsRelatedToESG()
    {
        if (BinaryFields is null)
            return null;

        return BinaryFields.RelatedToESG;
    }

    public string? GetConductRiskJustification()
    {
        if (BinaryFields is null)
            return string.Empty;

        return BinaryFields.ConductRiskJustification;
    }

    public bool? IsRelatedToConductRisk()
    {
        if (BinaryFields is null)
            return null;

        return BinaryFields.RelatedToConductRisk;
    }

    public void Update(Observation entity)
    {
        Title = entity.Title;
        BusinessUnitId = entity.BusinessUnitId;
    }

    public void SetCreation(DateTime dateTime, string currentUser)
    {
        CreationDate = dateTime;
        ModifiedDate = dateTime;
        ModifiedUser = currentUser;
        CreationUser = currentUser;

    }
    public void UpdateBinaryFields(ObservationDetailsStep detailsStep, ObservationRiskCategorizationStep riskCategorizationStep, int observationID, string currentUser)
    {
        if (BinaryFields == null)
        {
            BinaryFields = new ObservationBinaryFields(observationID, detailsStep.IsSelfRaised, detailsStep.SelfRaisedJustification, riskCategorizationStep.EsgRisk, riskCategorizationStep.EsgJustification, riskCategorizationStep.ConductRisk, riskCategorizationStep.ConductJustification, currentUser) { };
            return;
        }
        BinaryFields.UpdateSelfRaised(detailsStep.IsSelfRaised, detailsStep.SelfRaisedJustification, currentUser);
        BinaryFields.UpdateESG(riskCategorizationStep.EsgRisk, riskCategorizationStep.EsgJustification, currentUser);
        BinaryFields.UpdateConductRisk(riskCategorizationStep.ConductRisk, riskCategorizationStep.ConductJustification, currentUser);
    }

    public void UpdateDetailsStep(ObservationDetailsStep entity, string currentUser, int observationID)
    {
        Title = entity.Title;
        Summary = entity.Summary;
        //GradeID = entity.GradeID;
        CategoryId = entity.CategoryId;
        Deadline = entity.Deadline;
        DateIdentified = entity.DateIdentified;
        RevisedDeadline = entity.RevisedDeadline;
        ObservationCategoryExplanation = entity.ObservationCategoryExplanation;


        //if (SelfRaisedIssue == null)
        //   {
        //        SelfRaisedIssue = new ObservationSelfRaisedIssue(observationID, entity.IsSelfRaised, entity.SelfRaisedJustification, currentUser) { };
        //   }

        //SelfRaisedIssue.Update(entity.IsSelfRaised, entity.SelfRaisedJustification);
        //SelfRaisedIssue.ModifiedBy = currentUser;
        if (ObservationGrade != null)
        {
            ObservationGrade.Update(observationID, entity.GradeID, currentUser);
            return;

        }
        ObservationGrade = new ObservationGrade(entity.GradeID, observationID, currentUser);

        return;

       

    }

    public void UpdateResposibilityCentreStep(ObservationResposibilityCentreStep entity, string currentUser)
    {
        ActivityOwner = entity.ActivityOwner;
        Assignee = entity.Assignee;
        RiskOwner = entity.RiskOwner;
        BusinessUnitId = entity.BusinessUnitID;

        if (entity.LegalEntities is null)
        {
            LegalEntities.Clear();
            return;
        }

        foreach (var le in entity.LegalEntities)
        {
            if (!LegalEntities.Any(x => x.LegalEntityID == le))
            {
                LegalEntities.Add(new ObservationLegalEntity(Id, le, currentUser));
            }
        }

        List<ObservationLegalEntity> auxList = new();
        auxList.AddRange(LegalEntities);

        foreach (var item in auxList)
        {
            if (!entity.LegalEntities.Any(newItem => newItem == item.LegalEntityID))
            {
                LegalEntities.Remove(item);
            }
        }
    }

    public void UpdateCollaborationFieldsStep(ObservationCollaborationFieldsStep request, string currentUser, int observationID)
    {
       Comment1LoD = request.Comment1LoD;
       Comment = request.Comment;
       RAGStatusID = request.RagStatusID;

        if (ObservationRagStatus == null)
        {
            ObservationRagStatus = new ObservationRagStatus()
            {
                CurrentRAGStatusID = request.RagStatusID,
                ObservationID = observationID,
                Comment = request.RagJustification,
                ModifiedBy = currentUser
            };
        }

        ObservationRagStatus.Update(observationID, request.RagStatusID, request.RagJustification, currentUser);
        SubmittedForClosure = request.ClosureSubmitted;
        return;
    }
    
    public void UpdateStatusStep(ObservationStatusStep request)
    {
        StatusID = request.Status;
        ClosureDate = request.ClosureDate;
        ClosureJustification = request.ClosureJustification;
        CancellationDate = request.CancellationDate;
        CancellationComment = request.CancellationJustification;
        DeadlineExtensionDate = request.DeadlineExtensionRegistrationDate;
        DeadlineExtensionJustification = request.DeadlineExtensionJustification;
        RiskAcceptanceDate = request.RiskAcceptanceDate;
    }

    public void UpdateAffectedFieldsStep(ObservationAffectedFieldsStep request, string currentUser)
    {
        if (request.AffectedBusinessUnits is null)
        {
            AffectedBusinessUnits.Clear();
        }
        else
        {
            foreach (var bu in request.AffectedBusinessUnits)
            {
                var foundBusinessUnit = AffectedBusinessUnits.FirstOrDefault(x => x.BusinessUnitID == bu);
                if (foundBusinessUnit is null)
                {
                    AffectedBusinessUnits.Add(new ObservationAffectedBusinessUnits(Id, bu, currentUser));
                }

            }
            List<ObservationAffectedBusinessUnits> auxList = new();
            auxList.AddRange(AffectedBusinessUnits);
            foreach (var item in auxList)
            {
                if (!request.AffectedBusinessUnits.Any(newItem => newItem == item.BusinessUnitID))
                {
                    AffectedBusinessUnits.Remove(item);
                }
            }
           

        }
        
        if (request.AffectedBusinessAreas is null)
        {
            AffectedBusinessAreas.Clear();
        }
        else
        {
            foreach (var ba in request.AffectedBusinessAreas)
            {
                var foundBusinessAreas = AffectedBusinessAreas.FirstOrDefault(x => x.BusinessAreaID == ba);
                if (foundBusinessAreas is null)
                {
                    AffectedBusinessAreas.Add(new ObservationAffectedBusinessAreas(Id, ba, currentUser));
                }
            }
            List<ObservationAffectedBusinessAreas> auxList = new();
            auxList.AddRange(AffectedBusinessAreas);
            foreach (var item in auxList)
            {
                if (!request.AffectedBusinessAreas.Any(newItem => newItem == item.BusinessAreaID))
                {
                    AffectedBusinessAreas.Remove(item);
                }
            }

        }

        if (request.AffectedLegalEntities is null)
        {
            AffectedLegalEntities.Clear();
        }
        else
        {
            foreach (var le in request.AffectedLegalEntities)
            {
                var foundLegalEntity = AffectedLegalEntities.FirstOrDefault(x => x.LegalEntityID == le);
                if (foundLegalEntity is null)
                {
                    AffectedLegalEntities.Add(new ObservationAffectedLegalEntities(Id, le, currentUser));
                }
            }
            List<ObservationAffectedLegalEntities> auxList = new();
            auxList.AddRange(AffectedLegalEntities);
            foreach (var item in auxList)
            {
                if (!request.AffectedLegalEntities.Any(newItem => newItem == item.LegalEntityID))
                {
                    AffectedLegalEntities.Remove(item);
                }
            }
        }

        if (request.AffectedCountries is null)
        {
            AffectedCountries.Clear();
        }
        else
        {
            foreach (var ct in request.AffectedCountries)
            {
                var foundCountry = AffectedCountries.FirstOrDefault(x => x.CountryID == ct);
                if (foundCountry is null)
                {
                    AffectedCountries.Add(new ObservationAffectedCountries(Id, ct, currentUser));
                }
            }
            List<ObservationAffectedCountries> auxList = new();
            auxList.AddRange(AffectedCountries);
            foreach (var item in auxList)
            {
                if (!request.AffectedCountries.Any(newItem => newItem == item.CountryID))
                {
                    AffectedCountries.Remove(item);
                }
            }
        }
    }
    

    public void UpdateClosurFeldsStep(ObservationClosureFieldsStep request)
    {
        StatusID = request.StatusID;
        RiskAcceptanceDate = request.RiskAcceptanceDate;
        DeadlineExtensionDate = request.DeadlineExtentionRegistrationDate;
        CancellationDate = request.CancellationDate;
        CancellationComment = request.CancellationJustification;
        ClosureJustification = request.ClosureJustification;
    }

    public void ObservarionClosureStep(ObservationClosureStep request, string closureUser, DateTime dateTime)
    {
        StatusID = request.Status;
        ClosureJustification = request.ClosureJustification;
        ClosureDate = dateTime;
        ClosureUser = closureUser;
    }

    public void UpdateRiskCategorizationeStep(ObservationRiskCategorizationStep request, Taxonomy taxonomy, string currentUser)
    {
        Directive = request.Directive;
        BusinessLine = request.BusinessLine;
        //RelatedToESG = request.EsgRisk;
        //RelatedToConductRisk = request.ConductRisk;
        //ESGJustification = request.EsgJustification;
        //ConductRiskJustification = request.ConductJustification;

        UpdateRegulations(request.Regulations, request.RegulationComment, currentUser);
        UpdateRegCategories(request.RegCategories, currentUser);
        UpdateTaxonomies(request, taxonomy,currentUser);
    }

    public void UpdateActionPlanStep(ObservationActionPlanStep request)
    {
        Recommendation = request.Recommendation;
    }

    public void SetSubmissionState()
    {
        Submitted = true;
    }

    private void UpdateRegulations(ICollection<int> regulationIds, string? regulationComment, string currentUser)
    {
        if (Regulations is null || regulationIds is null)
        {
            Regulations = new List<ObservationRegulation>();
            return;
        }

        foreach (ObservationRegulation item in Regulations)
        {
            if (regulationIds.Contains(item.RegulationID)) 
                continue;

            Regulations.Remove(item);
        }

        foreach (int regId in regulationIds)
        {
            if (Regulations.Any(x => x.RegulationID == regId))
                continue;

            Regulations.Add(new ObservationRegulation()
            {
                ObservationID = Id,
                RegulationID = regId,
                RegulationComment = regulationComment,//FIX this (Fixed - needs test)
                ModifiedBy = currentUser
            });
        }
    }

    private void UpdateRegCategories(ICollection<int> regCategories, string currentUser)
    {
        if (RegulatoryCategories is null || regCategories is null || regCategories.Count == 0)
        {
            RegulatoryCategories = new List<ObservationRegCategories>();
            return;
        }

        foreach (var item in RegulatoryCategories)
        {
            if (regCategories.Contains(item.RegulatoryCategoryID))
                continue;

            RegulatoryCategories.Remove(item);
        }

        foreach (int regId in regCategories)
        {
            if (HasRegCategory(regId))
                continue;

            RegulatoryCategories.Add(new ObservationRegCategories()
            {
                ObservationID = Id,
                RegulatoryCategoryID = regId,
                ModifiedBy = currentUser
            });
        }
    }

    private void UpdateTaxonomies(ObservationRiskCategorizationStep request, Taxonomy taxonomy, string currentUser)
    {
        if (!request.HasValidTax1())
            return;

        if (!HasTaxonomy(request.TaxLevel1))
        {
            Taxonomies.Clear();

            Taxonomies.Add(new ObservationTaxonomy()
            {
                ObservationID = Id,
                TaxonomyID = request.TaxLevel1,
                ModifiedBy = currentUser
            });
        }

        foreach (var item in Taxonomies)
        {
            if (request.HasTaxonomy(item.TaxonomyID))
            {
                Taxonomies.Remove(item);
            }
        }

        foreach (int id in request.TaxLevel2)
        {
            if (HasTaxonomy(id))
                continue;

            if (!taxonomy.HasChild(id))
                continue;

            Taxonomies.Add(new ObservationTaxonomy()
            {
                ObservationID = Id,
                TaxonomyID = id,
                ModifiedBy = currentUser
            });
        }

        foreach (int id in request.TaxLevel3)
        {
            if (HasTaxonomy(id))
                continue;

            foreach (Taxonomy taxLevl2 in taxonomy.Children)
            {
                if (!taxLevl2.HasChild(id))
                    continue;

                Taxonomies.Add(new ObservationTaxonomy()
                {
                    ObservationID = Id,
                    TaxonomyID = id,
                    ModifiedBy = currentUser
                });

                break;
            }
        }
    }

    private bool HasRegulation(int id)
    {
        return Regulations.Any(x => x.RegulationID == id);
    }
    
    private bool HasRegCategory(int id)
    {
        return RegulatoryCategories.Any(x => x.RegulatoryCategoryID == id);
    }

    private bool HasTaxonomy(int id)
    {
        return Taxonomies.Any(x => x.TaxonomyID == id);
    }
}