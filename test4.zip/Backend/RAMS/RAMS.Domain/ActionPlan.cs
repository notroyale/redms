﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class ActionPlan : IEntity<int>, Entity<ActionPlan>
{
    public int Id { get; init; }
    public string? ActionTitle { get; set; }
    public string? ActionSummary { get; set; }
    public int? BusinessAreaID { get; set; }
    public int ObservationID { get; set; }
    public string? Assignee { get; set; }
    public DateTime Deadline { get; set; }
    public string? CreationUser { get; set; }
    public DateTime CreationDate { get; set; }
    public string? ModifiedUser { get; set; }
    public DateTime ModifiedDate { get; set; }
    public int ActionStatus { get; set; }
    public DateTime? ClosureDate { get; set; }
    public string? ClosureUser { get; set; }
    public int? TaxonomyLevel3ID { get; set; }
    public string? ActionComment1LoD { get; set; }
    public DateTime? ActionComment1LoDDate { get; set; }
    public string? ActionComment1LODUser { get; set; }
    public string? ActivityOwner { get; set; }
    public Observation Observation { get; set; }

    public void Update(ActionPlan entity)
    {
        ActionTitle = entity.ActionTitle;
        ActionSummary = entity.ActionSummary;
        BusinessAreaID = entity.BusinessAreaID;
        Assignee = entity.Assignee;
        TaxonomyLevel3ID = entity.TaxonomyLevel3ID;
        Deadline = entity.Deadline;
        ActivityOwner = entity.ActivityOwner;
        ActionComment1LoD = entity.ActionComment1LoD;
    }
    public void SetCreationValues(string creationUser, DateTime creationDate)
    {
        CreationUser = creationUser;
        CreationDate = creationDate;
        ModifiedUser = creationUser;
        ModifiedDate = creationDate;
    }
    public void SetModifiedValues(string modifiedUser, DateTime modifiedDate)
    {
        ModifiedUser = modifiedUser;
        ModifiedDate = modifiedDate;
    }

    public void CloseActionPlan(string modifiedUser, DateTime modifiedDate)
    {
        ActionStatus = 1;
        ClosureDate = modifiedDate;
        ClosureUser = modifiedUser;
    }

}