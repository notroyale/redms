﻿using RAMS.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain
{
    public class ObservationBinaryFields : IEntity<int>, Entity<ObservationBinaryFields>
    {
        public int Id { get; init; }
        public int ObservationID { get; private set; }
        public bool IsSelfRaised { get; private set; }
        public string? IsSelfRaisedJustification { get; private set; }
        public bool RelatedToESG { get; private set; }
        public string? ESGJustification { get; private set; }
        public bool RelatedToConductRisk { get; private set; }
        public string? ConductRiskJustification { get; private set; }
        public string ModifiedBy { get; set; }
        public Observation Observation { get; set; }

        public ObservationBinaryFields(int observationID, bool isSelfRaised, string? isSelfRaisedJustification, bool relatedToESG, string? eSGJustification, bool relatedToConductRisk, string? conductRiskJustification, string modifiedBy)
        {
            ObservationID = observationID;
            IsSelfRaised = isSelfRaised;
            IsSelfRaisedJustification = isSelfRaisedJustification;
            RelatedToESG = relatedToESG;
            ESGJustification = eSGJustification;
            RelatedToConductRisk = relatedToConductRisk;
            ConductRiskJustification = conductRiskJustification;
            ModifiedBy = modifiedBy;
        }

        public ObservationBinaryFields()
        {
            IsSelfRaised = false;
            RelatedToESG = false;
            RelatedToConductRisk = false;
            ConductRiskJustification = string.Empty;
            IsSelfRaisedJustification = string.Empty;
            ESGJustification = string.Empty;
            ModifiedBy = "SYSTEM";
        }

        public void Update(ObservationBinaryFields entity)
        {
            IsSelfRaised = entity.IsSelfRaised;
            IsSelfRaisedJustification = entity.IsSelfRaisedJustification;
            RelatedToESG = entity.RelatedToESG;
            ESGJustification = entity.ESGJustification;
            RelatedToConductRisk = entity.RelatedToConductRisk;
            ConductRiskJustification = entity.ConductRiskJustification;
            ModifiedBy = entity.ModifiedBy;
        }

        public void UpdateConductRisk(bool relatedToConductRisk, string conductRiskJustification, string modifiedBy)
        {
            RelatedToConductRisk = relatedToConductRisk;
            ConductRiskJustification = conductRiskJustification;
            ModifiedBy = modifiedBy;

        }

        public void UpdateESG(bool relatedToESG, string eSGJustification, string modifiedBy)
        {
            RelatedToESG = relatedToESG;
            ESGJustification = eSGJustification;
            ModifiedBy = modifiedBy;

        }

        public void UpdateSelfRaised(bool isSelfRaised, string isSelfRaisedJustification, string modifiedBy)
        {
            IsSelfRaised = isSelfRaised;
            IsSelfRaisedJustification = isSelfRaisedJustification;
            ModifiedBy = modifiedBy;

        }
    }
}
