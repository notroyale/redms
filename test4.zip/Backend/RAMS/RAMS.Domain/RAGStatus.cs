﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class RAGStatus : IEntity<int>, Entity<RAGStatus>
{
    public int Id { get; init; }
    public string Name { get; set; }
    public string Color { get; set; }
    public bool IsActive { get; set; }
    public IReadOnlyCollection<Observation> Observations { get; set; }


    public void Update(RAGStatus entity)
    {
        Name = entity.Name;
        Color = entity.Color;
        IsActive = entity.IsActive;
    }
}