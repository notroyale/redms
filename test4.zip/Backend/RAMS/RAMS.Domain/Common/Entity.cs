﻿namespace RAMS.Domain.Common;

public interface Entity<TEntity>
{
    void Update(TEntity entity);
}