﻿namespace RAMS.Domain.Common;

public record MultipleSearchOptions(int[] Ids, string? SortColumn, string? SortOrder, int Page, int PageSize);