﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain.Common
{
    public interface IAuditableEntity
    {
        //public DateTime PeriodStart { get; set; }
        //public DateTime PeriodEnd { get; set; }
        int Id { get; init; }
    }
}
