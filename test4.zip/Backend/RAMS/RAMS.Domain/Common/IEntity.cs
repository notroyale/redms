﻿namespace RAMS.Domain.Common;

public interface IEntity<TId>
{
    TId Id { get; init; }
    /*Guid Uid { get; init; }*/
    /*string Name { get; set; }*/
}