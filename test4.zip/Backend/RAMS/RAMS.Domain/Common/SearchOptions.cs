﻿using RAMS.Domain.Enumerators;

namespace RAMS.Domain.Common;

public record SearchOptions(
    string? SearchTerm, 
    string? SortColumn,
    SortOrder? SortOrder, 
    int Page, 
    int PageSize, 
    int[]? StatusIDs, 
    int[]? BusinessUnitIDs, 
    int[]? BusinessAreaIDs, 
    int[]? LegalEntityIDs, 
    int[]? CategoryIDs, 
    int[]? Countries, 
    int[]? TaxonomyLevel1IDs,
    int[]? TaxonomyLevel2IDs,
    int[]? TaxonomyLevel3IDs,
    int[]? GradeIDs);