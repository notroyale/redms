﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class ObservationAffectedLegalEntities : Entity<ObservationAffectedLegalEntities>
{
    public int Id { get; init; }
    public int ObservationID { get;  set; }
    public int LegalEntityID { get;  set; }
    public string ModifiedBy { get; set; }

    public Observation Observation { get; set; }

    public ObservationAffectedLegalEntities(int observationID, int legalEntityID, string modifiedBy)
    {
        ObservationID = observationID;
        LegalEntityID = legalEntityID;
        ModifiedBy = modifiedBy;
    }

    public void Update(ObservationAffectedLegalEntities entity)
    {
        ObservationID = entity.ObservationID;
        LegalEntityID = entity.LegalEntityID;
    }
    public ObservationAffectedLegalEntities()
    {

    }

}