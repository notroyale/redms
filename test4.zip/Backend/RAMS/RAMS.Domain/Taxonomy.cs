﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class Taxonomy : IEntity<int>, Entity<Taxonomy>
{
    public int Id { get; init; }
    public string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; }
    public int LevelID { get; set; }
    public TaxonomyLevel Level { get; set; }
    public IEnumerable<Taxonomy> Parents { get; set; }
    public IEnumerable<Taxonomy> Children { get; set; }
    public IReadOnlyCollection<ObservationTaxonomy> Observations { get; set; }

    public void Update(Taxonomy entity)
    {
        Name = entity.Name;
        Description = entity.Description;
        IsActive = entity.IsActive;
        LevelID = entity.LevelID;
    }

    public bool HasChild(int id)
    {
        if (Children is null)
        {
            return false;
        }

        return Children.Any(x => x.Id == id);
    }
}