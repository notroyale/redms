﻿namespace RAMS.Domain;

public class BusinessUnitBusinessArea
{
    public int BusinessAreaID { get; set; }
    public int BusinessUnitID { get; set; }
    public bool IsActive { get; set; }

    public BusinessUnitBusinessArea(int businessAreaID, int businessUnitID, bool isActive)
    {
        BusinessAreaID = businessAreaID;
        BusinessUnitID = businessUnitID;
        IsActive = isActive;
    }
}