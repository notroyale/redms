﻿namespace RAMS.Domain;

public class ObservationComment
{
    public int Id { get; init; }
    public string Comment { get; init; }
    public int LineId { get; init; }
    public DateTime Date { get; init; }
    public string User { get; init; }

    public ObservationComment(int id, string comment, int lineId, DateTime date, string user)
    {
        Id = id;
        Comment = comment;
        LineId = lineId;
        Date = date;
        User = user;
    }
}