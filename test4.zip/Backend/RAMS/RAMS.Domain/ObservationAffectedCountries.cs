﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class ObservationAffectedCountries : Entity<ObservationAffectedCountries>
{
    public int Id { get; init; }
    public int ObservationID { get; private set; }
    public int CountryID { get; private set; }
    public string ModifiedBy { get; set; }

    public Observation Observation { get; set; }

    public ObservationAffectedCountries(int observationID, int countryID, string modifiedBy)
    {
        ObservationID = observationID;
        CountryID = countryID;
        ModifiedBy = modifiedBy;
    }

    public void Update(ObservationAffectedCountries entity)
    {
        ObservationID = entity.ObservationID;
        CountryID = entity.CountryID;
    }
    public ObservationAffectedCountries()
    {

    }

}