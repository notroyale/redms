﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class ObservationTaxonomy : Entity<ObservationTaxonomy>
{
    public int ObservationID { get; set; }
    public int TaxonomyID { get; set; }
    public string ModifiedBy { get; set; }

    public Observation Observation { get; set; }
    public Taxonomy Taxonomy { get; set; }

    public void Update(ObservationTaxonomy entity)
    {
        ObservationID = entity.ObservationID;
        TaxonomyID = entity.TaxonomyID;
    }
}