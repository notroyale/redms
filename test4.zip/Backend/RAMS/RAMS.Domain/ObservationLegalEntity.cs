﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class ObservationLegalEntity : Entity<ObservationLegalEntity>
{
    public int ObservationID { get; private set; }
    public int LegalEntityID { get; private set; }
    public string ModifiedBy { get; set; }
    public Observation Observation { get; private set; }
    public LegalEntity LegalEntity { get; private set; }

    public ObservationLegalEntity(int observationID, int legalEntityID, string modifiedBy)
    {
        ObservationID = observationID;
        LegalEntityID = legalEntityID;
        ModifiedBy = modifiedBy;
    }

    public void Update(ObservationLegalEntity entity)
    {
        ObservationID = entity.ObservationID;
        LegalEntityID = entity.LegalEntityID;
    }

    public ObservationLegalEntity()
    {
       
    }
}