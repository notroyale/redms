﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class RegulatoryCategory : IEntity<int>, Entity<RegulatoryCategory>
{
    public int Id { get; init; }
    public string Name { get; set; }
    public int? TaxonomyLevel3ID { get; set; }
    public bool IsActive { get; set; }
    public string? AppliedRegulation { get; set; }
    public IReadOnlyList<ObservationRegCategories> Observations { get; set; }

    public RegulatoryCategory()
    {
    }

    public void Update(RegulatoryCategory entity)
    {
        Name = entity.Name;
        TaxonomyLevel3ID = entity.TaxonomyLevel3ID;
        IsActive = entity.IsActive;
        AppliedRegulation = entity.AppliedRegulation;
    }
}