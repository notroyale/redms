﻿using RAMS.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain
{
    public class FieldHelpText: IEntity<int>, Entity<FieldHelpText>
    {
        public int Id { get; init; }
        public string FieldName { get; set; }
        public string? HelpTextValue { get; set; }
        public string? ForNames { get; set; }

        public void Update(FieldHelpText entity)
        {
            FieldName = entity.FieldName;
            HelpTextValue = entity.HelpTextValue;
            ForNames = entity.ForNames;
        }
    }
}
