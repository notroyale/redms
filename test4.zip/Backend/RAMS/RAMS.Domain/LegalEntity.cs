﻿using RAMS.Domain.Common;

namespace RAMS.Domain;
public class LegalEntity : IEntity<int>, Entity<LegalEntity>
{
    public int Id { get; init; }
    public string Name { get; set; }
    public bool IsActive { get; set; }
    public IEnumerable<BusinessUnit> BusinessUnits { get; set; }
    public IEnumerable<ObservationLegalEntity> Observations { get; set; }
    public IEnumerable<Authorisation> Authorisations { get; set; }

    public LegalEntity(int id, string name)
    {
        Id = id;
        Name = name;
    }

    public LegalEntity()
    {
    }

    public void Update(LegalEntity entity)
    {
        Name = entity.Name;
        IsActive = entity.IsActive;
    }
}