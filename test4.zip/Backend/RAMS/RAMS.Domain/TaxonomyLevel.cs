﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class TaxonomyLevel : IEntity<int>, Entity<TaxonomyLevel>
{
    public int Id { get; init; }
    public int Level { get; set; }
    public string Name { get; set; }
    public bool IsActive { get; set; }
    public bool IsMandatory { get; set; }
    public IReadOnlyCollection<Taxonomy> Taxonomies { get; set; }

    public TaxonomyLevel()
    {
    }

    public void Update(TaxonomyLevel entity)
    {
        Level = entity.Level;
        Name = entity.Name;
        IsActive = entity.IsActive;
        IsMandatory = entity.IsMandatory;
    }
}