﻿using RAMS.Domain.Common;

namespace RAMS.Domain;
public class News : IEntity<int>, Entity<News>
{
    public int Id { get; init; }
    public string Title { get; set; }
    public string Description { get; set; }
    public string ShortDescription { get; set; }
    public DateTime Date { get; set; }
    public string Author { get; set; }

    public News(int id, string title, string description, string shortDescription, string author)
    {
        Id = id;
        Title = title;
        Description = description;
        ShortDescription = shortDescription;
        Author = author;
    }

    public News()
    {
    }

    public void Update(News entity)
    {
        Title = entity.Title;
        Description = entity.Description;
        ShortDescription = entity.ShortDescription;
    }
}