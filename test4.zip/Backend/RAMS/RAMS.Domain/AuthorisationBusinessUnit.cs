﻿namespace RAMS.Domain;

public class AuthorisationBusinessUnit
{
    public int AuthorisationID { get; set; }
    public int BusinessUnitID { get; set; }
    public bool IsActive { get; set; }
}