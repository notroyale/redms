﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class Country : IEntity<int>, Entity<Country>
{
    public int Id { get; init; }
    public string Name { get; set; }
    public bool IsActive { get; set; }
    public IReadOnlyList<Observation> Observations { get; set; }

    public void Update(Country entity)
    {
        Name = entity.Name;
        IsActive = entity.IsActive;
    }
}