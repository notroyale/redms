﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class ObservationAffectedBusinessUnits : Entity<ObservationAffectedBusinessUnits>
{
    public int Id { get; init; }
    public int ObservationID { get; private set; }
    public int BusinessUnitID { get; private set; }
    public string ModifiedBy { get; set; }

    public Observation Observation { get; set; }

    public ObservationAffectedBusinessUnits(int observationID, int businessUnitID, string modifiedBy)
    {
        ObservationID = observationID;
        BusinessUnitID = businessUnitID;
        ModifiedBy = modifiedBy;
    }

    public void Update(ObservationAffectedBusinessUnits entity)
    {
        ObservationID = entity.ObservationID;
        BusinessUnitID = entity.BusinessUnitID;
    }
    public ObservationAffectedBusinessUnits()
    {

    }
}