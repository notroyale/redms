﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class Regulation : IEntity<int>, Entity<Regulation>
{
    public int Id { get; init; }
    public string Name { get; set; }
    public bool IsActive { get; set; }
    public bool HasComment { get; set; }
    public IReadOnlyList<ObservationRegulation> Observations { get; set; }

    public void Update(Regulation entity)
    {
        Name = entity.Name;
        IsActive = entity.IsActive;
        HasComment = entity.HasComment;
    }
}