﻿namespace RAMS.Domain;

public class AuthorisationLegalEntity
{
    public int AuthorisationID { get; set; }
    public int LegalEntityID { get; set; }
    public bool IsActive { get; set; }
}