﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class StatusRequest : IEntity<int>, Entity<StatusRequest>
{
    public int Id { get; init; }
    public string Name { get; set; }
    public string TemplateName { get; set; }
    public string TemplateLocation { get; set; }
    public bool IsActive { get; set; }

    public void Update(StatusRequest entity)
    {
        Name = entity.Name;
        TemplateName = entity.TemplateName;
        TemplateLocation = entity.TemplateLocation;
        IsActive = entity.IsActive;
    }
}