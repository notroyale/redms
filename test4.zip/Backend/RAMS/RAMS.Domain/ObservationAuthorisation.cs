﻿using RAMS.Domain.User;

namespace RAMS.Domain;

public record ObservationAuthorisation
{
    public Observation Observation { get; init; }
    public IEnumerable<FieldHelpText>? HelpText { get; init; }
    public bool AdminAccess { get; init; }
    public bool ApproverAccess { get; init; }
    public bool CommentAccess { get; init; }
    public bool EditAccess { get; init; }
    public bool ViewAccess { get; init; }

    protected ObservationAuthorisation(Observation observation, bool adminAccess, bool approverAccess, bool commentAccess, bool editAccess, bool viewAccess, IEnumerable<FieldHelpText> helpText)
    {
        Observation = observation;
        AdminAccess = adminAccess;
        ApproverAccess = approverAccess;
        CommentAccess = commentAccess;
        EditAccess = editAccess;
        ViewAccess = viewAccess;
        HelpText = helpText;
    }

    public static ObservationAuthorisation Create(Observation observation, AccessControl accessControl, IEnumerable<FieldHelpText> helpText)
    {
        bool hasNoLegalEntities = observation.LegalEntities is null || observation.LegalEntities.Count == 0;

        bool hasAuthorizedBusinessUnit = accessControl.AuthorisedBusinessUnits.ContainsKey(observation.BusinessUnitId);

        bool HasAdminAccess = hasAuthorizedBusinessUnit && accessControl.AuthorisedBusinessUnits[observation.BusinessUnitId].HasAdminAccess && hasNoLegalEntities;
        bool HasApproverAccess = hasAuthorizedBusinessUnit && accessControl.AuthorisedBusinessUnits[observation.BusinessUnitId].HasApproverAccess && hasNoLegalEntities;
        bool HasCommentAccess = hasAuthorizedBusinessUnit && accessControl.AuthorisedBusinessUnits[observation.BusinessUnitId].HasCommentAccess && hasNoLegalEntities;
        bool HasEditAccess = hasAuthorizedBusinessUnit && accessControl.AuthorisedBusinessUnits[observation.BusinessUnitId].HasEditAccess && hasNoLegalEntities;
        bool HasViewAccess = hasAuthorizedBusinessUnit && accessControl.AuthorisedBusinessUnits[observation.BusinessUnitId].HasViewAccess && hasNoLegalEntities;

        if (!hasAuthorizedBusinessUnit)
        {
            foreach (int legalEntityId in observation.LegalEntities.Select(x => x.LegalEntityID))
            {
                if (!accessControl.AuthorisedLegalEntities.ContainsKey(legalEntityId))
                {
                    continue;
                }

                HasAdminAccess |= accessControl.AuthorisedLegalEntities[legalEntityId].HasAdminAccess;
                HasApproverAccess |= accessControl.AuthorisedLegalEntities[legalEntityId].HasApproverAccess;
                HasCommentAccess |= accessControl.AuthorisedLegalEntities[legalEntityId].HasCommentAccess;
                HasEditAccess |= accessControl.AuthorisedLegalEntities[legalEntityId].HasEditAccess;
                HasViewAccess |= accessControl.AuthorisedLegalEntities[legalEntityId].HasViewAccess;
            }

            return new(observation, HasAdminAccess, HasApproverAccess, HasCommentAccess, HasEditAccess, HasViewAccess, helpText);
        }

        if (hasNoLegalEntities)
        {
            return new(observation, HasAdminAccess, HasApproverAccess, HasCommentAccess, HasEditAccess, HasViewAccess, helpText);
        }

        foreach (int legalEntityId in observation.LegalEntities.Select(x => x.LegalEntityID))
        {
            HasAdminAccess |= accessControl.AuthorisedBusinessUnits[observation.BusinessUnitId].HasAdminAccess && accessControl.AuthorisedLegalEntities[legalEntityId].HasAdminAccess;
            HasApproverAccess |= accessControl.AuthorisedBusinessUnits[observation.BusinessUnitId].HasApproverAccess && accessControl.AuthorisedLegalEntities[legalEntityId].HasApproverAccess;
            HasCommentAccess |= accessControl.AuthorisedBusinessUnits[observation.BusinessUnitId].HasCommentAccess && accessControl.AuthorisedLegalEntities[legalEntityId].HasCommentAccess;
            HasEditAccess |= accessControl.AuthorisedBusinessUnits[observation.BusinessUnitId].HasEditAccess && accessControl.AuthorisedLegalEntities[legalEntityId].HasEditAccess;
            HasViewAccess |= accessControl.AuthorisedBusinessUnits[observation.BusinessUnitId].HasViewAccess && accessControl.AuthorisedLegalEntities[legalEntityId].HasViewAccess;
        }

        return new(observation, HasAdminAccess, HasApproverAccess, HasCommentAccess, HasEditAccess, HasViewAccess, helpText);
    }
    public static ObservationAuthorisation Create(Observation observation)
    {
          return new(observation, false, false, false, true, false, null);
    }

}