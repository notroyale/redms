﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class Authorisation : IEntity<int>
{
    public int Id { get; init; }
    public string Name { get; set; } 
    public bool IsActive { get; set; } 
    public string ShortName { get; set; }
    public string Description { get; set; }
    public AuthorisationAccessPermission AccessPermission { get; set; }
    public IEnumerable<BusinessUnit> BusinessUnits { get; set; }
    public IEnumerable<LegalEntity> LegalEntities { get; set; }
    public IEnumerable<Roles> Role { get; set; }
}