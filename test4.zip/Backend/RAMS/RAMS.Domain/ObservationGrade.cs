﻿using RAMS.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain
{
    public class ObservationGrade : IEntity<int>, Entity<ObservationGrade>
    {
        public int Id { get; init; }
        public int ObservationID { get; set; }
        public int GradeID { get; set; }
        public string ModifiedBy { get; set; }
        public Observation Observation { get; set; }

        public ObservationGrade(int gradeId, int observationID, string modifiedBy)
        {
            GradeID = gradeId;
            ObservationID = observationID;
            ModifiedBy = modifiedBy;
        }
        public ObservationGrade()
        {
            
        }
        public void Update(ObservationGrade entity)
        {
            ObservationID = entity.ObservationID;
            GradeID = entity.GradeID;
            ModifiedBy = entity.ModifiedBy;
        }
        public void Update(int observationID, int gradeID, string modifiedBy)
        {
            ObservationID = observationID;
            GradeID = gradeID;
            ModifiedBy = modifiedBy;
        }
    }
}
