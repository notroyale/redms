﻿using RAMS.Domain.Common;

namespace RAMS.Domain
{
    public class ObservationSelfRaisedIssue : IEntity<int>, Entity<ObservationSelfRaisedIssue>
    {
        public int Id { get; init; }
        public int ObservationID { get; private set; }
        public bool IsSelfRaised { get; private set; }
        public string? Justification { get; private set; }
        public string ModifiedBy { get; set; }
        public Observation Observation { get; set; }

        public ObservationSelfRaisedIssue(int observationID, bool isSelfRaised, string? justification, string modifiedBy)
        {
            ObservationID = observationID;
            IsSelfRaised = isSelfRaised;
            Justification = justification;
            ModifiedBy = modifiedBy;
        }

        public ObservationSelfRaisedIssue()
        {
            IsSelfRaised = false;
            Justification = string.Empty;
        }

        public void Update(ObservationSelfRaisedIssue entity)
        {
            IsSelfRaised = entity.IsSelfRaised;
            Justification = entity.Justification;
        }

        public void Update(bool selfRaised, string? justification)
        {
            IsSelfRaised = selfRaised;
            Justification = justification;
        }
        public void Insert(bool selfRaised, string? justification)
        {
            new ObservationSelfRaisedIssue()
            {
                ObservationID = ObservationID,
                IsSelfRaised = selfRaised,
                Justification = justification,
                ModifiedBy = ModifiedBy,

            };
        }
    }
}
