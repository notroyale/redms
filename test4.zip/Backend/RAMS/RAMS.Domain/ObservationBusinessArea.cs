﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class ObservationBusinessArea :  Entity<ObservationBusinessArea>
{
    public int? ID { get; set; }
    public int ObservationID { get; set; }
    public int BusinessAreaID { get; set; }
    public int CountryID { get; set; }
    public string? ModifiedBy { get; set; }
    public Observation Observation { get; private set; }
    public BusinessArea BusinessArea { get; set; }
    public Country Country { get; set; }

    public ObservationBusinessArea(int id,int observationID, int businessAreaID, int countryID)
    {
        ID = id;
        ObservationID = observationID;
        BusinessAreaID = businessAreaID;
        CountryID = countryID;
    }

    public ObservationBusinessArea(int observationID, int businessAreaID, int countryID)
    {
        ObservationID = observationID;
        BusinessAreaID = businessAreaID;
        CountryID = countryID;
    }

    public ObservationBusinessArea()
    {
        
    }

    public void Update(ObservationBusinessArea entity)
    {
        ObservationID = entity.ObservationID;
        BusinessAreaID = entity.BusinessAreaID;
        CountryID = entity.CountryID;
    }
    public void Insert(ObservationBusinessArea entity)
    {
        ObservationID = entity.ObservationID;
        BusinessAreaID = entity.BusinessAreaID;
        CountryID = entity.CountryID;
        ModifiedBy = entity.ModifiedBy;

    }

    public void UpdateBusinessArea(BusinessArea businessArea)
    {
        BusinessArea = businessArea;
    }

    public void UpdateCountry(Country country)
    {
        Country = country;
    }
}