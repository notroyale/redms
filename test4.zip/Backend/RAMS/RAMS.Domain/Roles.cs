﻿using RAMS.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain
{
    public class Roles : IEntity<int>, Entity<Roles>
    {
        public int Id { get; init; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
        public IEnumerable<Authorisation> Authorisations { get; set; }

        public void Update(Roles entity)
        {
            Name = entity.Name;
            Description = entity.Description;
            IsActive = entity.IsActive; 
        }
    }
}
