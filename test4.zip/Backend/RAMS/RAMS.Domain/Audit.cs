﻿using RAMS.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace RAMS.Domain
{
    public class Audit : Entity<Audit>
    {
        public int LogID { get; set; }
        public int ObservationID { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string Action { get; set; }
        public string Field { get; set; }
        public string? OldValue { get; set; }
        public string? NewValue { get; set; }

        public Audit(int observationID, string modifiedUser, DateTime modifiedDate, string action, string field, string oldValue, string newValue)
        {
            ObservationID = observationID;
            ModifiedUser = modifiedUser;
            ModifiedDate = modifiedDate;
            Action= action; 
            Field = field;
            OldValue = oldValue;
            NewValue = newValue;
        }

        public void Update(Audit entity)
        {
            ObservationID = entity.ObservationID;
            ModifiedUser = entity.ModifiedUser;
            ModifiedDate = entity.ModifiedDate;
            Action = entity.Action;
            Field = entity.Field;
            OldValue = entity.OldValue;
            NewValue = entity.NewValue;
        }
    }
}
