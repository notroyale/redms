﻿
namespace RAMS.Domain
{
    public class AttachmentMetadata
    {
       public int ObservationID { get; set; }
       public string UploaderRole { get; set; }
       public bool Gdpr { get; set; }
    }
}
