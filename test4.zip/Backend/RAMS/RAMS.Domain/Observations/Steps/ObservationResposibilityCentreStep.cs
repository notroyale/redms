﻿namespace RAMS.Domain.Observations.Steps;

public class ObservationResposibilityCentreStep
{
    public string ActivityOwner { get; init; }
    public string Assignee { get; init; }
    public string RiskOwner { get; init; }
    public int BusinessUnitID { get; set; }
    public IEnumerable<int> LegalEntities { get; init; }

    public ObservationResposibilityCentreStep( string activityOwner, string assignee, string riskOwner, int businessUnitID, IEnumerable<int> legalEntities)
    {
        ActivityOwner = activityOwner;
        Assignee = assignee;
        RiskOwner = riskOwner;
        BusinessUnitID = businessUnitID;
        LegalEntities = legalEntities;
    }

    public ObservationResposibilityCentreStep()
    {
        ActivityOwner = string.Empty;
        Assignee = string.Empty;
        RiskOwner = string.Empty;
        BusinessUnitID = new();
        LegalEntities = new List<int>();
    }
}