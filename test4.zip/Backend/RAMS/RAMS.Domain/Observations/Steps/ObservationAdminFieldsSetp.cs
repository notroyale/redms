﻿namespace RAMS.Domain.Observations.Steps;

public class ObservationClosureFieldsStep
{
    public int StatusID { get; set; }
    public DateTime? CancellationDate {  get; set; }
    public DateTime? RiskAcceptanceDate { get; set; }
    public DateTime? DeadlineExtentionRegistrationDate { get; set; }
    public string? CancellationJustification { get; set; }
    public string? ClosureJustification { get; set; }

    public ObservationClosureFieldsStep(int statusID, DateTime? cancellationDate, DateTime? riskAcceptanceDate, DateTime? deadlineExtentionRegistrationDate, string? cancellationJustification, string? closureJustification)
    {
        StatusID = statusID;
        CancellationDate = cancellationDate;
        RiskAcceptanceDate = riskAcceptanceDate;
        DeadlineExtentionRegistrationDate = deadlineExtentionRegistrationDate;
        CancellationJustification = cancellationJustification;
        ClosureJustification = closureJustification;
    }

    public ObservationClosureFieldsStep()
    {
    }
}