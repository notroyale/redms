﻿namespace RAMS.Domain.Observations.Steps;

public class ObservationAffectedFieldsStep
{
    public IEnumerable<int> AffectedBusinessUnits { get; init; }
    public IEnumerable<int> AffectedBusinessAreas { get; init; }
    public IEnumerable<int> AffectedLegalEntities { get; init; }
    public IEnumerable<int> AffectedCountries { get; init; }

    public ObservationAffectedFieldsStep() { }

    public ObservationAffectedFieldsStep(
        IEnumerable<int> affectedBusinessUnits, 
        IEnumerable<int> affectedBusinessAreas, 
        IEnumerable<int> affectedLegalEntities, 
        IEnumerable<int> affectedCountries)
    {
        AffectedBusinessUnits = affectedBusinessUnits;
        AffectedBusinessAreas = affectedBusinessAreas;
        AffectedLegalEntities = affectedLegalEntities;
        AffectedCountries = affectedCountries;
    }
}