﻿namespace RAMS.Domain.Observations.Steps;

public class ObservationDetailsStep 
{
    public string Title { get; set; }
    public string Summary { get; set; }
    public int GradeID { get; set; }
    public int CategoryId { get; set; }
    public DateTime Deadline { get; set; }
    public DateTime? DateIdentified { get; set; }
    public DateTime? RevisedDeadline { get; set; }
    public bool IsSelfRaised { get; set; }
    public string? SelfRaisedJustification { get; set; }
    public string? ObservationCategoryExplanation { get; set; }

    public ObservationDetailsStep( string title, string? summary, int gradeID, int categoryId, DateTime deadline, DateTime? dateIdentified, DateTime? revisedDeadline, bool selfRaised, string? selfRaisedJustification, string? observationCategoryExplanation)
    {
        Title = title;
        Summary = summary;
        GradeID = gradeID;
        CategoryId = categoryId;
        Deadline = deadline;
        DateIdentified = dateIdentified;
        RevisedDeadline = revisedDeadline;
        IsSelfRaised = selfRaised;
        SelfRaisedJustification = selfRaisedJustification;
        ObservationCategoryExplanation = observationCategoryExplanation;
    }

    public ObservationDetailsStep()
    {
        Title = string.Empty;
        Summary = string.Empty;
    }
}