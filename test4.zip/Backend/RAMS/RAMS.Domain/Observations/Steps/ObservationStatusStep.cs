﻿using RAMS.Domain.Enumerators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain.Observations.Steps
{
    public class ObservationStatusStep
    {
        public int Status {  get; set; }   
        public DateTime? CancellationDate {  get; set; }
        public string? CancellationJustification { get; set; }
        public DateTime? ClosureDate { get; set; }
        public string? ClosureJustification { get; set; }
        public DateTime? DeadlineExtensionRegistrationDate { get; set; }
        public string? DeadlineExtensionJustification { get; set; }
        public DateTime? RiskAcceptanceDate { get; set; }
        public string? RiskAcceptanceJustification { get; set; }


        public ObservationStatusStep(int status, DateTime? cancellationDate, string? cancellationJustification, DateTime? closureDate, string? closureJustification, DateTime? deadlineExtention, string? deadlineJustification, DateTime? riskAcceptance, string? riskAcceptenceJustification)
        {
            Status = status;
            CancellationDate = cancellationDate;
            CancellationJustification = cancellationJustification;
            ClosureDate = closureDate;
            ClosureJustification = closureJustification;
            DeadlineExtensionRegistrationDate = deadlineExtention;
            DeadlineExtensionJustification = deadlineJustification;
            RiskAcceptanceDate = riskAcceptance;
            RiskAcceptanceJustification = riskAcceptenceJustification;
        }

        public ObservationStatusStep()
        {
        }
    }
}
