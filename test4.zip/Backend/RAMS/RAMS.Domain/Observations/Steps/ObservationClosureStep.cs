﻿using RAMS.Domain.Enumerators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain.Observations.Steps
{
    public class ObservationClosureStep
    {
        public string ClosureJustification { get; set; }
        public int Status { get; set; }



        public ObservationClosureStep(string closureJustification)
        {
            ClosureJustification = closureJustification;
            Status = (int)ObservationStatus.Closed;
        }

        public ObservationClosureStep()
        {
            Status = (int)ObservationStatus.Open;
        }
    }
}
