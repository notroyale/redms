﻿namespace RAMS.Domain.Observations.Steps;

public class ObservationRiskCategorizationStep
{
    public string? Directive { get; set; }
    public string? BusinessLine { get; set; }
    public int TaxLevel1 { get; set; }
    public ICollection<int> TaxLevel2 { get; set; }
    public ICollection<int> TaxLevel3 { get; set; }
    public bool ConductRisk { get; set; }
    public bool EsgRisk { get; set; }
    public string? ConductJustification {  get; set; }
    public string? EsgJustification {  get; set; }
    public ICollection<int> Regulations { get; set; }
    public ICollection<int> RegCategories { get; set; }
    public string? RegulationComment { get; set; }


    public ObservationRiskCategorizationStep(string? directive, string? businessLine, int taxLevel1, ICollection<int> taxLevel2, ICollection<int> taxLevel3, bool conductRisk, bool esgRisk, string? conductJustification,
        string? esgJustification, ICollection<int> regulations, ICollection<int> regCategories, string? regulationComment)
    {
        Directive = directive;
        BusinessLine = businessLine;
        TaxLevel1 = taxLevel1;
        TaxLevel2 = taxLevel2;
        TaxLevel3 = taxLevel3;
        ConductRisk = conductRisk;
        EsgRisk = esgRisk;
        ConductJustification = conductJustification;
        EsgJustification = esgJustification;
        Regulations = regulations;
        RegCategories = regCategories;
        RegulationComment = regulationComment;
    }

    public ObservationRiskCategorizationStep()
    {
    }

    public bool HasValidTax1()
    {
        return TaxLevel1 != 0;
    }

    public bool HasTaxonomy(int taxId)
    {
        return HasTaxLevel1(taxId) || HasTaxLevel2(taxId) || HasTaxLevel3(taxId);
    }
    
    public bool HasRegulation(int regId)
    {
        return Regulations.Any(x => x == regId);
    }
    
    public bool HasRegCategories(int regId)
    {
        return RegCategories.Any(x => x == regId);
    }

    private bool HasTaxLevel1(int taxId)
    {
        return TaxLevel1 != taxId;
    }

    private bool HasTaxLevel2(int taxId)
    {
        return TaxLevel2.Any(x => x == taxId);
    }

    private bool HasTaxLevel3(int taxId)
    {
        return TaxLevel3.Any(x => x == taxId);
    }
}