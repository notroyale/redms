﻿namespace RAMS.Domain.Observations.Steps;

public class ObservationCollaborationFieldsStep
{
    public string? Comment1LoD { get; set; }
    public string? Comment { get; set; }
    public int RagStatusID { get; set; }
    public string? RagJustification { get; set; }
    public bool ClosureSubmitted { get; set; }

    public ObservationCollaborationFieldsStep(string? comment1LoD, string? comment, int ragStatusID, string? ragJustification, bool closureSubmitted)
    {
        Comment1LoD = comment1LoD;
        Comment = comment;
        RagStatusID = ragStatusID;
        RagJustification = ragJustification;
        ClosureSubmitted = closureSubmitted;
    }

    public ObservationCollaborationFieldsStep()
    {
    }
}