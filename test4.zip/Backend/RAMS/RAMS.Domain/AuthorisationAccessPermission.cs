﻿namespace RAMS.Domain;

public class AuthorisationAccessPermission 
{
    public bool ViewAccess { get; set; }
    public bool EditAccess { get; set; }
    public bool CommentAccess { get; set; }
    public int AuthorisationID { get; set; }
    public bool ApproverAccess { get; set; }
    public bool AdminAccess { get; set; }
    public Authorisation Authorisation { get; set; }

}