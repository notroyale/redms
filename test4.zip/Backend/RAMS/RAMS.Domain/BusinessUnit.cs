﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class BusinessUnit : IEntity<int>, Entity<BusinessUnit>
{
    public int Id { get; init; }
    public string Code { get; set; }
    public string Name { get; set; }
    public bool IsActive { get; set; }

    public IEnumerable<Observation> Observations { get; set; }
    public IEnumerable<BusinessArea> BusinessAreas { get; set; }
    public IEnumerable<LegalEntity> LegalEntities { get; set; }
    public IEnumerable<Authorisation> Authorisations { get; set; }

    public BusinessUnit(int id, string code, string name, bool active)
    {
        Id = id;
        Code = code;
        Name = name;
        IsActive = active;
    }

    public BusinessUnit()
    {
    }

    public void Update(BusinessUnit entity)
    {
        Name = entity.Name;
        Code = entity.Code;
        IsActive = entity.IsActive;
    }
}