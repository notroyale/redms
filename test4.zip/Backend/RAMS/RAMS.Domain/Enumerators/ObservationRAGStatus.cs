﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain.Enumerators
{
    public enum ObservationRAGStatus 
    {
        OnTrack = 1,
        AtRisk,
        OffTrack,
        OnHold,
        NotSpecified
    }
}
