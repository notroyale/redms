﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain.Enumerators
{
    public enum AuthRoles
    {
        Admin = 1,
        Approver,
        SQLViewer,
        ViewEdit,
        ViewComments,
        ViewOnly,
        ViewOnlyTableau
    }
}
