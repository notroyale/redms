﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain.Enumerators
{
    public enum SortOrder
    {
        Asc = 1, 
        Desc = 2,
        None = 0
    }
}
