﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain.Enumerators
{
    public enum BusinessUnits
    {
        GroupWide=9,
        GroupRiskManagement=11,
        GroupInternalAudit=12,
    }
}
