﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAMS.Domain.Enumerators
{
    public enum ObservationStatus
    {
        Closed = 1,
        Open,
        Cancelled,
        RiskAccepted,
        DeadlineExt
    }
}
