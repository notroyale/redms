﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace RAMS.Domain.Enumerators
{
    public enum AuditAction
    {
        Insert,
        Delete,
        Update,
        View,
        Download, 
        Upload
    }
}
