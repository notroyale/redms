﻿using RAMS.Domain.Common;

namespace RAMS.Domain;

public class ObservationRegulation : Entity<ObservationRegulation>
{
    public int ObservationID { get;  set; }
    public int RegulationID { get;  set; }
    public string? RegulationComment { get; set; }

    public string ModifiedBy { get; set; }
    public Regulation Regulation { get;  set; }
    public Observation Observation { get;  set; }

    public ObservationRegulation(int observationID, int regulationID)
    {
        ObservationID = observationID;
        RegulationID = regulationID;
    }

    public ObservationRegulation()
    {
    }

    public void Update(ObservationRegulation entity)
    {
        ObservationID = entity.ObservationID;
        RegulationID = entity.RegulationID;
    }
}